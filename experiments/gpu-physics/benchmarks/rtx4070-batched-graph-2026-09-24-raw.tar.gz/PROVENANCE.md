# Diagnostic checkpoint provenance

Each island-fix, batched, and batched256 directory contains a manifest with the copied benchmark executable hash and its source patch. Those snapshots identify the measured implementation. The source fingerprint inside individual raw JSON files is a runtime working-tree observation, not a compile-time fingerprint; it can reflect subsequent edits and must not be used to identify the executable source.

The batched256 runs measure the corrected island union and 256-edge coloring algorithm with explicit scheduling overrides. They precede automatic selection, eager pipeline preparation, and completed-wait status refresh. They are diagnostic before/after measurements, not the final default-engine CPU crossover sweep.

checks/library-nvidia-qualified.log records all 253 library tests passing. Its validation-manifest.json and validated-source.patch identify the later validated implementation including those changes. No 100,000-body or CPU-crossover claim is made by this archive.
