#!/usr/bin/env python3
"""Plot raw-verified solver-schedule diagnostics (requires matplotlib)."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PHASES = ['broadphase', 'narrowphase', 'graph', 'prepare', 'solve']
COLORS = ['#56a7b8', '#83ba68', '#d89442', '#a69acf', '#c55d60']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--title', default='GPU solver scheduling investigation')
    p.add_argument('--note', default='Experimental timings; solver equivalence unresolved.')
    a = p.parse_args()
    manifest = json.loads((a.input / 'manifest.json').read_text())
    rows = json.loads((a.input / 'trials.json').read_text())
    identities = [(r['count'], r['variant'], r['trial']) for r in rows]
    assert len(set(identities)) == len(identities), 'duplicate trial'
    for row in rows:
        path = a.input / f"{row['count']}-{row['variant']}-{row['trial']}.json"
        assert row['returncode'] == 0, 'invalid trial'
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['raw_sha256']
        data = json.loads(path.read_text())
        raw = data['raw_runs'][0]
        assert data['bodies'] == row['count'] + 1 and not data['sleep']
        assert data['sub_steps'] == 4 and raw['live_contacts'] > 0
        for key in ['p50_ms', 'p95_ms']:
            assert row[key] == data['completed_step'][key], 'cached percentile mismatch'
        settings = manifest['source']['arguments']
        assert raw['physics_step'] == settings['warmup'] + settings['timed']
        for name in ['completed_step', *PHASES]:
            values = raw[name + '_ms']
            assert len(values) == settings['timed']
            assert all(math.isfinite(v) and v >= 0 for v in values)
            expected = row['mean_ms'] if name == 'completed_step' else row['phase_mean_ms'][name]
            assert math.isclose(statistics.mean(values), expected, abs_tol=1e-9)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), layout='constrained')
    labels, summary = [], []
    for count in manifest['counts']:
        for variant in manifest['variants']:
            group = [r for r in rows if r['count'] == count and r['variant'] == variant]
            assert len(group) == manifest['trials'], 'incomplete group'
            x = len(labels)
            labels.append(f'{count:,}\n{variant}')
            means = [r['mean_ms'] for r in group]
            mean = statistics.median(means)
            axes[0].bar(x, mean, color={'component': '#426c9c', 'global-colors': '#55a28b',
                                      'batched-global': '#9b70b8'}[variant])
            axes[0].errorbar(x, mean, yerr=[[mean - min(means)], [max(means) - mean]],
                            fmt='none', color='black', capsize=4)
            axes[0].text(x, max(means) + .6, f'{mean:.1f}', ha='center', fontsize=9)
            bottom = 0
            phases = {}
            for name, color in zip(PHASES, COLORS):
                value = statistics.median(r['phase_mean_ms'][name] for r in group)
                phases[name] = value
                axes[1].bar(x, value, bottom=bottom, color=color, label=name if x == 0 else None)
                bottom += value
            summary.append(dict(count=count, variant=variant, mean_ms=mean,
                                min_ms=min(means), max_ms=max(means), phase_mean_ms=phases))
            summary[-1].update(p50_ms=statistics.median(r['p50_ms'] for r in group),
                               p95_ms=statistics.median(r['p95_ms'] for r in group))
    axes[0].set_title('Completed physics step • trial median and range')
    axes[1].set_title('GPU phases • median of per-trial means')
    axes[1].legend(loc='upper left', fontsize=8)
    for ax in axes:
        ax.set_xticks(range(len(labels)), labels, fontsize=9)
        ax.set_ylabel('Milliseconds (lower is better)')
        ax.grid(axis='y', alpha=.15)
        ax.set_axisbelow(True)
    fig.suptitle(a.title)
    fig.supxlabel(f"{manifest['trials']} trials • sleep off • dt 1/60; 4 substeps • "
                  f"{settings['warmup']} warmup + {settings['timed']} timed steps\n"
                  + a.note + ' Phase medians are not an exact total breakdown.', fontsize=9)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.output.with_suffix('.png'), dpi=150)
    fig.savefig(a.output.with_suffix('.svg'))
    svg = a.output.with_suffix('.svg')
    svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines()) + '\n')
    a.output.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
