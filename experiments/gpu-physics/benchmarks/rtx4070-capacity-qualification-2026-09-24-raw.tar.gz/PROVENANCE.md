# Capacity qualification checkpoint

One trial per count, global color solving, sleeping disabled, dt 1/60, four substeps, 90 warmup plus 240 timed steps. These data establish valid collision-heavy execution through 330 steps, not repeatable CPU crossover or renderer FPS. The same executable is used for all five counts. manifest.json records its hash and source.patch records its source against the stated Git commit. Raw JSON source_sha256 is a runtime source-tree observation, not the compiled-source fingerprint.

qualification-all merges non-overlapping counts from qualification and qualification-large; original manifests and raw results are retained. Primary buffer bytes exclude staging, CCD, renderer resources, pipelines and driver overhead. The power/temperature/clock/AC observations are in trials.json before/after each trial; these are sampled conditions, not a continuous power trace.

checks/pair-capacity-library.log proves all 256 native-cache NVIDIA library tests passed. Its corresponding manifest and source patch identify the tested implementation. Scene recordings remain required before a solver commit. Shape-pair IDs are still 16-bit; this checkpoint does not demonstrate 100,000 bodies.
