#!/usr/bin/env python3
"""Build a phase/memory view from completed GPU rows without rerunning physics."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import statistics

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('sweep', type=Path)
p.add_argument('output', type=Path)
p.add_argument('--counts', type=int, nargs='+', required=True)
a = p.parse_args()
manifest = json.loads((a.sweep / 'manifest.json').read_text())
trials = json.loads((a.sweep / 'trials.json').read_text())
rows = []
files = []
for count in a.counts:
    group = sorted((r for r in trials if r['count'] == count and r['mode'] == 'physics-gpu'), key=lambda r: r['trial'])
    assert [r['trial'] for r in group] == list(range(1, manifest['arguments']['trials'] + 1)), f'incomplete group: {count}'
    for row in group:
        assert row['status'] == 'ok', row
        source = a.sweep / f"{count}-physics-gpu-{row['trial']}.json"
        data = json.loads(source.read_text())
        assert len(data['raw_runs']) == 1
        raw = data['raw_runs'][0]
        mean = statistics.mean(raw['completed_step_ms'])
        assert mean == row['mean_ms']
        assert raw['allocations']['scope'] == 'primary_simulation_buffers'
        name = f"{count}-batched-global-{row['trial']}.json"
        files.append((source, name))
        rows.append(dict(count=count, variant='batched-global', trial=row['trial'],
            returncode=0, raw_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            mean_ms=mean, p50_ms=row['p50_ms'], p95_ms=row['p95_ms'],
            phase_mean_ms={phase: statistics.mean(raw[phase + '_ms'])
                for phase in ['broadphase', 'narrowphase', 'graph', 'prepare', 'solve']}))
a.output.mkdir(parents=True, exist_ok=True)
for source, name in files:
    shutil.copyfile(source, a.output / name)
(a.output / 'manifest.json').write_text(json.dumps(dict(source=manifest,
    counts=a.counts, variants=['batched-global'], trials=manifest['arguments']['trials'],
    note='Exact copies of completed physics-GPU trial JSON; phase/memory view, not additional measurements.'), indent=2) + '\n')
(a.output / 'trials.json').write_text(json.dumps(rows, indent=2) + '\n')
print(f'Derived {len(rows)} verified phase/memory rows in {a.output}')
