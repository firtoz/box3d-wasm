# Complete falling-cube sweep — RTX 4070 Laptop

345 valid trials; three rejected GPU dispatch-capacity failures at 150k.
The manifest records five measured binary hashes and all environment/settings.
Power/load snapshots are per-trial boundaries, not continuous telemetry.

## Regenerate charts without GPU hardware

Install Python and matplotlib, then run from the extracted archive root:

```sh
python scripts/plot-falling-cubes.py sweep reproduced --title 'RTX 4070 Laptop / Ryzen 9 8945HS • driver 610.57.04' --scope-note 'GPU validated through 100,000; 150,000 hits dispatch capacity, not a measured FPS threshold'
python scripts/derive-profile.py sweep profile-reproduced --counts 15000 50000 80000 100000
python scripts/plot-falling-solvers.py profile-reproduced phases-reproduced --title 'RTX 4070 Laptop: validated falling-cube GPU costs' --note 'GPU trials at 150,000 fail dispatch capacity; no timing plotted. Memory excludes renderer, staging, pipeline and driver allocations.'
```

Compare reproduced.json to report.json and phases-reproduced.json to phases.json.
Plotters revalidate raw samples, trial summaries and phase-view hashes. Failed
trials remain in sweep/trials.json and stopped.json, with their original logs.

## Rebuild and measure

Check out repository base commit from source-manifest.json; apply
measured-source.patch from the repository root (includes newly added source).
Follow repository-README.md build/benchmark instructions. Native-cache builds need
the pinned compiler/backend preparation documented in the repository. Build CPU,
direct GPU and native sample viewers before measurement, not concurrently with it.
Run scripts/bench-falling-cubes.py with manifest.arguments (output and binary paths
must be local to your checkout). The manifest records requested 1280x720, but the
recorded actual framebuffer is 2040x1148; compare actual sizes across machines.

scripts/ contains the final analysis tools; measured-source.patch preserves the
code used to build the benchmark binaries before later plotting/doc edits.
qualification/ preserves test/source manifests, library and sanitizer logs, native
qualification JSON and raw checks. The separate earlier before/after archives in
the repository retain their own source versions; do not mix their raw timings
into this sweep. Hardware-specific dispatch limits remain documented in
capacity-boundary.md. Three-trial FPS means do not imply locked frame rates.
