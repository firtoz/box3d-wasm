# Observed 150,000-cube dispatch boundary

The full native-cache GPU paths fail before producing a valid 150k trial. The
first panic is at sim.rs:2363: insert_capacity.div_ceil(64) exceeds
max_compute_workgroups_per_dimension (65,535). At 150,001 shapes, the geometric
insertion reservation is 4,194,304 entries, requiring 65,536 groups of 64.
Pair/contact capacity-sized work also crosses this one-dimensional boundary.
This is not an out-of-memory measurement and does not establish a 10 FPS limit.

All three 100k GPU physics and renderer trials were valid. Report 100k as the
largest validated sampled count, 150k as an invalid capacity boundary. Preserve
failure logs and stopped reasons; never plot failed-run throughput.

Further scaling requires tiled/multidimensional dispatch and matching flattened
indices across direct, indirect, and native cached command paths; changing only
the assertion is unsafe. It needs boundary fixtures plus cache-on/off parity and
fresh larger-count qualification. The existing 80k/100k crossover and 50k average
30 FPS stretch remain established, but no claim beyond100k is supported.
