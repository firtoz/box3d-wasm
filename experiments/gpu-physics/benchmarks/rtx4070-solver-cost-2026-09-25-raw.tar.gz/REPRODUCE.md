# Solver-cost qualification, 2026-09-25

RTX 4070 Laptop / Ryzen 9 8945HS. Baseline commit 0bbf5f63; build/source hashes
in artifacts/solver-cost/qualification-build.json. Runtime checkout metadata can
change during measurement; frozen executable hashes identify measured code.
Apply changes-from-0bbf5f63.patch from the repository root. This archive excludes
executables, driver caches and MP4s; recording manifests and decoded comparisons
retain clip identities. Prior charts and evidence archives remain separate.

Extract into an empty directory; verify every entry in SHA256SUMS.json. Revalidate
without a GPU or matplotlib, from the extracted directory:

    python3 artifacts/solver-cost/audit-qualification.py
    python3 artifacts/solver-cost/summarize-pilots.py

The audit checks both complete raw grids, hashes, configurations, binary identities,
computed timings and paired GPU contact/awake/dispatch/allocation arrays. Archived
absolute command paths identify original runs; no GPU executable is invoked by
validation. Install matplotlib to regenerate charts:

    python3 scripts/plot-small-scene.py artifacts/solver-cost/qualification-physics physics --title 'RTX 4070 Laptop - solver cost'
    python3 scripts/plot-small-scene.py artifacts/solver-cost/qualification-renderers renderers --title 'RTX 4070 Laptop - solver cost' --renderers
    python3 scripts/plot-solver-cost-experiments.py artifacts/solver-cost experiments --title 'RTX 4070 Laptop - solver cost'

For hardware replication, build each revision with scripts/build-native-cache.sh
build --release. Sokol additionally needs --features external-c-shim and the
samples_gpu CMake target. Freeze both binaries and update paths/hashes in runners.
Use fresh output folders. Qualification uses three alternating before/after/CPU
trials, global solver, automatic color prefix and full/global replay, dt=1/60,
four substeps, no sleep, 90 warmup +240 timed steps and eight CPU workers. Normal
desktop load is permitted; no idle gate. Hardware rendering and identical 1280x720
viewports run on isolated Xvfb:96. These FPS values are not native desktop ceilings.

276 library tests pass, with the timing probe ignored by default; nine cache-off
checks pass separately. Both Vulkan ICDs are visible during the suite so the
cross-adapter fixture can use AMD while normal physics selects NVIDIA. To repeat
the synthetic scheduling experiment alone:

    VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json ./scripts/build-native-cache.sh test --release --lib solver_dispatch_boundary_probe -- --ignored --nocapture

Probe inputs are restored before each timed interval; complete outputs agree
byte-for-byte. It reuses synthetic contacts under 20 color visits, not a real falling
pile. Timings compare scheduling at a fixed width, not scaling between widths or
an additive decomposition of application costs. Pilot charts compare each variant
against its own named control. Failed/rejected experiments and raw timings remain
included; only the impulse-store optimization is enabled. GPU phase timings
include shader memory/instruction/synchronization costs and overlap host work.
Trial ranges are not confidence intervals; p50/p95 are medians of trial percentiles.
