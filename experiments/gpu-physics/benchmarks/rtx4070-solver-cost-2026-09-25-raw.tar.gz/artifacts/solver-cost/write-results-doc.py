"""Generate reviewable result prose only from complete validated qualification data."""
from pathlib import Path
import json,statistics
root=Path.cwd();base=root/'artifacts/solver-cost';prefix='rtx4070-solver-cost-'
p=json.loads((root/f'benchmarks/{prefix}physics-2026-09-25.json').read_text())
r=json.loads((root/f'benchmarks/{prefix}renderers-2026-09-25.json').read_text())
audit=json.loads((base/'qualification-audit.json').read_text())
recordings=json.loads((base/'recordings-validation.json').read_text());assert len(recordings)==19

def group(data,scope,n,v):return next(g for g in data['groups'] if (g['scene'],g['count'],g['variant'])==(scope,n,v))
def phase(n,v,k):return statistics.median(t[k] for t in p['phase_trials'] if (t['scene'],t['count'],t['variant'])==('falling-cubes',n,v))
def table(data,scopes,counts,fps=False):
 lines=['| '+('Renderer / cubes' if fps else 'Falling cubes')+' | Baseline GPU '+('FPS' if fps else 'ms')+' | Candidate GPU '+('FPS' if fps else 'ms')+' | CPU '+('FPS' if fps else 'ms')+' |'+('' if fps else ' GPU time reduction |'),'| --- | ---: | ---: | ---: |'+('' if fps else ' ---: |')]
 for scope in scopes:
  for n in counts:
   b,a,c=[group(data,scope,n,v)['mean_ms'] for v in ['before','after','cpu']]
   if fps:lines.append(f'| {scope.title()} / {n:,} | {1000/b:.1f} | {1000/a:.1f} | {1000/c:.1f} |')
   else:lines.append(f'| {n:,} | {b:.3f} | {a:.3f} | {c:.3f} | {100*(1-a/b):.1f}% |')
 return '\n'.join(lines)
met=all(group(p,'falling-cubes',n,'after')['mean_ms']<=.8*group(p,'falling-cubes',n,'before')['mean_ms'] for n in [2000,5000])
wins=[g['count'] for g in audit['physics'] if g['scope']=='falling-cubes' and g['median_ms']['after']<g['median_ms']['cpu']]
crossover=min(wins) if wins else None
baseline_wins=[g['count'] for g in audit['physics'] if g['scope']=='falling-cubes' and g['median_ms']['before']<g['median_ms']['cpu']]
baseline_crossover=min(baseline_wins) if baseline_wins else None
separated=any(g['scope']=='falling-cubes' and g['count']==crossover and g['all_gpu_trials_faster_than_cpu'] for g in audit['physics'])
small_pairs='; '.join(f"{n:,}: "+', '.join(f'{x:+.1f}%' for x in next(g['paired_change_percent'] for g in audit['physics'] if g['scope']=='falling-cubes' and g['count']==n)) for n in [1000,2000,5000])
large_pairs='\n'.join(f"- {g['scope']} / {g['count']:,}: "+', '.join(f'{x:+.2f}%' for x in g['paired_change_percent']) for g in audit['physics'] if g['scope']=='mixed-stacks' or g['count'] in [20000,100000,200000])
different=sum(v['different_frames'] for v in recordings.values())
text=f'''The **solver writeback follow-up (2026-09-25)** compares baseline `0bbf5f63`
with impulse-only contact stores. The simulation, color order, dispatch count,
four substeps, 1/60 s timestep and disabled sleeping are unchanged. These are
medians of three alternating trial means on the RTX 4070 Laptop / Ryzen 9 8945HS,
with eight CPU workers, 90 warmup and 240 timed steps under normal desktop load.
The qualification contains 108 physics runs and 72 representative renderer runs.

{table(p,['falling-cubes'],[100,1000,2000,5000,10000,15000,20000,100000,200000])}

The **20% completed-step target at both 2k and 5k was {'reached' if met else 'not reached'}**.
The requested approximate absolute targets were 2.17 ms at 2k and 2.94 ms at 5k.
Individual paired time changes (positive means slower) are {small_pairs}.
The first sampled median GPU physics win moves from {f'{baseline_crossover:,}' if baseline_crossover else 'none'}
cubes for the baseline to {f'{crossover:,}' if crossover else 'none'} for the candidate in this matched sweep.
{'At that candidate count, every GPU trial mean is below every CPU trial mean.' if separated else 'The trial ranges overlap at that count.'}
This is workload-specific, not a universal crossover threshold. Consult the raw
trial ranges rather than treating small median differences as guaranteed gains.

The 100-cube median is worse, with paired changes of +6.8%, +19.2% and
−1.5%. Small-scene timings vary; there is no claim of a universal speedup.
The sparse and large-scene paired time changes are retained explicitly:

{large_pairs}

At 5k, GPU solver time changes from {phase(5000,'before','solve_ms'):.3f} to
{phase(5000,'after','solve_ms'):.3f} ms, while graph construction changes from
{phase(5000,'before','graph_ms'):.3f} to {phase(5000,'after','graph_ms'):.3f} ms.
Narrow contact writes reduce assigned fields from 352 to 56 bytes per writeback.
This is a source-level footprint, not a hardware memory-transaction measurement.
The fixed-schedule comparison isolates the effect of that shader change; GPU
phase time includes its memory and instruction costs. It is not an additive
breakdown of host, shader execution and synchronization time.

![Completed physics-step latency and CPU comparison](benchmarks/{prefix}physics-2026-09-25-latency.png)

[Throughput](benchmarks/{prefix}physics-2026-09-25-throughput.png),
[p50/p95](benchmarks/{prefix}physics-2026-09-25-percentiles.png),
[GPU phase costs](benchmarks/{prefix}physics-2026-09-25-phases.png),
and [validated physics data](benchmarks/{prefix}physics-2026-09-25.json).

Experiments also tested velocity-only body stores and per-phase specialization
of broad-color or all color shaders. They did not show reliable additional
completed-step gains, so they are not enabled. All 72 pilot trials are retained,
including unfavorable pairs; they are separate from final qualification.

![Accepted and rejected solver experiments](benchmarks/{prefix}experiments-2026-09-25-pilots.png)

A controlled synthetic probe restored identical prepared inputs and compared
260 dispatches with 13 grouped dispatches using workgroup storage barriers.
Outputs matched byte-for-byte. Grouping helped at 64 contacts per color visit
but lost at 256 and 1,024 as parallelism fell. This supports retaining the existing
occupancy-based schedule. The repeated synthetic contacts are not a falling pile,
and these intervals do not estimate an additive dispatch overhead for the live app.

![Dispatch versus workgroup scheduling probe](benchmarks/{prefix}experiments-2026-09-25-boundaries.png)

{table(r,['direct','sokol'],[1000,5000,10000,20000],True)}

![Full-app FPS for both renderers](benchmarks/{prefix}renderers-2026-09-25-throughput.png)

[Frame latency](benchmarks/{prefix}renderers-2026-09-25-latency.png),
[frame p50/p95](benchmarks/{prefix}renderers-2026-09-25-percentiles.png),
and [validated renderer data](benchmarks/{prefix}renderers-2026-09-25.json).
Both renderers use matched 1280×720 viewports, NVIDIA hardware and unpaced
presentation on the same isolated Xvfb setup. These FPS values include application,
rendering and display costs; they are not native-desktop FPS ceilings.

All 276 native-cache library tests pass, plus nine cache-disabled checks. The
synthetic timing probe is ignored by default and passed separately. Coverage
includes bytewise full-record agreement after each solver phase, linked one- and
four-point manifolds, graph changes, spawning/destruction, slot reuse, growth,
cache invalidation and long replay reentry. Nineteen affected scenes were recorded
for 300 frames each, with {different} decoded frames differing from the baseline;
the real Box3D CPU comparison column remains pinned.

The [raw evidence archive](benchmarks/{prefix}2026-09-25-raw.tar.gz)
([SHA-256](benchmarks/{prefix}2026-09-25-raw.tar.gz.sha256)) includes frozen executable
identities, source hashes and patch, raw timings, environments, tests, rejected
experiments, recording hashes and reproduction scripts. Earlier charts and
archives remain unchanged. Box3D and the WASM package are unchanged.

'''
(base/'results-draft.md').write_text(text)
print(text)
