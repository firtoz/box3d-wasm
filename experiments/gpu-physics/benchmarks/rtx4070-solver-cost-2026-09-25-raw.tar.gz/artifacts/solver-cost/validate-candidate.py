from pathlib import Path
import json,os,subprocess
base=Path('artifacts/solver-cost')
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}
env.update(json.loads((base/'baseline-environment.json').read_text())['environment'])
env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None)
with (base/'qualification-library.log').open('w') as f:
 subprocess.run(['./scripts/build-native-cache.sh','test','--release','--lib','--','--test-threads=1','--nocapture'],env=env,stdout=f,stderr=f,check=True)
print('Native-cache library suite passed',flush=True)
off=env.copy()
for key in list(off):
 if key.startswith('GPU_PHYSICS_NATIVE_') or key in ['GPU_PHYSICS_FULL_REPLAY','GPU_PHYSICS_GLOBAL_REPLAY','GPU_PHYSICS_GRAPH_MEMO']:off[key]='0'
for case in ['solver_narrow_writes','graph_mutations_match_canonical','graph_density_status','color_tail_tests','appended_extent_tests','destroy_and_reuse_slots']:
 with (base/('cache-off-'+case+'.log')).open('w') as f:
  subprocess.run(['./scripts/build-native-cache.sh','test','--release','--lib',case,'--','--test-threads=1','--nocapture'],env=off,stdout=f,stderr=f,check=True)
 print('Passed cache-off '+case,flush=True)
