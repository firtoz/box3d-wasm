"""Validate and package solver-cost evidence; exclude executables, caches and videos."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path.cwd();base=root/'artifacts/solver-cost'
subprocess.run(['python3',str(base/'audit-qualification.py')],check=True)
subprocess.run(['python3',str(base/'summarize-pilots.py')],check=True)
assert '276 passed; 0 failed; 1 ignored' in (base/'qualification-library.log').read_text()
for case,n in {'solver_narrow_writes':1,'graph_mutations_match_canonical':3,'graph_density_status':1,'color_tail_tests':1,'appended_extent_tests':2,'destroy_and_reuse_slots':1}.items():
 assert f'{n} passed; 0 failed' in (base/('cache-off-'+case+'.log')).read_text()
assert '1 passed; 0 failed' in (base/'boundary-probe.log').read_text()
recordings=json.loads((base/'recordings-validation.json').read_text());assert len(recordings)==19 and all(r['frames']==300 and r['different_frames']==0 for r in recordings.values())
build=json.loads((base/'qualification-build.json').read_text())
for p,h in build['sources'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h
for p,h in build['binaries'].items():assert hashlib.sha256((base/p).read_bytes()).hexdigest()==h
files={}
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.log','.py','.wgsl','.patch','.md','.rs'] and '__pycache__' not in p.parts:
  files[str(p.relative_to(root))]=p.read_bytes()
for p in (root/'scripts').iterdir():
 if p.suffix in ['.py','.sh','.ts']:files[str(p.relative_to(root))]=p.read_bytes()
for p in (root/'benchmarks').glob('rtx4070-solver-cost-*.json'):files[str(p.relative_to(root))]=p.read_bytes()
files['changes-from-0bbf5f63.patch']=subprocess.check_output(['git','diff','0bbf5f63','--','src','shaders','scripts','README.md'],cwd=root)
for name in build['sources']:files['candidate-sources/'+name]=(root/name).read_bytes()
for label in ['000-box3d-cpu','2026-09-25-connected-scheduling-after','2026-09-25-solver-cost-after']:
 for p in (root/'recordings/snapshots'/label).glob('*.json'):files[str(p.relative_to(root))]=p.read_bytes()
files['REPRODUCE.md']=b'''# Solver-cost qualification, 2026-09-25

RTX 4070 Laptop / Ryzen 9 8945HS. Baseline commit 0bbf5f63; build/source hashes
in artifacts/solver-cost/qualification-build.json. Runtime checkout metadata can
change during measurement; frozen executable hashes identify measured code.
Apply changes-from-0bbf5f63.patch from the repository root. This archive excludes
executables, driver caches and MP4s; recording manifests and decoded comparisons
retain clip identities. Prior charts and evidence archives remain separate.

Extract into an empty directory; verify every entry in SHA256SUMS.json. Revalidate
without a GPU or matplotlib, from the extracted directory:

    python3 artifacts/solver-cost/audit-qualification.py
    python3 artifacts/solver-cost/summarize-pilots.py

The audit checks both complete raw grids, hashes, configurations, binary identities,
computed timings and paired GPU contact/awake/dispatch/allocation arrays. Archived
absolute command paths identify original runs; no GPU executable is invoked by
validation. Install matplotlib to regenerate charts:

    python3 scripts/plot-small-scene.py artifacts/solver-cost/qualification-physics physics --title 'RTX 4070 Laptop - solver cost'
    python3 scripts/plot-small-scene.py artifacts/solver-cost/qualification-renderers renderers --title 'RTX 4070 Laptop - solver cost' --renderers
    python3 scripts/plot-solver-cost-experiments.py artifacts/solver-cost experiments --title 'RTX 4070 Laptop - solver cost'

For hardware replication, build each revision with scripts/build-native-cache.sh
build --release. Sokol additionally needs --features external-c-shim and the
samples_gpu CMake target. Freeze both binaries and update paths/hashes in runners.
Use fresh output folders. Qualification uses three alternating before/after/CPU
trials, global solver, automatic color prefix and full/global replay, dt=1/60,
four substeps, no sleep, 90 warmup +240 timed steps and eight CPU workers. Normal
desktop load is permitted; no idle gate. Hardware rendering and identical 1280x720
viewports run on isolated Xvfb:96. These FPS values are not native desktop ceilings.

276 library tests pass, with the timing probe ignored by default; nine cache-off
checks pass separately. Both Vulkan ICDs are visible during the suite so the
cross-adapter fixture can use AMD while normal physics selects NVIDIA. To repeat
the synthetic scheduling experiment alone:

    VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json ./scripts/build-native-cache.sh test --release --lib solver_dispatch_boundary_probe -- --ignored --nocapture

Probe inputs are restored before each timed interval; complete outputs agree
byte-for-byte. It reuses synthetic contacts under 20 color visits, not a real falling
pile. Timings compare scheduling at a fixed width, not scaling between widths or
an additive decomposition of application costs. Pilot charts compare each variant
against its own named control. Failed/rejected experiments and raw timings remain
included; only the impulse-store optimization is enabled. GPU phase timings
include shader memory/instruction/synchronization costs and overlap host work.
Trial ranges are not confidence intervals; p50/p95 are medians of trial percentiles.
'''
manifest={name:hashlib.sha256(data).hexdigest() for name,data in files.items()};files['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'benchmarks/rtx4070-solver-cost-2026-09-25-raw.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;archive.addfile(info,io.BytesIO(data))
out.with_suffix(out.suffix+'.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print('Packaged',len(files),'files;',out.stat().st_size,'bytes')
