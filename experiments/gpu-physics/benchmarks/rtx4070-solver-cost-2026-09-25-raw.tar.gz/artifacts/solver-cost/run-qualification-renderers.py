"""Real direct/Sokol viewers on an isolated X display; sequential matched trials."""
from pathlib import Path
import json,os,subprocess,hashlib,time,fcntl
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent;out=base/'qualification-renderers';out.mkdir(exist_ok=True)
# Do not qualify renderers while paired physics has a consistent regression.
physics=json.loads((base/'qualification-physics/jobs.json').read_text())
regressions=[]
for scene,count in [('mixed-stacks',100),('mixed-stacks',1000),('mixed-stacks',5000),('falling-cubes',20000),('falling-cubes',100000),('falling-cubes',200000)]:
 pairs=[]
 for trial in [1,2,3]:
  values={r['variant']:r['result'][0]['mean_ms'] for r in physics if r['status']=='ok' and (r['scene'],r['count'],r['trial'])==(scene,count,trial)}
  pairs.append(values['after']/values['before'])
 if all(x>1 for x in pairs):regressions.append((scene,count,pairs))
assert not regressions, ('Consistent paired regression requires investigation before renderer qualification', regressions)

lock=(out/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
variants={'before':{'direct':base/'baseline-gpu','sokol':base/'baseline-sokol'},'after':{'direct':base/'qualified-candidate-gpu','sokol':base/'qualified-candidate-sokol'}}
manifest={'counts':[1000,5000,10000,20000],'renderers':['direct','sokol'],'trials':3,'warmup':90,'timed':240,'workers':8,'binaries':{v:{k:{'path':str(p),'sha256':sha(p)} for k,p in bins.items()} for v,bins in variants.items()},'display':':96','display_size':[2048,1152],'requested_viewport':[1280,720],'load_gate':False,'baseline':'0bbf5f63','configurations':{v:{'color_prefix':'auto','global_replay':'1'} for v in variants}}
settings_path=root.parents[1]/'box3d/settings.ini';original=settings_path.read_bytes() if settings_path.exists() else None
settings=json.loads((base.parent/'startup-optimization/startup-inputs.json').read_text())['sokol_settings'];manifest['sokol_settings']=settings
if (out/'manifest.json').exists():assert json.loads((out/'manifest.json').read_text())==manifest
else:save(out/'manifest.json',manifest)
rows=json.loads((out/'jobs.json').read_text()) if (out/'jobs.json').exists() else []
subprocess.run([str(base.parent/'startup-optimization/plot-env/bin/python'),str(root/'scripts/plot-small-scene.py'),str(base/'qualification-physics'),str(root/'benchmarks/rtx4070-solver-cost-physics-2026-09-25'),'--title','RTX 4070 Laptop / Ryzen 9 8945HS — 2026-09-25'],cwd=root,check=True)
env=os.environ|{'DISPLAY':':96','WINIT_UNIX_BACKEND':'x11','VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json','__NV_PRIME_RENDER_OFFLOAD':'1','__GLX_VENDOR_LIBRARY_NAME':'nvidia'};env.pop('WAYLAND_DISPLAY',None)
xlog=(out/'xvfb.log').open('w');xvfb=subprocess.Popen(['Xvfb',':96','-screen','0','2048x1152x24','-nolisten','tcp'],stdout=xlog,stderr=xlog)
try:
 time.sleep(1);assert xvfb.poll() is None,'Could not own isolated display'
 for count in manifest['counts']:
  for renderer in manifest['renderers']:
   for trial in range(1,4):
    for variant in (['before','after','cpu'] if trial%2 else ['cpu','after','before']):
     key=f'{count}-{renderer}-{trial}-{variant}'
     if any(r['key']==key and r['status']=='ok' for r in rows):continue
     folder=out/key
     if folder.exists():raise RuntimeError('Prior attempt retained: '+key)
     settings_path.write_text(settings)
     bins=variants['after' if variant=='after' else 'before'];mode=renderer+('-cpu' if variant=='cpu' else '-gpu')
     cmd=['python3','scripts/bench-falling-cubes.py',str(folder),'--counts',str(count),'--modes',mode,'--trials','1','--warmup','90','--timed','240','--workers','8','--adapter','nvidia','--width','1280','--height','720','--gpu-solver','global','--gpu-color-prefix','auto','--global-replay','1','--gpu-binary',str(bins['direct']),'--sokol-gpu-binary',str(bins['sokol']),'--timeout','900']
     row=dict(key=key,count=count,renderer=renderer,mode=mode,trial=trial,variant=variant,command=cmd,status='running',started=time.time());rows.append(row);save(out/'jobs.json',rows);print(key,flush=True)
     with (out/(key+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=log)
     results=json.loads((folder/'trials.json').read_text()) if (folder/'trials.json').exists() else []
     row.update(status='ok' if p.returncode==0 and len(results)==1 and results[0]['status']=='ok' else 'failed',returncode=p.returncode,finished=time.time(),result=results)
     if row['status']=='ok':
      fb=results[0]['framebuffer'];prior=[r['result'][0]['framebuffer'] for r in rows if r['status']=='ok' and r['renderer']==renderer];assert all(f==fb for f in prior),'Viewport changed'
     save(out/'jobs.json',rows)
     if row['status']!='ok':raise RuntimeError('Failed: '+key)
 print('All renderer trials complete',flush=True)
finally:
 if original is None:settings_path.unlink(missing_ok=True)
 else:settings_path.write_bytes(original)
 xvfb.terminate();xvfb.wait(timeout=10);xlog.close()
