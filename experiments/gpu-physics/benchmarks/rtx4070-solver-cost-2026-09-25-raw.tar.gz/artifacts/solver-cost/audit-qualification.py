"""Check complete raw grids and paired workload/counter invariants before publication."""
from pathlib import Path
import json,subprocess,statistics
root=Path.cwd();base=root/'artifacts/solver-cost'
report={}
for kind in ['physics','renderers']:
 folder=base/('qualification-'+kind)
 subprocess.run(['python3','scripts/plot-small-scene.py',str(folder),'unused','--title','raw qualification audit','--validate-only',*(['--renderers'] if kind=='renderers' else [])],check=True)
 rows=json.loads((folder/'jobs.json').read_text());scopes=sorted({(r.get('scene',r.get('renderer')),r['count']) for r in rows});groups=[]
 for scope,count in scopes:
  variants={v:sorted([r for r in rows if r.get('scene',r.get('renderer'))==scope and r['count']==count and r['variant']==v],key=lambda r:r['trial']) for v in ['before','after','cpu']}
  paired=[100*(a['result'][0]['mean_ms']/b['result'][0]['mean_ms']-1) for a,b in zip(variants['after'],variants['before'])]
  if kind=='physics':
   for a,b in zip(variants['after'],variants['before']):
    data=[]
    for row in [a,b]:
     raw=folder/row['key']/f'{count}-physics-gpu-1.json';data.append(json.loads(raw.read_text())['raw_runs'][0])
    for key in ['solver_dispatches','live_contacts','awake_dynamic','allocations']:
     assert data[0][key]==data[1][key],(scope,count,a['trial'],key)
  groups.append({'scope':scope,'count':count,'paired_change_percent':paired,'median_ms':{v:statistics.median(r['result'][0]['mean_ms'] for r in rs) for v,rs in variants.items()},'all_gpu_trials_faster_than_cpu':max(r['result'][0]['mean_ms'] for r in variants['after'])<min(r['result'][0]['mean_ms'] for r in variants['cpu']),'all_pairs_slower':all(x>0 for x in paired)})
 report[kind]=groups
(base/'qualification-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
