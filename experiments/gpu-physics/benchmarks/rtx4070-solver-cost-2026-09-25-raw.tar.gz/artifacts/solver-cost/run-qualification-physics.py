"""Matched original baseline/candidate physics trials; never overwrite attempts."""
from pathlib import Path
import json,os,subprocess,hashlib,time,fcntl
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
out=base/'qualification-physics';out.mkdir(exist_ok=True)
lock=(out/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
variants={'before':base/'baseline-gpu','after':base/'qualified-candidate-gpu'}
manifest={'baseline':'0bbf5f63','variants':{v:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for v,p in variants.items()},'scenes':{'falling-cubes':[100,1000,2000,5000,10000,15000,20000,100000,200000],'mixed-stacks':[100,1000,5000]},'trials':3,'warmup':90,'timed':240,'workers':8,'candidate':'impulse-only contact stores','baseline_configuration':'global solver, automatic prefix and global replay on; both variants retain four substeps and disabled sleep','load_gate':False,'configurations':{v:{'color_prefix':'auto','global_replay':'1'} for v in variants}}
def save(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
if (out/'manifest.json').exists():assert json.loads((out/'manifest.json').read_text())==manifest
else:save(out/'manifest.json',manifest)
rows=json.loads((out/'jobs.json').read_text()) if (out/'jobs.json').exists() else []
for scene,counts in manifest['scenes'].items():
 for count in counts:
  for trial in range(1,4):
   order=['before','after','cpu'] if trial%2 else ['cpu','after','before']
   for variant in order:
    key=f'{scene}-{count}-{trial}-{variant}'
    if any(row['key']==key and row['status']=='ok' for row in rows):continue
    folder=out/key
    if folder.exists():raise RuntimeError('Prior incomplete attempt retained: '+key)
    binary=variants['after' if variant=='after' else 'before']
    cmd=['python3','scripts/bench-falling-cubes.py',str(folder),'--scene',scene,'--counts',str(count),'--modes','physics-cpu' if variant=='cpu' else 'physics-gpu','--trials','1','--warmup','90','--timed','240','--workers','8','--adapter','nvidia','--gpu-solver','global','--gpu-color-prefix','auto','--global-replay','1','--gpu-binary',str(binary),'--sokol-gpu-binary',str(base/'baseline-sokol'),'--timeout','900']
    row={'key':key,'scene':scene,'count':count,'trial':trial,'variant':variant,'command':cmd,'status':'running','started':time.time()};rows.append(row);save(out/'jobs.json',rows);print(key,flush=True)
    with (out/(key+'.log')).open('w') as log:
     proc=subprocess.run(cmd,cwd=root,env=os.environ|{'VK_DRIVER_FILES':'/usr/share/vulkan/icd.d/nvidia_icd.json'},stdout=log,stderr=log)
    results=json.loads((folder/'trials.json').read_text()) if (folder/'trials.json').exists() else []
    row.update(status='ok' if proc.returncode==0 and len(results)==1 and results[0]['status']=='ok' else 'failed',finished=time.time(),returncode=proc.returncode,result=results);save(out/'jobs.json',rows)
    if row['status']!='ok':raise RuntimeError('Failed: '+key)
print('All matched physics trials complete',flush=True)
