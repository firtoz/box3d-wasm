"""Extract final evidence into a fresh directory and revalidate without a GPU."""
from pathlib import Path
import argparse,hashlib,json,subprocess,tarfile,tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);a=p.parse_args();archive=a.archive.resolve()
expected=archive.with_suffix(archive.suffix+'.sha256').read_text().split()[0]
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
with tempfile.TemporaryDirectory(prefix='solver-cost-evidence-audit-') as tmp:
 root=Path(tmp)
 with tarfile.open(archive) as t:t.extractall(root,filter='data')
 hashes=json.loads((root/'SHA256SUMS.json').read_text())
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 assert actual==set(hashes)|{'SHA256SUMS.json'}
 for name,h in hashes.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
 base=root/'artifacts/solver-cost';build=json.loads((base/'qualification-build.json').read_text())
 for name,h in build['sources'].items():assert hashlib.sha256((root/'candidate-sources'/name).read_bytes()).hexdigest()==h
 for kind in ['physics','renderers']:
  subprocess.run(['python3','scripts/plot-small-scene.py',f'artifacts/solver-cost/qualification-{kind}','unused','--title','fresh extraction validation','--validate-only',*(['--renderers'] if kind=='renderers' else [])],cwd=root,check=True)
 subprocess.run(['python3','artifacts/solver-cost/audit-qualification.py'],cwd=root,check=True)
 subprocess.run(['python3','artifacts/solver-cost/summarize-pilots.py'],cwd=root,check=True)
 print('Verified',len(hashes),'payload hashes, candidate sources, and both raw qualification grids in fresh extraction.')
