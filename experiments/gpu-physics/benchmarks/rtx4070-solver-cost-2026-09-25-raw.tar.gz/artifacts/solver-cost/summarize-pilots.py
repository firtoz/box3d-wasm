"""Validate retained experimental results and summarize each against its own control."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,runpy,statistics
root=Path.cwd();base=root/'artifacts/solver-cost';bench=runpy.run_path('scripts/bench-falling-cubes.py');result={}
for label in ['impulse','velocity','specialize','all-specialize']:
 folder=base/(label+'-pilot');manifest=json.loads((folder/'manifest.json').read_text());rows=json.loads((folder/'trials.json').read_text());assert len(rows)==18
 seen=set()
 for r in rows:
  key=(r['count'],r['trial'],r['variant']);assert key not in seen;seen.add(key)
  raw=folder/f'{key[0]}-{key[1]}-{key[2]}.json';assert hashlib.sha256(raw.read_bytes()).hexdigest()==r['sha256']
  binary=manifest['binaries'][r['variant']];assert str(r['command'][0])==binary['path']
  # Archived source/executable identity remains usable without shipping binaries.
  if Path(binary['path']).exists():assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest()==binary['sha256']
  d=json.loads(raw.read_text());assert d['sub_steps']==4 and abs(d['dt']-1/60)<1e-7 and not d['sleep']
  metrics=bench['metrics'](d,'physics-gpu',raw,SimpleNamespace(warmup=90,timed=240),r['count'])
  for k in ['mean_ms','p50_ms','p95_ms']:assert abs(metrics[k]-r[k])<1e-8
  for k in ['graph','prepare','solve']:assert abs(statistics.mean(d['raw_runs'][0][k+'_ms'])-r['phase_ms'][k])<1e-8
 summary=[]
 for count in [1000,2000,5000]:
  g={v:sorted([r for r in rows if r['count']==count and r['variant']==v],key=lambda r:r['trial']) for v in ['before','after']}
  for t in range(1,4):
   d={v:json.loads((folder/f'{count}-{t}-{v}.json').read_text())['raw_runs'][0] for v in g}
   for k in ['allocations','solver_dispatches','awake_dynamic','live_contacts']:assert d['before'][k]==d['after'][k]
  summary.append({'count':count,'completed_ms':{v:statistics.median(r['mean_ms'] for r in rs) for v,rs in g.items()},'solver_ms':{v:statistics.median(r['phase_ms']['solve'] for r in rs) for v,rs in g.items()},'paired_reduction_percent':[100*(1-a['mean_ms']/b['mean_ms']) for a,b in zip(g['after'],g['before'])]})
 result[label]=summary
(base/'pilots-summary.json').write_text(json.dumps(result,indent=2)+'\n');print('Validated 72 pilot trials and their raw hashes, timings, binary identities and workload counters.')
