from pathlib import Path
import json,os,subprocess,hashlib,shutil,statistics,runpy
from types import SimpleNamespace
root=Path.cwd();base=root/'artifacts/solver-cost';out=base/'impulse-pilot';out.mkdir(exist_ok=False)
bench=runpy.run_path('scripts/bench-falling-cubes.py')
source=json.loads((base/'baseline-environment.json').read_text())
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_','GPU_SOKOL_'))};env.update(source['environment'])
shutil.copy2(root/'target/native-cache-build/release/gpu-physics',base/'impulse-gpu')
variants={'before':base/'baseline-gpu','after':base/'impulse-gpu'}
manifest={'baseline':'0bbf5f63','environment':env,'binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in variants.items()},'source_sha256':hashlib.sha256((root/'shaders/physics/solve.wgsl').read_bytes()).hexdigest(),'purpose':'Impulse-only stores; unchanged solver arithmetic and dispatch schedule; diagnostic pilot'}
# Record selected runtime environment rather than unrelated shell secrets.
manifest['environment']={k:v for k,v in env.items() if k.startswith(('GPU_','VK_','WGPU_'))}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');rows=[]
for count in [1000,2000,5000]:
 for trial in range(1,4):
  for variant in (['before','after'] if trial%2 else ['after','before']):
   path=out/f'{count}-{trial}-{variant}.json'; binary=variants[variant]
   cmd=[str(binary),'--scene','falling-cubes','--bodies',str(count),'--warmup','90','--frames','240','--no-sleep','--bench',str(path),'--metric-runs','1']
   row={'count':count,'trial':trial,'variant':variant,'command':cmd,'before':bench['system']()}
   with path.with_suffix('.log').open('w') as log:r=subprocess.run(cmd,env=env|{'GPU_BENCH_CUBES':str(count)},stdout=log,stderr=log,timeout=600)
   row.update(returncode=r.returncode,after=bench['system']());assert r.returncode==0
   data=json.loads(path.read_text()); row.update(bench['metrics'](data,'physics-gpu',path,SimpleNamespace(warmup=90,timed=240),count))
   row['phase_ms']={k:statistics.mean(data['raw_runs'][0][k+'_ms']) for k in ['graph','prepare','solve']};row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();rows.append(row)
   (out/'trials.json').write_text(json.dumps(rows,indent=2)+'\n');print(count,trial,variant,row['mean_ms'],row['phase_ms'],flush=True)
