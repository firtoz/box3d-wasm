"""Run only after validate-candidate.py completes; preserve failures and all raw trials."""
from pathlib import Path
import os,json,subprocess,hashlib,shutil,re
root=Path.cwd();base=root/'artifacts/solver-cost'
assert '276 passed; 0 failed; 1 ignored' in (base/'qualification-library.log').read_text()
cases={'solver_narrow_writes':1,'graph_mutations_match_canonical':3,'graph_density_status':1,'color_tail_tests':1,'appended_extent_tests':2,'destroy_and_reuse_slots':1}
for case,n in cases.items():assert f'{n} passed; 0 failed' in (base/('cache-off-'+case+'.log')).read_text()
source=json.loads((base/'baseline-environment.json').read_text())
for key in ['cpu','cpu_bridge','sokol_cpu']:
 info=source['binaries'][key];assert hashlib.sha256(Path(info['path']).read_bytes()).hexdigest()==info['sha256'],key
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_','GPU_SOKOL_'))}|source['environment']
def run(cmd,name):
 with (base/name).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=log,check=True)
 print('PASS '+name,flush=True)
run(['./scripts/build-native-cache.sh','build','--release'],'qualification-build.log')
shutil.copy2('target/native-cache-build/release/gpu-physics',base/'qualified-candidate-gpu')
run(['./scripts/build-native-cache.sh','build','--release','--features','external-c-shim'],'qualification-shim-build.log')
run(['cmake','--build','native-samples/build-gpu-native-cache-portable','--target','samples_gpu','-j6'],'qualification-sokol-build.log')
shutil.copy2('native-samples/build-gpu-native-cache-portable/bin/samples_gpu',base/'qualified-candidate-sokol')
files=['src/sim.rs','src/api/world.rs','src/manifold_chain_tests.rs','shaders/physics/solve.wgsl','shaders/physics/broadphase.wgsl']
(base/'qualification-build.json').write_text(json.dumps({'baseline':'0bbf5f63','binaries':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['qualified-candidate-gpu','qualified-candidate-sokol']},'sources':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}},indent=2)+'\n')
print('Qualified binaries frozen; starting alternating physics measurements',flush=True)
subprocess.run(['python3',str(base/'run-qualification-physics.py')],env=env,check=True)
subprocess.run(['python3','scripts/plot-small-scene.py',str(base/'qualification-physics'),'unused','--title','qualification raw validation','--validate-only'],env=env,check=True)
print('Physics complete; checking regressions before renderer qualification',flush=True)
subprocess.run(['python3',str(base/'run-qualification-renderers.py')],env=env,check=True)
print('Qualification complete',flush=True)
