# Repeated physics crossover checkpoint

Three alternating CPU/GPU trials at 50,000 and 60,000 falling cubes, eight Box3D CPU workers, global-color GPU solver, four substeps, sleeping disabled, 90 warmup and 240 measured steps. No idle gate. All runs passed the existing validity checks. GPU median completed-step throughput is 11.36% higher at50k and22.95% higher at60k. All three60k trials exceed20%; no50k trial does. The goal of20% at two adjacent counts is NOT met. Renderer FPS and100k-body qualification remain pending.

The top-level manifest.json records the preserved GPU executable hash; source.patch describes that compiled checkpoint against the Git commit in that manifest. crossover/manifest.json records both actual executable hashes, environment, hardware and run settings. Individual GPU JSON source_sha256 values inspect the runtime working tree, not compiled source. Use the preserved executable/source snapshot for binary provenance.

AC was connected. Before/after power, temperature, clock and load snapshots are retained in trials.json; these include idle transitions and are not a continuous power trace. The GPU power limit query reported unavailable. No fixed power budget or peak-FLOPS scaling claim follows from these runs.

checks/ contains the256-test passing NVIDIA library log and source/binary manifest. No scene-recording or100k-body claim is made. Replot with scripts/plot-falling-cubes.py crossover OUTPUT --title 'RTX 4070 Laptop / Ryzen 9 8945HS (NVIDIA 610.57.04)'. Plotting requires matplotlib; the runner uses only Python's standard library.
