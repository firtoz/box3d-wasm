# Small-scene GPU qualification, RTX 4070 Laptop / Ryzen 9 8945HS

Baseline: 73373dfb. Candidate: changes-from-73373dfb.patch, plus the included
scripts/plot-small-scene.py. Apply the patch from the repository root (paths are
repository-relative). Candidate source copies and binary identities are included.
The raw git/dirty/source_sha256 fields describe the runtime checkout, not the
compiled binary. Use frozen executable SHA-256 identities and build records.
Compiled binaries, caches and videos are excluded; recording hashes/frame counts
are included. The existing Box3D CPU oracle and pinned visual column are unchanged.

Extract into an empty directory. SHA256SUMS.json checks every payload except itself.
Revalidate archived raw results without a GPU:

    python3 scripts/plot-small-scene.py artifacts/small-scene-optimization/qualification-physics unused --title validation --validate-only
    python3 scripts/plot-small-scene.py artifacts/small-scene-optimization/qualification-renderers unused --title validation --validate-only --renderers

To plot, install matplotlib in a virtual environment, omit --validate-only and
supply an output prefix. Chart medians are medians of trial means; shading shows
full trial ranges, not confidence intervals. p50/p95 are medians across trials.

For hardware replication, build both revisions using scripts/build-native-cache.sh;
Sokol also requires --features external-c-shim and its CMake build. Freeze the
binaries, update their paths in the included qualification runners and use fresh
output directories. These runners preserve paired order, four substeps, sleep off,
90 warmup + 240 measured steps, eight CPU workers and normal desktop load.
Baseline uses the previous global solver prefix20 configuration; candidate uses
adaptive prefix plus global command replay. Neither reduces solver iterations or
moves physics to the CPU. Component-solver runs are separate diagnostics.

Both headline GPU variants retain the engine's ordinary GPU phase timestamps;
extra host timing and broadphase instrumentation are off. Instrumented pilot
profiles are separate evidence, not mixed into headline measurements. Step-call
wall time and completion wait sum to completed latency; GPU execution overlaps
them, so never add GPU phase durations to those host wall times. The separate
step-plus-host-mirror pass uses a fresh world and is not an additive decomposition.

Renderer comparisons use matched actual framebuffers within each renderer. Inspect
raw manifests for GPU/driver identity, display size, render settings and machine
load. FPS comes from completed application cadence, not submission time alone.
