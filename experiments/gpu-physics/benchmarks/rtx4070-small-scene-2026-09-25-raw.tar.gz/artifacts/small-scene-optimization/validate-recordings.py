"""Verify clip completeness and compare decoded frames without recompression."""
from pathlib import Path
import json,subprocess,hashlib,re
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
scenes=['single-box','box-stack','sphere-stack','capsule-stack','revolute','weld','stack','pyramid','bounce','mixed','spinner','ramp','spheres','dominoes','high-resistance','mixed-stacks','falling-cubes','anchored-mechanisms','joint-chain']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def decoded(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-f','framemd5','-'])
 return [line.split(b',')[-1].strip().decode() for line in raw.splitlines() if not line.startswith(b'#') and line.strip()]
cpu_manifest=json.loads((root/'recordings/snapshots/000-box3d-cpu/recording-manifest.json').read_text())
assert cpu_manifest['oracle']['sha256']==sha(root/'oracle/build/box3d_oracle')
report={'status':'needs_visual_review','scenes':{},'recordings':{},'cpu_manifest':cpu_manifest}
for variant in ['before','after']:
 folder=root/'recordings/snapshots'/('2026-09-25-small-scene-'+variant);m=json.loads((folder/'recording-manifest.json').read_text());assert m['frames']==300
 assert m['environment']['GPU_PHYSICS_IDLE']=='0' and m['environment']['GPU_PHYSICS_COMPONENT_TGS']=='0'
 expected=base/('baseline-gpu' if variant=='before' else 'qualified-candidate-gpu');assert m['viewer']['sha256']==sha(expected)
 assert (folder/'metrics.json').exists();report['recordings'][variant]=m
for scene in scenes:
 info={}
 for variant in ['before','after']:
  p=root/'recordings/snapshots'/('2026-09-25-small-scene-'+variant)/(scene+'.mp4');frames=decoded(p);assert len(frames)==300,(scene,variant,len(frames))
  info[variant]={'sha256':sha(p),'frames':len(frames),'decoded_sha256':hashlib.sha256('\n'.join(frames).encode()).hexdigest()}
  if variant=='before':before=frames
  else:info['different_frames']=sum(a!=b for a,b in zip(before,frames))
 cpu=root/'recordings/snapshots/000-box3d-cpu'/(scene+'.mp4');frames=decoded(cpu);assert len(frames)==300
 info['cpu']={'sha256':sha(cpu),'frames':len(frames)};report['scenes'][scene]=info
 print(scene,info['different_frames'],'different decoded frames',flush=True)
# Visual review must be supplied after inspecting representative contact sheets.
review=base/'recordings-visual-review.json'
if review.exists():
 r=json.loads(review.read_text());assert r['status']=='ok';assert r['reviewed_scenes']==scenes
 report['visual_review']=r;report['status']='ok'
(base/'recordings-validation.json').write_text(json.dumps(report,indent=2)+'\n')
