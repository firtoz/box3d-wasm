"""Package qualified small-scene raw data; refuse incomplete measurement grids."""
from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
for name,renderer in [('qualification-physics',False),('qualification-renderers',True)]:
 subprocess.run(['python3',str(root/'scripts/plot-small-scene.py'),str(base/name),'unused','--title','archive validation','--validate-only',*(['--renderers'] if renderer else [])],cwd=root,check=True)
subprocess.run(['python3',str(root/'scripts/plot-small-scene-profile.py'),str(base),'unused','--validate-only'],cwd=root,check=True)
assert '272 passed; 0 failed' in (base/'qualification-library.log').read_text()
assert json.loads((base/'recordings-validation.json').read_text())['status']=='ok'
for case in ['color_tail_tests','appended_extent_tests','mass_queries_preserve','destroy_and_reuse_slots']:
 log=(base/('cache-off-'+case+'.log')).read_text();results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',log);assert results and all(int(ok)>0 and int(fail)==0 for ok,fail in results)
files={}
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.log','.py','.png','.jpg'] and not any(x in p.parts for x in ['__pycache__','cache']):files[str(p.relative_to(root))]=p.read_bytes()
for p in (root/'scripts').iterdir():
 if p.suffix in ['.py','.sh','.ts']:files[str(p.relative_to(root))]=p.read_bytes()
files['changes-from-73373dfb.patch']=subprocess.check_output(['git','diff','73373dfb','--','src','scripts','README.md'],cwd=root)
# Full changed sources supplement the patch, including newly added plot scripts.
changed=subprocess.check_output(['git','diff','--name-only','73373dfb','--','src','scripts'],cwd=root,text=True).splitlines()
for name in changed:
 prefix='experiments/gpu-physics/';rel=name.removeprefix(prefix);p=root/rel
 if p.is_file():files['candidate-sources/'+rel]=p.read_bytes()
for label in ['000-box3d-cpu','2026-09-25-small-scene-before','2026-09-25-small-scene-after']:
 d=root/'recordings/snapshots'/label
 for p in d.glob('*.json'):files[str(p.relative_to(root))]=p.read_bytes()
files['REPRODUCE.md']=b'''# Small-scene GPU qualification, RTX 4070 Laptop / Ryzen 9 8945HS

Baseline: 73373dfb. Candidate: changes-from-73373dfb.patch, plus the included
scripts/plot-small-scene.py. Apply the patch from the repository root (paths are
repository-relative). Candidate source copies and binary identities are included.
The raw git/dirty/source_sha256 fields describe the runtime checkout, not the
compiled binary. Use frozen executable SHA-256 identities and build records.
Compiled binaries, caches and videos are excluded; recording hashes/frame counts
are included. The existing Box3D CPU oracle and pinned visual column are unchanged.

Extract into an empty directory. SHA256SUMS.json checks every payload except itself.
Revalidate archived raw results without a GPU:

    python3 scripts/plot-small-scene.py artifacts/small-scene-optimization/qualification-physics unused --title validation --validate-only
    python3 scripts/plot-small-scene.py artifacts/small-scene-optimization/qualification-renderers unused --title validation --validate-only --renderers

To plot, install matplotlib in a virtual environment, omit --validate-only and
supply an output prefix. Chart medians are medians of trial means; shading shows
full trial ranges, not confidence intervals. p50/p95 are medians across trials.

For hardware replication, build both revisions using scripts/build-native-cache.sh;
Sokol also requires --features external-c-shim and its CMake build. Freeze the
binaries, update their paths in the included qualification runners and use fresh
output directories. These runners preserve paired order, four substeps, sleep off,
90 warmup + 240 measured steps, eight CPU workers and normal desktop load.
Baseline uses the previous global solver prefix20 configuration; candidate uses
adaptive prefix plus global command replay. Neither reduces solver iterations or
moves physics to the CPU. Component-solver runs are separate diagnostics.

Both headline GPU variants retain the engine's ordinary GPU phase timestamps;
extra host timing and broadphase instrumentation are off. Instrumented pilot
profiles are separate evidence, not mixed into headline measurements. Step-call
wall time and completion wait sum to completed latency; GPU execution overlaps
them, so never add GPU phase durations to those host wall times. The separate
step-plus-host-mirror pass uses a fresh world and is not an additive decomposition.

Renderer comparisons use matched actual framebuffers within each renderer. Inspect
raw manifests for GPU/driver identity, display size, render settings and machine
load. FPS comes from completed application cadence, not submission time alone.
'''
files['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())},indent=2)+'\n').encode()
archive=root/'benchmarks/rtx4070-small-scene-2026-09-25-raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
archive.with_suffix('.gz.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(len(files),'files;',archive.stat().st_size,'bytes')
