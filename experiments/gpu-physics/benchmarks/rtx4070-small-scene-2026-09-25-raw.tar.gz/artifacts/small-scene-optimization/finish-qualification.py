"""Wait for the live renderer runner, then validate and record sequentially."""
from pathlib import Path
import fcntl,json,subprocess
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
own=(base/'finish-qualification.lock').open('w')
fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
with (base/'qualification-renderers/runner.lock').open('r') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 rows=json.loads((base/'qualification-renderers/jobs.json').read_text())
 assert len(rows)==162 and all(r['status']=='ok' for r in rows),'Renderer run did not complete successfully'
 print('Renderer measurements complete; validating and plotting',flush=True)
 subprocess.run([str(base.parent/'startup-optimization/plot-env/bin/python'),'scripts/plot-small-scene.py',str(base/'qualification-renderers'),'benchmarks/rtx4070-small-scene-renderers-2026-09-25','--title','RTX 4070 Laptop / Ryzen 9 8945HS — 2026-09-25','--renderers'],cwd=root,check=True)
 print('Starting cache-off checks and matched recordings',flush=True)
 subprocess.run(['python3',str(base/'record-qualified-scenes.py')],cwd=root,check=True)
 subprocess.run(['python3',str(base/'validate-recordings.py')],cwd=root,check=True)
 print('Automated validation complete; manual chart and scene review remains',flush=True)
