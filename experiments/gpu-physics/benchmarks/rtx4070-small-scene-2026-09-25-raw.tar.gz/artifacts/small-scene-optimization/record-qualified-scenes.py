"""Run only after measurements: cache-off checks and matched visual recordings."""
from pathlib import Path
import json,os,subprocess,hashlib
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
rows=json.loads((base/'qualification-renderers/jobs.json').read_text());assert len(rows)==162 and all(r['status']=='ok' for r in rows),'Renderer qualification incomplete'
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))};env.update(json.loads((base/'baseline-sweep/manifest.json').read_text())['environment'])
def run(cmd,env,path):
 with path.open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=log,check=True)
off=env.copy()
for k in off:
 if k.startswith('GPU_PHYSICS_NATIVE_') or k in ['GPU_PHYSICS_FULL_REPLAY','GPU_PHYSICS_GLOBAL_REPLAY','GPU_PHYSICS_GRAPH_MEMO']:off[k]='0'
for case in ['color_tail_tests','appended_extent_tests','mass_queries_preserve','destroy_and_reuse_slots']:
 run(['target/native-cache-build/release/deps/gpu_physics-f43e538e836f4d30',case,'--test-threads=1','--nocapture'],off,base/('cache-off-'+case+'.log'))
for variant,binary,prefix in [('before','baseline-gpu','20'),('after','qualified-candidate-gpu','auto')]:
 label='2026-09-25-small-scene-'+variant;dest=root/'recordings/snapshots'/label
 assert not dest.exists(),'Prior recording attempt retained: '+label
 recordenv=env|{'GPU_RECORD_BIN':str(base/binary),'GPU_PHYSICS_COMPONENT_TGS':'0','GPU_PHYSICS_IDLE':'0','GPU_PHYSICS_GLOBAL_REPLAY':'1' if variant=='after' else '0','GPU_PHYSICS_COLOR_PREFIX':prefix,'FRAMES':'300','METRIC_RUNS':'1'}
 run(['./scripts/record-snapshot.sh',label],recordenv,base/('record-'+variant+'.log'))
print('Cache-off checks and both scene recordings complete',flush=True)
