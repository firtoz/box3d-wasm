import pathlib,json,os,subprocess,statistics,hashlib
r=pathlib.Path('/home/frtn/work/2026/box3d-wasm/experiments/gpu-physics');o=r/'artifacts/small-scene-optimization';out=o/'color-prefix-pilot';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))};env.update(json.loads((o/'baseline-sweep/manifest.json').read_text())['environment'])
b=o/'global-replay-gpu'
(out/'manifest.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith(('GPU_','VK_','WGPU_','__NV','__GLX','DISPLAY'))},'trials':2,'counts':[100,1000,5000], 'prefixes':['auto','0','4','8','20']},indent=2))
for n in [100,1000,5000]:
 for trial in range(1,3):
  for enabled in (['auto','0','4','8','20'] if trial%2 else ['20','8','4','0','auto']):
   p=out/f'{n}-{trial}-{enabled}.json'
   with p.with_suffix('.log').open('w') as log:subprocess.run([str(b),'--scene','falling-cubes','--bodies',str(n),'--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1'],cwd=r,env=env|{'GPU_PHYSICS_GLOBAL_REPLAY':'1','GPU_PHYSICS_COLOR_PREFIX':str(enabled)},stdout=log,stderr=log,check=True,timeout=300)
   d=json.loads(p.read_text())['raw_runs'][0];print(n,trial,enabled,round(statistics.mean(d['completed_step_ms']),3),'encode',round(statistics.mean(d['encode_ms']),3),flush=True)
