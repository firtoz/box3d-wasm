import pathlib,json,os,subprocess,shutil,statistics,hashlib
r=pathlib.Path('/home/frtn/work/2026/box3d-wasm/experiments/gpu-physics');o=r/'artifacts/small-scene-optimization/host-profile';o.mkdir(exist_ok=True)
b=o/'profile-gpu';
if not b.exists(): shutil.copy2(r/'target/native-cache-build/release/gpu-physics',b)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))};env.update(json.loads((o.parent/'baseline-sweep/manifest.json').read_text())['environment']);env['GPU_PHYSICS_PROFILE_HOST']='1'
(o/'manifest.json').write_text(json.dumps({'environment':{k:v for k,v in env.items() if k.startswith(('GPU_','VK_','WGPU_','__NV','__GLX','DISPLAY'))},'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'counts':[5,100,1000,2000,5000,10000]},indent=2))
for n in [5,100,1000,2000,5000,10000]:
 p=o/f'{n}.json'
 if not p.exists():
  with p.with_suffix('.log').open('w') as log:subprocess.run([str(b),'--scene','falling-cubes','--bodies',str(n),'--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1'],cwd=r,env=env,stdout=log,stderr=log,check=True,timeout=300)
 d=json.loads(p.read_text())['raw_runs'][0];h=d['host_profile'];assert len(h['step_call_ms'])==240
 assert all(abs(a+b-c)<=0.000151 for a,b,c in zip(h['step_call_ms'],h['completion_wait_ms'],d['completed_step_ms']))
 print(n,{k:round(statistics.mean(v),3) for k,v in h.items()},flush=True)
