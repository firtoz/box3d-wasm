import pathlib,json,os,subprocess,statistics,hashlib
r=pathlib.Path('/home/frtn/work/2026/box3d-wasm/experiments/gpu-physics');o=r/'artifacts/small-scene-optimization';out=o/'independent-groups-pilot';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))};env.update(json.loads((o/'baseline-sweep/manifest.json').read_text())['environment'])
b=o/'global-replay-gpu'
(out/'manifest.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith(('GPU_','VK_','WGPU_','__NV','__GLX','DISPLAY'))},'trials':2,'counts':[5,100,1000,2000,5000,10000], 'variants':['baseline','global-auto','component']},indent=2))
for n in [5,100,1000,2000,5000,10000]:
 for trial in range(1,3):
  for enabled in (['baseline','global-auto','component'] if trial%2 else ['component','global-auto','baseline']):
   p=out/f'{n}-{trial}-{enabled}.json'
   with p.with_suffix('.log').open('w') as log:subprocess.run([str(b),'--scene','mixed-stacks','--bodies',str(n),'--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1'],cwd=r,env=env|{'GPU_PHYSICS_GLOBAL_REPLAY':'0' if enabled=='baseline' else '1','GPU_PHYSICS_COLOR_PREFIX':'20' if enabled=='baseline' else 'auto','GPU_PHYSICS_COMPONENT_TGS':'1' if enabled=='component' else '0','GPU_PHYSICS_PROFILE_HOST':'1'},stdout=log,stderr=log,check=True,timeout=300)
   d=json.loads(p.read_text())['raw_runs'][0];assert d['live_contacts']>0 and len(d['completed_step_ms'])==240
   print(n,trial,enabled,round(statistics.mean(d['completed_step_ms']),3),'encode',round(statistics.mean(d['encode_ms']),3),flush=True)
