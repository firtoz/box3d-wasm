"""Create visual review sheets only after all matched scene recordings exist."""
from pathlib import Path
import json,subprocess,tempfile
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
report=json.loads((base/'recordings-validation.json').read_text())
labels=[('Box3D CPU','000-box3d-cpu'),('GPU before','2026-09-25-small-scene-before'),('GPU after','2026-09-25-small-scene-after')]
out=base/'review-sheets';out.mkdir(exist_ok=True)
for scene in report['scenes']:
 sheet=Image.new('RGB',(1200,785),'#eeeeee');draw=ImageDraw.Draw(sheet)
 draw.text((10,8),scene+' — columns: frames 0 / 100 / 299',fill='black')
 with tempfile.TemporaryDirectory(prefix='scene-frames-') as tmp:
  tmp=Path(tmp)
  for row,(label,folder) in enumerate(labels):
   pattern=tmp/(str(row)+'-%02d.png')
   subprocess.run(['ffmpeg','-v','error','-threads','1','-i',str(root/'recordings/snapshots'/folder/(scene+'.mp4')),'-vf',"select='eq(n,0)+eq(n,100)+eq(n,299)',scale=400:225",'-fps_mode','passthrough','-threads','1',str(pattern)],check=True)
   paths=sorted(tmp.glob(str(row)+'-*.png'));assert len(paths)==3
   y=30+row*250;draw.text((10,y),label,fill='black')
   for col,p in enumerate(paths):
    with Image.open(p) as frame:sheet.paste(frame,(400*col,y+20))
 sheet.save(out/(scene+'.jpg'),quality=90)
 print(scene,flush=True)
print('Sheets generated; human/model visual inspection still required, no review status set')
