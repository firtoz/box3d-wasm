"""Revalidate the distributable archive in a fresh directory without a GPU."""
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,tarfile,tempfile
root=Path(__file__).resolve().parents[2]
archive=root/'benchmarks/rtx4070-small-scene-2026-09-25-raw.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==archive.with_suffix('.gz.sha256').read_text().split()[0]
with tempfile.TemporaryDirectory(prefix='small-scene-evidence-') as tmp:
 dst=Path(tmp)
 with tarfile.open(archive,'r:gz') as tar:
  seen=set()
  for member in tar.getmembers():
   name=PurePosixPath(member.name)
   assert member.isfile() and not name.is_absolute() and '..' not in name.parts
   assert member.name not in seen;seen.add(member.name)
   target=dst/member.name;target.parent.mkdir(parents=True,exist_ok=True)
   target.write_bytes(tar.extractfile(member).read())
 hashes=json.loads((dst/'SHA256SUMS.json').read_text())
 assert seen==set(hashes)|{'SHA256SUMS.json'}
 for name,want in hashes.items():assert hashlib.sha256((dst/name).read_bytes()).hexdigest()==want,name
 base=dst/'artifacts/small-scene-optimization'
 for name,flags in [('qualification-physics',[]),('qualification-renderers',['--renderers'])]:
  subprocess.run(['python3',str(dst/'scripts/plot-small-scene.py'),str(base/name),'unused','--title','Archive validation','--validate-only',*flags],cwd=dst,check=True)
 subprocess.run(['python3',str(dst/'scripts/plot-small-scene-profile.py'),str(base),'unused','--validate-only'],cwd=dst,check=True)
 print(f'Archive SHA-256, {len(hashes)} payload hashes, both qualification grids and diagnostic profiles verified',flush=True)
