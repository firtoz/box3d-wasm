import json, hashlib, math, statistics, shutil
from pathlib import Path
base=Path(__file__).resolve().parent
out=base/'crossover'; prof=base/'profile';prof.mkdir(exist_ok=True)
manifest=json.loads((out/'manifest.json').read_text())
rows=[]
for count in (80000,100000):
 p=out/f'{count}-original.json';d=json.loads(p.read_text());h=hashlib.sha256(p.read_bytes()).hexdigest()
 assert len(d['raw_runs'])==len(d['cpu_trials'])==3
 for i,(raw,cpu) in enumerate(zip(d['raw_runs'],d['cpu_trials'])):
  v={k:d[k] for k in ['scene','adapter','git','dirty','source_sha256','profile','bodies','sub_steps','dt','warmup_steps','timed_steps','sleep','timing_path','notes']}
  a=sorted(raw['completed_step_ms']);q=lambda f:a[max(0,math.ceil(f*len(a))-1)]
  v.update(derived_from=dict(file=p.name,sha256=h,run_index=i),raw_runs=[raw],runs=1,cpu_trials=[cpu],cpu_trial_count=1,completed_step=dict(p50_ms=q(.5),p95_ms=q(.95)))
  target=out/f'{count}-physics-gpu-{i+1}.json';target.write_text(json.dumps(v,indent=2)+'\n')
  copy=prof/f'{count}-batched-global-{i+1}.json';shutil.copyfile(target,copy)
  rows.append(dict(count=count,variant='batched-global',trial=i+1,returncode=0,raw_sha256=hashlib.sha256(copy.read_bytes()).hexdigest(),mean_ms=statistics.mean(a),p50_ms=q(.5),p95_ms=q(.95),phase_mean_ms={k:statistics.mean(raw[k+'_ms']) for k in ['broadphase','narrowphase','graph','prepare','solve']}))
(prof/'manifest.json').write_text(json.dumps(dict(source=manifest,counts=[80000,100000],variants=['batched-global'],trials=3),indent=2)+'\n')
(prof/'trials.json').write_text(json.dumps(rows,indent=2)+'\n')
