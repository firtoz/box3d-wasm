#!/usr/bin/env python3
"""Matched CPU/GPU trials using native benchmark's alternating fresh-world runs.
Original aggregate JSON is retained; per-trial views only adapt existing plotting.
"""
import hashlib,json,math,os,runpy,subprocess
from pathlib import Path
from types import SimpleNamespace
BASE=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('GPU_SCALING_ROOT', str(BASE.parents[2])))
OUT=BASE/'crossover'
OUT.mkdir(exist_ok=False)
B=runpy.run_path(str(ROOT/'scripts/bench-falling-cubes.py'))
m=json.loads((BASE/'manifest.json').read_text());m['arguments'].update(counts=[80000,100000],modes=['physics-cpu','physics-gpu'],trials=3,gpu_solver='global',require_idle=False)
m['purpose']='Repeated completed-physics CPU/GPU crossover; native benchmark alternates CPU-before-GPU / GPU-before-CPU per fresh-world trial. Renderer FPS is separate.'
m['environment'].update(GPU_PHYSICS_COMPONENT_TGS='0',GPU_PHYSICS_COLOR_PREFIX='20',GPU_PHYSICS_GRAPH_BATCHED='1')
for name in ['cpu','gpu']:
 b=m['binaries'][name];assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256']
B['write_json'](OUT/'manifest.json',m);B['write_json'](OUT/'stopped.json',{})
a=SimpleNamespace(**m['arguments']);env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_','GPU_SOKOL_'))};env.update(m['environment'])
rows=[]
for count in a.counts:
 aggregate=OUT/f'{count}-original.json'
 cmd=[m['binaries']['gpu']['path'],'--scene','falling-cubes','--bodies',str(count),'--warmup',str(a.warmup),'--frames',str(a.timed),'--no-sleep','--bench',str(aggregate),'--metric-runs',str(a.trials)]
 before=B['system']();assert not before['ac'] or '1' in before['ac'].values()
 B['write_json'](OUT/f'{count}-run.json',dict(command=cmd,before=before))
 with aggregate.with_suffix('.log').open('w') as log:
  result=subprocess.run(cmd,cwd=ROOT,env=env|{'GPU_BENCH_CUBES':str(count)},stdout=log,stderr=log,timeout=1200)
 after=B['system']();B['write_json'](OUT/f'{count}-run.json',dict(command=cmd,before=before,after=after,returncode=result.returncode))
 assert not after['ac'] or '1' in after['ac'].values()
 if result.returncode: raise RuntimeError(f'Invalid trial aggregate: {aggregate}')
 data=json.loads(aggregate.read_text());assert len(data['raw_runs'])==len(data['cpu_trials'])==a.trials
 assert data['sub_steps']==4 and abs(data['dt']-1/60)<1e-7
 parent_hash=hashlib.sha256(aggregate.read_bytes()).hexdigest()
 for index,(gpu,cpu) in enumerate(zip(data['raw_runs'],data['cpu_trials'])):
  assert cpu['sub_steps']==4 and cpu['warmup_steps']==a.warmup and cpu['timed_steps']==a.timed
  gpu_view={k:data[k] for k in ['scene','adapter','git','dirty','source_sha256','profile','bodies','sub_steps','dt','warmup_steps','timed_steps','sleep','timing_path','notes']}
  gpu_view['derived_from']=dict(file=aggregate.name,sha256=parent_hash,run_index=index)
  values=sorted(gpu['completed_step_ms']);quantile=lambda q:values[max(0,math.ceil(q*len(values))-1)]
  gpu_view.update(raw_runs=[gpu],runs=1,cpu_trials=[cpu],cpu_trial_count=1,completed_step=dict(p50_ms=quantile(.5),p95_ms=quantile(.95)))
  for mode,view in [('physics-cpu',cpu),('physics-gpu',gpu_view)]:
   path=OUT/f'{count}-{mode}-{index+1}.json';B['write_json'](path,view)
   row=dict(count=count,mode=mode,trial=index+1,status='ok',command=cmd,aggregate=aggregate.name,aggregate_sha256=parent_hash,aggregate_run_index=index,before=before,after=after,load_gate_enabled=False)
   row.update(B['metrics'](view,mode,path,a,count));rows.append(row)
   print(count,mode,index+1,round(row['mean_ms'],3),'ms',flush=True)
 B['write_json'](OUT/'trials.json',rows)
