#!/usr/bin/env python3
import hashlib,json,os,runpy,statistics,subprocess
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/home/frtn/work/2026/box3d-wasm/experiments/gpu-physics')
OUT=Path(__file__).resolve().parent
B=runpy.run_path(str(ROOT/'scripts/bench-falling-cubes.py'))
source=json.loads((OUT.parent/'pair-capacity/manifest.json').read_text())
args=SimpleNamespace(**source['arguments'])
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_','GPU_SOKOL_'))}
env.update(source['environment']);env.update(GPU_PHYSICS_COMPONENT_TGS='0',GPU_PHYSICS_COLOR_PREFIX='20',GPU_PHYSICS_GRAPH_BATCHED='1')
variants={'before':OUT.parent/'pair-capacity/gpu-physics','after':OUT/'gpu-physics'}
counts=[15000,50000,60000]
patch=subprocess.check_output(['git','diff','HEAD'],cwd=ROOT);(OUT/'source.patch').write_bytes(patch)
manifest=dict(source=source,variants={name:dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in variants.items()},counts=counts,trials=3,environment=env,source_patch_sha256=hashlib.sha256(patch).hexdigest())
# Preserve only benchmark settings, never unrelated inherited environment secrets.
manifest['environment']={k:v for k,v in env.items() if k.startswith(('GPU_PHYSICS_','GPU_BENCH_','GPU_SOKOL_','WGPU_','VK_','__NV_','__GLX_')) or k=='DISPLAY'}
manifest['compiled_base']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
manifest['baseline_compiled_base']='9a66819d5267789a2525309dc9dd55499c2dbb01'
manifest['source_git_note']='source.git is inherited original sweep metadata; use the explicit compiled base fields.'
B['write_json'](OUT/'manifest.json',manifest)
rows=[]
for count in counts:
 for trial in range(1,4):
  for variant in (['before','after'] if trial%2 else ['after','before']):
   path=OUT/f'{count}-{variant}-{trial}.json'
   command=[str(variants[variant]),'--scene','falling-cubes','--bodies',str(count),'--warmup',str(args.warmup),'--frames',str(args.timed),'--no-sleep','--bench',str(path),'--metric-runs','1']
   row=dict(count=count,trial=trial,variant=variant,command=command,before=B['system']())
   with path.with_suffix('.log').open('w') as log:
    r=subprocess.run(command,cwd=ROOT,env=env|{'GPU_BENCH_CUBES':str(count)},stdout=log,stderr=log,timeout=600)
   row.update(after=B['system'](),returncode=r.returncode)
   if r.returncode:
    rows.append(row);B['write_json'](OUT/'trials.json',rows);raise RuntimeError(path)
   data=json.loads(path.read_text());row.update(B['metrics'](data,'physics-gpu',path,args,count))
   assert data['sub_steps']==4 and abs(data['dt']-1/60)<1e-7
   raw=data['raw_runs'][0]
   row['phase_mean_ms']={phase:statistics.mean(raw[phase+'_ms']) for phase in ['broadphase','narrowphase','graph','prepare','solve']}
   row['raw_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();rows.append(row);B['write_json'](OUT/'trials.json',rows)
   print(count,variant,trial,round(row['mean_ms'],3),'ms',flush=True)
