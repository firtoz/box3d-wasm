# Full-width identity preparation: before/after diagnostic

This compares the preserved runtime-capacity binary with the later full-width
retained-contact hash and canonical-cell broadphase binary. It does not isolate
those two changes from each other, and neither binary supports 100,000 cubes yet.
No solver settings or falling-cube scene parameters were reduced.

`compare.py` alternates the two executables over three trials at each count.
`manifest.json` records executable SHA-256 digests and the applied environment.
`source.patch` identifies the after source over git HEAD 9a66819d; the archived
baseline source and executable hash identify the before build. Both source
patches were checked against HEAD 9a66819d. The nested source.git field is
inherited metadata from the original sweep, not the compiled base of this run;
use compiled_base and baseline_compiled_base in the outer manifest. The source fingerprint
inside each raw benchmark JSON is a runtime working-tree fingerprint, not a
compiled-source identifier; use the outer binary/source manifests instead.
Binaries remain local and are omitted from the source/raw archive. Rebuild with
`scripts/build-native-cache.sh build --release` in the experiment after applying
the appropriate source snapshot to the recorded base revision.

All trials use falling-cubes v1, sleep disabled, dt 1/60, four substeps, global
color solving, batched canonical coloring, 90 warmup and 240 timed steps. The
headline metric is completed GPU physics step (submit plus wait, no pose mirror).
The raw JSON also contains incidental CPU oracle measurements; these are not the
matched CPU crossover dataset or renderer FPS results. No idle gate was used.
Before/after system snapshots retain load, AC connection, NVIDIA temperature,
clocks, power draw, and power-limit reports. These are endpoint snapshots, not a
continuous power trace or a controlled fixed-power comparison.

The after engine passed all 258 NVIDIA native-cache library tests. Separate
candidate-set fixtures compare the canonical grid against the independent
all-pairs matrix, including exact cell-hash collisions and retained-contact
mutations. Raw append counts must equal the unique pair count. Capacity-loss or
invalid simulation exits invalidate a trial; they must not count as speedups.
The full-width identity migration and full renderer/CPU sweep remain unfinished.
