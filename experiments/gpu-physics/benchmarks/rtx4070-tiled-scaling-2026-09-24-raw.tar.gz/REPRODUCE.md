# RTX 4070 Laptop tiled scaling evidence

The baseline is commit 1559a049 and the measured implementation is 533f14cd.
The source patch between these commits, engine input hashes, preserved executable
hashes and build logs are included. Executables and MP4 files are not embedded;
recording metadata and hashes identify the 19 affected scene pairs.

Use a checkout with native build dependencies as documented in the experiment
README. Build CPU and GPU native samples, the CPU oracle/bridge and the native-cache
Rust executable before timing. Build external-C-shim and direct variants
sequentially. Preserve both versions' GPU executables for the comparison.

The runner copies under scripts/ are the measurement and plotting tools.
Run bench-falling-cubes.py with --workers 8 --gpu-solver global --timeout 900.
Use the GPU/driver/display environment recorded in final-sweep/manifest.json;
paths in manifests are original-machine locations and must be adjusted on another
machine. Normal desktop load is intentional; do not enable --require-idle.

For the before/after comparison, use compare-falling-binaries.py with the
baseline manifest, --binary before=<baseline-executable>,
--binary after=<candidate-executable>, --counts 100000 --trials 3.
Its raw windows match the sweep: 90 warmup + 240 measured steps, dt 1/60,
four substeps, disabled sleep. These timings include collisions and landing.

Use plot-falling-cubes.py for CPU/GPU throughput, application cadence and p50/p95;
plot-falling-resources.py for GPU phases and primary buffer memory;
plot-falling-solvers.py for the final-100k before/after comparison.
Plotters require matplotlib; runners use Python's standard library.

Retained invalid rows and logs must not be discarded. A stopping reason of
invalid is not proof of a hardware capacity limit: consult the final report's
failure diagnosis. Older pre-tiling 150k failures remain in the repository's
rtx4070-complete-scene-2026-09-24-raw.tar.gz archive and its SHA-256 sidecar.
CPU/GPU application settings, exact hardware/driver, AC state and power/clock
snapshots are in the manifests and trial records. GPU allocation figures cover
primary simulation buffers, not total VRAM. Do not extrapolate from FLOPS alone.
