import json,os,select,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];os.chdir(root)
try:
 fd=os.pidfd_open(563898);p=select.poll();p.register(fd,select.POLLIN)
 print('Waiting for qualification process 563898',flush=True);p.poll();os.close(fd)
except ProcessLookupError:pass
folder=Path('artifacts/dispatch-scaling')
status=json.loads((folder/'final-qualification-status.json').read_text())
assert all(r['status']=='passed' for r in status), 'qualification queue failed or remains incomplete'
python='/tmp/falling-plots-env/bin/python'
commands=[
 [python,'scripts/plot-falling-cubes.py',str(folder/'final-sweep'),'benchmarks/rtx4070-tiled-scaling-2026-09-24','--title','Ryzen 9 8945HS / RTX 4070 Laptop • NVIDIA 610.57.04'],
 [python,'scripts/plot-falling-resources.py',str(folder/'final-sweep'),'benchmarks/rtx4070-tiled-resources-2026-09-24','--title','RTX 4070 Laptop • NVIDIA 610.57.04 • GPU costs and allocations'],
]
for i,command in enumerate(commands):
 print('Generating',command[3],flush=True)
 with (folder/f'final-plot-{i}.log').open('w') as f:
  subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Charts generated. Review stop reasons, raw data, images and final 200k qualification before publication claims.',flush=True)
