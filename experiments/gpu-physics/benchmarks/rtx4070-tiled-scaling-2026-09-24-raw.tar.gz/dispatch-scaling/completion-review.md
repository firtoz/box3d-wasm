# Completion review — 2026-09-24

Measured implementation: 533f14cd; baseline: 1559a049. Engine source and executable
hashes are checked by audit-final-sweep.py. Documentation checkpoint: 085c8330.

| Requirement | Evidence inspected | Result |
|---|---|---|
| Tiled direct, indirect and native cached dispatch | dispatch.rs, physics/dispatch.wgsl, four-mode GPU boundary fixture and full library log | Pass at 0/1/65535/65536/65537 workgroups; production 131075-shape lifecycle passes with cache on/off |
| Dirty clearing preserves lifecycle | dirty_contact_range fixture, root_free_scan fixture, production callback/event/remap/reuse fixture | Pass, including retired history, untouched unused range and mesh fallback |
| Graph optimization preserves assignments/quality | batch_memo input-change fixture, independent ordered-greedy reference, 15000-cube impact-equivalence fixture | Pass for changed endpoints, masks, order, slot reuse, early insertion and partial groups; original 1e-5 assertion retained |
| 200000 colliding cubes | Three physics raw records and three direct application records; final sweep audit | Pass; 410745 contacts, all 200000 awake at step330, no rejected runs |
| >=20% faster at100k | Six alternating raw runs, source reconstruction and executable hashes | +30.273% throughput, -23.238% completed step time |
| Matched CPU/GPU and both renderers | All360 raw trials, identical environment/settings,8CPU workers,3trials/count,90+240steps | Pass; all6 paths stop at <=10/s; no idle gate or discarded trials |
| Charts and documentation | Rendered throughput, latency, resource and paired100k charts; README links and threshold tables | Reviewed, all file links resolve; primary allocation and workload limits stated |
| Correctness | Final267-test suite, native-cache/graph-cache opt-outs, native replacement and normal/strict drag logs | Pass; current large-world qualification NVIDIA-only |
| Affected scene recordings |19CPU/currentGPU pairs,300frames each, binary/clip hashes;5contact sheets with baselineGPU third | Recorded before solver commit; final-frame visual review shows no apparent new GPU/baseline discrepancy. CPU differences such as joint-chain pile already present in baseline. Still-frame review is supplementary to regression tests, not a numerical equivalence claim. |
| Raw results and failures | SHA-256 archive with runner copies, manifests, all intermediate logs, source patches and power snapshots | Packager reads every member back; older failed150k runs remain in linked pre-tiling archive |
| Keep Box3D/WASM unchanged | git diff1559a049 for submodule, WASM package and WASM artifacts; submodule working status | Empty |

Limitations: 200k is a measured FPS stop, not memory exhaustion. Primary simulation
buffers use3.42GiB excluding renderer/driver/staging. Timed workload is an awake
falling pile over steps91–330, not arbitrary games or continuous spawning. Physics
crossover at20k has overlapping trial ranges; all three pairs exceed20% at30k.
CPU remains faster at small counts. No FLOPS-based cross-GPU scaling claim.
All explicit performance targets met. No new commit or push after085c8330.
