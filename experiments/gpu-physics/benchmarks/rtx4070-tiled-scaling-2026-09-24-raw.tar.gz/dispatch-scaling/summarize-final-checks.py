import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parents[2]
folder=root/'artifacts/dispatch-scaling'
checks={
 'full_library':('precommit-stable-library.log','267 passed; 0 failed'),
 'native_cache_off_boundary':('final-uncached-boundary.log','1 passed; 0 failed'),
 'graph_memo_off':('stable-buckets-off.log','1 passed; 0 failed'),
 'graph_memo_input_changes':('stable-buckets-cases.log','1 passed; 0 failed'),
 'impact_equivalence':('stable-buckets-impact.log','1 passed; 0 failed'),
 'strict_ground_drag':('final-strict-drag.log','PASS ground-contact comparison'),
}
result={}
for name,(filename,expected) in checks.items():
 p=folder/filename;text=p.read_text();assert expected in text,(name,expected)
 result[name]={'log':filename,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
               'result_lines':[line for line in text.splitlines() if expected in line]}
status=json.loads((folder/'final-qualification-status.json').read_text())
result['native_checks_and_builds']=[row for row in status if row['name']!='final-sweep']
assert all(row['status']=='passed' and row['returncode']==0 for row in result['native_checks_and_builds'])
full=(folder/'precommit-stable-library.log').read_text()
required=['linear_dispatch_grid_boundaries_and_unique_coverage',
          'tiled_dispatch_direct_indirect_and_cached_cover_each_element_once',
          'tiled_physics_dispatch_preserves_callbacks_events_and_remapping',
          'dirty_contact_range_preserves_retired_history_and_skips_unused_slots',
          'root_free_scan_preserves_lowest_slots_and_mesh_pool',
          'batch_memo_matches_greedy_after_input_changes_and_slot_reuse',
          'falling_cube_solver_schedules_match_through_impact']
result['required_cases']={name:next(line for line in full.splitlines() if name+' ... ok' in line) for name in required}
result['scope']='NVIDIA final implementation; graph memo and native-cache opt-out are separate checks. AMD solver qualification is not claimed. Large-count capacity and full renderer results are recorded separately.'
(root/'benchmarks/rtx4070-tiled-validation-2026-09-24.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified final regression evidence and native build/check statuses.')
