import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2]
labels=['000-box3d-cpu','2026-09-24-tiled-stable-buckets']
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={}
scene_files=sorted(p.name for p in (root/'recordings/snapshots'/labels[1]).glob('*.mp4'))
assert len(scene_files)==19
for label in labels:
 directory=root/'recordings/snapshots'/label
 manifest=json.loads((directory/'recording-manifest.json').read_text())
 clips=[]
 for name in scene_files:
  path=directory/name
  data=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,width,height','-of','json',str(path)]))['streams'][0]
  assert int(data['nb_frames'])==300
  clips.append(dict(file=path.name,sha256=digest(path),**data))
 assert len(clips)==19
 result[label]=dict(manifest=manifest,clips=clips,metrics_sha256=digest(directory/'metrics.json'))
assert [p['file'] for p in result[labels[0]]['clips']]==[p['file'] for p in result[labels[1]]['clips']]
assert result[labels[1]]['manifest']['viewer']['sha256']==digest(root/'artifacts/dispatch-scaling/final-binaries/gpu')
assert result[labels[0]]['manifest']['oracle']['sha256']==digest(root/'oracle/build/box3d_oracle')
viewer=(root/'compare/snapshots.js').read_text()
grid=json.loads(viewer.split('window.GPU_COMPARE = ',1)[1].rstrip().removesuffix(';'))
assert grid['snapshots'][0]['id']==labels[0]
result['note']='CPU oracle unchanged; GPU recording binary matches the final measured binary. Recorded before implementation commit as required. 19 scenes, 300 frames each, CPU first in comparison grid.'
(root/'benchmarks/rtx4070-tiled-recordings-2026-09-24.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['note'])
