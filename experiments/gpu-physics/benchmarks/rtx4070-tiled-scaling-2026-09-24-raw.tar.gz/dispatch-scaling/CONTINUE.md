# Latest: 200k target passes firstphysics/direct; repeats live

exec77075 verifiedlive, final-sweep200k physicsGPUtrial2. Firstphysics200kpassed
~9.8steps/s,p50 94.6963,p95 127.2844ms,step330,livecontacts410745,
awake200000,primarybytes3674669472(~3.42GiB). Firsttwo directGPU200k valid9.7FPS
both; thirdstillrequired. No failures. Fourotherpaths already10FPS-stopped.
MainGPUphysics/direct likelystop200k butwaitfor3trialmedians,notassumption.
exec43812 autochartswaitingparent563898; don'tduplicateoroverlapheavyjobs.

READMEclarificationsadded: rawcpu_win_validated flagishardcodedfalseinsingle
--bench output; aggregate matched3trialmulti-pathsweep establishesreportedCPU
crossovers. Rawgit/source_sha256areruntimeworkingtreecontext,notcompiled
fingerprints; frozenbinarySHA+enginehashes/patch/buildlogsidentifymeasuredcode.
Noenginechanges. review-recordings.py nowthreecolumns CPU/currentGPU/baselineGPU
(2026-09-24-throughput-scaling), toseparateexistingdifferencesfromnewregressions;
onlysyntaxchecked, runaftermeasurementswith/tmp/falling-plots-env/bin/python.

Stillneedremaining200ktrials/stops,autofiguresvisualreview,recordingreview,
finalREADME/thresholds/limits+docs,rawarchiveandcompletionaudit. No newcommits.

# Latest: 200k qualification LIVE; 150k all3trials qualified

exec77075 verifiedlive; final-sweep200k physicsGPUtrial1. 150kmedians:
physicsCPU6.81/GPU13.02steps/s; directCPU6.43/GPU12.96FPS; GPUSokol8.73FPS.
Fourterminalpaths nowin stopped.json: CPU Sokol80k; CPUphysics150k;
CPUdirect150k; GPU Sokol150k. Allstops10FPSthreshold, noinvalidruns.
GPUphysics/directcontinue200k (and400kifstillabove10FPS).
exec43812 postplotterwaitingforparent563898;donotduplicateorstartheavywork.
All19recordingsand267tests/nativegatesalreadydone;finaldata/visualreview/docs/
archive/auditremaining. No newcommits/pushesauthorized. Goalactive.

# Latest: 150k third round live (verified wait)

exec77075 verifiedlive, final-sweep150k physicsGPUtrial3. GPUphysfirsttwo13.0/s
bothvalid; CPUphysallthree6.7/7.0/6.8/s. GPU Sokolfirsttwo8.6/8.7FPS; directGPU
firsttwo13.0/12.9FPS; CPUdirectfirsttwo6.4FPS. No validationfailures. Remaining
thirdGPUphysics+renderers mustfinishbefore200k. stopped.jsonstillonlyCPU Sokol80k
untilall150kpathgroupscomplete. exec43812 plotterqueuedafterparent563898 ends.
No newcode/binarychanges. Keepgoalactive; no commit/pushauthorized.

# Latest: all three GPU paths pass first150k trial; repeats still live

exec77075 verifiedlive. final-sweep at150k SokolGPUtrial2. AllfirstGPUtrialsat
150k passed: physics13.0steps/s, Sokol8.6FPS,direct13.0FPS. DirectGPUtrial2
12.9FPS also valid. CPUphysicsfirst6.7, CPUdirectfirsttwo6.4; thesearebelow10
butstopped.json updatesafterall3trials. StillonlyterminalpathCPU Sokol80k.
No validationfailures. First150kphysics completedstep330/livecontacts305913/
awake_dynamic150000; primarybuffers3595069472bytes (~3.35GiB).
Thiscrossesold150kdispatchfailureinallthreeGPUmodes, butfinalrepeatedcountand
200ktargetstillpending. No source/binarychanges thisturn.

exec43812 postplotterstillwaitingforparent563898;don'tduplicategeneration.
Finalrawarchivepackagerandrecordingscontactsheethelperpreparedinpreviousnotes.
Keepgoalactive: remainingrepeats,200k(andfurtherif>10),allstops,charts/README/
docs/rawarchive pluscompletionauditrequired. No furthercommit/pushauthorized.

# Latest: 150k sweep live; baseline source independently verified

exec77075 verifiedlive; final-sweep at150k physicsCPUtrial1. 100kall15remaining
pathtrialscomplete. CPU/GPUmedianphysics10.84/20.68steps/s;
direct10.31/20.29FPS; GPU Sokol12.87FPS (CPUalready stopped80k8.14).
stopped.jsonstillonly sokol-cpu80k10FPSthreshold. No validationfailures.
exec43812 chartpostprocessstillwaitingforqualificationPID563898; pollsamehandle.

New baseline-source-audit.json: reconstructed archived measured-source.patch
frombase9a66819d intoaprivateGitindex; verifiedpatchSHA aff45db35ff2bca0008e162edb9abea39ae6a54fe4377faa3cb6f9e594860537.
Compared reconstructedtreeagainst1559a049 for src/shaders/c_abi/native-samples/
compiler/build.rs/Cargo.toml/Cargo.lock: ZEROdifferences. Thisindependentlyties
preservedbaselinebinary+archive torequestedbaselinecommit despiteoriginal
manifest'spre-commitHEAD. Currentworkingtree/indexnotchanged byprivateindex.
ArchivepackagerwillincludethisJSON.

Remaining150k/200k(andhigherif>10FPS)trials, stopdiagnoses, finalplotsvisualreview,
recordingcontactsheets, finalREADME/table/limits+docs, rawarchive andfullaudit.
No newcommit/pushauthorized. Keepgoalactive. DoNOTrestartlivejoboroverlapGPUwork.

# Latest: 100k sweep live; first terminal path at80k

exec77075 verifiedlive, final-sweep at100k physicsCPUtrial1. 80kcomplete,
CPU/GPUmedians: physics14.06/24.96steps/s; Sokol8.14/16.37FPS;
direct12.93/25.77FPS. stopped.json: sokol-cpu at80000 reason10FPSthreshold.
No validationfailures. Remaining5pathscontinue; do NOT restart oroverlapheavyjobs.

NEW exec43812 waitinglive: artifacts/dispatch-scaling/plot-after-sweep.py haspidfd
forqualificationPID563898. Afterqueueendsandallstagespassed, it generatesfull
benchmarks/rtx4070-tiled-scaling-2026-09-24{.json,.md,.svg,.png,-latency*,-timings.md}
andrtx4070-tiled-resources-2026-09-24.{json,svg,png}. Pollsamehandle; don'tduplicate
plottingwhilequeued. Logsfinal-plot-0.log andfinal-plot-1.log. Itdoesnotclaim
invalidstop=capacity; manualauditandREADMEpublicationstillrequired.

Prepared artifacts/dispatch-scaling/review-recordings.py (syntaxcheckedonly).
Runwith /tmp/falling-plots-env/bin/python AFTERmeasurement;guardrequiresqueue
passed. Creates5pairedCPU/GPUcontactsheetpages of19scenes, frame299, in
artifacts/dispatch-scaling/recording-review/. Visuallyreviewwithview_image.
Metadata/clipframe/binaryidentitychecks alreadyverified.

Stillneedcurrent200kqualification/all5remainingstops, fullplotsvisualaudit,
finalcohesiveREADMEthresholds/crossover/limits+docs, rawarchivepackager then
requirementaudit. No newcommits/pushesauthorized. Goalactive.

# Latest: 80k sweep live (verified wait turn)

exec77075 verified live; final-sweep now80k trial1. 60kall18validtrialscomplete.
CPU/GPUmedians: physics19.86/34.62steps/s; Sokol11.57/21.58FPS;
direct18.64/33.23FPS. No stoppedpaths orvalidationfailuresyet.
No new implementationchanges thisturn; only observedliveworkerandcompleteddata.
Do not restarttheliveprocess or launchcompetingGPUjobs. Final200kproof,
all6stoppingpoints, finalcharts/table/docs/archive andfullauditstillremaining.
Aftermeasurement, considercontact-sheetreviewofrecorded19scenes; metadata/frame/
binaryidentitychecks alreadydone. No newcommit/pushauthorized.

# Latest: 60k sweep live; evidence packager prepared

exec77075 verifiedlive, final-sweep at60k trial1. 50k three-trial CPU/GPUmedians:
physics24.98/39.85steps/s; Sokol14.50/25.45FPS; direct23.80/39.80FPS.
No stoppedpaths or invalidtrials yet. Repeated100kbeforeafterremains30.3%gain.
Box3dsubmodulegitstatusclean and gitdiff1559a049 acrossBox3d,WASMpackage,public
WASMpaths isempty. No source/binarychangeswhilebenchmarkruns.

New ignored helper artifacts/dispatch-scaling/package-final-evidence.py prepared
and syntaxchecked; NOT executed (guardsrequirequeuecompletedand6terminalpaths).
AfterallmeasurementsandpublishedJSONready, runit tobuild benchmarks/
rtx4070-tiled-scaling-2026-09-24-raw.tar.gz +sha256. It includes raw/failed/
intermediateruns, logs,sourcepatches+hashes, scripts includinguntrackedresource
plotter, recordingmanifests/metrics, publishedJSON, reproductionREADME andinternal
SHA256SUMS;excludesexecutablesandMP4 butpreserveshashes. Roundtripverifiesallmembers.
Olderbaseline150kfailuresalreadyinbaselinearchive; newarchiveREADMEreferencesit.
Needfinalfailurediagnosisifinvalid; archiveguarddoesnotclaiminvalidiscapacity.

Goalstillactive: final200kproof, allpaths until10FPS/verifiedlimit, finalplots/
thresholds/table/cohesivedocs, archive+audit. No newcommit/pushauthorized.

# Latest: 50k sweep live, final validation record added

exec77075 verified live. final-sweep at50k trial1;40kall18trialscomplete.
40k CPU/GPUmedians: physics34.70/47.78steps/s, Sokol19.99/31.29FPS,
direct30.72/48.84FPS. No stoppedpaths/validationfailures yet.
New benchmarks/rtx4070-tiled-validation-2026-09-24.json gathers checkedfinal267
suite, native-cache-off boundary, graph-memo-off andinputchange tests,15kimpact
agreement, normal/strictdrag andnative buildchecks. Generator in artifacts/
dispatch-scaling/summarize-final-checks.py;includeitandlogsinfuturearchive.
READMElinkadded; docsAMDsupportnotedearlierqualificationvsnewNVIDIA-onlyscaling.
No changes toengine orbinaries. No additionalcommitsauthorized.
Remainingfullobjective: finishall6paths to10FPS/verifiedcapacityfailure,
final200k qualification, fullcharts/thresholds/rawarchive, cohesivefinaldocs and
requirementaudit. Check livehandle beforeanything; do NOT restartonobservation
waittimeouts orruncompetingGPUtasks. Goalactive,notblocked.

# Latest: README consolidated; 40k sweep live

exec77075 remains live, final-sweep at40k. 30k three-trial medians:
physics CPU49.70/GPU64.92steps/s;SokolCPU27.23/GPU41.01FPS;
directCPU43.61/GPU69.00FPS. No validationfailures orstoppedpaths yet.

README benchmark section consolidated from~500lines to~280, preserving
methodology/reprocommands/architectureandlinkstoarchivedearlierexperiments.
Current100kbeforeafterproof leads; fullsweepand200kexplicitlypending. Oldfull
sweep resultsnowlinkedratherthan shownascurrent. Finaldatawillneedinsertfull
curves/latency/thresholdtable/resourcesplotsandreplacependingcapacityparagraphs.
Beforeedit README retainedinartifacts/dispatch-scaling/readme-before-consolidation.md.
consolidate-readme.py isone-timeedithelper;doNOTrerunoncurrentREADME.
No corecodechanged; no newcommitsauthorized.

# Latest continuation: 20k groups complete, 30k sweep live

Verified exec77075 live; final-sweep at30k trial2, no stoppedpaths or invalidruns.
Prior goalturn progress: independently compared baseline/final environment dicts
EXACT MATCH;90warmup240timed8workersglobal4substeps. Completed20k three-trial
medians CPU/GPU physics86.20/92.43 steps/s; Sokol46.31/56.65FPS;
direct75.61/96.60FPS. At15k physics122.56/90.47, Sokol64.78/64.65,
direct100.36/125.53. Thus currentphysicscrossover20k, finalreport pending.
Variability flags>1.5 atsmallcounts only atthispoint; keepallvalidtrials.

New recordingproof benchmarks/rtx4070-tiled-recordings-2026-09-24.json generated
by artifacts/dispatch-scaling/check-final-recordings.py. Verifiedall19affected
CPU/GPUsceneclips300frames, hashes, finalbinaryidentityandCPUoracleidentity,
CPUfirstgrid. CPUdirectoryalso hasolder shape-replacement1031frameclip; itis
outsideaffected19scenegridset, intentionallypreserved andnotcounted as300frames.
Savedimplementation-1559a049-to-533f14cd.patch and final-engine-source-sha256.json
(63source/buildinputs)for finalrawarchive. Theseandnewrecordingchecker needinclude.
No furthercommitsauthorized. Goalstillactive:large200kqualification/fullstops,
finalcohesiveREADMEcharts+docs+rawarchive+requirementauditmissing.

# Latest continuation update (sweep still live)

Verified exec77075 still running; final-sweep.log reached2000cubes, no stopped
paths or validationfailures sofar. Do NOT restart; pollhandle77075.
Current new uncommitted work: docs/gpu-physics.md stale unresolveddispatch/
blanketSokolslower claims corrected; README repeated100kchart alreadyadded;
new scripts/plot-falling-resources.py verifies rawGPU phase/allocatedbyte samples
and generates count-scalingchart+JSON. Exercisedon six completedcountgroups,
preview artifacts/dispatch-scaling/resources-preview.png visuallyreviewed.
README reproduction commandadded. Finalresourcesplot shoulduse complete
final-sweep/ and committedbenchmarks stem oncefinished, notpreview.
Goal still incomplete: final200k, all sixstoppingpoints, completecharts/docs,
reproduciblearchive, requirementaudit. Keep normaldesktopload; retain smallcount
renderer variability and reportflags. No new commits authorized.

# Latest update: repeated comparison complete; full sweep live

exec session16563 TERMINAL exit0: final-100k six valid rows. Baseline median
61.20727625ms (16.3379/s), final46.98368ms (21.2840/s): throughput+30.27%,
time-23.24%. Means ranges61.1661–61.3990 and46.8023–47.0739. Graph26.0502→12.0454.
Raw-verified chart generated and visually reviewed:
benchmarks/rtx4070-tiled-100k-2026-09-24.{png,svg,json}. README updated (uncommitted)
with repeated result, explicitly labels previous full CPU/renderer sweep baseline.

exec session77075 STILL LIVE at last check: final-sweep stage running.
Queue PID563898; child PID in final-qualification-status.json. Poll samehandle.
All preceding queued stages passed: uncached boundary, native independent
shape replacement, pointer/normal ten-drag, strict ground ten-drag, Sokol/direct
builds. Peak dragvelocity .230405m/s underunchanged .5 strictlimit.
final-binaries/gpu hash equals preservedstable-buckets-gpu exactly.
SokolGPU hash18b14b267df585f563660a9ff462f9b08d4bf434b16e3b7ce8d12dd7811cac97.
Full sweep at final-sweep/ (log final-sweep.log), first5/10counttrials underway.
Do NOT launch competing heavy work or restart live measurement.
Small-count directFPS variability already visible; retain allruns and report
flagsratherthan gateCPUload. Need final200k qualification, complete sweep/report/
archive plus final correctnessauditbefore goalcomplete. No new commit authorized.

--- Earlier detailed context follows ---

# Current qualification — supersedes older notes below

Implementation committed at 533f14cd at explicit user request. Working tree clean.
No further commit/push authorized. Goal still active, final data/charts incomplete.
Final current-code full native library suite: 267 passed, 0 failed (299.47s),
precommit-stable-library.log. Current GPU 19 scene recordings completed,
2026-09-24-tiled-stable-buckets; ffprobe verified 300 frames each; existing real
CPU column remains first. precommit-validation.json records evidence.

Live jobs launched in latest goal continuation:
- exec session 16563: compare-falling-binaries.py, PID 549703 when launched.
  final-100k/ has three alternating pairs baseline1559 vs preserved stable-buckets-gpu
  (label final-533f14cd). First pair 61.399 vs 46.802 ms. Poll same session.
- exec session 77075: artifacts/dispatch-scaling/run-final-qualification.py.
  Waits with pidfd for that exact comparison process, then requires 6 valid rows.
  Runs cache-off production boundary, independent native shape replacement,
  normal pointer/drag and strict ground drag, rebuilds Sokol GPU and direct GPU
  sequentially, preserves final-binaries/, launches full six-mode three-trial
  sweep at final-sweep/ until <=10fps or invalid (invalid must be diagnosed).
  Status JSON/logs final-qualification-status.json and final-*.log.
  Do not launch overlapping heavy jobs. Inspect handles/process state before any
  resumption; observation timeout is not failure. Queue stops on failed step.

CPU/oracle/Sokol CPU/CPU bridge current hashes match baseline. Sokol GPU was old
baseline but queue rebuilds before sweep. Candidate preserved hash:
a5efec3a1c6833addfabf320ac7a354a998670adec96f67383fcddf22cf27299.
No idle/load gating. All build/test stages happen outside benchmarks.

After queue: verify 200k current candidate and all stop reasons, all repeated
results; generate raw-verified final charts with /tmp/falling-plots-env/bin/python,
update README cohesively and related docs, preserve full reproducible archive
including failed diagnostics, source/binary hashes, hardware/power and test logs.
Final 200k missing if physics path stops below200k: run explicit qualification.
Do not call goal complete until all deliverables verified.

--- HISTORICAL NOTES (live states below are obsolete) ---

# Latest state: graph batch memo + bounded root free scan, full validation/profile live

HEAD remains17e9aa5f, no new commits or pushes authorized. Goal ACTIVE, incomplete:
200k diagnostic success; 20%100k target not yet met; repeated CPU/GPU both-renderer
sweep, final charts/raw packaging/recordings still required. Last turn made major
concrete implementation and validation progress. Keep Box3D/WASM unchanged.

LIVE exec session20654 (single Python sequential orchestrator):
1. Full native release library tests -> bounded-root-library.log (267 tests).
   Env from baseline/manifest.json, except VK_DRIVER_FILES includes BOTH
   nvidia_icd.json and radeon_icd.json; GPU_PHYSICS_ADAPTER=nvidia unchanged.
2. On PASS only: release GPU binary build -> bounded-root-build.log.
3. Copy executable to artifacts/dispatch-scaling/bounded-root-gpu, then one
   100k diagnostic via compare-falling-binaries.py -> bounded-root-100k/ and
   bounded-root-100k-run.log. Exit stops chain on failure. Poll SAME handle;
   no benchmark/build should run concurrently. No other jobs live.

Completed since prior notes:
- dirty-range full suite264PASS/1failed because NVIDIA-only driver env hidAMD
  from cross-adapter test. Same test PASS with both drivers visible (2.37s).
  Dirty-range cacheoff boundary lifecycle PASS31.27s. Logs/manifests preserved:
  dirty-range-validation.json. Testsession61023terminal101,30412terminal0.
- Added scripts/compare-falling-binaries.py (UNTRACKED, include in final artifact/
  eventual requested commit). Preserved executable comparison, alternatingtrial
  order, exact same manifest env/settings, raw failures/phase/memory/power/hashes.
  Script help exercised and actual runs succeed. Saves runner/helper source.
- dirty-range-100k/ completed (session6292 terminal0), ONE matched diagnostic:
  baseline1559 preserved binary62.43322875ms(mean),61.6087p50,68.9536p95;
  dirtyrange60.6661054167ms,60.2616p50,62.6618p95 =2.91%throughputgain.
  phase means baseline bp10.36556,np3.819737,graph26.063680,solve17.36854;
  dirty bp9.758526,np3.876423,graph25.804111,solve17.30064. Thus step3profile done.

Graph batch memo implementation (in broadphase.wgsl +sim.rs):
- Optional GRAPH_MEMO allocation now supports large worlds, device limits checked.
- query memo_base=261+54*reserved_body_capacity+2*contactcapacity (same as smallmemo).
- Tag GRAPH_BATCH_MEMO_TAG differs from smallmemo valid=1; switching invalidates.
- Headers per256edge batch; records6u32(a,b,incomingDynamicMaskA/B,color,localWithinBatch).
- All endpoints and incoming masks must match. Cache HIT replays exactcolors,
  rebases local indices by current global counts, accumulates shared atomicmasks.
- MISS uses original sequential greedy order, updates cache. Entire headerarray
  cleared on invalidtag, including unusedbatches, so shrinking/regrowth safe.
- graph_batch_masks now shared atomics for safe parallel replay. v2fallbackuses
  atomicStore of alreadyloadedmasks insteadof redundantatomicOr; cachekey ignores
  staticbits20..22 (irrelevant to dynamicchoices) but retains actualoutputmask.
- Extra allocation at100k: primary buffers1837715104bytes (vs1739759836baseline).

Graph validation completed:
- graph-batch-memo-smoke.log: existing dynamic greedy reference /holes/overflow PASS.
- graph-batch-memo-cases.log +off.log: new batch_memo_matches_greedy_after_input_changes_and_slot_reuse PASS cacheon/off.
- graph-batch-memo-physics.log: dense overflow/partial physics fixture PASS.
- graph-batch-memo-impact.log:15000cubes,checkpoints1,65,78,79,90,150,330 exact
  zero position/rotation/velocity/omega differences vs reference,33.90s.
- v2cases strengthened to compare output masks and static-bit-only changes;
  graph-batch-memo-v2-cases.log PASS3.25s and -v2-off.log PASS1.02s.
- All those sessions terminal0:2114,51437,7426,20222,13359.

Graph measured diagnostic ONEtrial results:
- graph-batch-memo-100k/ (session21809 terminal0): mean56.6588408333ms,
  p5056.5584,p9564.6832; graph19.60018ms,bp10.20737,solve17.80863.
  ~10.19%throughputgain vs fresh1559baseline, below20%target.
- graph-batch-memo-v2-100k/ (session22135 terminal0): mean56.5195441667ms,
  p5056.6103,p9565.2195; graph19.564446,bp9.888230,solve17.570849.
  v2tweaks negligible; don't oversell. Preserved eachbinary *-gpu.
- source patches graph-batch-memo-source.patch (v1), dirty-range-source.patch,
  production-tiling.patch preserve stages. v2source also in its run working-tree.patch.

Latest UNMEASURED change after v2, now in session20654:
- free_scan_limit() =contactcap for meshes; otherwise highwater+min(missing,cap-highwater).
- alloc_free_histogram/bases/scatter and write_alloc_indirects all use that limit.
  Slots>=highwater neverallocated, so prefix guarantees enough free roots and
  retains canonical lowest-free-slot assignment. Children keep fullmeshpool.
- root_free_scan_preserves_lowest_slots_and_mesh_pool test PASS3.06s,
  root-free-prefix-test.log, session98878terminal0. Alternatesconvex/mesh/convex
  provingprefixcounts ignore stale histogramtail and slots10,11,12,13,15 same.
- Fullsuite now267tests scheduled before measuring; do NOT claim passuntilterminal.

Next: inspect20654 results and new phase timings. If targetstillshort, graph~19.6ms
remainslargest. Possible next experiment (NOT implemented): anchor cache batches
on stable body-index ranges instead of global edge-list positions, since an early
contact insertion shifts all256-edge boundaries and invalidates latercachehits.
Would need bounded per-bucket storage/fallback and same exactreference tests.
Do not weaken solver or validation. Full final sweep/recording/archive work remains.

--- Older baseline/integration notes below ---

# Latest state: dirty-range clearing implemented, regression suite live

Previous turn/current continuation made concrete progress. No new commit.
200k-initial run session65315 TERMINAL0. Valid final JSON:
200k-initial/200000-physics-gpu-1.json; mean132.89936125ms=7.52449steps/s,
p50132.8087,p95136.6674; live_contacts410745,awake200000,step330,
primary simulation bytes3478816732. One diagnostic trial only; all-renderer
three-trial sweep and correctness/recording artifacts remain. Preserved tiling-only
binary artifacts/dispatch-scaling/tiling-only-gpu and production-tiling.patch/source
hashes before clearing edits; baseline1559 binaries remain intact.

New clearing implementation in worktree (unqualified performance):
- QUERY_CONTACT_HIGH_WATER query[73], monotonic exclusive allocated slot bound.
- Raised in prepare_contact_identity (root allocation/remap) and allocate_manifold_slot.
- clear_broadphase visits contact/history/marks only below this dirty bound;
  removed redundant capacity-wide SCR_PAIRS fill (producers overwrite liveprefix).
- Initial previous-touching history filled EMPTY once AFTER native scratch clear.
- copy_contacts_from copies query[73] across growth; queryresize copies allquery.
- Bound never shrinks after retirement, preserving clearing of old event keys.
- Correction to earlier audit: scr_color_list() is only an obsolete alias name;
  current graph lists use separate color_contact_base(), so no actual color alias.
- New manifold_chain_tests dirty_contact_range_preserves_retired_history_and_skips_unused_slots
  seeds slot5, checks capture/retirement and verifies outside-range sentinels unchanged.

LIVE exec session61023: full NVIDIA native-cache library suite (265tests), log
artifacts/dispatch-scaling/dirty-range-library.log. Uses environment frombaseline
manifest; test --release --lib -- --test-threads=1. Last observed process181287
live, tests passing through component/falling-cube fixtures. Poll SAMEhandle.
No benchmarks live. Do not rebuild/starttiming until suite completes. If new
failures, inspect assertions; do not weaken. Then cache-off targeted lifecycle,
rebuild GPU binary, measure100k before/after clearing and profile. Goalstep3 graph
optimization only after this profile. Graphdynamicbatched still serial lane0;
read-only audit considered parallel intra-batch dependency coloring but NO graph
edits yet. Fullgoal remains active, no new commits/push authorized.

--- Earlier integration and baseline references ---

# Latest continuation (supersedes earlier integration notes below)

User requested checkpoint commit: 17e9aa5f, tiled helper primitives only. No push.
Active goal still targets 200k and >=20% throughput gain vs1559a049; do not commit
new changes unless asked again. Previous turn made concrete implementation and
validation progress, not a wait-only turn.

Production integration is now implemented in working tree:
- PHYSICS_WGSL includes dispatch helpers; build.rs tracks the new shader.
- 1D physics entrypoints canonicalize global/workgroup IDs; component solver's
  custom 2D layout preserved. Strided kernels use full x*y stride.
- All sim.rs direct dispatches and native Command aliases use linear dispatch.
- All broadphase indirect producers use shared write_group_indirect, preserving
  zero dispatch. Removed obsolete 1D capacity assertions and native tail fallback.
- Radix group-indexed kernels reject padded groups >= radix_groups uniformly.
- New production lifecycle fixture reuses existing full-width shape test with
  131072 filler shapes (131075 total), crossing 65535 WG64 boundary.

Validation completed:
- production-tiling-smoke.log: bounded/conflict-free stacked box contacts PASS.
- production-boundary-cached.log: lifecycle fixture PASS (31.87s).
- production-boundary-uncached.log: same fixture with all native *_CACHE=0 and
  FULL_REPLAY=0 PASS (28.03s). Callbacks/events/deletion/remapping/reuse checked.
- production-build.log: release gpu-physics binary rebuilt successfully.
- git diff --check clean. No Box3D/WASM changes, no new commits.

Live job: exec session 65315, bench-falling-cubes.py, output 200k-initial/
One trial physics-gpu, 200000 cubes, 90 warmup +240 timed, global solver,8workers,
normal desktop load, timeout900. Top log 200k-initial-run.log. Last observed live
PID128867 gpu-physics. CPU oracle finished:182.969ms/step. GPU primary run finished
and passed capacity/contact/finite/ground-escape checks: p50=132.809ms,p95=136.667ms,
bp=30.199ms,np=6.973ms,graph=53.497ms (log values). The harness now builds a
SECOND world to measure step_plus_host_mirror; final JSON is written only after
that completes. Do not mistake this expected second world for a restarted job.
Do not restart; poll existing handle. GPU test sessions21108,57088 and build20783
are terminal0. Need inspect bench result and capacity/correctness diagnostics,
then full regressions/boundary tests as appropriate before clearing optimization.
Full three-trial matched all-renderer sweep, optimization, charts,recordings remain.

Clearing audit: SCR_PAIRS appears overwritten for entire live prefix, making its
capacity fill potentially removable. Contact marks alias scr_color_list, so an
occupied-only clear alone is NOT safe. Previous-touching arrays require proper
handling of old retired slots and remap step history. No clearing edits yet.

--- Older baseline / audit references follow ---

# Active NEW goal: dispatch tiling, clearing, graph optimization

Base/current HEAD1559a049; no commits authorized. Old goal complete. New goal targets
200k validated cubes and >=20% faster completed GPU100k physics vs1559, with matched
3trialCPU/GPU/allrenderers charts,raw archives,correctness,recordings. Step order:
1tiling,2occupied/dirtyclearing,3profilethenlargegraphparallel/reuse. KeepBox3D/WASMclean.
No subagents allowed absentexplicitrequest. Normaldesktopload,noidle gate.

## This turn completed
- Preserved all5 exact baseline binaries in artifacts/dispatch-scaling/baseline/
  with hashes, originalpaths and baselinecommit in manifest.json. Use these for
  later matched100kbaseline runs; rebuildingnowmustnotdestroybeforemeasurement.
- Added src/dispatch.rs and shaders/physics/dispatch.wgsl primitives.
  <=65535groups stays[x,1,1];larger uses[256,ceil(groups/256),1]. Matching linear
  globalid=x+y*256*workgroupsize,groupid=x+y*256. Shader bounds handle final-rowpadding.
  Host rejects beyond256*65535groups (farbeyond200ktarget). Preservezero dispatch.
- Added OPT-IN nativeCommand::DispatchLinear; existingDispatch unchanged so no
  existingphysics kernel receives tiledgrid before its indexing is migrated.
- Added src/dispatch_gpu_tests.rs,modregisteredlib.rs. RealGPUtest usessharedWGSL
  helper, comparesdirect/indirect/nativecached-direct/nativecached-indirect for
  groups0,1,65535,65536,65537. Atomicoutputs mustequal1 for EVERY logicalelement,
  zero forpadding. Nativeindirect producer+CopyArgs matchesrealcache mechanism.
- 2hosttests PASS,1GPUtestall20casesPASSonRTX4070Laptop(2.37s). Logs:
  dispatch-host-tests.log and dispatch-gpu-tests.log. Sessions77168and88898TERMINAL0.
  gitdiff--checkpasses. No productionphysics integrationyet;150kNOTfixedyet.

## Next concrete step: integrate tiling completely
Audit /tmp/dispatch-index-audit.txt (123gid/groupindexreferences) and source.
- PHYSICS_WGSL concat in src/sim.rs59+: prepend newdispatch.wgsl; addbuild.rsrerun.
- All one-dimensional physics entrypoints usingbuiltin global_invocation_id or
  workgroup_id mustcanonicalizeindices. Canrenamebuiltin gid->dispatch_gid then
  localgid=vec3(linear_invocation_id(dispatch_gid,WORKGROUP_SIZE),0,0) atentry;
  similarlygroup. Workgroupsizes64/256/ISLAND_WORKGROUP_SIZE/etc. This preserves
  helperfunction callers takinggid/group. Audit everyentrypoint and local barriers.
- IMPORTANT: integrate.wgsl component workgroup alreadyusesgroup.x+256*group.y
  (around506). Preserveexistingcustom2Dlayout;don'tdoubleflattenitsgroup.
- finish_occupied_contacts and clear_remapped_contact_hash use num_workgroups
  stridegroups.x*64;use total x*y*64 withflattenedstart.
- Ordinarysim.rs .dispatch_workgroups(x,1,1) ->LinearDispatch traitmethodonlywhere
  kernelindexisupdated. Most productiondirectdispatcheslivehere;CCDhasownshader
  anddoesnotneedblanketmutation. Someunitfixturesinmanifoldtestsown directdispatch.
- NativecachedphysicsCommand::Dispatch nodes correspondingtoportedkernels->
  DispatchLinear explicitly. Keepdevicegridchecks;removeobsoleteone-dimensional
  capacityassertionsonlyonceindirectproducersandallconsumersareported.
- WGSL types.wgsl write_count_indirect mustwritelinear_dispatch_groups.
- Broadphase manualindirectwriters MUSTalsoported: write_insert_indirect,
  write_occupied_indirect,write_alloc_indirects,graphcompaction,finish_dynamic_graph,
  color_and_compact(percolorandJacobiargs). PreserveZEROargs semantics(one-group
  wave/overflowserialpaths). grep '+1u]=1u'/'+ 1u] = 1u' findsmanualtriples.
- Rustsim.rs5334 nativecontactfixture writes[count.div_ceil(WORKGROUP_SIZE),1,1,0]
  intoscratch;updateusinghosthelperwhenrelevant. indirectscratchCopyArgsalready
  copiesx/y/z bytes,nativecacheIndirect executesallthree,noAPIadditionneeded.
- Barrier/histogram kernels mayhavepaddingworkgroups. Makeuniformgroup bounds
  explicitwhereoutputhistogramindexedbygroupid. Capacitypower-of-twoaligns256
  rowsatcurrentlargecounts;don'trelyonthatinsteadofcorrectgeneralbounds.

Afterintegrationbuildthenfocusedshader/boundary/highindex/contactevent/remaptests,
150k/200kcorrectnessqualificationscacheon/off,fullsuiteasjustified. Thenstep2clearing.
Avoid simultbuildvariants external-C-shim vsdirectsameoutput. Freezebaselinealready.

Existingfullsweepbaseline/artifacts are under artifacts/scaling-profile/complete-scene.
Oldfullchartmatches1559code:100k63.227ms(meanmedian),graph26.4508ms,solve17.9828ms,
broadphase10.6226ms. Primarybuffers1,739,759,836bytes. Prior150kfailsinsertcap4,194,304
/64=65536workgroups>65535. Contact/paircapacityalso4m,sofixingonlyinsertsisunsafe.
Newcodecurrentlyprivateprimitivesonly,noAPIorbehaviorchangesrequiringuserdocsyet;
updatebackend/experimentdocswhenintegrated. Goalactive,notblocked,notcomplete.
