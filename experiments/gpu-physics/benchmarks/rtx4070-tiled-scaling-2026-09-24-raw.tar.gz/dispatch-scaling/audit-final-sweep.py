"""Audit the completed FPS-limited sweep; capacity failures need separate review."""
import hashlib,json,math,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[2]
folder=root/'artifacts/dispatch-scaling'
load=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=load(root/'benchmarks/rtx4070-tiled-scaling-2026-09-24.json')
manifest=report['manifest'];args=manifest['arguments'];trials=load(folder/'final-sweep/trials.json')
baseline=load(folder/'baseline/manifest.json')
assert manifest['environment']==baseline['environment']
assert args['trials']==3 and args['workers']==8 and args['warmup']==90 and args['timed']==240
assert args['gpu_solver']=='global'
assert all(r['status']=='ok' for r in trials), 'retain and diagnose invalid runs separately'
assert len(report['stopped'])==6
for mode,stop in report['stopped'].items():
 assert stop['reason']=='10 FPS threshold', 'non-FPS stops require explicit capacity diagnosis'
 expected=[n for n in args['counts'] if n<=stop['count']]
 series=[r for r in report['results'] if r['mode']==mode]
 assert [r['count'] for r in series]==expected, (mode,'missing count group')
 assert series[-1]['fps']<=10 and all(r['fps']>10 for r in series[:-1])
 for row in series:
  group=[r for r in trials if r['mode']==mode and r['count']==row['count']]
  assert sorted(r['trial'] for r in group)==[1,2,3]
  assert math.isclose(row['fps'],1000/statistics.median(r['mean_ms'] for r in group),abs_tol=1e-9)
  assert all(not r['load_gate_enabled'] for r in group)
  for r in group:
   for phase in ['before','after']:
    assert '1' in r[phase]['ac'].values(), 'AC status changed'
    assert r[phase]['gpu'] not in ('','unavailable')
    assert r[phase]['gpu_power_limits'] not in ('','unavailable')
for name,identity in manifest['binaries'].items():
 assert digest(Path(identity['path']))==identity['sha256'],name
for key in ['cpu','sokol_cpu','cpu_bridge']:
 assert manifest['binaries'][key]['sha256']==baseline['binaries'][key]['sha256']
assert load(folder/'baseline-source-audit.json')['differences']==[]
for path,expected in load(folder/'final-engine-source-sha256.json').items():
 assert digest(root/path)==expected,path
comparison=load(root/'benchmarks/rtx4070-tiled-100k-2026-09-24.json')
before,after=comparison
comparison_trials=load(folder/'final-100k/trials.json')
assert len(comparison_trials)==6
for summary in comparison:
 means=[]
 for row in comparison_trials:
  if row['variant']!=summary['variant']:continue
  path=folder/f"final-100k/100000-{row['variant']}-{row['trial']}.json"
  assert row['status']=='ok' and digest(path)==row['raw_sha256']
  raw=load(path)['raw_runs'][0]
  assert len(raw['completed_step_ms'])==240
  means.append(statistics.mean(raw['completed_step_ms']))
 assert len(means)==3 and math.isclose(summary['mean_ms'],statistics.median(means),abs_tol=1e-9)
assert before['variant']=='baseline-1559a049' and after['variant']=='final-533f14cd'
assert before['trial_count']==after['trial_count']==3
ratio=before['mean_ms']/after['mean_ms']
assert ratio>=1.2 and after['mean_ms']<=.8*before['mean_ms']
assert after['phase_mean_ms']['graph']<before['phase_mean_ms']['graph']
capacity=[]
for trial in range(1,4):
 path=folder/f'final-sweep/200000-physics-gpu-{trial}.json';data=load(path);r=data['raw_runs'][0]
 assert data['bodies']==200001 and data['sub_steps']==4 and not data['sleep']
 assert math.isclose(data['dt'],1/60,abs_tol=1e-7)
 assert r['awake_dynamic']==200000 and r['live_contacts']>0 and r['physics_step']==330
 assert len(r['completed_step_ms'])==240
 capacity.append(dict(trial=trial,contacts=r['live_contacts'],awake=r['awake_dynamic'],
                      primary_bytes=r['allocations']['total_bytes'],raw_sha256=digest(path)))
checks=load(root/'benchmarks/rtx4070-tiled-validation-2026-09-24.json')
for name in ['full_library','native_cache_off_boundary','graph_memo_off','graph_memo_input_changes','impact_equivalence','strict_ground_drag']:
 assert digest(folder/checks[name]['log'])==checks[name]['sha256']
assert len(checks['required_cases'])==7
assert all(r['status']=='passed' for r in checks['native_checks_and_builds'])
proof=dict(valid_trials=len(trials),counts_by_mode={mode:[r['count'] for r in report['results'] if r['mode']==mode] for mode in report['stopped']},
           stopped=report['stopped'],throughput_gain_percent=100*(ratio-1),
           step_time_reduction_percent=100*(1-after['mean_ms']/before['mean_ms']),
           capacity_trials=capacity,source_and_binary_hashes_verified=True,
           matched_environment=True,normal_desktop_load=True,
           note='This audits numerical/source evidence. Final charts, documentation, recordings and archive require separate review before goal completion.')
(root/'benchmarks/rtx4070-tiled-audit-2026-09-24.json').write_text(json.dumps(proof,indent=2)+'\n')
print(f'Validated {len(trials)} trials, all six FPS stops, 200k collision-window records and both performance targets.')
