from pathlib import Path
p=Path('README.md');s=p.read_text()
Path('artifacts/dispatch-scaling/readme-before-consolidation.md').write_text(s)
def between(a,b):return s[s.index(a):s.index(b)]
intro='''## Falling-cube scaling benchmark

**RTX 4070 Laptop (8,188 MiB), Ryzen 9 8945HS, NVIDIA 610.57.04; 2026-09-24.**
The tiled implementation removes the previous 150,000-cube dispatch failure and
reduces large-world graph construction time without changing solver settings.
The matched before/after comparison below is complete. The replacement three-trial
CPU/GPU sweep, both renderers and final 200,000-cube qualification are in progress.

'''
comparison=between('Three matched 100,000-cube trials','Global color solving can')
capacity=between('Production physics now uses','Contact clearing now tracks')
clearing=between('Contact clearing now tracks','At 100,000 cubes, graph construction costs').replace('Repeated performance qualification is pending.','The repeated 100,000-cube comparison above includes these changes.')
method=between('The `falling-cubes` workload','The scaling investigation found')
island=between('The scaling investigation found','Dynamic coloring now')
memo=between('Dynamic coloring now','Three matched 100,000-cube trials')
capacity_design=between('Global color solving can','With the island fix present in both variants')
capacity_design=capacity_design.replace('The combined NVIDIA library suite passes all 260 tests','The preceding capacity build passed all 260 NVIDIA library tests')
memory=between('New completed-step raw runs include','The expanded-capacity build completes')
reproduce=between('For fresh CPU comparisons','<details>\n<summary>Historical first diagnostic')
portability=between('The runner records adapter/driver','## Validation and recordings')
history='''The [pre-tiling CPU/GPU sweep](benchmarks/rtx4070-complete-scene-2026-09-24.json)
and [raw archive](benchmarks/rtx4070-complete-scene-2026-09-24-raw.tar.gz) preserve
the `1559a049` baseline, including all three failed 150,000-cube dispatch attempts.
Earlier investigations retain their own binaries, settings and source snapshots:
[batched graph coloring](benchmarks/rtx4070-batched-graph-2026-09-24-raw.tar.gz),
[capacity expansion](benchmarks/rtx4070-capacity-qualification-2026-09-24-raw.tar.gz),
[full-width identities](benchmarks/rtx4070-full-width-2026-09-24-raw.tar.gz), and
[the initial solver diagnostic that exposed the island-union bug](benchmarks/rtx4070-solver-profile-2026-09-24-raw.tar.gz).
That last diagnostic failed correctness and is not a qualified performance result.

The comparison grid retains the real Box3D CPU column first and records the
current GPU implementation in `2026-09-24-tiled-stable-buckets`. All 19 affected
scenes have 300-frame CPU/GPU clips. [Recording identities and clip checks](benchmarks/rtx4070-tiled-recordings-2026-09-24.json)
verify that the GPU recording binary matches the measured binary and the CPU
oracle is unchanged. Ordinary scene recordings are separate from the no-sleep
benchmark window. Run `bun run compare` to inspect the grid.

'''
p.write_text(s[:s.index('## Falling-cube scaling benchmark')]+intro+comparison+capacity+clearing+method+island+memo+capacity_design+memory+reproduce+history+portability+s[s.index('## Validation and recordings'):])
