import os, json, subprocess, hashlib, shutil, select, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
os.chdir(root)
out=Path('artifacts/dispatch-scaling')
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_', 'GPU_SOKOL_', 'GPU_BENCH_'))}
env.update(json.loads((out/'baseline/manifest.json').read_text())['environment'])
records=[]
def save():
 (out/'final-qualification-status.json').write_text(json.dumps(records,indent=2)+'\n')
def run(name,args,e=env):
 row=dict(name=name,command=args,started=time.time(),status='running',environment={k:v for k,v in e.items() if k.startswith(('GPU_', 'VK_', 'WGPU_', 'DISPLAY','__NV','__GLX'))})
 records.append(row);save();print(name,flush=True)
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen(args,env=e,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row.update(status='passed' if rc==0 else 'failed',returncode=rc,ended=time.time());save()
 if rc: raise SystemExit(rc)
# The specific comparison process is live when this queue is launched.
try:
 fd=os.pidfd_open(549703);poll=select.poll();poll.register(fd,select.POLLIN);print('Waiting for comparison PID 549703',flush=True);poll.poll();os.close(fd)
except ProcessLookupError: pass
rows=json.loads((out/'final-100k/trials.json').read_text())
assert len(rows)==6 and all(r['status']=='ok' for r in rows), 'comparison incomplete or failed'
off=env|{k:'0' for k in env if k.startswith('GPU_PHYSICS_NATIVE_') and k.endswith('_CACHE')}|{'GPU_PHYSICS_FULL_REPLAY':'0'}
run('final-uncached-boundary',['./scripts/build-native-cache.sh','test','--release','--lib','tiled_physics_dispatch_preserves_callbacks_events_and_remapping','--','--test-threads=1'],off)
run('final-shape-replacement',['./scripts/check-shape-replacement.sh',str(out/'final-shape-replacement')])
run('final-pointer-drag',['./scripts/check-both-pointer.sh',str(out/'final-pointer-drag')])
run('final-strict-drag',[str(out/'final-pointer-drag/both-drag'),'--ground-strict'],env|{'GPU_PHYSICS_COMPONENT_TGS':'1'})
run('final-sokol-build',['python3','scripts/run-native-samples.py','gpu','--build-only','--build-info',str(out/'final-sokol-build.json')])
run('final-direct-build',['./scripts/build-native-cache.sh','build','--release','--bin','gpu-physics'])
dest=out/'final-binaries';dest.mkdir(exist_ok=False)
bins={'gpu':Path('target/native-cache-build/release/gpu-physics'),'sokol_gpu':Path('native-samples/build-gpu-native-cache-portable/bin/samples_gpu')}
identities={}
for name,src in bins.items():
 target=dest/name;shutil.copy2(src,target);identities[name]={'path':str(target.resolve()),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
identities['commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(dest/'manifest.json').write_text(json.dumps(identities,indent=2)+'\n')
run('final-sweep',['python3','scripts/bench-falling-cubes.py',str(out/'final-sweep'),'--workers','8','--gpu-solver','global','--timeout','900','--gpu-binary',str(dest/'gpu')])
print('Qualification queue complete; inspect all trial statuses and stopped reasons.',flush=True)
