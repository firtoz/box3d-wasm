"""Create paired final-frame contact sheets after performance measurements end."""
import hashlib,io,json,subprocess
from pathlib import Path
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[2]
status=json.loads((root/'artifacts/dispatch-scaling/final-qualification-status.json').read_text())
assert all(row['status']=='passed' for row in status), 'wait until timing work finishes'
labels=['000-box3d-cpu','2026-09-24-tiled-stable-buckets','2026-09-24-throughput-scaling']
baseline_manifest=json.loads((root/'recordings/snapshots'/labels[2]/'recording-manifest.json').read_text())
assert baseline_manifest['viewer']['sha256']==hashlib.sha256((root/'artifacts/dispatch-scaling/baseline/gpu').read_bytes()).hexdigest()
scenes=sorted(p.name for p in (root/'recordings/snapshots'/labels[1]).glob('*.mp4'))
out=root/'artifacts/dispatch-scaling/recording-review';out.mkdir(exist_ok=True)
for start in range(0,len(scenes),4):
 names=scenes[start:start+4];sheet=Image.new('RGB',(1260,40+len(names)*265),'white');draw=ImageDraw.Draw(sheet)
 draw.text((10,10),'Box3D CPU | GPU 533f14cd | GPU 1559a049: frame 299 of 300',fill='black')
 for row,name in enumerate(names):
  draw.text((10,40+row*265),name,fill='black')
  for column,label in enumerate(labels):
   path=root/'recordings/snapshots'/label/name
   data=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vf',r'select=eq(n\,299),scale=410:-1','-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'])
   frame=Image.open(io.BytesIO(data)).convert('RGB');sheet.paste(frame,(10+column*420,60+row*265))
 sheet.save(out/f'page-{start//4+1}.png')
print(f'Created {(len(scenes)+3)//4} paired review sheets for {len(scenes)} scenes.')
