"""Package completed scaling evidence; refuses to snapshot a running sweep."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root=Path(__file__).resolve().parents[2]
folder=root/'artifacts/dispatch-scaling'
status=json.loads((folder/'final-qualification-status.json').read_text())
assert all(row['status']=='passed' for row in status), 'qualification queue is incomplete or failed'
stopped=json.loads((folder/'final-sweep/stopped.json').read_text())
assert len(stopped)==6, 'not all paths reached a terminal condition'
files={}
# Keep failed and intermediate runs. Executables stay locally preserved and are
# identified by SHA; source changes and build metadata reproduce them.
for path in folder.rglob('*'):
 if path.is_file() and path.suffix in {'.json','.log','.patch','.py','.md','.sh','.txt','.sha256'}:
  files['dispatch-scaling/'+str(path.relative_to(folder))]=path.read_bytes()
for name in ['bench-falling-cubes.py','compare-falling-binaries.py','plot-falling-cubes.py',
             'plot-falling-solvers.py','plot-falling-resources.py','build-native-cache.sh',
             'run-native-samples.py','native-samples-cache-env.sh','record-snapshot.sh',
             'record-box3d-oracle.sh','recording-manifest.py']:
 files['scripts/'+name]=(root/'scripts'/name).read_bytes()
for label in ['000-box3d-cpu','2026-09-24-tiled-stable-buckets']:
 for name in ['recording-manifest.json','metrics.json']:
  files[f'recordings/{label}/{name}']=(root/'recordings/snapshots'/label/name).read_bytes()
for path in (root/'benchmarks').glob('rtx4070-tiled-*.json'):
 files['published/'+path.name]=path.read_bytes()
files['source/working-tree.patch']=subprocess.check_output(['git','diff','--binary'],cwd=root)
files['source/HEAD.txt']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root)
files['REPRODUCE.md']=b'''# RTX 4070 Laptop tiled scaling evidence

The baseline is commit 1559a049 and the measured implementation is 533f14cd.
The source patch between these commits, engine input hashes, preserved executable
hashes and build logs are included. Executables and MP4 files are not embedded;
recording metadata and hashes identify the 19 affected scene pairs.

Use a checkout with native build dependencies as documented in the experiment
README. Build CPU and GPU native samples, the CPU oracle/bridge and the native-cache
Rust executable before timing. Build external-C-shim and direct variants
sequentially. Preserve both versions' GPU executables for the comparison.

The runner copies under scripts/ are the measurement and plotting tools.
Run bench-falling-cubes.py with --workers 8 --gpu-solver global --timeout 900.
Use the GPU/driver/display environment recorded in final-sweep/manifest.json;
paths in manifests are original-machine locations and must be adjusted on another
machine. Normal desktop load is intentional; do not enable --require-idle.

For the before/after comparison, use compare-falling-binaries.py with the
baseline manifest, --binary before=<baseline-executable>,
--binary after=<candidate-executable>, --counts 100000 --trials 3.
Its raw windows match the sweep: 90 warmup + 240 measured steps, dt 1/60,
four substeps, disabled sleep. These timings include collisions and landing.

Use plot-falling-cubes.py for CPU/GPU throughput, application cadence and p50/p95;
plot-falling-resources.py for GPU phases and primary buffer memory;
plot-falling-solvers.py for the final-100k before/after comparison.
Plotters require matplotlib; runners use Python's standard library.

Retained invalid rows and logs must not be discarded. A stopping reason of
invalid is not proof of a hardware capacity limit: consult the final report's
failure diagnosis. Older pre-tiling 150k failures remain in the repository's
rtx4070-complete-scene-2026-09-24-raw.tar.gz archive and its SHA-256 sidecar.
CPU/GPU application settings, exact hardware/driver, AC state and power/clock
snapshots are in the manifests and trial records. GPU allocation figures cover
primary simulation buffers, not total VRAM. Do not extrapolate from FLOPS alone.
'''
files['SHA256SUMS']=(''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items()))).encode()
out=root/'benchmarks/rtx4070-tiled-scaling-2026-09-24-raw.tar.gz'
with out.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz, tarfile.open(fileobj=gz,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(out) as tar:
 assert len(tar.getmembers())==len(files)
 for name,data in files.items():assert tar.extractfile(name).read()==data,name
out.with_suffix(out.suffix+'.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print(f'Verified {len(files)} archive members; {out.stat().st_size:,} compressed bytes.')
