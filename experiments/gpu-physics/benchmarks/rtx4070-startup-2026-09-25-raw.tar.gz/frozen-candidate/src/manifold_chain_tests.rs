//! Seed contact patches directly to test solver ownership independently of narrowphase.
use super::*;
use crate::types::{
    ContactHotGpu, FLAG_STATIC, OVERFLOW_COLOR, PAIR_CAP, RADIX_BUCKETS, SCR_COLOR, SCR_PAIRS,
    SCR_RADIX_BASE,
};

#[derive(Clone, Copy, Debug)]
enum Path {
    Color,
    Wave,
    Overflow,
    Jacobi,
    Legacy,
}
const PATHS: [Path; 5] = [
    Path::Color,
    Path::Wave,
    Path::Overflow,
    Path::Jacobi,
    Path::Legacy,
];

fn make_sim(gpu: &GpuDevice, endpoint: u32) -> GpuSim {
    make_sim_sized(gpu,endpoint,2)
}

#[cfg(all(feature = "native-command-cache", not(target_arch = "wasm32")))]
#[test]
fn native_reset_replay_tracks_growing_and_shrinking_body_span() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim_sized(&gpu, 0, 130);
    sim.native_tail_enabled = true;
    let mut seed = BodyGpu::zeroed();
    seed.rot = [0.0, 0.0, 0.0, 1.0];
    seed.dp = [1.0, 2.0, 3.0];
    seed.dq = [0.5; 4];
    seed.vel = [4.0, 5.0, 6.0];
    let states = vec![crate::types::BodyStateGpu::from_body(&seed); 130];
    for count in [2, 130, 65, 2] {
        sim.count = count;
        sim.params.body_count = count;
        sim.flush_params();
        let mut results = Vec::new();
        for cached in [false, true] {
            sim.queue.write_buffer(&sim.bodies, 0, bytemuck::cast_slice(&states));
            let mut enc = sim.device.create_command_encoder(&Default::default());
            if cached {
                assert!(sim.try_native_tail(&mut enc, 3));
                assert_eq!(sim.tail_cache[3].as_ref().unwrap().key[1], count);
            } else {
                sim.dispatch_n(&mut enc, &sim.reset_deltas, sim.body_groups(), 0, 1);
            }
            sim.queue.submit(Some(enc.finish()));
            let bodies = pollster::block_on(sim.read_bodies());
            assert_eq!(bodies.len(), count as usize);
            for body in &bodies {
                assert_eq!(body.dp, [0.0; 3]);
                assert_eq!(body.dq, [0.0, 0.0, 0.0, 1.0]);
                assert_eq!(body.vel, seed.vel);
            }
            results.push(bytemuck::cast_slice::<BodyGpu, u8>(&bodies).to_vec());
        }
        assert_eq!(results[0], results[1], "body span {count}");
    }
}

fn make_sim_sized(gpu: &GpuDevice, endpoint: u32, count:u32) -> GpuSim {
    let mut ground = BodyGpu::zeroed();
    ground.flags = FLAG_STATIC;
    ground.rot = [0.0, 0.0, 0.0, 1.0];
    ground.dq = ground.rot;
    ground.half = [0.5; 3];
    let mut body = ground;
    body.flags = 0;
    body.inv_mass = 1.0;
    body.inv_inertia = [1.0; 3];
    body.vel = [-2.0, -2.0, 0.0];
    match endpoint {
        1 => {
            ground.flags = 0;
            ground.inv_mass = 1.0;
            ground.inv_inertia = [1.0; 3];
        }
        2 => {
            ground.flags = crate::types::FLAG_KINEMATIC;
            ground.vel = [-0.5, 0.5, 0.0];
        }
        _ => {}
    }
    let caps = GpuSceneCaps::allocate(GpuSceneCaps::live(count, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), 1, 1);
    let mut bodies=vec![ground;count as usize];bodies[1]=body;
    GpuSim::new(
        gpu,
        &bodies,
        &vec![[0.0; 3];count as usize],
        &vec![[0.0; 3];count as usize],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        &[],
        caps,
        true,
        1.0 / 60.0,
        [0.0; 3],
    )
    .unwrap()
}

fn patches() -> [ContactHotGpu; 2] {
    let mut root = ContactHotGpu::zeroed();
    root.a = 0;
    root.b = 1;
    root.count = 1;
    root.n = [0.0, 1.0, 0.0];
    root.restitution = 0.5;
    root.manifold_link = [2, 0, 2, 0];
    let mut child = root;
    child.n = [1.0, 0.0, 0.0];
    child.manifold_link = [0, 1, 0, 0];
    [root, child]
}

fn run(
    gpu: &GpuDevice,
    patches: Vec<ContactHotGpu>,
    path: Path,
    modes: &[u32],
) -> (Vec<BodyGpu>, LiveStepStats) {
    run_with_endpoint(gpu, patches, path, modes, 0)
}

fn run_with_endpoint(
    gpu: &GpuDevice,
    mut patches: Vec<ContactHotGpu>,
    path: Path,
    modes: &[u32],
    endpoint: u32,
) -> (Vec<BodyGpu>, LiveStepStats) {
    let mut sim = make_sim(gpu, endpoint);
    let color = if matches!(path, Path::Overflow) {
        OVERFLOW_COLOR
    } else {
        0
    };
    for patch in &mut patches {
        patch.color = color;
    }
    sim.queue
        .write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&patches));
    // One active root, irrespective of how many patches it owns. This mirrors
    // the graph contract; child slots must never be independent body writers.
    let write = |word: u32, value: u32| {
        sim.queue.write_buffer(
            &sim.scratch,
            u64::from(word) * 4,
            bytemuck::bytes_of(&value),
        );
    };
    write(3, 1); // SCR_NCONTACTS
    write(SCR_PAIRS + 3 * PAIR_CAP, 0); // SCR_ACTIVE_CONTACT
    write(SCR_COLOR + color, 1);
    // Exact WGSL color_contact_base() layout (uses live body slots, not caps).
    let color_base = SCR_RADIX_BASE + RADIX_BUCKETS + 208 * sim.params.body_count + 192;
    write(color_base + color * sim.params.contact_capacity, 0);
    let mut enc = sim
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("manifold-chain-regression"),
        });
    sim.dispatch_n(&mut enc, &sim.prepare_contacts, 1, color, 0);
    for &mode in modes {
        let pipeline = match path {
            Path::Color => &sim.solve_color,
            Path::Wave => &sim.solve_color_wave_one_group,
            Path::Overflow => &sim.solve_overflow,
            Path::Jacobi => &sim.solve_jacobi,
            Path::Legacy if mode == 2 => &sim.warm_start,
            Path::Legacy => &sim.solve_contacts,
        };
        if matches!(path, Path::Jacobi) {
            sim.dispatch_n(&mut enc, &sim.jacobi_clear, 1, color, mode);
        }
        sim.dispatch_n(&mut enc, pipeline, 1, color, mode);
        if matches!(path, Path::Jacobi) {
            sim.dispatch_n(&mut enc, &sim.apply_jacobi, 1, color, mode);
        }
    }
    sim.queue.submit(Some(enc.finish()));
    let bodies = pollster::block_on(sim.read_bodies());
    let stats = pollster::block_on(sim.read_live_step_stats());
    (bodies, stats)
}

fn assert_velocity(bodies: &[BodyGpu], expect: [f32; 3], label: &str) {
    for axis in 0..3 {
        assert!(
            (bodies[1].vel[axis] - expect[axis]).abs() < 0.002,
            "{label}: {:?} expected {expect:?}",
            bodies[1].vel
        );
        assert_eq!(bodies[0].vel[axis], 0.0, "static endpoint changed: {label}");
    }
}

#[test]
fn manifold_chain_executes_every_patch_in_all_solver_paths() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for path in PATHS {
        let (bodies, stats) = run(&gpu, patches().to_vec(), path, &[0]);
        assert_velocity(&bodies, [0.0; 3], &format!("{path:?}"));
        assert_eq!(stats.drops.contact_pairs_dropped, 0);
        let mut root = patches()[0];
        root.manifold_link = [0; 4];
        let (single, _) = run(&gpu, vec![root], path, &[0]);
        assert_velocity(&single, [-2.0, 0.0, 0.0], "singleton control");
    }
}

#[test]
fn manifold_chain_warm_start_and_restitution_visit_children_once() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for path in PATHS {
        let mut warm = patches();
        for patch in &mut warm {
            patch.rb[0][3] = 2.0;
        }
        let (bodies, _) = run(&gpu, warm.to_vec(), path, &[2]);
        assert_velocity(&bodies, [0.0; 3], &format!("warm {path:?}"));
        let (bodies, _) = run(&gpu, patches().to_vec(), path, &[0, 3]);
        assert_velocity(&bodies, [1.0, 1.0, 0.0], &format!("restitution {path:?}"));
    }
}

#[test]
fn manifold_chain_rejects_corruption_before_applying_impulses() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for corruption in 0..7 {
        let mut bad = patches();
        match corruption {
            0 => bad[1].manifold_link[1] = 7,        // wrong owner
            1 => bad[0].manifold_link[0] = u32::MAX, // invalid next slot
            2 => bad[1].manifold_link[0] = 1,        // cycle to root
            3 => bad[1].b = 0,                       // different body pair
            4 => bad[1].count = 5,                   // point array overflow
            5 => bad[1].count = 0,                   // empty child in active ownership chain
            6 => bad[0].manifold_link[2] = u32::MAX, // unbounded traversal
            _ => unreachable!(),
        }
        for path in PATHS {
            let (bodies, stats) = run(&gpu, bad.to_vec(), path, &[2, 0, 3]);
            assert_velocity(
                &bodies,
                [-2.0, -2.0, 0.0],
                &format!("bad {corruption} {path:?}"),
            );
            assert!(stats.drops.contact_pairs_dropped > 0);
            assert!(stats.sticky.contact_pairs_dropped > 0);
        }
    }
}

#[test]
fn manifold_chain_conserves_dynamic_momentum_and_respects_kinematics() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for path in PATHS {
        for endpoint in [1, 2] {
            let (bodies, stats) =
                run_with_endpoint(&gpu, patches().to_vec(), path, &[1, 0], endpoint);
            assert_eq!(stats.drops.contact_pairs_dropped, 0);
            let expected = if endpoint == 1 {
                [-1.0, -1.0, 0.0]
            } else {
                [-0.5, 0.5, 0.0]
            };
            for body in &bodies[..2] {
                for axis in 0..3 {
                    assert!(
                        (body.vel[axis] - expected[axis]).abs() < 0.003,
                        "endpoint={endpoint} {path:?}: {:?}, expected {expected:?}",
                        body.vel
                    );
                }
            }
        }
    }
}

fn test_pipeline(sim: &GpuSim, entry: &str, suffix: &str) -> ComputePipeline {
    let module = sim
        .device
        .create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("manifold-pool-test"),
            source: wgpu::ShaderSource::Wgsl(format!("{PHYSICS_WGSL}\n{suffix}").into()),
        });
    let bgl = sim.solve_color.get_bind_group_layout(0);
    let layout = sim
        .device
        .create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("manifold-pool-test"),
            bind_group_layouts: &[&bgl],
            push_constant_ranges: &[],
        });
    make_compute_cached(&sim.device, &layout, &module, entry, None)
}

fn prepare_pool(sim: &mut GpuSim, missing: u32, mesh: bool) {
    sim.params.mesh_triangle_count = u32::from(mesh);
    sim.flush_params();
    sim.queue
        .write_buffer(&sim.scratch, 54 * 4, bytemuck::bytes_of(&missing));
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &sim.write_alloc_indirects, 1, 0, 0);
    sim.copy_radix_indirect(&mut enc);
    {
        let mut pass = enc.begin_compute_pass(&Default::default());
        pass.set_bind_group(0, sim.ping_bg(), &[GpuSim::pass_lut_offset(0, 0) as u32]);
        pass.set_pipeline(&sim.alloc_free_histogram);
        pass.dispatch_workgroups_indirect(&sim.indirect, GpuSim::indirect_radix_offset());
        pass.set_pipeline(&sim.alloc_free_bases);
        pass.dispatch_workgroups(1, 1, 1);
        pass.set_pipeline(&sim.alloc_free_scatter);
        pass.dispatch_workgroups_indirect(&sim.indirect, GpuSim::indirect_radix_offset());
    }
    sim.queue.submit(Some(enc.finish()));
}

#[test]
fn manifold_pool_allocates_uniquely_after_primary_reservations_and_reports_exhaustion() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    sim.queue
        .write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&patches()));
    prepare_pool(&mut sim, 3, true);
    let pipeline = test_pipeline(
        &sim,
        "test_allocate_patches",
        r#"
        @compute @workgroup_size(64)
        fn test_allocate_patches(@builtin(global_invocation_id) gid: vec3<u32>) {
            if (gid.x >= params.contact_capacity) { return; }
            let slot = allocate_manifold_slot(0u);
            scratch[scr_active_contact() + gid.x] = slot;
            if (slot != EMPTY) {
                var c = empty_contact();
                c.a = 0u; c.b = 1u; c.count = 1u;
                c.n = vec3<f32>(0.0, 1.0, 0.0);
                c.manifold_link.y = 1u;
                store_contact(slot, c);
            }
        }
    "#,
    );
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(
        &mut enc,
        &pipeline,
        sim.params.contact_capacity.div_ceil(64),
        0,
        0,
    );
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    let words = pollster::block_on(
        sim.read_scratch_prefix(SCR_PAIRS + 3 * PAIR_CAP + sim.params.contact_capacity),
    );
    let out = &words[(SCR_PAIRS + 3 * PAIR_CAP) as usize..];
    let unique: std::collections::BTreeSet<_> = out
        .iter()
        .copied()
        .filter(|&slot| slot != u32::MAX)
        .collect();
    let expected: std::collections::BTreeSet<_> = (5..sim.params.contact_capacity).collect();
    assert_eq!(unique, expected);
    assert_eq!(
        out.iter().filter(|&&slot| slot != u32::MAX).count(),
        unique.len(),
        "duplicate allocation"
    );
    assert_eq!(contacts[0].manifold_link, [2, 0, 2, 0]);
    assert_eq!(
        contacts[1].manifold_link,
        [0, 1, 0, 0],
        "old warm-start patch overwritten"
    );
    for slot in 2..5 {
        assert_eq!(
            contacts[slot].a,
            u32::MAX,
            "primary reservation overwritten"
        );
    }
    let stats = pollster::block_on(sim.read_live_step_stats());
    assert_eq!(stats.drops.contact_pairs_dropped, 5);
    assert_eq!(stats.sticky.contact_pairs_dropped, 5);
}

#[test]
fn manifold_pool_is_available_for_mesh_patch_growth_without_new_pairs() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    sim.queue
        .write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&patches()));
    prepare_pool(&mut sim, 0, false);
    let words = pollster::block_on(sim.read_scratch_prefix(55));
    assert_eq!(
        words[48], 0,
        "non-mesh singleton fast path should skip free scan"
    );
    assert_eq!(words[53], 0);
    prepare_pool(&mut sim, 0, true);
    let words = pollster::block_on(sim.read_scratch_prefix(55));
    assert_eq!(words[48], sim.params.contact_capacity.div_ceil(256));
    assert_eq!(words[53], sim.params.contact_capacity - 2);
}

#[test]
fn manifold_pool_retires_deleted_body_chains_but_preserves_malformed_chains() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for corrupt in [false, true] {
        let mut sim = make_sim(&gpu, 0);
        let mut old = patches();
        for c in &mut old {
            c.a = 900;
            c.b = 901;
        }
        if corrupt {
            old[1].manifold_link[1] = 8;
        }
        sim.queue
            .write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&old));
        sim.queue
            .write_buffer(&sim.scratch, 5 * 4, bytemuck::bytes_of(&1u32));
        sim.queue.write_buffer(
            &sim.scratch,
            u64::from(SCR_PAIRS + 4 * PAIR_CAP) * 4,
            bytemuck::bytes_of(&0u32),
        );
        let mut enc = sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc, &sim.retire_stale_contacts, 1, 0, 0);
        sim.queue.submit(Some(enc.finish()));
        let contacts = pollster::block_on(sim.read_contacts());
        let stats = pollster::block_on(sim.read_live_step_stats());
        if corrupt {
            assert_eq!(contacts[0].a, 900);
            assert_eq!(
                contacts[1].a, 900,
                "partial retirement of invalid ownership"
            );
            assert!(stats.sticky.contact_pairs_dropped > 0);
        } else {
            assert_eq!(contacts[0].a, u32::MAX);
            assert_eq!(contacts[1].a, u32::MAX);
            assert_eq!(contacts[0].manifold_link, [0; 4]);
            assert_eq!(contacts[1].manifold_link, [0; 4]);
            assert_eq!(stats.drops.contact_pairs_dropped, 0);
            prepare_pool(&mut sim, 0, true);
            let words = pollster::block_on(sim.read_scratch_prefix(55));
            assert_eq!(
                words[53], sim.params.contact_capacity,
                "retired slots unavailable on next pass"
            );
        }
    }
}

#[test]
fn manifold_finalization_uses_selected_patch_history_not_pair_root() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let mut old = patches();
    old[0].rb[0][3] = 2.0;
    old[1].rb[0][3] = 5.0;
    old[0].friction_impulse = [1.0, 2.0];
    old[1].friction_impulse = [3.0, 4.0];
    sim.queue
        .write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&old));
    let pipeline = test_pipeline(
        &sim,
        "test_finalize_history",
        r#"
        @compute @workgroup_size(64)
        fn test_finalize_history(@builtin(local_invocation_index) lid: u32) {
            if (lid == 0u) { prepare_contact_identity(0u, vec2<u32>(0u)); publish_contact_slot(vec2<u32>(0u), 0u); }
            storageBarrier(); workgroupBarrier();
            if (lid >= 3u) { return; }
            var previous = empty_contact();
            if (lid < 2u) { previous = load_contact(lid); }
            var c = empty_contact();
            c.a = 0u; c.b = 1u; c.count = 1u;
            c.n = select(vec3<f32>(0.0, 1.0, 0.0), vec3<f32>(1.0, 0.0, 0.0), lid == 1u);
            finish_manifold_from_previous(&c, load_body(0u), load_body(1u), 0u, 1u, previous);
            store_contact(2u + lid, c);
        }
    "#,
    );
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    for (index, impulse) in [2.0, 5.0, 0.0].into_iter().enumerate() {
        assert_eq!(
            contacts[2 + index].rb0[3],
            impulse,
            "wrong patch history for {index}"
        );
    }
    assert_eq!(contacts[2].friction_impulse, [1.0, 2.0]);
    assert_eq!(contacts[3].friction_impulse, [3.0, 4.0]);
    assert_eq!(contacts[4].friction_impulse, [0.0, 0.0]);
}

#[test]
fn mesh_point_history_requires_full_triangle_and_feature_identity() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let pipeline = test_pipeline(
        &sim,
        "test_triangle_history",
        r#"
        @compute @workgroup_size(1)
        fn test_triangle_history() {
            var old = empty_contact();
            old.a = 0u; old.b = 1u; old.count = 4u;
            old.n = vec3<f32>(0.0, 1.0, 0.0);
            old.point_triangles = vec4<u32>(1u, 65537u, 70001u, 90001u);
            for (var i = 0u; i < 4u; i++) {
                set_point(&old, i, vec4<f32>(0.0), vec4<f32>(0.0, 0.0, 0.0, f32(i + 2u)));
                set_feat_at(&old, i, 0u); // zero is a valid mesh feature id
            }
            var c = old;
            c.point_triangles = vec4<u32>(65537u, 1u, 65537u, 42u);
            let matched = match_previous_points(c, old);
            let impulse = matched.impulses;
            c.lifecycle.y = matched.persisted;
            c.rb0.w = impulse.x; c.rb1.w = impulse.y; c.rb2.w = impulse.z; c.rb3.w = impulse.w;
            store_contact(0u, c);
            // Same triangle but a different feature must not use proximity fallback.
            c = old;
            for (var i = 0u; i < 4u; i++) { set_feat_at(&c, i, 99u); }
            let unmatched = match_previous_points(c, old);
            let mismatch = unmatched.impulses;
            c.lifecycle.y = unmatched.persisted;
            c.rb0.w = mismatch.x; c.rb1.w = mismatch.y; c.rb2.w = mismatch.z; c.rb3.w = mismatch.w;
            store_contact(1u, c);
            old.rb0.w = 0.0; old.rb1.w = 0.0; old.rb2.w = 0.0; old.rb3.w = 0.0;
            c = old;
            let zero_match = match_previous_points(c, old);
            c.lifecycle.y = zero_match.persisted;
            store_contact(2u, c);
        }
    "#,
    );
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    let impulses = |c: &ContactGpu| [c.rb0[3], c.rb1[3], c.rb2[3], c.rb3[3]];
    assert_eq!(impulses(&contacts[0]), [3.0, 2.0, 0.0, 0.0]);
    assert_eq!(impulses(&contacts[1]), [0.0; 4]);
    assert_eq!(std::array::from_fn::<_, 4, _>(|i| contacts[0].point_persisted(i)), [true,true,false,false]);
    assert!((0..4).all(|i| !contacts[1].point_persisted(i)));
    assert_eq!(impulses(&contacts[2]), [0.0;4]);
    assert!((0..4).all(|i| contacts[2].point_persisted(i)), "zero impulse is still a persisted point");
    assert!(!contacts[2].point_persisted(usize::MAX));
    assert_eq!(
        contacts[0].point_triangles,
        [65537, 1, 65537, 42],
        "GPU/host triangle layout or identity truncation"
    );
}

#[test]
fn mesh_point_reduction_carries_triangle_and_feature_with_retained_witness() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let pipeline = test_pipeline(
        &sim,
        "test_triangle_reduction",
        r#"
        @compute @workgroup_size(1)
        fn test_triangle_reduction() {
            var c = empty_contact(); c.a = 0u; c.b = 1u;
            c.n = vec3<f32>(0.0, 1.0, 0.0);
            let points = array<vec3<f32>, 5>(vec3<f32>(-1.0,0.0,-1.0), vec3<f32>(1.0,0.0,-1.0),
                vec3<f32>(1.0,0.0,1.0), vec3<f32>(-1.0,0.0,1.0), vec3<f32>(0.0));
            for (var i = 0u; i < 5u; i++) {
                let depth = select(0.0, -1.0, i == 4u);
                append_mesh_point_with_identity(&c, vec4<f32>(points[i], depth), vec4<f32>(points[i], 0.0),
                    c.n, 70000u + i, 1000u + i);
            }
            store_contact(0u, c);
        }
    "#,
    );
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    let c = &contacts[0];
    assert_eq!(c.count, 4);
    assert!(
        c.point_triangles.contains(&70004),
        "deepest witness discarded"
    );
    let points = [
        [-1.0, 0.0, -1.0],
        [1.0, 0.0, -1.0],
        [1.0, 0.0, 1.0],
        [-1.0, 0.0, 1.0],
        [0.0; 3],
    ];
    let anchors = [c.ra0, c.ra1, c.ra2, c.ra3];
    let features = [
        c._tail[6],
        c._tail[7],
        c._pad_ca.to_bits(),
        c._pad_cb.to_bits(),
    ];
    for i in 0..4 {
        let source = (c.point_triangles[i] - 70000) as usize;
        assert!(source < 5);
        assert_eq!(&anchors[i][..3], &points[source]);
        assert_eq!(features[i], 1000 + source as u32);
    }
}

#[test]
fn mesh_clipping_preserves_incoming_and_outgoing_feature_edges() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let pipeline = test_pipeline(
        &sim,
        "test_mesh_clip_features",
        r#"
        @compute @workgroup_size(1)
        fn test_mesh_clip_features() {
            var polygon: ClipPolygon; polygon.count = 4u;
            polygon.points[0] = vec3<f32>(-1.0,0.0,-1.0);
            polygon.points[1] = vec3<f32>(1.0,0.0,-1.0);
            polygon.points[2] = vec3<f32>(1.0,0.0,1.0);
            polygon.points[3] = vec3<f32>(-1.0,0.0,1.0);
            for (var i = 0u; i < 4u; i++) { polygon.features[i] = pack_feature(1u, (i+3u)%4u, 1u, i); }
            let clipped = clip_polygon_with_features(polygon, vec3<f32>(1.0,0.0,0.0), 0.0, 9u, 0u);
            var c = empty_contact(); c.a = 0u; c.b = 1u; c.count = clipped.count;
            for (var i = 0u; i < clipped.count; i++) {
                set_point(&c, i, vec4<f32>(clipped.points[i], 0.0), vec4<f32>(0.0));
                set_feat_at(&c, i, clipped.features[i]);
            }
            store_contact(0u, c);
        }
    "#,
    );
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    let c = &contacts[0];
    assert_eq!(c.count, 4);
    let pack = |o1: u32, i1: u32, o2: u32, i2: u32| (o1 << 24) | (i1 << 16) | (o2 << 8) | i2;
    assert_eq!(
        [
            c._tail[6],
            c._tail[7],
            c._pad_ca.to_bits(),
            c._pad_cb.to_bits()
        ],
        [
            pack(1, 3, 1, 0),
            pack(1, 0, 0, 9),
            pack(0, 9, 1, 2),
            pack(1, 2, 1, 3)
        ]
    );
    assert_eq!(&c.ra1[..3], &[0.0, 0.0, -1.0]);
    assert_eq!(&c.ra2[..3], &[0.0, 0.0, 1.0]);
}

#[test]
fn generated_mesh_list_publishes_root_and_children() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    prepare_pool(&mut sim, 1, true);
    let pipeline = test_pipeline(&sim, "test_mesh_publication", r#"
        @compute @workgroup_size(1)
        fn test_mesh_publication() {
            var first = empty_contact(); first.a = 0u; first.b = 1u; first.count = 1u;
            first.n = vec3<f32>(0.0,1.0,0.0); first.manifold_link = vec4<u32>(3u,1u,0u,1u);
            var second = first; second.n = vec3<f32>(1.0,0.0,0.0); second.manifold_link.x = 0u;
            var list = MeshPatchList(EMPTY, EMPTY, 0u);
            var shape: Shape;
            append_mesh_patch(&list, 0u, first, shape, load_body(0u));
            append_mesh_patch(&list, 0u, empty_contact(), shape, load_body(0u));
            append_mesh_patch(&list, 0u, second, shape, load_body(0u));
            let result = finalize_mesh_patch_list(list,0u,load_body(0u),load_body(1u),0u,1u);
            store_pair(0u,vec2<u32>(0u,1u),result,0u,1u,load_body(0u),load_body(1u));
        }
    "#);
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&pipeline,1,0,0); sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    assert_eq!(contacts[0].count,1,"root {:?}",contacts[0]);
    assert_eq!(contacts[0].manifold_link,[3,0,2,1]);
    assert_eq!(contacts[1].a,u32::MAX);
    assert_eq!(contacts[2].manifold_link,[0,1,0,1]);
    assert_eq!(contacts[2].lifecycle[1],3);
}

#[test]
fn callback_veto_validates_complete_manifold_ownership() {
    let mut contacts = vec![ContactGpu::empty(); 3];
    contacts[0].a=1; contacts[0].b=2; contacts[0].count=1;
    contacts[0].manifold_link=[3,0,2,0];
    contacts[2].a=1; contacts[2].b=2; contacts[2].count=1;
    contacts[2].manifold_link=[0,1,0,0];
    assert_eq!(callback_disabled_members(&[(0,5)],&contacts).unwrap(),vec![(0,5),(2,1)]);
    contacts[2].manifold_link[1]=2;
    assert!(callback_disabled_members(&[(0,5)],&contacts).is_err());
    contacts[2].manifold_link[1]=1;
    contacts[2].manifold_link[0]=3;
    assert!(callback_disabled_members(&[(0,5)],&contacts).is_err());
    contacts[2].manifold_link[0]=0;
    contacts[2].count=0;
    assert!(callback_disabled_members(&[(0,5)],&contacts).is_err());
}

#[test]
fn gear_mesh_reduction_keeps_both_native_penetrating_witnesses() {
    // Accepted, unique candidates from the identical-state native Gear Lift
    // rock impact. The former deepest-first reduction discarded point 1.
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let pipeline = test_pipeline(&sim, "test_gear_reduction", r#"
        @compute @workgroup_size(1)
        fn test_gear_reduction() {
            var c = empty_contact(); c.a = 0u; c.b = 1u;
            c.n = vec3<f32>(0.0, 1.0, 0.0);
            let points = array<vec4<f32>,5>(
                vec4<f32>(-1.9323504,2.8985815,-0.9133200,-0.05971861),
                vec4<f32>(-1.9261181,2.9189296,-0.8577611,-0.039370537),
                vec4<f32>(-1.9532518,3.0111532,-0.6526684,0.052853107),
                vec4<f32>(-2.2156858,3.0421884,-0.7973329,0.08388829),
                vec4<f32>(-1.8998071,3.0048330,-0.6232074,0.04653287));
            for (var i=0u; i<5u; i++) {
                append_mesh_point_with_identity(&c, points[i], vec4<f32>(points[i].xyz,0.0),
                    c.n, 100u+i, 200u+i);
            }
            store_contact(0u,c);
        }
    "#);
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    let c = &contacts[0];
    assert_eq!(c.count, 4);
    let mut identities = c.point_triangles;
    identities.sort();
    assert_eq!(identities, [100,101,103,104], "native coverage and both penetrating witnesses");
    assert_eq!([c.ra0,c.ra1,c.ra2,c.ra3].iter().filter(|p| p[3]<0.0).count(),2);
}

#[test]
fn body_extra_reads_use_capacity_when_live_slot_span_changes() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let capacity = sim.params.shape_base_u32 / 32;
    assert!(capacity > 2, "fixture requires spare allocated body slots");
    let extra = [0.125f32,0.25,0.5,0.0625,0.3,0.6,1.2,0.0];
    sim.queue.write_buffer(&sim.body_cold, u64::from(16*capacity+16)*4, bytemuck::cast_slice(&extra));
    let pipeline = test_pipeline(&sim,"test_body_extra",r#"
        @compute @workgroup_size(1)
        fn test_body_extra() {
            let body=load_body(1u);
            let extra=body_extra_offset(1u);
            var c=empty_contact();c.a=0u;c.b=1u;c.count=1u;
            c.ra0=vec4<f32>(body.inv_inertia_offdiag,scene_f32(extra+3u));
            c.rb0=vec4<f32>(scene_f32(extra+4u),scene_f32(extra+5u),scene_f32(extra+6u),0.0);
            store_contact(0u,c);
        }
    "#);
    for live in [2,capacity-1,capacity] {
        sim.params.body_count=live;
        sim.flush_params();
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,&pipeline,1,0,0);
        sim.queue.submit(Some(enc.finish()));
        let contacts=pollster::block_on(sim.read_contacts());
        assert_eq!(contacts[0].ra0,[0.125,0.25,0.5,0.0625],"live={live}");
        assert_eq!(contacts[0].rb0,[0.3,0.6,1.2,0.0],"live={live}");
    }
}


#[test]
fn convex_rolling_uses_child_inner_radius_not_body_bounds() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    // Two children of one body have identical bounds but different inner radii.
    // Native contact.c uses quarter innerRadius; mesh_contact.c uses it whole.
    for (slot, radius) in [(0u64, 0.2f32), (1, 0.6)] {
        let mut shape = crate::types::ShapeGpu::zeroed();
        shape.body_index = 1;
        shape.kind = crate::types::KIND_CONVEX_HULL;
        shape.half = [2.0, 3.0, 4.0];
        shape.inner_radius = radius;
        sim.queue.write_buffer(
            &sim.body_cold,
            u64::from(sim.params.shape_base_u32) * 4 + slot * core::mem::size_of::<crate::types::ShapeGpu>() as u64,
            bytemuck::bytes_of(&shape),
        );
    }
    let pipeline = test_pipeline(&sim, "test_child_rolling", r#"
        @compute @workgroup_size(1)
        fn test_child_rolling() {
            var c = empty_contact(); c.a = 0u; c.b = 1u; c.count = 1u;
            c.ra0 = vec4<f32>(rolling_radius(load_collider(0u)),
                rolling_radius(load_collider(1u)),
                mesh_rolling_radius(load_shape(0u)), mesh_rolling_radius(load_shape(1u)));
            var rounded = load_collider(0u);
            rounded.kind = KIND_SPHERE; rounded.half.x = 0.8;
            let sphere = rolling_radius(rounded);
            rounded.kind = KIND_CAPSULE;
            let capsule = rolling_radius(rounded);
            rounded.kind = KIND_BOX; rounded.half = vec3<f32>(2.0, 3.0, 4.0);
            c.rb0 = vec4<f32>(sphere, capsule, rolling_radius(rounded), 0.0);
            store_contact(0u, c);
        }
    "#);
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    assert_eq!(contacts[0].ra0, [0.05, 0.15, 0.2, 0.6]);
    assert_eq!(contacts[0].rb0, [0.8, 0.8, 0.5, 0.0]);
}

#[test]
fn joint_pair_retirement_owns_children_and_preserves_other_roots() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for corrupt in [false, true] {
        let mut sim = make_sim(&gpu, 0);
        let mut contacts = patches().to_vec();
        if corrupt { contacts[1].manifold_link[1] = 8; }
        let mut unrelated = contacts[0];
        unrelated.a = 77; unrelated.b = 78;
        unrelated.manifold_link = [0; 4];
        contacts.push(unrelated);
        sim.queue.write_buffer(&sim.contacts, 0, bytemuck::cast_slice(&contacts));
        sim.queue.write_buffer(&sim.scratch, u64::from(crate::types::SCR_UNIQUE_N) * 4, bytemuck::bytes_of(&2u32));
        sim.queue.write_buffer(&sim.scratch, u64::from(SCR_PAIRS + 3 * PAIR_CAP) * 4, bytemuck::cast_slice(&[0u32, 2]));
        sim.retire_body_pair_contacts(1, 0); // Endpoint order must not matter.
        let after = pollster::block_on(sim.read_contacts());
        let stats = pollster::block_on(sim.read_live_step_stats());
        assert_eq!((after[2].a, after[2].b), (77, 78));
        if corrupt {
            assert_eq!((after[0].a, after[1].a), (0, 0));
            assert!(stats.sticky.contact_pairs_dropped > 0);
            assert_ne!(stats.contact_drop_reasons & (1 << 1), 0);
        } else {
            assert_eq!((after[0].a, after[1].a), (u32::MAX, u32::MAX));
            assert_eq!(stats.sticky.contact_pairs_dropped, 0);
        }
    }
}

#[test]
fn contact_metrics_distinguish_candidates_roots_and_patch_slots_with_step_identity() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu,0);
    assert!(sim.contact_metrics(false).is_none());
    let seed = test_pipeline(&sim,"test_metrics",r#"
        @compute @workgroup_size(1)
        fn test_metrics() {
            store_contact(0u,empty_contact()); store_contact(1u,empty_contact());
            let mode = atomicLoad(&query[70u]);
            let live = mode != 0u;
            let count = select(3u,130u,mode == 2u);
            scratch[SCR_UNIQUE_N] = select(0u,count,live);
            for (var i=0u; i<130u; i++) { scratch[scr_active_contact()+i] = EMPTY; }
            if (live) { scratch[scr_active_contact()+count-1u] = 0u; }
            if (live) {
                var root = empty_contact(); root.a=0u; root.b=1u; root.count=1u;
                root.manifold_link=vec4<u32>(2u,0u,2u,0u);
                root.lifecycle.y=CONTACT_TOUCHING;
                var child=root; child.manifold_link=vec4<u32>(0u,1u,0u,0u);
                store_contact(0u,root); store_contact(1u,child);
            }
        }
    "#);
    let submit = |sim: &mut GpuSim,step:u64,live:u32| {
        sim.restore_physics_step(step);
        sim.queue.write_buffer(&sim.query,70*4,bytemuck::bytes_of(&live));
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,&seed,1,0,0);
        sim.dispatch_n(&mut enc,&sim.begin_occupied_contacts,1,0,0);
        sim.dispatch_n(&mut enc,&sim.collect_occupied_contacts,3,0,0);
        sim.dispatch_n(&mut enc,&sim.finish_occupied_contacts,1,0,0);
        sim.encode_contact_status(&mut enc);
        sim.record_submit(sim.queue.submit(Some(enc.finish())));
        sim.map_contact_status();
    };
    let first=(1u64<<32)+11;
    submit(&mut sim,first,1);
    // Keep the status slot occupied across another submit. Its data and ID
    // must remain paired, even if a newer completed GPU state is now empty.
    submit(&mut sim,first+1,0);
    let old=sim.contact_metrics(true).unwrap();
    assert_eq!(old,ContactMetrics {step:first,topology_revision:0,state_revision:0,capacity_loss:false,candidate_pairs:3,allocated_roots:1,
        allocated_manifold_slots:2,touching_roots:1,non_sensor_roots:0});
    assert_eq!(sim.physics_step(),first+1);
    assert_eq!(sim.pose_snapshot_maps(),0);
    submit(&mut sim,first+2,0);
    assert_eq!(sim.contact_metrics(true).unwrap(),ContactMetrics {step:first+2,..ContactMetrics::default()});
    let contacts=pollster::block_on(sim.read_contacts());
    assert!(contacts.iter().all(|c|c.a==u32::MAX));
    submit(&mut sim,first+3,2);
    assert_eq!(sim.contact_metrics(true).unwrap(),ContactMetrics {step:first+3,topology_revision:0,state_revision:0,
        candidate_pairs:130,allocated_roots:1,allocated_manifold_slots:2,touching_roots:1,non_sensor_roots:0,capacity_loss:false});
    let actual=pollster::block_on(sim.read_contacts());
    assert_eq!(actual.iter().filter(|c|c.a!=u32::MAX).count(),2);
    assert_eq!(actual.iter().filter(|c|c.a!=u32::MAX && c.manifold_link[1]==0).count(),1);
}

#[test]
fn dynamic_greedy_colors_match_reference_with_holes_and_overflow() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for (shared,span,edge_count) in [(false,32,193),(true,32,127),(true,32,128),(true,32,193),(true,32,257),(true,7390,257),(true,7391,257),(true,7966,193),(true,7967,193),(true,7975,193),(true,7976,193),(false,8168,193),(true,8168,193),(true,8169,193),(true,8169,255),(true,8169,256),(true,8169,257),(false,32769,513)] {
    let mut sim = make_sim_sized(&gpu, 0,span);
    sim.graph_shared_requested=shared;
    sim.graph_batched_override=None;
    assert_eq!(sim.shared_graph_eligible(),shared && span<=8168);
    sim.params.body_count = span;
    if shared && std::env::var("GPU_PHYSICS_GRAPH_MEMO").as_deref()==Ok("1")
        && sim.device.limits().max_compute_workgroup_storage_size>=32768 {
        assert!(sim.graph_memo_base.is_some(),
            "memo allocation supports both small-world and large batch caches");
    }
    sim.upload_pass_lut();
    let seed = test_pipeline(&sim, "seed_greedy_graph", &r#"
        @compute @workgroup_size(1)
        fn seed_greedy_graph() {
            for (var b=0u; b<params.body_count; b++) {
                atomicStore(&atom[atom_jacobi()+b],select(0u,(1u<<20u)|(1u<<22u),b%3u==0u));
            }
            for (var c=0u; c<24u; c++) {atomicStore(&atom[atom_graph_color()+c],0u);}
            for (var i=0u; i<EDGE_COUNT; i++) {
                var a=(i*13u)%32u;
                var b=(a+1u+i%17u)%32u;
                if (i<24u) {a=0u;b=i+1u;}
                var c=empty_contact();c.a=a+params.body_count-32u;c.b=b+params.body_count-32u;c.count=1u;
                store_contact(i,c);
                scratch[scr_active_contact()+i]=i;
                scratch[scr_next_occupied()+i]=i;
            }
            scratch[SCR_DYN_DYN_N]=EDGE_COUNT;
            scratch[SCR_NCONTACTS]=EDGE_COUNT;
        }
    "#.replace("EDGE_COUNT", &format!("{edge_count}u")));
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&seed,1,0,1);
    sim.dispatch_n(&mut enc,sim.dynamic_graph_pipeline(),1,0,1);
    sim.queue.submit(Some(enc.finish()));
    let contacts=pollster::block_on(sim.read_contacts());
    let mut masks: Vec<u32>=(0..span).map(|b|if b%3==0 {(1<<20)|(1<<22)} else {0}).collect();
    let mut overflow=0;
    let mut counts=[0u32;24];
    for c in contacts.iter().take(edge_count) {
        let (a,b)=(c.a as usize,c.b as usize);
        let expected=(0..20).find(|color|(masks[a]|masks[b])&(1<<color)==0).unwrap_or(OVERFLOW_COLOR);
        assert_eq!(c.color,expected,"edge {a}-{b}");
        assert_eq!(c.lifecycle[2],counts[expected as usize],"per-color order changed");
        counts[expected as usize]+=1;
        if expected==OVERFLOW_COLOR {overflow+=1;} else {masks[a]|=1<<expected;masks[b]|=1<<expected;}
    }
    assert!(overflow>=4,"fixture must exercise all dynamic colors and overflow");
    let mut enc=sim.device.create_command_encoder(&Default::default());
    let copy_masks=test_pipeline(&sim,"copy_graph_masks",&r#"
        @compute @workgroup_size(64)
        fn copy_graph_masks(@builtin(global_invocation_id) gid:vec3<u32>) {
            if (gid.x<params.body_count) {scratch[gid.x]=atomicLoad(&atom[atom_jacobi()+gid.x]);}
            if (gid.x<EDGE_COUNT) {
                let c=contacts[gid.x];let local=contact_persistent[gid.x].lifecycle.z;
                scratch[params.body_count+gid.x]=scratch[color_contact_base()+c.color*params.contact_capacity+local];
            }
            if (gid.x<24u) {scratch[params.body_count+EDGE_COUNT+gid.x]=atomicLoad(&atom[atom_graph_color()+gid.x]);}
        }
    "#.replace("EDGE_COUNT",&format!("{edge_count}u")));
    sim.dispatch_n(&mut enc,&copy_masks,span.max(edge_count as u32).div_ceil(64),0,1);
    sim.queue.submit(Some(enc.finish()));
    masks.extend(0..edge_count as u32);
    masks.extend(counts);
    assert_eq!(pollster::block_on(sim.read_scratch_prefix(masks.len() as u32)),masks);
    // Re-seed inputs but change a generation within an otherwise identical list.
    // Cached output must preserve overflow order, masks and compact indices even
    // when the reusable prefix ends on either side of a 64-edge batch boundary.
    if shared && span==32 && edge_count==257 && sim.graph_memo_base.is_some() {
        for changed_edge in [256u32,256,128,127,64,63,257] {
            let mutate=test_pipeline(&sim,"mutate_prefix_generation",&format!(r#"
                @compute @workgroup_size(1)
                fn mutate_prefix_generation() {{
                    if ({changed_edge}u<257u) {{contact_persistent[{changed_edge}u].pair.x=1u;}}
                }}
            "#));
            let mut enc=sim.device.create_command_encoder(&Default::default());
            sim.dispatch_n(&mut enc,&seed,1,0,1);
            sim.dispatch_n(&mut enc,&mutate,1,0,1);
            sim.dispatch_n(&mut enc,sim.dynamic_graph_pipeline(),1,0,1);
            sim.dispatch_n(&mut enc,&copy_masks,span.max(edge_count as u32).div_ceil(64),0,1);
            sim.queue.submit(Some(enc.finish()));
            assert_eq!(pollster::block_on(sim.read_scratch_prefix(masks.len() as u32)),masks,"prefix generation at {changed_edge}");
            let actual=pollster::block_on(sim.read_contacts());
            for (old,new) in contacts.iter().zip(actual.iter()).take(edge_count) {
                assert_eq!((old.color,old.lifecycle[2]),(new.color,new.lifecycle[2]));
            }
        }
    }
    if shared && span==32 && edge_count==257 && sim.graph_memo_base.is_some() {
        for (live,seed_bit,overflow_start) in [(257u32,0u32,0u32),(193,0,0),(192,0,0),(128,0,0),(127,0,0),(0,0,0),(257,0,0),(257,8,0),(257,8,2),(257,0,0)] {
            let mutate=test_pipeline(&sim,"resize_prefix_inputs",&format!(r#"
                @compute @workgroup_size(1)
                fn resize_prefix_inputs() {{
                    scratch[SCR_DYN_DYN_N]={live}u;scratch[SCR_NCONTACTS]={live}u;
                    atomicOr(&atom[atom_jacobi()],{seed_bit}u);
                    atomicStore(&atom[atom_graph_color()+23u],{overflow_start}u);
                }}
            "#));
            let mut enc=sim.device.create_command_encoder(&Default::default());
            sim.dispatch_n(&mut enc,&seed,1,0,1);
            sim.dispatch_n(&mut enc,&mutate,1,0,1);
            sim.dispatch_n(&mut enc,sim.dynamic_graph_pipeline(),1,0,1);
            sim.dispatch_n(&mut enc,&copy_masks,span.max(edge_count as u32).div_ceil(64),0,1);
            sim.queue.submit(Some(enc.finish()));
            let words=pollster::block_on(sim.read_scratch_prefix(masks.len() as u32));
            let actual=pollster::block_on(sim.read_contacts());
            let mut expected_masks:Vec<u32>=(0..span).map(|b|if b%3==0 {(1<<20)|(1<<22)} else {0}).collect();
            expected_masks[0]|=seed_bit;
            let mut expected_counts=[0u32;24];expected_counts[23]=overflow_start;
            for (slot,c) in actual.iter().take(live as usize).enumerate() {
                let (a,b)=(c.a as usize,c.b as usize);
                let color=(0..20).find(|col|(expected_masks[a]|expected_masks[b])&(1<<col)==0).unwrap_or(OVERFLOW_COLOR);
                assert_eq!((c.color,c.lifecycle[2]),(color,expected_counts[color as usize]),"live {live}, seed {seed_bit}, overflow {overflow_start}, slot {slot}");
                expected_counts[color as usize]+=1;
                if color!=OVERFLOW_COLOR {expected_masks[a]|=1<<color;expected_masks[b]|=1<<color;}
                assert_eq!(words[span as usize+slot],slot as u32);
            }
            assert_eq!(&words[..span as usize],&expected_masks);
            assert_eq!(&words[span as usize+edge_count..],&expected_counts);
        }
    }
    assert_eq!(sim.shared_graph_initialized(),shared && span<=8168);
    if shared && span<=8168 {
        sim.params.body_count=8169;
        assert!(!sim.shared_graph_eligible());
        assert!(sim.batched_graph_eligible());
        let selected=sim.dynamic_graph_pipeline();
        assert!(std::ptr::eq(selected,&sim.graph_assign_batched));
    }

    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()) {panic!("{error}");}
}

#[test]
fn larger_pair_capacity_compacts_and_preserves_contacts_on_growth() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    let old=make_sim(&gpu,0);
    let seed=test_pipeline(&old,"seed_growth_contacts",r#"
        @compute @workgroup_size(1)
        fn seed_growth_contacts() {
            scratch[SCR_OCCUPIED_N]=3u;
            for (var i=0u;i<3u;i++) {
                let slot=select(i,params.contact_capacity-1u,i==2u);
                let key=vec2<u32>(0u,i+1u);
                var c=empty_contact();c.a=1u;c.b=0u;c.count=1u;
                c.pair=vec4<u32>(key,0u,0u);c.friction_impulse=vec2<f32>(f32(i)+0.25);
                store_contact(slot,c);
                scratch[scr_occupied_contact()+i]=slot;
                store_pair_words(scr_previous_touching(),i,key);
                prepare_contact_identity(slot,key);
                let published=publish_contact_slot(key,slot);
            }
        }
    "#);
    let mut enc=old.device.create_command_encoder(&Default::default());
    old.dispatch_n(&mut enc,&seed,1,0,1);old.queue.submit(Some(enc.finish()));
    let mut grown=make_sim_sized(&gpu,0,8193);
    assert!(grown.params.pair_capacity>old.params.pair_capacity);
    grown.copy_contacts_from(&old);
    let verify=test_pipeline(&grown,"verify_growth_contacts",r#"
        @compute @workgroup_size(1)
        fn verify_growth_contacts() {
            for (var i=0u;i<3u;i++) {
                scratch[64u+i]=find_contact_slot(vec2<u32>(0u,i+1u));
                scratch[67u+i]=scratch[scr_occupied_contact()+i];
                scratch[70u+i]=load_pair_words(scr_previous_touching(),i).y;
            }
        }
    "#);
    let mut enc=grown.device.create_command_encoder(&Default::default());
    grown.dispatch_n(&mut enc,&verify,1,0,1);grown.queue.submit(Some(enc.finish()));
    let words=pollster::block_on(grown.read_scratch_prefix(73));
    let slots=[0,1,old.params.contact_capacity-1];
    assert_eq!(words[5],3);
    assert_eq!(&words[64..67],&slots);
    assert_eq!(&words[67..70],&slots);
    assert_eq!(&words[70..73],&[1,2,3]);
    let contacts=pollster::block_on(grown.read_contacts());
    for (i,&slot) in slots.iter().enumerate() {
        assert_eq!(contacts[slot as usize].friction_impulse,[i as f32+0.25;2]);
    }
    // More than 256 histogram groups and more than 65,536 unique outputs.
    let pairs:Vec<u64>=(0..131073u64).map(|i|i/2).collect();
    let (count,raw,out)=pollster::block_on(grown.debug_compact_unique(&pairs,0x00ff_ff00));
    assert_eq!((count,raw),(65537,65537));
    assert_eq!(&out[..count as usize],(0..65537u64).collect::<Vec<_>>().as_slice());
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()) {panic!("{error}");}
}

// Exercise full-width sort keys independently of the still-limited world IDs,
// then verify both stable sorts preserve canonical static colors and overflow.
#[test]
fn static_graph_sort_preserves_full_width_keys_and_canonical_order() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for span in [32, 8193] {
    let mut sim = make_sim_sized(&gpu, 0, span);
    let layout = crate::types::pair_layout(sim.params.pair_capacity);
    let seed = test_pipeline(&sim, "seed_static_sort", r#"
        @compute @workgroup_size(256)
        fn seed_static_sort(@builtin(global_invocation_id) gid:vec3<u32>) {
            let i=gid.x; let n=scratch[SCR_GRAPH_STATIC_N];
            if (i<n) {
                let body=i%7u+1u;
                var c=empty_contact(); c.a=body;c.b=0u;c.count=1u;
                c.color=(i%37u)*65537u;
                store_contact(i,c);
                scratch[scr_active_contact()+2u*i]=i;
                scratch[scr_radix_out()+i]=2u*i;
                scratch[scr_radix_hist()+2u*i]=(body<<2u)|1u;
            }
            if (i<24u) {atomicStore(&atom[atom_graph_color()+i],0u);}
            if (i==0u) {
                scratch[SCR_GRAPH_STATIC_MAX]=max(2u,(n+6u)/7u);
                scratch[SCR_RADIX_GROUP_N]=(n+255u)/256u;
            }
        }
    "#);
    let counts = if span == 32 { vec![1u32,255,256,257,513] } else { vec![65537] };
    for n in counts {
        for full_graph in [false,true] {
            sim.queue.write_buffer(&sim.scratch,57*4,bytemuck::bytes_of(&n));
            let mut enc=sim.device.create_command_encoder(&Default::default());
            sim.dispatch_n(&mut enc,&seed,n.div_ceil(256),0,1);
            if full_graph {
                sim.dispatch_n(&mut enc,&sim.graph_pack_static_keys,n.div_ceil(64),0,1);
            }
            let sort = |enc: &mut wgpu::CommandEncoder| {
                for digit in 0..4 {
                    sim.dispatch_n(enc,&sim.graph_radix_histogram[digit],n.div_ceil(256),0,1);
                    sim.dispatch_n(enc,&sim.radix_bucket_bases,1,0,1);
                    sim.dispatch_n(enc,&sim.radix_group_prefix,1,0,1);
                    sim.dispatch_n(enc,&sim.graph_radix_scatter[digit],n.div_ceil(256),0,1);
                }
            };
            sort(&mut enc);
            if full_graph {
                sim.dispatch_n(&mut enc,&sim.graph_mark_static_starts,n.div_ceil(64),0,1);
                sim.dispatch_n(&mut enc,&sim.graph_encode_static_colors,n.div_ceil(64),0,1);
                sort(&mut enc);
                sim.dispatch_n(&mut enc,&sim.graph_mark_color_starts,n.div_ceil(64),0,1);
                sim.dispatch_n(&mut enc,&sim.graph_assign_static,n.div_ceil(64),0,1);
            }
            sim.queue.submit(Some(enc.finish()));
            if full_graph {
                let contacts=pollster::block_on(sim.read_contacts());
                let mut counts=[0u32;24];
                for i in 0..n as usize {
                    let rank=i/7;
                    let color=if rank>=22 {23} else {22-rank};
                    assert_eq!((contacts[i].color,contacts[i].lifecycle[2]),
                        (color as u32,counts[color]),"n={n} edge={i}");
                    counts[color]+=1;
                }
            } else {
                let words=pollster::block_on(sim.read_scratch_prefix(layout.radix_out+n));
                let mut expected: Vec<u32>=(0..n).collect();
                expected.sort_by_key(|i|(i%37)*65537);
                let expected: Vec<u32>=expected.into_iter().map(|i|2*i).collect();
                let start=layout.radix_out as usize;
                assert_eq!(&words[start..start+n as usize],expected.as_slice(),"n={n}");
            }
        }
    }
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()) {panic!("{error}");}
}

#[test]
fn paired_graph_compaction_preserves_both_ordered_lists() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for span in [2, 8193] {
    let mut sim=make_sim_sized(&gpu,0,span);
    let layout=crate::types::pair_layout(sim.params.pair_capacity);
    let seed=test_pipeline(&sim,"seed_paired_compact",r#"
        @compute @workgroup_size(256)
        fn seed_paired_compact(@builtin(global_invocation_id) gid:vec3<u32>) {
            let i=gid.x;
            if (i<scratch[SCR_UNIQUE_N]) {
                let mode=scratch[58u];
                let kind=select(i%4u,mode,mode<3u);
                scratch[scr_radix_hist()+i]=(i<<2u)|kind;
                scratch[scr_occupied_contact()+i]=0xa5000000u+i;
            }
            if (i<2u*radix_groups()) {scratch[scr_ins_cell()+i]=0xdeadbeefu;}
        }
    "#);
    for n in [0u32,1,255,256,257,511,512,513,PAIR_CAP,65537.min(sim.params.pair_capacity),sim.params.pair_capacity,17,0] {
        for mode in [0u32,1,2,3] {
            let expect_static:Vec<u32>=(0..n).filter(|i|if mode<3 {mode==1}else{i%4==1}).collect();
            let expect_dynamic:Vec<u32>=(0..n).filter(|i|if mode<3 {mode==2}else{i%4==2}).collect();
            {
                sim.queue.write_buffer(&sim.scratch,u64::from(crate::types::SCR_UNIQUE_N)*4,bytemuck::bytes_of(&n));
                sim.queue.write_buffer(&sim.scratch,58*4,bytemuck::bytes_of(&mode));
                let mut enc=sim.device.create_command_encoder(&Default::default());
                sim.dispatch_n(&mut enc,&seed,n.max(512).div_ceil(256),0,1);
                let groups=n.div_ceil(256).max(1);
                let p=sim.paired_graph_pipelines();
                sim.dispatch_n(&mut enc,&p[0],groups,0,1);
                sim.dispatch_n(&mut enc,&p[1],1,0,1);
                sim.dispatch_n(&mut enc,&p[2],groups,0,1);
                sim.queue.submit(Some(enc.finish()));
                let words=pollster::block_on(sim.read_scratch_prefix(layout.radix_out+n));
                assert_eq!(words[57] as usize,expect_static.len(),"static count n={n} mode={mode}");
                assert_eq!(words[56] as usize,expect_dynamic.len());
                let start=layout.radix_out as usize;
                assert_eq!(&words[start..start+expect_static.len()],expect_static.as_slice());
                let start=layout.next_occupied as usize;
                assert_eq!(&words[start..start+expect_dynamic.len()],expect_dynamic.as_slice());
                let previous=layout.occupied as usize;
                for i in 0..n as usize {assert_eq!(words[previous+i],0xa5000000+i as u32,
                    "graph compaction overwrote previous occupied root {i}");}
            }
        }
    }
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()) {panic!("{error}");}
}


#[test]
fn single_manifold_rejects_corrupt_ownership_and_points() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    for corruption in 0..4 {
        let mut bad = patches()[0];
        bad.manifold_link = [0; 4];
        match corruption {
            0 => bad.manifold_link[1] = 7,
            1 => bad.manifold_link[0] = 1,
            2 => bad.count = 5,
            3 => bad.b = bad.a,
            _ => unreachable!(),
        }
        for path in PATHS {
            let (bodies, stats) = run(&gpu, vec![bad], path, &[2, 0, 3]);
            assert_velocity(&bodies, [-2.0, -2.0, 0.0],
                &format!("single bad {corruption} {path:?}"));
            assert!(stats.drops.contact_pairs_dropped > 0);
        }
    }
}

#[test]
fn small_component_rejects_bad_chains_before_integration() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for corruption in 0..6 {
        let mut sim=make_sim(&gpu,0);
        // Production enables this path through the setter, which grows and
        // rebinds the component metadata buffer. Seed that same allocation.
        sim.set_component_tgs(true);
        let mut chain=patches().to_vec();
        match corruption {
            0=>chain[0].manifold_link[1]=7,
            1=>chain[1].manifold_link[0]=1,
            2=>chain[1].count=5,
            3=>chain[1].b=chain[1].a,
            4=>chain[0].manifold_link[0]=sim.params.contact_capacity+1,
            5=>{}, // Valid chain proves the seeded component actually executes.
            _=>unreachable!(),
        }
        sim.queue.write_buffer(&sim.contacts,0,bytemuck::cast_slice(&chain));
        let setup=test_pipeline(&sim,"seed_small_component",r#"
@compute @workgroup_size(1)
fn seed_small_component() {
    atomicStore(&atom[atom_island_label()],EMPTY);
    atomicStore(&atom[atom_island_label()+1u],1u);
    atomicStore(&query[260u],0u);
    let m=component_meta(1u);
    atomicStore(&query[m],1u);atomicStore(&query[m+1u],1u);
    atomicStore(&query[m+2u],0u);atomicStore(&query[m+3u],0u);
    atomicStore(&query[component_bodies()],1u);
    atomicStore(&query[component_contacts()],0u);
    atomicStore(&query[component_contacts()+1u],0u);
}
"#);
        let mut enc=sim.device.create_command_encoder(&wgpu::CommandEncoderDescriptor{label:Some("bad-small-component")});
        sim.dispatch_n(&mut enc,&setup,1,0,1);
        // Deliberately bypass prepare: the component must guard its own chains.
        sim.dispatch_n(&mut enc,&sim.solve_complete_components,1,0,1);
        sim.queue.submit(Some(enc.finish()));
        let bodies=pollster::block_on(sim.read_bodies());
        let stats=pollster::block_on(sim.read_live_step_stats());
        if corruption == 5 {
            assert!(bodies[1].dp[0] < 0.0, "valid component did not integrate");
            assert_eq!(stats.drops.contact_pairs_dropped, 0, "valid chain rejected");
        } else {
            assert_velocity(&bodies,[-2.0,-2.0,0.0],&format!("bad small component {corruption}"));
            assert_eq!(bodies[1].dp,[0.0;3],"invalid component integrated");
            assert!(stats.drops.contact_pairs_dropped>0,"bad chain {corruption} was not reported");
        }
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()){panic!("{error}");}
}

#[test]
fn large_component_rejects_bad_chains_before_integration() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for corruption in 0..6 {
        let mut sim=make_sim(&gpu,0);
        // Production enables this path through the setter, which grows and
        // rebinds the component metadata buffer. Seed that same allocation.
        sim.set_component_tgs(true);
        let mut chain=patches().to_vec();
        match corruption {
            0=>chain[0].manifold_link[1]=7,
            1=>chain[1].manifold_link[0]=1,
            2=>chain[1].count=5,
            3=>chain[1].b=chain[1].a,
            4=>chain[0].manifold_link[0]=sim.params.contact_capacity+1,
            5=>{}, // Valid chain proves the seeded component actually executes.
            _=>unreachable!(),
        }
        sim.queue.write_buffer(&sim.contacts,0,bytemuck::cast_slice(&chain));
        let setup=test_pipeline(&sim,"seed_large_component",r#"
@compute @workgroup_size(1)
fn seed_large_component() {
    atomicStore(&atom[atom_island_label()],EMPTY);
    atomicStore(&atom[atom_island_label()+1u],1u);
    atomicStore(&query[260u],0u);
    atomicStore(&query[256u],1u);
    atomicStore(&query[component_large_roots()],1u);
    atomicStore(&query[component_color_counts()+24u],1u);
    atomicStore(&query[component_color_starts()+24u],0u);
    let m=component_meta(1u);
    atomicStore(&query[m],1u);atomicStore(&query[m+1u],1u);
    atomicStore(&query[m+2u],0u);atomicStore(&query[m+3u],0u);
    atomicStore(&query[component_bodies()],1u);
    atomicStore(&query[component_contacts()],0u);
    atomicStore(&query[component_contacts()+1u],0u);
}
"#);
        let mut enc=sim.device.create_command_encoder(&wgpu::CommandEncoderDescriptor{label:Some("bad-small-component")});
        sim.dispatch_n(&mut enc,&setup,1,0,1);
        // Deliberately bypass prepare: the component must guard its own chains.
        sim.dispatch_n(&mut enc,&sim.solve_large_components,1,0,1);
        sim.queue.submit(Some(enc.finish()));
        let bodies=pollster::block_on(sim.read_bodies());
        let stats=pollster::block_on(sim.read_live_step_stats());
        if corruption == 5 {
            assert!(bodies[1].dp[0] < 0.0, "valid component did not integrate");
            assert_eq!(stats.drops.contact_pairs_dropped, 0, "valid chain rejected");
        } else {
            assert_velocity(&bodies,[-2.0,-2.0,0.0],&format!("bad small component {corruption}"));
            assert_eq!(bodies[1].dp,[0.0;3],"invalid component integrated");
            assert!(stats.drops.contact_pairs_dropped>0,"bad chain {corruption} was not reported");
        }
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()){panic!("{error}");}
}

#[test]
fn occupied_publication_parallel_preserves_order_at_boundaries() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let seed = test_pipeline(&sim, "seed_publication", r#"
        @compute @workgroup_size(64)
        fn seed_publication(@builtin(global_invocation_id) gid: vec3<u32>) {
            let count = atomicLoad(&query[70u]);
            if (gid.x < params.contact_capacity) {
                scratch[scr_next_occupied() + gid.x] = params.contact_capacity - 1u - gid.x;
                scratch[scr_occupied_contact() + gid.x] = EMPTY;
            }
            if (gid.x == 0u) { atomicStore(&atom[ATOM_OCCUPIED_N], count); }
        }
    "#);
    let cap = sim.params.contact_capacity;
    for count in [0u32, 1, 63, 64, 65, 2047, 2048, 2049, cap] {
        if count > cap { continue; }
        sim.queue.write_buffer(&sim.query, 70*4, bytemuck::bytes_of(&count));
        let mut enc = sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc, &seed, cap.div_ceil(64), 0, 0);
        sim.dispatch_n(&mut enc, &sim.finish_occupied_contacts, 32, 0, 0);
        sim.queue.submit(Some(enc.finish()));
        let words = pollster::block_on(sim.read_scratch_prefix(crate::types::SCR_OCCUPIED_CONTACT+cap));
        assert_eq!(words[crate::types::SCR_OCCUPIED_N as usize], count);
        let start = crate::types::SCR_OCCUPIED_CONTACT as usize;
        for i in 0..cap {
            assert_eq!(words[start+i as usize], if i < count {cap-1-i} else {u32::MAX},
                "count={count}, index={i}: copy changed order or wrote past the live list");
        }
    }
}

#[test]
fn occupied_retirement_keeps_input_until_publication() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let mut shapes = [ShapeGpu::zeroed(); 2];
    for (i, shape) in shapes.iter_mut().enumerate() {
        shape.body_index = i as u32;
        shape.half = [0.5; 3];
        shape.category_bits_lo = 1;
        shape.mask_bits_lo = u32::MAX;
    }
    sim.params.shape_count = 2;
    sim.queue.write_buffer(&sim.body_cold, u64::from(sim.params.shape_base_u32)*4,
        bytemuck::cast_slice(&shapes));
    sim.upload_pass_lut();
    let seed = test_pipeline(&sim, "seed_occupied_retirement", r#"
        @compute @workgroup_size(64)
        fn seed_occupied_retirement(@builtin(global_invocation_id) gid: vec3<u32>) {
            let i = gid.x;
            if (i >= 512u) { return; }
            var c = empty_contact();
            c.a = select(900u, 0u, i % 2u == 0u);
            c.b = select(901u, 1u, i % 2u == 0u);
            c.count = 1u;
            c.pair = vec4<u32>(0u,1u,0u,0u);
            store_contact(i, c);
            scratch[scr_occupied_contact() + i] = 511u - i;
            scratch[scr_contact_mark() + i] = select(0u, 1u, i == 0u);
            if (i == 0u) {
                scratch[SCR_OCCUPIED_N] = 512u;
                scratch[SCR_UNIQUE_N] = 1u;
                scratch[scr_active_contact()] = 0u;
            }
        }
    "#);
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&seed,8,0,0);
    sim.dispatch_n(&mut enc,&sim.begin_occupied_contacts,1,0,0);
    sim.dispatch_n(&mut enc,&sim.retire_stale_contacts,8,0,0);
    sim.queue.submit(Some(enc.finish()));
    let words=pollster::block_on(sim.read_scratch_prefix(crate::types::SCR_OCCUPIED_CONTACT+512));
    let start=crate::types::SCR_OCCUPIED_CONTACT as usize;
    for i in 0..512 {assert_eq!(words[start+i],511-i as u32,
        "parallel retirement overwrote its input at {i}");}
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&sim.collect_occupied_contacts,1,0,0);
    sim.dispatch_n(&mut enc,&sim.finish_occupied_contacts,32,0,0);
    sim.queue.submit(Some(enc.finish()));
    let words=pollster::block_on(sim.read_scratch_prefix(crate::types::SCR_OCCUPIED_CONTACT+512));
    assert_eq!(words[crate::types::SCR_OCCUPIED_N as usize],256);
    let next = pollster::block_on(sim.read_scratch_prefix(crate::types::SCR_NEXT_OCCUPIED+256));
    let next_start = crate::types::SCR_NEXT_OCCUPIED as usize;
    assert_eq!(&words[start..start+256], &next[next_start..next_start+256],
        "publication must preserve the collected order exactly");
    let mut actual=words[start..start+256].to_vec();actual.sort_unstable();
    assert_eq!(actual,(0..512u32).step_by(2).collect::<Vec<_>>(),
        "each surviving root must be published exactly once, including the active root");
    assert_eq!(pollster::block_on(sim.read_live_step_stats()).sticky.contact_pairs_dropped,0);
}

#[test]
fn hull_reduction_preserves_small_polygons_and_spreads_large_ones() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    let pipeline = test_pipeline(&sim, "test_hull_reduction", r#"
        @compute @workgroup_size(1)
        fn test_hull_reduction() {
            var body = load_body(1u);
            body.pos = vec3<f32>(0.0);
            body.rot = vec4<f32>(0.0, 0.0, 0.0, 1.0);
            var polygon: ClipPolygon;
            polygon.count = 4u;
            polygon.points[0] = vec3<f32>(0.0, 0.0, 0.0);
            polygon.points[1] = vec3<f32>(1.0, 0.0, 0.0);
            polygon.points[2] = vec3<f32>(1.1, 0.0, 0.2);
            polygon.points[3] = vec3<f32>(0.2, 0.0, 1.0);
            let n = vec3<f32>(0.0, 1.0, 0.0);
            let ref_point = vec3<f32>(0.0, 0.01, 0.0);
            var c = empty_contact(); c.a = 0u; c.b = 1u; c.count = 1u;
            c.ra0 = vec4<f32>(reduce_hull_polygon(polygon, body, n, ref_point));
            polygon.count = 8u;
            for (var i = 0u; i < 8u; i++) {
                let angle = f32(i) * 0.7853981633974483;
                polygon.points[i] = vec3<f32>(cos(angle), 0.0, sin(angle));
            }
            c.rb0 = vec4<f32>(reduce_hull_polygon(polygon, body, n, ref_point));
            store_contact(0u, c);
        }
    "#);
    let mut enc = sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc, &pipeline, 1, 0, 0);
    sim.queue.submit(Some(enc.finish()));
    let contacts = pollster::block_on(sim.read_contacts());
    assert_eq!(contacts[0].ra0, [0.0, 1.0, 2.0, 3.0]);
    let indices = contacts[0].rb0;
    for (i, &index) in indices.iter().enumerate() {
        assert!(index >= 0.0 && index < 8.0 && index.fract() == 0.0);
        assert!(!indices[..i].contains(&index), "duplicate retained polygon vertex");
    }
    let mut angles: Vec<_> = indices.iter().map(|i| i * std::f32::consts::FRAC_PI_4).collect();
    angles.sort_by(f32::total_cmp);
    let area = 0.5 * (0..4).map(|i| (angles[(i+1)%4] - angles[i]).sin()).sum::<f32>();
    assert!(area > 1.6, "retained polygon must cover the contact patch: {area}");
}

#[test]
fn hull_triangle_incident_face_matches_native_support_edge_choice() {
    // Generated from Box3D b3FindIncidentFace using the Gear Lift rock hull.
    // Global normal alignment chooses face 6; the support-edge witness chooses 7.
    mod fixture { include!("fixtures/hull_incident_face.rs"); }
    let points = fixture::POINTS;
    let planes = fixture::PLANES;
    let topology = fixture::TOPOLOGY;
    let normal = fixture::NORMAL;
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut body = BodyGpu::zeroed(); body.rot=[0.0,0.0,0.0,1.0];body.dq=body.rot;
    body.kind=crate::types::KIND_CONVEX_HULL;body.inv_mass=1.0;body.inv_inertia=[1.0;3];
    let mut shape = crate::types::ShapeGpu::zeroed();shape.kind=body.kind;
    shape.topology_counts=points.len() as u32 | ((planes.len() as u32)<<8) | ((topology.len() as u32)<<24);
    let caps=GpuSceneCaps::allocate(GpuSceneCaps::live(1,1,points.len() as u32,planes.len() as u32,0,topology.len() as u32,0,0,0,0,0),1,1);
    let mut sim=GpuSim::new(&gpu,&[body],&[[0.0;3]],&[[0.0;3]],&[shape],&points,&planes,&[],&topology,&[],&[],&[],&[],&[],&[],caps,true,1.0/60.0,[0.0;3]).unwrap();
    let shader=format!(r#"
        @compute @workgroup_size(1)
        fn test_incident_face() {{
            let shape=load_shape(0u); let body=load_body(0u);
            let n=vec3<f32>({:?},{:?},{:?});
            var c=empty_contact();c.count=1u;
            c.ra0=vec4<f32>(f32(hull_triangle_incident_face(shape,body,n)),f32(best_hull_face(shape,body,-n)),0.0,0.0);
            store_contact(0u,c);
        }}
    "#,normal[0],normal[1],normal[2]);
    let pipeline=test_pipeline(&sim,"test_incident_face",&shader);
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&pipeline,1,0,0);sim.queue.submit(Some(enc.finish()));
    let contacts=pollster::block_on(sim.read_contacts());
    assert_eq!(contacts[0].ra0[0],fixture::EXPECTED);
    assert_eq!(contacts[0].ra0[1],fixture::OLD);
    assert_ne!(contacts[0].ra0[0],contacts[0].ra0[1]);
}

#[test]
fn full_width_contact_hash_preserves_identity_through_retirement_and_reuse() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim_sized(&gpu, 0, 8193);
    let source = r#"
        fn test_key(i: u32) -> vec2<u32> {
            // Same low 16 bits, distinct full-width identities. Include words
            // equal to hash sentinels: only slot references reserve those values.
            if (i == 254u) { return vec2<u32>(EMPTY, TOMBSTONE); }
            if (i == 255u) { return vec2<u32>(TOMBSTONE, EMPTY); }
            if (i < 128u) { return vec2<u32>(1u + (i << 16u), 2u + (i << 16u)); }
            let x = 1u + (i << 16u);
            // Force the same initial hash bucket for the second half.
            return vec2<u32>(x, pair_hash_mix(x) ^ 7u);
        }
        @compute @workgroup_size(64)
        fn prepare_test(@builtin(global_invocation_id) gid: vec3<u32>) {
            prepare_contact_identity(65536u + gid.x, test_key(gid.x));
        }
        @compute @workgroup_size(64)
        fn publish_test(@builtin(global_invocation_id) gid: vec3<u32>) {
            scratch[64u + gid.x] = u32(publish_contact_identity(test_key(gid.x), 65536u + gid.x));
        }
        @compute @workgroup_size(64)
        fn read_test(@builtin(global_invocation_id) gid: vec3<u32>) {
            scratch[320u + gid.x] = find_contact_identity(test_key(gid.x));
        }
        @compute @workgroup_size(64)
        fn retire_test(@builtin(global_invocation_id) gid: vec3<u32>) {
            if (gid.x % 2u == 0u) { retire_contact_identity(test_key(gid.x)); }
        }
    "#;
    let prepare = test_pipeline(&sim, "prepare_test", source);
    let publish = test_pipeline(&sim, "publish_test", source);
    let read = test_pipeline(&sim, "read_test", source);
    let retire = test_pipeline(&sim, "retire_test", source);
    for stage in 0..4 {
        let mut enc = sim.device.create_command_encoder(&Default::default());
        if stage == 0 {
            sim.dispatch_n(&mut enc, &prepare, 4, 0, 1);
        }
        if stage % 2 == 1 {
            sim.dispatch_n(&mut enc, &retire, 4, 0, 1);
        } else {
            sim.dispatch_n(&mut enc, &publish, 4, 0, 1);
        }
        sim.dispatch_n(&mut enc, &read, 4, 0, 1);
        sim.queue.submit(Some(enc.finish()));
        let words = pollster::block_on(sim.read_scratch_prefix(576));
        for i in 0..256 {
            assert_eq!(words[64+i], 1, "publish slot {i}, stage {stage}");
            let expected = if stage % 2 == 1 && i % 2 == 0 { u32::MAX } else { 65536 + i as u32 };
            assert_eq!(words[320+i], expected, "lookup slot {i}, stage {stage}");
        }
    }
}

#[test]
fn full_width_pair_radix_matches_u64_order_and_compaction() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim=make_sim(&gpu,0);
    for shape_count in [65_536u32,65_537,100_001,16_777_217,u32::MAX] {
    sim.shape_count=shape_count;sim.params.shape_count=shape_count;sim.flush_params();
    let hi=shape_count-1;let lo=hi-1;
    let mut input=vec![u64::MAX, (u64::from(hi)<<32)|u64::from(lo), (1u64<<32), (u64::from(hi)<<32)|u64::from(lo)];
    for i in 0..1025u32 {
        let a=i.wrapping_mul(0x9e3779b9)%shape_count;let b=i.wrapping_mul(0x85ebca6b)%shape_count;
        input.push(u64::from(a.min(b))|(u64::from(a.max(b))<<32));
    }
    let mut expected=input.clone();expected.sort_unstable();
    sim.queue.write_buffer(&sim.scratch,u64::from(SCR_PAIRS)*4,bytemuck::cast_slice(&input));
    sim.queue.write_buffer(&sim.atom,0,bytemuck::bytes_of(&(input.len() as u32)));
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&sim.write_radix_indirect,1,0,1);
    let groups=(input.len() as u32).div_ceil(256);
    for digit in sim.pair_radix_digits() {
        sim.dispatch_n(&mut enc,&sim.radix_histogram[digit],groups,0,1);
        sim.dispatch_n(&mut enc,&sim.radix_bucket_bases,1,0,1);
        sim.dispatch_n(&mut enc,&sim.radix_group_prefix,1,0,1);
        sim.dispatch_n(&mut enc,&sim.radix_scatter[digit],groups,0,1);
    }
    sim.queue.submit(Some(enc.finish()));
    let words=pollster::block_on(sim.read_scratch_prefix(SCR_PAIRS+2*input.len() as u32));
    let actual:Vec<u64>=words[SCR_PAIRS as usize..].chunks_exact(2).map(|w|u64::from(w[0])|(u64::from(w[1])<<32)).collect();
    assert_eq!(actual,expected,"shape span {shape_count}");
    expected.retain(|&v|v!=u64::MAX);expected.dedup();
    let (unique,_,out)=pollster::block_on(sim.debug_compact_unique(&actual,0xabcdef01));
    assert_eq!(&out[..unique as usize],expected.as_slice());
    }
}

#[test]
fn dirty_contact_range_preserves_retired_history_and_skips_unused_slots() {
    let gpu = pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim = make_sim(&gpu, 0);
    sim.params.remap_history_step = u32::MAX;
    sim.flush_params();
    let seed = test_pipeline(&sim, "seed_dirty_contact_range", r#"
        @compute @workgroup_size(1) fn seed_dirty_contact_range() {
            var c = empty_contact();
            c.a=0u; c.b=1u; c.count=1u;
            c.lifecycle.y=CONTACT_TOUCHING;
            c.pair=vec4<u32>(0u,1u,0u,0u);
            store_contact(5u,c);
            prepare_contact_identity(5u,c.pair.xy);
            scratch[scr_contact_mark()+5u]=3u;
            // Sentinel outside the allocated range proves capacity-wide writes
            // are gone. Real unused histories initialize to EMPTY.
            scratch[scr_contact_mark()+7u]=123u;
            store_pair_words(scr_previous_touching(),7u,vec2<u32>(456u));
            store_pair_words(SCR_PAIRS,7u,vec2<u32>(789u));
        }
    "#);
    let retire = test_pipeline(&sim, "retire_dirty_contact", r#"
        @compute @workgroup_size(1) fn retire_dirty_contact() {
            store_contact(5u,empty_contact());
        }
    "#);
    let inspect = test_pipeline(&sim, "inspect_dirty_contact_range", r#"
        @compute @workgroup_size(1) fn inspect_dirty_contact_range() {
            scratch[64u]=atomicLoad(&query[QUERY_CONTACT_HIGH_WATER]);
            scratch[65u]=scratch[scr_contact_mark()+5u];
            scratch[66u]=load_pair_words(scr_previous_touching(),5u).y;
            scratch[67u]=scratch[scr_contact_mark()+7u];
            scratch[68u]=load_pair_words(scr_previous_touching(),7u).y;
            scratch[69u]=load_pair_words(SCR_PAIRS,7u).y;
        }
    "#);
    for retired in [false,true] {
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,if retired {&retire} else {&seed},1,0,1);
        sim.dispatch_n(&mut enc,&sim.clear_broadphase,sim.pair_groups(),0,1);
        sim.dispatch_n(&mut enc,&inspect,1,0,1);
        sim.queue.submit(Some(enc.finish()));
        let words=pollster::block_on(sim.read_scratch_prefix(70));
        assert_eq!(&words[64..70],&[6,0,if retired {u32::MAX} else {1},123,456,789]);
    }
}

#[test]
fn batch_memo_matches_greedy_after_input_changes_and_slot_reuse() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    let mut sim=make_sim_sized(&gpu,0,8193);
    let cached=sim.graph_memo_base.is_some();
    let seed=test_pipeline(&sim,"seed_batch_memo_cases",r#"
        @compute @workgroup_size(1) fn seed_batch_memo_cases() {
            let n=atomicLoad(&query[90u]); let mode=atomicLoad(&query[91u]);
            for (var b=0u;b<params.body_count;b++) {
                var mask=select(0u,(1u<<20u)|(1u<<22u),b%3u==0u);
                if (mode==1u && b==params.body_count-32u) {mask|=4u;}
                if (mode==6u) {mask|=1u<<21u;}
                atomicStore(&atom[atom_jacobi()+b],mask);
            }
            for (var col=0u;col<24u;col++) {
                var count=0u;
                if (mode==3u && col==0u) {count=7u;}
                if (mode==3u && col==23u) {count=5u;}
                atomicStore(&atom[atom_graph_color()+col],count);
            }
            for (var i=0u;i<n;i++) {
                var j=select(i,n-1u-i,mode==4u);
                if (mode==8u && i>=257u) {j--;}
                var a=(j*13u)%32u;var b=(a+1u+j%17u)%32u;
                if (j<24u) {a=0u;b=j+1u;}
                if (mode==2u && i==256u) {b=(b+3u)%32u;if(b==a){b=(b+1u)%32u;}}
                let slot=select(i,1024u-i,mode==5u);
                let offset=select(params.body_count-32u,params.body_count-160u,
                    (mode==7u && i<256u) || (mode==8u && i<257u));
                var c=empty_contact();c.a=a+offset;c.b=b+offset;c.count=1u;
                store_contact(slot,c);
                scratch[scr_active_contact()+i]=slot;scratch[scr_next_occupied()+i]=i;
            }
            scratch[SCR_DYN_DYN_N]=n;scratch[SCR_NCONTACTS]=n;
        }
    "#);
    let inspect=test_pipeline(&sim,"inspect_batch_memo_cases",r#"
        @compute @workgroup_size(1) fn inspect_batch_memo_cases() {
            let n=atomicLoad(&query[90u]);
            let cache=arrayLength(&query)>=graph_batch_memo_end();
            scratch[0u]=0u;scratch[1u]=0u;
            if(cache){scratch[0u]=atomicLoad(&query[graph_batch_memo_base()+1u]);
                scratch[1u]=atomicLoad(&query[graph_batch_memo_base()+2u]);}
            for(var i=0u;i<n;i++) {
                let slot=scratch[scr_active_contact()+i];
                scratch[2u+2u*i]=contacts[slot].color;
                scratch[3u+2u*i]=contact_persistent[slot].lifecycle.z;
            }
            for(var b=0u;b<160u;b++) {
                scratch[2u+2u*n+b]=atomicLoad(&atom[atom_jacobi()+params.body_count-160u+b]);
            }
        }
    "#);
    let mut previous_hits=0;
    for (n,mode,required_hits) in [(513u32,0u32,0),(513,0,3),(513,1,0),(513,0,0),
        (513,2,0),(256,0,0),(257,0,0),(257,3,2),(513,0,0),(0,0,0),
        (513,4,0),(513,4,3),(513,0,0),(513,6,3),(513,0,3),(513,5,3),(513,7,0),(514,8,3),(514,8,4)] {
        sim.queue.write_buffer(&sim.query,90*4,bytemuck::cast_slice(&[n,mode]));
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,&seed,1,0,1);
        sim.dispatch_n(&mut enc,&sim.graph_assign_batched,1,0,1);
        sim.dispatch_n(&mut enc,&inspect,1,0,1);
        sim.queue.submit(Some(enc.finish()));
        let words=pollster::block_on(sim.read_scratch_prefix(2+2*n+160));
        if cached {assert!(words[0]-previous_hits>=required_hits,"n={n}, mode={mode}: expected cached batches");}
        previous_hits=words[0];
        let mut masks:Vec<u32>=(0..8193).map(|b|if b%3==0 {(1<<20)|(1<<22)} else {0}).collect();
        if mode==1 {masks[8193-32]|=4;}
        if mode==6 {for mask in &mut masks {*mask|=1<<21;}}
        let mut counts=[0u32;24];
        if mode==3 {counts[0]=7;counts[23]=5;}
        for i in 0..n {
            let mut j=if mode==4 {n-1-i} else {i};
            if mode==8 && i>=257 {j-=1;}
            let mut a=(j*13)%32;let mut b=(a+1+j%17)%32;
            if j<24 {a=0;b=j+1;}
            if mode==2 && i==256 {b=(b+3)%32;if b==a {b=(b+1)%32;}}
            let offset=if (mode==7 && i<256) || (mode==8 && i<257) {8193-160} else {8193-32};
            let (a,b)=((a+offset) as usize,(b+offset) as usize);
            let color=(0..20u32).find(|c|(masks[a]|masks[b])&(1<<c)==0).unwrap_or(23);
            assert_eq!(&words[(2+2*i) as usize..(4+2*i) as usize],&[color,counts[color as usize]],"n={n}, mode={mode}, edge={i}");
            counts[color as usize]+=1;
            if color<20 {masks[a]|=1<<color;masks[b]|=1<<color;}
        }
        assert_eq!(&words[(2+2*n) as usize..],&masks[8193-160..],"n={n}, mode={mode}: output masks");
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()) {panic!("{error}");}
}

#[test]
fn root_free_scan_preserves_lowest_slots_and_mesh_pool() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    let mut sim=make_sim(&gpu,0);
    let seed=test_pipeline(&sim,"seed_root_free_prefix",r#"
        @compute @workgroup_size(1) fn seed_root_free_prefix() {
            for(var slot=0u;slot<20u;slot++) {
                if(slot<10u || slot==14u || slot==19u) {
                    var c=empty_contact();c.a=0u;c.b=1u;
                    store_contact(slot,c);
                    prepare_contact_identity(slot,vec2<u32>(0u,slot+1u));
                }
            }
        }
    "#);
    let inspect=test_pipeline(&sim,"inspect_root_free_prefix",r#"
        @compute @workgroup_size(1) fn inspect_root_free_prefix() {
            scratch[64u]=free_scan_limit();scratch[65u]=scratch[SCR_FREE_N];
            for(var i=0u;i<5u;i++){scratch[66u+i]=scratch[scr_radix_out()+i];}
        }
    "#);
    let mut enc=sim.device.create_command_encoder(&Default::default());
    sim.dispatch_n(&mut enc,&seed,1,0,0);sim.queue.submit(Some(enc.finish()));
    for mesh in [false,true,false] {
        prepare_pool(&mut sim,5,mesh);
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,&inspect,1,0,0);sim.queue.submit(Some(enc.finish()));
        let words=pollster::block_on(sim.read_scratch_prefix(71));
        let limit=if mesh {sim.params.contact_capacity} else {25};
        assert_eq!(&words[64..71],&[limit,limit-12,10,11,12,13,15]);
    }
}

#[test]
fn spatial_hash_growth_clears_buckets_without_touching_contact_identity() {
    let gpu=pollster::block_on(GpuDevice::new(None)).unwrap();
    gpu.device.push_error_scope(wgpu::ErrorFilter::Validation);
    for bodies in [2,8193] {
        let mut sim=make_sim_sized(&gpu,0,bodies);
        let seed=test_pipeline(&sim,"seed_spatial_hash_bounds",r#"
            @compute @workgroup_size(64) fn seed_spatial_hash_bounds(
                @builtin(global_invocation_id) gid:vec3<u32>) {
                if(gid.x<spatial_hash_buckets()) {
                    atomicStore(&atom[spatial_hash_base()+gid.x],123u);
                }
                if(gid.x==0u) {
                    atomicStore(&atom[atom_contact_key()],456u);
                    atomicStore(&atom[atom_contact_key()-1u],789u);
                    atomicStore(&atom[ATOM_HASH+HASH_BUCKETS-1u],123u);
                }
            }
        "#);
        let inspect=test_pipeline(&sim,"inspect_spatial_hash_bounds",r#"
            @compute @workgroup_size(1) fn inspect_spatial_hash_bounds() {
                var uncleared=0u;
                for(var i=0u;i<spatial_hash_buckets();i++) {
                    if(atomicLoad(&atom[spatial_hash_base()+i])!=EMPTY){uncleared++;}
                }
                scratch[64u]=uncleared;
                scratch[65u]=atomicLoad(&atom[atom_contact_key()]);
                scratch[66u]=atomicLoad(&atom[atom_contact_key()-1u]);
                scratch[67u]=atomicLoad(&atom[ATOM_HASH+HASH_BUCKETS-1u]);
                scratch[68u]=spatial_hash_buckets();
            }
        "#);
        let mut enc=sim.device.create_command_encoder(&Default::default());
        sim.dispatch_n(&mut enc,&seed,sim.pair_groups(),0,1);
        sim.dispatch_n(&mut enc,&sim.clear_broadphase,sim.pair_groups().max(sim.hash_groups()),0,1);
        sim.dispatch_n(&mut enc,&inspect,1,0,1);
        sim.queue.submit(Some(enc.finish()));
        let words=pollster::block_on(sim.read_scratch_prefix(69));
        assert_eq!(&words[64..68],&[0,456,789,u32::MAX]);
        assert!(words[68].is_power_of_two());
        assert!(words[68]<=sim.params.pair_capacity);
        assert_eq!(words[68]>crate::types::HASH_BUCKETS,bodies>8192);
    }
    if let Some(error)=pollster::block_on(gpu.device.pop_error_scope()){panic!("{error}");}
}
