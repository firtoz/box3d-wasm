from pathlib import Path
import json,os,subprocess,hashlib,shutil,time,fcntl
p=Path(__file__).resolve().parent;root=p.parents[1];out=p/'steady-small-recheck';out.mkdir(exist_ok=True)
lock=(out/'runner.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,data):
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)
base=json.loads((p/'baseline.json').read_text())
for b in base['binaries'].values():assert sha(Path(b['path']))==b['sha256']
fixed=Path(json.loads((p/'sokol-lifecycle-build-info.json').read_text())['binary'])
frozen=p/'candidate-sokol-final'
if not frozen.exists():shutil.copy2(fixed,frozen)
assert sha(frozen)==sha(fixed),'Sokol changed since freeze'
variants={'before':{'direct':p/'baseline-direct','sokol':p/'baseline-sokol'},'after':{'direct':p/'candidate-direct','sokol':frozen}}
identities={v:{m:{'path':str(b),'sha256':sha(b)} for m,b in bins.items()} for v,bins in variants.items()}
settings_path=root.parents[1]/'box3d/settings.ini';original=settings_path.read_bytes() if settings_path.exists() else None
settings=json.loads((p/'startup-inputs.json').read_text())['sokol_settings']
manifest={'counts':[1000],'modes':['physics-gpu'],'trials':5,'warmup':90,'timed':240,'workers':8,'solver':'global','binaries':identities,'sokol_settings':settings,'load_gate':False,'scope':'Steady-state regression at small and large scenes; 200k startup is qualified separately. Per-mode before/after framebuffers must match.'}
if (out/'manifest.json').exists():assert json.loads((out/'manifest.json').read_text())==manifest
else:save(out/'manifest.json',manifest)
rows=json.loads((out/'jobs.json').read_text()) if (out/'jobs.json').exists() else []
env=os.environ.copy();env.update(VK_DRIVER_FILES='/usr/share/vulkan/icd.d/nvidia_icd.json',__NV_PRIME_RENDER_OFFLOAD='1',__GLX_VENDOR_LIBRARY_NAME='nvidia')
try:
 for count in manifest['counts']:
  for trial in range(1,6):
   for mode in manifest['modes']:
    for variant in (['before','after'] if trial%2 else ['after','before']):
     key=f'{count}-{mode}-{trial}-{variant}'
     if any(r['key']==key and r['status']=='ok' for r in rows):continue
     folder=out/key;settings_path.write_text(settings)
     args=['python3','scripts/bench-falling-cubes.py',str(folder),'--counts',str(count),'--modes',mode,'--trials','1','--warmup','90','--timed','240','--workers','8','--adapter','nvidia','--gpu-solver','global','--gpu-binary',str(variants[variant]['direct']),'--sokol-gpu-binary',str(variants[variant]['sokol']),'--timeout','900']
     if folder.exists():raise RuntimeError('Incomplete prior job retained; inspect before retry: '+key)
     row={'key':key,'count':count,'trial':trial,'mode':mode,'variant':variant,'command':args,'status':'running','started':time.time()};rows.append(row);save(out/'jobs.json',rows);print(key,flush=True)
     with (out/(key+'.log')).open('w') as log:code=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
     completed=json.loads((folder/'trials.json').read_text()) if (folder/'trials.json').exists() else []
     if code!=0 or len(completed)!=1 or completed[0]['status']!='ok':
      row.update(status='failed',exit_code=code);save(out/'jobs.json',rows);raise RuntimeError('Job failed: '+key)
     result=completed[0]
     if 'framebuffer' in result:
      previous=[r['framebuffer'] for r in rows if r['status']=='ok' and r['mode']==mode]
      assert not previous or result['framebuffer']==previous[0],('Framebuffer changed',key,result['framebuffer'],previous[0])
      row['framebuffer']=result['framebuffer']
     row.update(status='ok',finished=time.time(),result=result);save(out/'jobs.json',rows)
 print('All 10 focused recheck jobs complete',flush=True)
finally:
 if original is None:settings_path.unlink(missing_ok=True)
 else:settings_path.write_bytes(original)
