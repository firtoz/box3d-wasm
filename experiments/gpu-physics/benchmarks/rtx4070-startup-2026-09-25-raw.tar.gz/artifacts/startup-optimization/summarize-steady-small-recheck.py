"""Revalidate paired steady-state evidence and retain full trial ranges."""
from pathlib import Path
import argparse,hashlib,itertools,json,runpy,statistics
p=Path(__file__).resolve().parent;root=p.parents[1];folder=p/'steady-small-recheck'
manifest=json.loads((folder/'manifest.json').read_text());jobs=json.loads((folder/'jobs.json').read_text())
expected=set(itertools.product(manifest['counts'],manifest['modes'],range(1,manifest['trials']+1),['before','after']))
assert len(jobs)==len(expected) and all(j['status']=='ok' for j in jobs),'Incomplete steady-state comparison'
seen=set();hashes={};groups={}
metrics=runpy.run_path(str(root/'scripts/bench-falling-cubes.py'))['metrics']
args=argparse.Namespace(warmup=90,timed=240,workers=8,profile_broadphase=False)
for job in jobs:
 key=(job['count'],job['mode'],job['trial'],job['variant']);assert key in expected and key not in seen;seen.add(key)
 sub=folder/job['key'];trials=json.loads((sub/'trials.json').read_text());assert len(trials)==1 and trials[0]==job['result']
 m=json.loads((sub/'manifest.json').read_text());a=m['arguments']
 assert a['counts']==[job['count']] and a['modes']==[job['mode']] and a['trials']==1
 assert a['warmup']==90 and a['timed']==240 and a['workers']==8 and a['gpu_solver']=='global' and not a['require_idle']
 kind='sokol' if job['mode']=='sokol-gpu' else 'direct';binary_key='sokol_gpu' if kind=='sokol' else 'gpu'
 assert m['binaries'][binary_key]==manifest['binaries'][job['variant']][kind]
 raw=sub/f"{job['count']}-{job['mode']}-1.json";data=json.loads(raw.read_text());measured=metrics(data,job['mode'],raw,args,job['count'])
 for k,v in measured.items():assert job['result'][k]==v,(job['key'],k)
 groups.setdefault((job['count'],job['mode'],job['variant']),[]).append(job['result'])
 for path in sub.iterdir():
  if path.is_file() and path.suffix in ['.json','.log']:hashes[str(path.relative_to(folder))]=hashlib.sha256(path.read_bytes()).hexdigest()
assert seen==expected
summary=[]
for count,mode in itertools.product(manifest['counts'],manifest['modes']):
 pair={}
 for variant in ['before','after']:
  r=groups[(count,mode,variant)];assert len(r)==5
  pair[variant]={field:{'median':statistics.median(x[field] for x in r),'minimum':min(x[field] for x in r),'maximum':max(x[field] for x in r),'trials':[x[field] for x in r]} for field in ['mean_ms','p50_ms','p95_ms']}
 change=100*(pair['after']['mean_ms']['median']/pair['before']['mean_ms']['median']-1)
 summary.append({'count':count,'mode':mode,'results':pair,'mean_change_percent':change})
 print(f"{count:>6} {mode:12} {pair['before']['mean_ms']['median']:.3f} → {pair['after']['mean_ms']['median']:.3f} ms ({change:+.1f}%)")
(folder/'summary.json').write_text(json.dumps({'manifest':manifest,'groups':summary,'raw_sha256':hashes,'meaning':'Physics mode measures completed-step latency; renderer modes measure full application cadence. Medians of five trial means; full trial ranges retained.'},indent=2)+'\n')
