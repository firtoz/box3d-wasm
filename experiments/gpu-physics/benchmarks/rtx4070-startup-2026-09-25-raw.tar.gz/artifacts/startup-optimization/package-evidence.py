from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[2];p=root/'artifacts/startup-optimization';files={}
def add(path,name=None):
 if path.is_file():files[name or str(path.relative_to(root))]=path.read_bytes()
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.py','.patch'] and not f.name.startswith('remaining-validation'):add(f)
for name in ['matched-startup','steady-comparison','steady-small-recheck','sokol-lifecycle','sokol-lifecycle-fixed','scene-review']:
 folder=p/name
 for f in folder.rglob('*'):
  if 'cache' in f.relative_to(folder).parts:continue
  if f.suffix in ['.json','.log','.py','.ini','.png']:add(f)
for f in (p/'loading-video').iterdir():
 if f.suffix in ['.json','.log','.md'] or f.name=='loading-cold-cache.mp4':add(f)
for f in (root/'scripts').iterdir():
 if f.suffix in ['.py','.sh','.ts']:add(f)
for name in ['000-box3d-cpu','2026-09-25-spatial-hash-growth','2026-09-25-startup']:
 for leaf in ['recording-manifest.json','metrics.json']:add(root/'recordings/snapshots'/name/leaf)
base=json.loads((p/'baseline-timing-sources.json').read_text())
for rel,sha in base['instrumented_files'].items():
 f=Path(base['root'])/rel;assert hashlib.sha256(f.read_bytes()).hexdigest()==sha;add(f)
initial=json.loads((p/'candidate-input-hashes.json').read_text())
for rel,sha in initial.items():
 raw=subprocess.check_output(['git','show','5385a33f:experiments/gpu-physics/'+rel],cwd=root)
 assert hashlib.sha256(raw).hexdigest()==sha,rel
 files['frozen-candidate/'+rel]=raw
files['final-sokol-cleanup.patch']=subprocess.check_output(['git','diff','5385a33f','--','native-samples/sokol_loading.cpp','native-samples/sokol_loading.h','scripts/inject-sokol-bench.py'],cwd=root)
files['REPRODUCE.md']=b'''# GPU startup evidence, 2026-09-25

Hardware: NVIDIA RTX 4070 Laptop GPU; AMD Ryzen 9 8945HS; Linux Vulkan.
Baseline: a34c065b. Startup candidate: 5385a33f. The subsequent Sokol renderer
cleanup fix is preserved in final-sokol-cleanup.patch; final steady-state and
character lifecycle runs use that fix. It changes replacement of an existing
scene, not initial startup. Frozen startup sources are under frozen-candidate/.

Extract into an empty directory to validate without GPU access:

    python3 scripts/plot-startup.py artifacts/startup-optimization/matched-startup unused --title validation --validate-only
    python3 artifacts/startup-optimization/summarize-steady.py
    python3 artifacts/startup-optimization/summarize-steady-small-recheck.py

SHA256SUMS.json identifies every payload file except itself. To plot, install
matplotlib in a virtual environment and omit --validate-only, supplying a real
output prefix. Charts use medians and full trial ranges, never process wall time.
The scheduler pause during a separately requested video capture is retained in
matched-startup/capture-pause-note.json; it affects one process-wall duration and
endpoint hardware sample, not the internal phase timers plotted.

To rerun on hardware, use a checkout of the repository at 5385a33f, extract the
artifacts/startup-optimization files into its experiment directory, and follow
the native-backend README for prerequisites. prepare-startup-baseline.py exports
a34c065b and applies timing instrumentation. build-timed-binaries.py constructs
the four frozen startup binaries. Baseline direct compilation moves the lazy
collision shader into its original UI-thread preparation phase; it does not
step physics or change engine algorithms. The eight exact instrumented baseline
files and their hashes are included. Update the absolute binary/environment
paths in startup-inputs.json for the destination machine and use a NEW output:

    python3 scripts/bench-startup.py startup-inputs.json NEW_OUTPUT --modes direct sokol --trials 3

Apply final-sokol-cleanup.patch and rebuild the Sokol sample for final lifecycle
and steady-state replication. Local helper scripts record their commands and
manifests; adjust machine/display paths before hardware use. The steady runner
uses a34's unmodified binaries, the startup candidate Rust binary, and the final
Sokol binary; 36 cases, 90 warmup + 240 timed steps, 8 CPU workers, global solver.
The separate five-pair 1k headless recheck retains an initial +5% timing difference
that did not reproduce. Normal desktop load is allowed; no idle gate was used.

Cache cold means fresh application/XDG/NVIDIA persistent paths, not flushed
kernel/driver internal caches. Cache inventories and loaded-byte counts remain
in the raw records; large caches, compiled binaries, the plotting environment
and crash core are excluded. The crash backtrace and successful lifecycle logs
are included. The 19 scene videos remain in the local comparison grid; frame
counts, exact binary/clip identities and decoded-frame equality evidence are
included. CPU reference sources and oracle binary were unchanged; the pinned
CPU column was verified rather than overwritten. A separate real-time loading
MP4 is included as visual evidence, not benchmark timing evidence.
'''
files['SHA256SUMS.json']=(json.dumps({name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())},indent=2)+'\n').encode()
archive=root/'benchmarks/rtx4070-startup-2026-09-25-raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
archive.with_suffix(archive.suffix+'.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(len(files),'files;',archive.stat().st_size,'archive bytes')
