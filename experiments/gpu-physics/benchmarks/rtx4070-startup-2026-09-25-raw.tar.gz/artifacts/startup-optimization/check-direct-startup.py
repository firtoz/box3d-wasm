from pathlib import Path
import os,json,subprocess,time
p=Path(__file__).resolve().parent;root=p.parents[1]
env=os.environ.copy();env.update(json.loads((p/'baseline-smoke-environment.json').read_text()));env.pop('GPU_PHYSICS_STARTUP_BENCH',None);env.pop('WAYLAND_DISPLAY',None);env['WINIT_UNIX_BACKEND']='x11'
import ctypes as C
class Data(C.Union):
 _fields_=[('l',C.c_long*5),('b',C.c_char*20)]
class ClientMessage(C.Structure):
 _fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class XEvent(C.Union):
 _fields_=[('client',ClientMessage),('pad',C.c_long*24)]
def request_close(window):
 lib=C.CDLL('libX11.so.6')
 lib.XOpenDisplay.argtypes=[C.c_char_p];lib.XOpenDisplay.restype=C.c_void_p
 lib.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];lib.XInternAtom.restype=C.c_ulong
 lib.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(XEvent)]
 lib.XFlush.argtypes=[C.c_void_p];lib.XCloseDisplay.argtypes=[C.c_void_p]
 display=lib.XOpenDisplay(env['DISPLAY'].encode());assert display
 event=XEvent();event.client.type=33;event.client.display=display;event.client.window=int(window)
 event.client.message_type=lib.XInternAtom(display,b'WM_PROTOCOLS',0);event.client.format=32
 event.client.data.l[0]=lib.XInternAtom(display,b'WM_DELETE_WINDOW',0)
 assert lib.XSendEvent(display,int(window),0,0,C.byref(event))
 lib.XFlush(display);lib.XCloseDisplay(display)
results=[]
for mode in ['resize','close']:
 env['GPU_PHYSICS_STARTUP_REPORT']=str(p/f'direct-{mode}-startup.json')
 with (p/f'direct-{mode}-startup.log').open('w') as log:
  args=[str(root/'target/native-cache-build/release/gpu-physics'),'--scene','falling-cubes','--bodies','200000','--native-timeline',str(p/f'direct-{mode}-timeline.json'),'--warmup','90','--frames','5']
  proc=subprocess.Popen(args,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+30;acted=False
  while proc.poll() is None and time.monotonic()<deadline:
   found=subprocess.run(['xdotool','search','--pid',str(proc.pid)],capture_output=True,text=True)
   if found.returncode==0:
    window=found.stdout.splitlines()[0];title=subprocess.check_output(['xdotool','getwindowname',window],text=True).strip()
    if 'PREPARING GPU' in title:
     action=time.monotonic()
     if mode=='resize':subprocess.run(['xdotool','windowsize',window,'1000','700'],check=True)
     else:
      request_close(window)
     acted=True;break
   time.sleep(.05)
  code=proc.wait(timeout=120)
  assert acted and code==0,(mode,acted,code)
  row={'mode':mode,'exit_code':code,'action_to_exit_s':time.monotonic()-action}
  if mode=='resize':
   metrics=json.loads((p/f'direct-{mode}-startup.json').read_text());assert 1<metrics['loading_frames']<300;row['startup']=metrics
   assert 'matched-window-end: 1000x700' in (p/f'direct-{mode}-startup.log').read_text()
  else:assert row['action_to_exit_s']<2,row
  results.append(row);print(row,flush=True)
(p/'direct-startup-checks.json').write_text(json.dumps(results,indent=2)+'\n')
