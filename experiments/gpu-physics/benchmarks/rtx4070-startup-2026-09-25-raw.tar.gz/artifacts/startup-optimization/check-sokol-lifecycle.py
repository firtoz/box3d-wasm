from pathlib import Path
import os,json,subprocess,time
p=Path(__file__).resolve().parent;root=p.parents[1]
env=os.environ.copy();env.update(json.loads((p/'baseline-smoke-environment.json').read_text()));env.pop('GPU_PHYSICS_STARTUP_BENCH',None);env.pop('WAYLAND_DISPLAY',None);env['WINIT_UNIX_BACKEND']='x11'
import ctypes as C
class Data(C.Union):
 _fields_=[('l',C.c_long*5),('b',C.c_char*20)]
class ClientMessage(C.Structure):
 _fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class XEvent(C.Union):
 _fields_=[('client',ClientMessage),('pad',C.c_long*24)]
def request_close(window):
 lib=C.CDLL('libX11.so.6')
 lib.XOpenDisplay.argtypes=[C.c_char_p];lib.XOpenDisplay.restype=C.c_void_p
 lib.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];lib.XInternAtom.restype=C.c_ulong
 lib.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(XEvent)]
 lib.XFlush.argtypes=[C.c_void_p];lib.XCloseDisplay.argtypes=[C.c_void_p]
 display=lib.XOpenDisplay(env['DISPLAY'].encode());assert display
 event=XEvent();event.client.type=33;event.client.display=display;event.client.window=int(window)
 event.client.message_type=lib.XInternAtom(display,b'WM_PROTOCOLS',0);event.client.format=32
 event.client.data.l[0]=lib.XInternAtom(display,b'WM_DELETE_WINDOW',0)
 assert lib.XSendEvent(display,int(window),0,0,C.byref(event))
 lib.XFlush(display);lib.XCloseDisplay(display)

out=p/'sokol-lifecycle-fixed';out.mkdir(exist_ok=True)
env.update(json.loads((p/'startup-inputs.json').read_text())['environment'])
env['DISPLAY']=':98';env.pop('WAYLAND_DISPLAY',None)
env['GPU_PHYSICS_STARTUP_REPORT']=str(out/'startup.json')
(out/'settings.ini').write_text(json.loads((p/'startup-inputs.json').read_text())['sokol_settings'])
xvfb=subprocess.Popen(['Xvfb',':98','-screen','0','1280x720x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
logpath=out/'viewer.log';proc=None
results=[]
def wait_ready(number):
 deadline=time.monotonic()+120
 while time.monotonic()<deadline:
  assert proc.poll() is None,'viewer exited: '+logpath.read_text()[-2000:]
  if logpath.read_text().count('gpu-loading: ready after')>=number:
   time.sleep(.4);return
  time.sleep(.1)
 raise RuntimeError('loading never completed: '+logpath.read_text()[-2000:])
def pointer_grabbed(window):
 lib=C.CDLL('libX11.so.6');lib.XOpenDisplay.argtypes=[C.c_char_p];lib.XOpenDisplay.restype=C.c_void_p
 lib.XGrabPointer.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_uint,C.c_int,C.c_int,C.c_ulong,C.c_ulong,C.c_ulong]
 lib.XUngrabPointer.argtypes=[C.c_void_p,C.c_ulong];lib.XCloseDisplay.argtypes=[C.c_void_p]
 display=lib.XOpenDisplay(b':98');assert display
 status=lib.XGrabPointer(display,int(window),0,0,1,1,0,0,0)
 if status==0:lib.XUngrabPointer(display,0)
 lib.XCloseDisplay(display)
 assert status in [0,1],('Unexpected XGrabPointer status',status)
 return status==1
try:
 time.sleep(.5)
 with logpath.open('w') as log:
  proc=subprocess.Popen([json.loads((p/'sokol-lifecycle-build-info.json').read_text())['binary'],'--sample-name','Character/Rigid Body'],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
  wait_ready(1)
  window=subprocess.check_output(['xdotool','search','--name','Box3D'],env=env,text=True).splitlines()[-1]
  subprocess.run(['xdotool','windowfocus','--sync',window],env=env,check=True)
  assert pointer_grabbed(window),'character constructor did not lock pointer'
  results.append({'operation':'initial character','pointer_grabbed':True})
  subprocess.run(['xdotool','key','r'],env=env,check=True);wait_ready(2)
  assert pointer_grabbed(window),'character restart lost pointer capture'
  results.append({'operation':'restart character','pointer_grabbed':True})
  subprocess.run(['xdotool','key','bracketleft'],env=env,check=True);wait_ready(3)
  assert not pointer_grabbed(window),'leaving character retained pointer capture'
  results.append({'operation':'switch away','pointer_grabbed':False})
  subprocess.run(['xdotool','key','bracketright'],env=env,check=True);wait_ready(4)
  assert pointer_grabbed(window),'returning to character did not lock pointer'
  results.append({'operation':'switch back','pointer_grabbed':True})
  request_close(window);code=proc.wait(timeout=30);assert code==0,code
  assert 'panicked' not in logpath.read_text()
  results.append({'operation':'close','exit_code':code})
 (out/'result.json').write_text(json.dumps(results,indent=2)+'\n');print(results,flush=True)
finally:
 if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 xvfb.terminate();xvfb.wait(timeout=10)
