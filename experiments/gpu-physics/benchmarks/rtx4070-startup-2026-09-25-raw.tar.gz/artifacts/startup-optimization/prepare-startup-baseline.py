"""Export a34c065b and add timing only; never swap the active checkout's engine."""
from pathlib import Path
import io,tarfile,subprocess,json,hashlib
root=Path(__file__).resolve().parents[2];out=root/'artifacts/startup-optimization';base=out/'baseline-source'
base.mkdir(exist_ok=True)
source=subprocess.check_output(['git','archive','a34c065b','experiments/gpu-physics'],cwd=root.parents[1])
with tarfile.open(fileobj=io.BytesIO(source)) as archive: archive.extractall(base,filter='data')
work=base/'experiments/gpu-physics'
if not (base/'box3d').exists():(base/'box3d').symlink_to(root.parents[1]/'box3d',target_is_directory=True)
p=work/'Cargo.toml';p.write_text(p.read_text()+'\n[workspace]\n')
# Identical headless measurement code, no engine changes.
for name in ['main.rs']:(work/'src'/name).write_bytes((root/'src'/name).read_bytes())
p=work/'src/headless.rs';s=p.read_text();current=(root/'src/headless.rs').read_text();s+='\n'+current[current.index('/// Isolated initialization timing:'):];p.write_text(s)
# Only the device-duration counter from the C bridge, not other candidate changes.
p=work/'src/c_abi.rs';s=p.read_text();cur=(root/'src/c_abi.rs').read_text();a=cur.index('static SHARED_DEVICE_STARTUP_NS');b=cur.index('\n#[no_mangle]',cur.index('fn shared_gpu()',a));x=s.index('fn shared_gpu()');y=s.index('\n#[no_mangle]',x);s=s[:x]+cur[a:b]+s[y:];p.write_text(s)
# Preserve synchronous initialization; bracket identical phase boundaries.
p=work/'src/app.rs';s=p.read_text();metrics=(root/'src/app/startup.rs').read_text();a=metrics.index('pub(super) struct StartupMetrics');b=metrics.index('\nimpl Startup {',a);metrics=metrics[a:b].replace('pub(super) ','')
s='use std::time::Instant;\n'+s+'\n'+metrics+'\n'
s=s.replace('    last_ms: f32,','    last_ms: f32,\n    startup: Option<StartupMetrics>,',1)
s=s.replace('renderer,last_ms:0.0}', 'renderer,last_ms:0.0,startup:None}')
for app in ['DemoApp','TimelineApp']:
 a=s.index('    fn resumed(',s.index('impl ApplicationHandler for '+app));b=s.index('\n    fn window_event(',a);part=s[a:b]
 part=part.replace('        let attrs =','        let started = Instant::now();\n        let attrs =',1)
 part=part.replace('        let world = build_demo_world(gpu.clone(), &self.config);','        let device_ms = started.elapsed().as_secs_f64()*1000.;\n        let scene_started=Instant::now();\n        let world = build_demo_world(gpu.clone(), &self.config);\n        let scene_ms=scene_started.elapsed().as_secs_f64()*1000.;',1)
 part=part.replace('        renderer.configure_reference(', '        let prepare_started=Instant::now();\n        renderer.configure_reference(',1)
 part=part.replace('        renderer.configure_reference(&render_gpu.device, &self.config, world, self.sleep);','        renderer.configure_reference(&render_gpu.device, &self.config, world, self.sleep);\n        crate::api::b3_world_prepare_collision(world);\n        crate::api::b3_world_gpu_wait(world);\n        let gpu_ms=prepare_started.elapsed().as_secs_f64()*1000.;',1)
 part=part.replace('            last_ms: 0.0,','            last_ms: 0.0,\n            startup: Some(StartupMetrics {started,device_ms,scene_ms,gpu_ms,first_loading_ms:None,loading_frames:0,count:self.config.body_count}),',1)
 s=s[:a]+part+s[b:]
s=s.replace('                    Ok(timings) => {','''                    Ok(timings) => {
                        if let Some(startup)=running.startup.take() {
                            startup.presented((running.window.inner_size().width,running.window.inner_size().height));
                            if std::env::var("GPU_PHYSICS_STARTUP_EXIT").as_deref()==Ok("1") { event_loop.exit(); return; }
                        }''',1)
p.write_text(s)
# Instrument original Sokol selection synchronously. Existing GPU loader remains unchanged.
p=work/'native-samples/sokol_loading.h';p.write_text(p.read_text()+'''\nvoid gpu_startup_begin();
void gpu_startup_scene_begin();
void gpu_startup_scene_end();
void gpu_startup_presented();
''')
p=work/'native-samples/sokol_loading.cpp';s=p.read_text();s=s.replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>')
s=s.replace('std::thread worker;','''extern "C" uint64_t gpu_b3_shared_device_startup_ns();
std::chrono::steady_clock::time_point startup_begin,scene_begin,gpu_begin;
uint64_t device_before=0;
double scene_ms=0,device_ms=0,gpu_ms=0,first_loading_ms=-1;
bool startup_pending=false;
std::thread worker;''',1)
s=s.replace('        worker = std::thread([world] {','        gpu_begin=std::chrono::steady_clock::now();\n        worker = std::thread([world] {',1)
s=s.replace('            gpu_b3_world_prepare_loading(world, 2);','            gpu_b3_world_prepare_loading(world, 2);\n            gpu_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-gpu_begin).count();',1)
anchor='bool gpu_loading_active() { return active; }'
extra='''void gpu_startup_begin() { startup_begin=std::chrono::steady_clock::now();startup_pending=true; }
void gpu_startup_scene_begin() { scene_begin=std::chrono::steady_clock::now();device_before=gpu_b3_shared_device_startup_ns(); }
void gpu_startup_scene_end() {
    device_ms=double(gpu_b3_shared_device_startup_ns()-device_before)/1e6;
    scene_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-scene_begin).count()-device_ms;
}
void gpu_startup_presented() {
    double elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-startup_begin).count();
    if(active) {if(first_loading_ms<0)first_loading_ms=elapsed;return;}
    if(!startup_pending)return; startup_pending=false;
    if(const char* path=std::getenv("GPU_PHYSICS_STARTUP_REPORT")) {
        if(FILE* file=std::fopen(path,"w")) {
            const char* cubes=std::getenv("GPU_BENCH_CUBES");
            std::fprintf(file,"{\\\"schema\\\":\\\"startup-v1\\\",\\\"mode\\\":\\\"sokol-renderer\\\",\\\"dynamic_cubes\\\":%lu,\\\"device_ms\\\":%.9f,\\\"scene_ms\\\":%.9f,\\\"gpu_prepare_ms\\\":%.9f,\\\"first_frame_ms\\\":%.9f,\\\"first_loading_frame_ms\\\":%.9f,\\\"loading_frames\\\":%u}\\n",cubes?std::strtoul(cubes,nullptr,10):0,device_ms,scene_ms,gpu_ms,elapsed,first_loading_ms,frames);
            std::fclose(file);
        }
    }
}
'''
s=s.replace(anchor,extra+anchor,1)
s=s.replace('bool gpu_loading_active() { return false; }','void gpu_startup_begin() {}\nvoid gpu_startup_scene_begin() {}\nvoid gpu_startup_scene_end() {}\nvoid gpu_startup_presented() {}\nbool gpu_loading_active() { return false; }');p.write_text(s)
p=work/'scripts/inject-sokol-bench.py';s=p.read_text();anchor='    return text\n\n\ndef inject_sample';replacement='''    text = text.replace('static void OnInit( void )\\n{', 'static void OnInit( void )\\n{\\n    gpu_startup_begin();')
    text = text.replace('\\tSelectSample( &s_context, index, false );', '\\tgpu_startup_scene_begin();\\n\\tSelectSample( &s_context, index, false );\\n\\tgpu_startup_scene_end();')
    text = text.replace('sg_commit();', 'sg_commit(); gpu_startup_presented();')
    return text


def inject_sample''';assert anchor in s;s=s.replace(anchor,replacement,1);p.write_text(s)
# Hash every instrumentation change relative to the commit, retaining exact files.
changes={}
for file in ['Cargo.toml','src/main.rs','src/headless.rs','src/app.rs','src/c_abi.rs','native-samples/sokol_loading.h','native-samples/sokol_loading.cpp','scripts/inject-sokol-bench.py']:
 changes[file]=hashlib.sha256((work/file).read_bytes()).hexdigest()
(out/'baseline-timing-sources.json').write_text(json.dumps({'baseline':'a34c065b','root':str(work),'instrumented_files':changes},indent=2)+'\n')
print(work)
