from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path(__file__).resolve().parents[2];out=root/'artifacts/startup-optimization';work=out/'baseline-source/experiments/gpu-physics'
def run(name,args):
 with (out/(name+'.log')).open('w') as log:subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
run('candidate-final-direct-build',['./scripts/build-native-cache.sh','build','--release'])
shutil.copy2(root/'target/native-cache-build/release/gpu-physics',out/'candidate-direct')
run('candidate-final-sokol-build',['python3','scripts/run-native-samples.py','gpu','--build-only','--build-info',str(out/'sokol-build-info.json')])
shutil.copy2(root/'native-samples/build-gpu-native-cache-portable/bin/samples_gpu',out/'candidate-sokol')
run('prepare-baseline-timing',['python3',str(out/'prepare-startup-baseline.py')])
command=['cargo','--config',str(root/'target/native-backend/cargo-config.toml'),'build','--release','--manifest-path',str(work/'Cargo.toml'),'--target-dir',str(root/'target/native-cache-build')]
run('baseline-final-direct-build',command+['--features','native-command-cache'])
shutil.copy2(root/'target/native-cache-build/release/gpu-physics',out/'baseline-direct-timed')
run('baseline-final-sokol-rust-build',command+['--lib','--features','native-command-cache,external-c-shim'])
run('baseline-final-sokol-build',['cmake','--build',str(out/'baseline-sokol-build'),'--target','samples_gpu','-j6'])
shutil.copy2(out/'baseline-sokol-build/bin/samples_gpu',out/'baseline-sokol-timed')
identities={}
for name in ['candidate-direct','candidate-sokol','baseline-direct-timed','baseline-sokol-timed']:
 p=out/name;identities[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'timed-binaries.json').write_text(json.dumps(identities,indent=2)+'\n')
print('All four timed binaries built and preserved.',flush=True)
