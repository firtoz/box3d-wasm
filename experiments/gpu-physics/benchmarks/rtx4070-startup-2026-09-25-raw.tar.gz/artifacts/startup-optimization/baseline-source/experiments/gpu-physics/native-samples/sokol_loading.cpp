#include "sokol_loading.h"
#include "imgui.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <thread>
#include <cstring>
#include <string>
#include <algorithm>
#include <cstdlib>

#if defined(GPU_PHYSICS_SAMPLES)
extern "C" bool gpu_b3_world_loading_needed(b3WorldId);
extern "C" void gpu_b3_world_prepare_loading(b3WorldId, unsigned);
extern "C" void gpu_b3_loading_message(char*, size_t);
extern "C" const char* gpu_b3_world_gpu_fail(b3WorldId);
namespace {
extern "C" uint64_t gpu_b3_shared_device_startup_ns();
std::chrono::steady_clock::time_point startup_begin,scene_begin,gpu_begin;
uint64_t device_before=0;
double scene_ms=0,device_ms=0,gpu_ms=0,first_loading_ms=-1;
bool startup_pending=false;
std::thread worker;
std::atomic<int> stage{0}; // 1 buffers/common kernels, 2 collision, 3 ready
std::string failure;
bool active = false;
unsigned frames = 0;
std::chrono::steady_clock::time_point started;
}
void gpu_startup_begin() { startup_begin=std::chrono::steady_clock::now();startup_pending=true; }
void gpu_startup_scene_begin() { scene_begin=std::chrono::steady_clock::now();device_before=gpu_b3_shared_device_startup_ns(); }
void gpu_startup_scene_end() {
    device_ms=double(gpu_b3_shared_device_startup_ns()-device_before)/1e6;
    scene_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-scene_begin).count()-device_ms;
}
void gpu_startup_presented() {
    double elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-startup_begin).count();
    if(active) {if(first_loading_ms<0)first_loading_ms=elapsed;return;}
    if(!startup_pending)return; startup_pending=false;
    if(const char* path=std::getenv("GPU_PHYSICS_STARTUP_REPORT")) {
        if(FILE* file=std::fopen(path,"w")) {
            const char* cubes=std::getenv("GPU_BENCH_CUBES");
            std::fprintf(file,"{\"schema\":\"startup-v1\",\"mode\":\"sokol-renderer\",\"dynamic_cubes\":%lu,\"device_ms\":%.9f,\"scene_ms\":%.9f,\"gpu_prepare_ms\":%.9f,\"first_frame_ms\":%.9f,\"first_loading_frame_ms\":%.9f,\"loading_frames\":%u}\n",cubes?std::strtoul(cubes,nullptr,10):0,device_ms,scene_ms,gpu_ms,elapsed,first_loading_ms,frames);
            std::fclose(file);
        }
    }
}
bool gpu_loading_active() { return active; }
bool gpu_loading_poll(b3WorldId world) {
    if (!active && gpu_b3_world_loading_needed(world)) {
        if (worker.joinable()) worker.join();
        failure.clear();
        active = true;
        frames = 0;
        stage.store(1);
        started = std::chrono::steady_clock::now();
        gpu_begin=std::chrono::steady_clock::now();
        worker = std::thread([world] {
            gpu_b3_world_prepare_loading(world, 1);
            stage.store(2);
            gpu_b3_world_prepare_loading(world, 2);
            gpu_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-gpu_begin).count();
            if (const char* error = gpu_b3_world_gpu_fail(world); error && error[0]) {
                failure = error;
                stage.store(4);
            } else { stage.store(3); }
        });
    }
    if (active && stage.load() == 3) {
        worker.join();
        active = false;
        fprintf(stderr, "gpu-loading: ready after %.3f s, %u loading frames, world %u:%u (no physics steps)\n",
            std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count(), frames,
            unsigned(world.index1), unsigned(world.generation));
    }
    if (active) ++frames;
    return active;
}
void gpu_loading_draw() {
    const int current = stage.load();
    const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    char detail[256]{};
    gpu_b3_loading_message(detail, sizeof(detail));
    const auto& io = ImGui::GetIO();
    if (current == 4) {
        ImGui::SetNextWindowPos(ImVec2(30,30));
        ImGui::Begin("GPU preparation failed");
        ImGui::TextWrapped("%s", failure.c_str());
        ImGui::TextUnformatted("Close the window to exit. The simulation has not advanced.");
        ImGui::End();
        return;
    }
    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min(560.0f, io.DisplaySize.x - 32.0f), 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(28, 24));
    ImGui::Begin("Preparing simulation", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove);
    ImGui::TextColored(ImVec4(0.45f, 0.77f, 1.0f, 1.0f), "PREPARING SIMULATION");
    ImGui::Spacing();
    ImGui::Text("%c  Loading GPU physics     %.1f s", "|/-\\"[int(elapsed*5)%4], elapsed);
    ImGui::Separator();
    ImGui::TextUnformatted("Done    Scene created");
    ImGui::Text("%s    GPU buffers and common shaders", current > 1 ? "Done" : "Active");
    ImGui::Text("%s    Scene collision shader", current > 2 ? "Done" : current == 2 ? "Active" : "Waiting");
    ImGui::TextUnformatted("Waiting    Start simulation");
    ImGui::Spacing();
    ImGui::TextWrapped("%s", detail[0] ? detail : "Preparing GPU resources...");
    ImGui::Spacing();
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
    ImGui::TextWrapped("First-time shader compilation can take a few minutes.");
    ImGui::TextWrapped("Progress advances when each operation finishes.");
    ImGui::PopStyleColor();
    ImGui::End();
    ImGui::PopStyleVar();
}
void gpu_loading_shutdown() { if (worker.joinable()) worker.join(); }
#else
void gpu_startup_begin() {}
void gpu_startup_scene_begin() {}
void gpu_startup_scene_end() {}
void gpu_startup_presented() {}
bool gpu_loading_active() { return false; }
bool gpu_loading_poll(b3WorldId) { return false; }
void gpu_loading_draw() {}
void gpu_loading_shutdown() {}
#endif
