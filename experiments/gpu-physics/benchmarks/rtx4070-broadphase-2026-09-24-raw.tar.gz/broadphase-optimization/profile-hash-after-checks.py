import json,os,select,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
try:fd=os.pidfd_open(1465354)
except ProcessLookupError:fd=None
if fd is not None:
 poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
checks=json.loads((folder/'candidate-status.json').read_text())
assert len(checks)==3 and all(c['status']=='passed' for c in checks),'candidate qualification failed'
env=os.environ.copy();env.update(json.loads((folder/'baseline/manifest.json').read_text())['environment'])
cmd=['python3','scripts/bench-falling-cubes.py',str(folder/'hash-profile-200k'),'--profile-broadphase','--counts','200000','--modes','physics-gpu','--trials','1','--workers','8','--gpu-solver','global','--gpu-binary',str(folder/'hash-candidate-gpu'),'--timeout','900']
with (folder/'hash-profile-200k.log').open('w') as log:
 r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
rows=json.loads((folder/'hash-profile-200k/trials.json').read_text())
assert r.returncode==0 and len(rows)==1 and rows[0]['status']=='ok',rows
print('First candidate 200k diagnostic passed; inspect stages before further tuning.')
