import hashlib,json,os,select,shutil,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
rows=json.loads((folder/'matched-hash/trials.json').read_text())
assert len(rows)==30 and all(r['status']=='ok' for r in rows),'matched physics comparison incomplete'
env=os.environ.copy();env.update(json.loads((folder/'baseline/manifest.json').read_text())['environment'])
with (folder/'hash-sokol-build.log').open('w') as log:
 subprocess.run(['python3','scripts/run-native-samples.py','gpu','--build-only','--build-info',str(folder/'hash-sokol-build.json')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sokol=folder/'hash-candidate-sokol';shutil.copy2(root/'native-samples/build-gpu-native-cache-portable/bin/samples_gpu',sokol)
(folder/'hash-sokol-binary.json').write_text(json.dumps(dict(path=str(sokol),sha256=hashlib.sha256(sokol.read_bytes()).hexdigest()),indent=2)+'\n')
with (folder/'matched-renderers.log').open('w') as log:
 subprocess.run(['python3','scripts/compare-falling-renderers.py',str(folder/'baseline/manifest.json'),str(folder/'matched-renderers'),
 '--gpu-binary',str(folder/'hash-candidate-gpu'),'--sokol-gpu-binary',str(sokol)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Matched application renderer comparisons completed.')
