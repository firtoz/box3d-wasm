import json,hashlib,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
assert Path('/sys/class/power_supply/ACAD/online').read_text().strip()=='1'
for path,expected in json.loads((folder/'candidate-engine-inputs.json').read_text()).items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,path
with (folder/'matched-renderers-resume.log').open('x') as log:
 subprocess.run(['python3','scripts/compare-falling-renderers.py',str(folder/'baseline/manifest.json'),str(folder/'matched-renderers'),
 '--resume','--gpu-binary',str(folder/'hash-candidate-gpu'),'--sokol-gpu-binary',str(folder/'hash-candidate-sokol')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Renderer trials complete; starting diagnostic profiles and recordings.',flush=True)
subprocess.run(['python3',str(folder/'finish-profiles-recordings-recovered.py')],cwd=root,check=True)
print('Measurements and recordings complete; charts, audit and archive remain.',flush=True)
