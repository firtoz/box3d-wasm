import json,os,select,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
try:fd=os.pidfd_open(1531507)
except ProcessLookupError:fd=None
if fd is not None:
 poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
checks=json.loads((folder/'regression-status.json').read_text())
assert len(checks)==3 and all(c['status']=='passed' for c in checks),'regressions failed'
manifest=folder/'baseline/manifest.json';source=json.loads(manifest.read_text())
assert 'GPU_PHYSICS_PROFILE_BROADPHASE' not in source['environment']
cmd=['python3','scripts/compare-falling-binaries.py',str(manifest),str(folder/'matched-hash'),
 '--binary','before-49b024f5='+str(folder/'baseline/gpu'),
 '--binary','after-hash-growth='+str(folder/'hash-candidate-gpu'),
 '--counts','5','1000','15000','100000','200000','--trials','3','--timeout','900']
with (folder/'matched-hash.log').open('w') as log:
 r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,'matched comparison failed; inspect retained log'
rows=json.loads((folder/'matched-hash/trials.json').read_text())
assert len(rows)==30 and all(r['status']=='ok' for r in rows)
print('All30 uninstrumented alternating comparison trials passed.')
