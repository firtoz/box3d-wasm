import os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
subprocess.run(['python3',str(folder/'check-final-recordings.py')],cwd=root,check=True)
subprocess.run(['python3',str(folder/'review-recordings.py')],cwd=root,check=True)
runtime=Path('/home/frtn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
venv=Path.home()/'.cache/box3d-falling-plots';python=venv/'bin/python'
with (folder/'chart-generation.log').open('w') as log:
 def run(cmd):subprocess.run(list(map(str,cmd)),cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 if not python.exists():run(['uv','venv','--python',runtime,venv])
 run(['uv','pip','install','--python',python,'matplotlib'])
 (folder/'chart-requirements.txt').write_bytes(subprocess.check_output(['uv','pip','freeze','--python',str(python)]))
 run(['python3',folder/'audit-measurements.py'])
 title='RTX 4070 Laptop (8 GiB) / Ryzen 9 8945HS / NVIDIA 610.57.04'
 run([python,'scripts/plot-falling-comparison.py',folder/'matched-hash',folder/'matched-renderers',
      'benchmarks/rtx4070-broadphase-comparison-2026-09-24','--title',title])
 run([python,'scripts/plot-falling-solvers.py',folder/'matched-hash',
      'benchmarks/rtx4070-broadphase-phases-2026-09-24','--counts','100000','200000',
      '--variant-label','before-49b024f5=Before','--variant-label','after-hash-growth=After',
      '--title',title,'--note','Broadphase spatial-hash growth; 3 alternating trials, normal desktop load. Primary buffers exclude driver/render/staging memory.'])
 run([python,'scripts/plot-broadphase-stages.py',folder/'profile-large',folder/'hash-profile-final',
      'benchmarks/rtx4070-broadphase-stages-2026-09-24','--title',title])
print('Numerical audit and charts generated. Visual review, final docs and archive still required.',flush=True)
