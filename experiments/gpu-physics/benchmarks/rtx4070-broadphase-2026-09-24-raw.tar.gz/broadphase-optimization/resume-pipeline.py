import json,os,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
for path,expected in json.loads((folder/'candidate-engine-inputs.json').read_text()).items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,path
manifest=json.loads((folder/'matched-hash/manifest.json').read_text())
cmd=['python3','scripts/compare-falling-binaries.py',str(folder/'baseline/manifest.json'),str(folder/'matched-hash'),
 '--resume','--counts',*map(str,manifest['counts']),'--trials',str(manifest['trials']),'--timeout',str(manifest['timeout'])]
for label,identity in manifest['binaries'].items():cmd+=['--binary',label+'='+identity['path']]
with (folder/'matched-hash-resume.log').open('x') as log:
 subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Matched physics complete; starting renderer build/comparison.',flush=True)
subprocess.run(['python3',str(folder/'renderers-after-matched-recovered.py')],cwd=root,check=True)
print('Renderers complete; starting diagnostic profiles and recordings.',flush=True)
subprocess.run(['python3',str(folder/'finish-profiles-recordings-recovered.py')],cwd=root,check=True)
print('Recovered pipeline complete. Final audit, visual review, charts and documentation remain.',flush=True)
