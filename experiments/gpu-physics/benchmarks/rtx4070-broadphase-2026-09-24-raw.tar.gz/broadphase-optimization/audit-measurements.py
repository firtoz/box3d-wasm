"""Verify complete broadphase datasets; targets are reported, never weakened."""
import hashlib,json,statistics,runpy
from types import SimpleNamespace
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,expected in read(folder/'candidate-engine-inputs.json').items():assert digest(root/path)==expected,path
for name,row in read(folder/'validation-summary.json').items():
 assert digest(folder/row['log'])==row['sha256']
 assert all('0 failed' in line for line in row['results'])
assert '268 passed; 0 failed' in (folder/'hash-library.log').read_text()
rows=read(folder/'matched-hash/trials.json');assert len(rows)==30 and all(r['status']=='ok' for r in rows)
manifest=read(folder/'matched-hash/manifest.json');assert not manifest['source']['arguments']['require_idle']
assert 'GPU_PHYSICS_PROFILE_BROADPHASE' not in manifest['source']['environment']
for identity in manifest['binaries'].values():assert digest(Path(identity['path']))==identity['sha256']
summary=[]
for count in [5,1000,15000,100000,200000]:
 grouped={}
 for variant in ['before-49b024f5','after-hash-growth']:
  group=[r for r in rows if r['count']==count and r['variant']==variant]
  assert sorted(r['trial'] for r in group)==[1,2,3]
  for row in group:
   path=folder/f'matched-hash/{count}-{variant}-{row["trial"]}.json';assert digest(path)==row['raw_sha256']
   data=read(path);raw=data['raw_runs'][0]
   assert data['bodies']==count+1 and data['sub_steps']==4 and not data['sleep']
   assert abs(data['dt']-1/60)<1e-7 and raw['physics_step']==330
   assert raw['awake_dynamic']==count and raw['live_contacts']>0
   assert len(raw['completed_step_ms'])==240
   assert abs(statistics.mean(raw['completed_step_ms'])-row['mean_ms'])<1e-9
   assert raw.get('broadphase_profile') is None
  grouped[variant]=dict(mean_ms=statistics.median(r['mean_ms'] for r in group),
   broadphase_ms=statistics.median(r['phase_mean_ms']['broadphase'] for r in group),
   trial_means_ms=[r['mean_ms'] for r in group],p50_ms=statistics.median(r['p50_ms'] for r in group),
   p95_ms=statistics.median(r['p95_ms'] for r in group))
 before,after=grouped.values()
 summary.append(dict(count=count,variants=grouped,
  throughput_gain_percent=100*(before['mean_ms']/after['mean_ms']-1),
  broadphase_reduction_percent=100*(1-after['broadphase_ms']/before['broadphase_ms'])))
render=read(folder/'matched-renderers/trials.json');assert len(render)==24 and all(r['status']=='ok' for r in render)
assert len({tuple(r['framebuffer']) for r in render})==1
render_manifest=read(folder/'matched-renderers/manifest.json')
assert render_manifest['source']['environment']==manifest['source']['environment']
for variant in render_manifest['binaries'].values():
 for identity in variant.values():assert digest(Path(identity['path']))==identity['sha256']
for count in [100000,200000]:
 for mode in ['direct-gpu','sokol-gpu']:
  for variant in ['before','after']:
   group=[r for r in render if (r['count'],r['mode'],r['variant'])==(count,mode,variant)]
   assert sorted(r['trial'] for r in group)==[1,2,3]
metric_reader=runpy.run_path(str(root/'scripts/bench-falling-cubes.py'))['metrics']
for row in render:
 run=folder/'matched-renderers'/row['directory']
 path=run/f'{row["count"]}-{row["mode"]}-1.json'
 assert digest(path)==row['raw_sha256']
 local_manifest=read(run/'manifest.json')
 assert local_manifest['environment']==manifest['source']['environment']
 args=local_manifest['arguments']
 assert args['workers']==8 and args['gpu_solver']=='global'
 assert args['warmup']==90 and args['timed']==240 and not args['require_idle']
 identity_key='sokol_gpu' if row['mode']=='sokol-gpu' else 'gpu'
 assert local_manifest['binaries'][identity_key]['sha256']==render_manifest['binaries'][row['variant']][identity_key]['sha256']
 # Re-read raw cadence, completed-pose/contact checks and presentation logs.
 measured=metric_reader(read(path),row['mode'],path,SimpleNamespace(**args),row['count'])
 for key in ['mean_ms','p50_ms','p95_ms']:
  assert abs(measured[key]-row[key])<1e-9,(path,key)
 assert measured['framebuffer']==row['framebuffer']
for dataset in ['profile-large','hash-profile-final']:
 trials=read(folder/dataset/'trials.json');assert len(trials)==6 and all(r['status']=='ok' for r in trials)
 for count in [100000,200000]:
  for trial in [1,2,3]:
   raw=read(folder/dataset/f'{count}-physics-gpu-{trial}.json')['raw_runs'][0]
   assert len(raw['broadphase_profile']['samples_ms'])==240
large=summary[-1]
proof=dict(physics=summary,physics_trials=30,renderer_trials=24,profile_trials=12,
 targets=dict(broadphase_20pct_met=large['broadphase_reduction_percent']>=20,
              throughput_10pct_met=large['throughput_gain_percent']>=10),
 note='Numerical/source audit only. Chart, documentation, recordings and raw archive review remain separate requirements.')
(folder/'measurement-audit.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
