import json,os,select,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
try:fd=os.pidfd_open(1583208)
except ProcessLookupError:fd=None
if fd is not None:
 poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
rows=json.loads((folder/'matched-renderers/trials.json').read_text())
assert len(rows)==24 and all(r['status']=='ok' for r in rows),'renderer comparison incomplete'
env=os.environ.copy();env.update(json.loads((folder/'baseline/manifest.json').read_text())['environment'])
with (folder/'hash-profile-final.log').open('w') as log:
 subprocess.run(['python3','scripts/bench-falling-cubes.py',str(folder/'hash-profile-final'),'--profile-broadphase',
 '--counts','100000','200000','--modes','physics-gpu','--trials','3','--workers','8','--gpu-solver','global',
 '--gpu-binary',str(folder/'hash-candidate-gpu'),'--timeout','900'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
rows=json.loads((folder/'hash-profile-final/trials.json').read_text())
assert len(rows)==6 and all(r['status']=='ok' for r in rows),'candidate profile incomplete'
label='2026-09-24-spatial-hash-growth'
assert not (root/'recordings/snapshots'/label).exists(),'do not overwrite prior recordings'
env.update(GPU_RECORD_BIN=str(folder/'hash-candidate-gpu'),FRAMES='300',METRIC_RUNS='1')
with (folder/'hash-recordings.log').open('w') as log:
 subprocess.run(['./scripts/record-snapshot.sh',label],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Repeated candidate profiles and affected scene recordings finished; audit and chart review remain.')
