import json,os,select,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
try:fd=os.pidfd_open(1481378)
except ProcessLookupError:fd=None
if fd is not None:
 poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
rows=json.loads((folder/'hash-profile-200k/trials.json').read_text())
assert len(rows)==1 and rows[0]['status']=='ok','candidate diagnostic failed'
env=os.environ.copy();env.update(json.loads((folder/'baseline/manifest.json').read_text())['environment']);env.pop('GPU_PHYSICS_PROFILE_BROADPHASE',None)
base=['./scripts/build-native-cache.sh','test','--release','--lib']
checks=[('hash-library',base+['--','--test-threads=1'],False),
 ('hash-cache-off-coverage',base+['canonical_grid_matches_matrix_across_cells_and_hash_collisions','--','--test-threads=1'],True),
 ('hash-cache-off-lifecycle',base+['tiled_physics_dispatch_preserves_callbacks_events_and_remapping','--','--test-threads=1'],True)]
status=[]
for name,cmd,off in checks:
 runenv=env.copy()
 if off:
  for key in ['RADIX','CONTACT','GRAPH','TAIL','PAIR','RESET']:runenv['GPU_PHYSICS_NATIVE_'+key+'_CACHE']='0'
  runenv['GPU_PHYSICS_FULL_REPLAY']='0'
 else:runenv['VK_DRIVER_FILES']='/usr/share/vulkan/icd.d/nvidia_icd.json:/usr/share/vulkan/icd.d/radeon_icd.json'
 row=dict(name=name,command=cmd,status='running',started=time.time(),environment={k:v for k,v in runenv.items() if k.startswith(('GPU_','VK_','WGPU_'))});status.append(row)
 with (folder/(name+'.log')).open('w') as log:
  child=subprocess.Popen(cmd,cwd=root,env=runenv,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid
  (folder/'regression-status.json').write_text(json.dumps(status,indent=2)+'\n');code=child.wait()
 row.update(status='passed' if code==0 else 'failed',returncode=code,ended=time.time())
 (folder/'regression-status.json').write_text(json.dumps(status,indent=2)+'\n')
 assert code==0,name
print('Full library and cache-off coverage/lifecycle checks passed.')
