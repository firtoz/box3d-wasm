# Broadphase goal completion audit

This checklist is not completion evidence by itself. Recheck each referenced
source after all queued jobs finish. Do not commit or push.

| Requirement | Evidence to inspect | Current state |
| --- | --- | --- |
| Baseline 49b024f5 and same hardware/settings | baseline/manifest.json, matched manifests, preserved binary hashes, source patches | Baseline preserved; final matching audit pending |
| Separate clear, insertion, pair generation, sorting at 100k/200k | profile-large and hash-profile-final raw 240-by-7 samples; stage plot | Before complete; repeated after queued |
| Broadphase optimization, unchanged solver | working diff, candidate-engine-inputs.json, coverage and lifecycle tests | Spatial table grows within existing reserved storage; engine frozen |
| Complete coverage and matrix/grid transitions | hash-coverage.log plus fixture source; cache-off coverage log | Passed |
| History, events, deletion/reuse and dispatch variants | hash-library.log and corresponding fixtures; hash-cache-off-lifecycle.log | 268 full tests and focused cache-off tests passed |
| >=20% broadphase reduction, >=10% throughput gain at 200k | three paired uninstrumented trial medians in matched-hash; measurement-audit.json | In progress; report any miss honestly |
| Small scenes under normal desktop load | 5/1000/15000 matched trials, ranges and saved telemetry | Trials complete; final reporting pending |
| Both renderers at 100k/200k, three alternating pairs | matched-renderers 24 rows, raw cadence, framebuffer/settings, binary identities | Queued |
| Affected-scene recordings | 19 new clips, recording manifests/metrics; CPU-first comparison grid; visual review | Queued; recording-review.json still needed |
| Useful dated charts | comparison, stages, phases/memory PNG/SVG/JSON; inspect rendered images | Plotters prepared; generation and QA pending |
| README and docs accurately describe results/limits | README.md and docs/gpu-physics.md; preserve old charts | Final update pending |
| Reproducible raw evidence including failures/settings | package-evidence.py output, SHA256 manifest and archive readback | Packager prepared; requires completed audit and recording review |
| Box3D/WASM unchanged | final git diff scope and submodule status | No changes so far; verify again at completion |

Targets are aspirations to assess honestly, not an excuse to drop trials or
relax correctness. Numerical audit, visual review and documentation/archival
checks are distinct; none replaces the others.
