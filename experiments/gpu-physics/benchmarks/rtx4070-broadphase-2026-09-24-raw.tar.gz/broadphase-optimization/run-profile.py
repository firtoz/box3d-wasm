import os,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];p=root/'artifacts/broadphase-optimization'
env=os.environ.copy();env.update(json.loads((p/'profile-environment.json').read_text()))
(p/'profile-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
cmd=['python3','scripts/bench-falling-cubes.py',str(p/'profile-large'),'--profile-broadphase','--counts','100000','200000','--modes','physics-gpu','--trials','3','--workers','8','--gpu-solver','global','--gpu-binary',str(p/'profile-gpu'),'--timeout','900']
with (p/'profile-large.log').open('w') as log:
 r=subprocess.run(cmd,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT)
trials=json.loads((p/'profile-large/trials.json').read_text())
assert r.returncode==0 and len(trials)==6 and all(x['status']=='ok' for x in trials),trials
print('All six large-world diagnostic trials passed.')
