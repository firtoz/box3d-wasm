import hashlib,json,os,select,shutil,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
# Wait for this exact process, never a stale lock or a process-name match.
try:
 fd=os.pidfd_open(1397502)
except ProcessLookupError:
 fd=None
if fd is not None:
 poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
trials=json.loads((folder/'profile-large/trials.json').read_text())
assert len(trials)==6 and all(t['status']=='ok' for t in trials),'baseline profile incomplete'
env=os.environ.copy();env.update(json.loads((folder/'baseline/manifest.json').read_text())['environment']);env.pop('GPU_PHYSICS_PROFILE_BROADPHASE',None)
stages=[]
commands=[
 ('hash-bounds',['./scripts/build-native-cache.sh','test','--release','--lib','spatial_hash_growth_clears_buckets_without_touching_contact_identity','--','--test-threads=1']),
 ('hash-coverage',['./scripts/build-native-cache.sh','test','--release','--lib','canonical_grid_matches_matrix_across_cells_and_hash_collisions','--','--test-threads=1']),
 ('hash-build',['./scripts/build-native-cache.sh','build','--release','--bin','gpu-physics']),
]
for name,cmd in commands:
 row=dict(name=name,command=cmd,started=time.time(),status='running');stages.append(row)
 (folder/'candidate-status.json').write_text(json.dumps(stages,indent=2)+'\n')
 with (folder/(name+'.log')).open('w') as log:
  child=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid
  (folder/'candidate-status.json').write_text(json.dumps(stages,indent=2)+'\n');code=child.wait()
 row.update(returncode=code,status='passed' if code==0 else 'failed',ended=time.time())
 (folder/'candidate-status.json').write_text(json.dumps(stages,indent=2)+'\n')
 assert code==0,name
binary=folder/'hash-candidate-gpu';shutil.copy2(root/'target/native-cache-build/release/gpu-physics',binary)
(folder/'hash-candidate-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
(folder/'hash-candidate-binary.json').write_text(json.dumps(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2)+'\n')
print('Hash bounds and independent coverage fixtures passed; candidate binary preserved.')
