LATEST session50679 now final candidate profile: 200k trial3. 5/6 profile
trials complete; both prior200kdiagnostics passed. Matched physics30/30 and
renderer24/24 already complete. After profile:19 scene recordings, then
check-final-recordings/review sheets, numerical audit and three plots via
queued generate-final-charts.py. All fresh output must still be inspected;
recording-review.json not yet created, archive gate remains unmet.
Docs/gpu-physics.md Performance row now updated with verified latest gains and
pending evidence notice. Final docs must remove pending notices only after audit.

LATEST recording review helpers prepared/syntax checked, NOT executed yet.
check-final-recordings.py verifies 19x300frame clips for CPU/current/previous GPU,
current and previous GPU binary hashes, CPU-first/new-GPU-next grid order; writes
recording-integrity.json (not visual approval). review-recordings.py generates
5 contact sheets at final frame299, CPU | current | previous, under recording-review/.
Both are queued at START of generate-final-charts.py, which has not executed yet.
Do not append work to already-running finish-profiles-recordings module and assume
it will execute: Python compiled it when current profiles began. Final manual
image/clip review still needed, then recording-review.json for archive gate.

LATEST session 50679 now profiles 200k trial1. All 3 candidate100k diagnostic
trials passed; stage median summary profile-100k-complete-summary.json. Renderer
24/24 + physics30/30 complete. Remaining: three200kdiagnostics, recordings,
queued audit/charts, visual QA/recording-review.json, docs and raw archive.

LATEST: ALL RENDERERS COMPLETE 24/24 valid, raw hashes verified. Session50679
now runs hash-profile-final (100k trial1), then recording label2026-09-25-spatial-
hash-growth, numerical audit and chart generation. Preserve same session; no
parallel heavy work. Renderer complete summary in renderer-complete-summary.json:
100k direct20.149->21.061FPS +4.53%;200k8.548->9.582 +12.10%;100kSokol12.474->13.010
+4.30%;200k6.388->6.900 +8.02%. README updated with these verified results;
remaining profiles/recording/charts explicitly pending. Need final docs/visual
review/recording-review.json and verified raw archive before marking goal complete.

LATEST recording label corrected BEFORE capture: 2026-09-25-spatial-hash-growth.
Updated queued finish-profiles-recordings-recovered.py and package-evidence.py.
Old planned 2026-09-24-spatial-hash-growth sorted before prior tiled snapshot,
so compare grid would show old GPU first. Actual recording date Sep25 now sorts
latest correctly. Engine/measurement unchanged. Benchmark charts/archive retain
2026-09-24 experiment-start date; explain measurement period Sep24–25 in docs.
Current renderer third direct after still running; third before passed8.55FPS.

LATEST session 50679 live: renderer trial grid now 20/24 valid. Second Sokol
pair passed 6.19 -> 6.90 FPS (+11.5%); second direct pair 8.93 -> 9.58 FPS
(+7.3%). Third direct baseline 200k now active. Remaining 4 renderer trials,
then 6 diagnostic profiles + recordings + queued numerical audit/chart generation.
Do not run old wrappers/duplicate jobs. Primary output log matched-renderers-resume.log.

LATEST plot environment recovery: /tmp/falling-plots-env disappeared on reboot.
Prepared generate-final-charts.py; queued at END of finish-profiles-recordings-
recovered.py after all timing/recordings. Creates ~/.cache/box3d-falling-plots via
uv using bundled Python, installs matplotlib, archives exact package list,
runs numerical audit + all 3 plotters. Outputs benchmarks/rtx4070-broadphase-
{comparison,phases,stages}-2026-09-24 PNG/SVG/JSON; log chart-generation.log.
Syntax checked only. No install or plotting launched during current timing.
Still must inspect generated images, recording review, final docs and pack archive.

LATEST live session 50679: matched-renderers has 16 valid rows. First 200k
Sokol pair passed 6.39 -> 6.95 FPS (+8.8%), means 156.54631 -> 143.83566 ms,
all 330 frames/zero Sokol errors. Current direct-gpu after trial 2 (alternating
order). 8 renderer trials remain, then queued profiles/recordings. No new engine
changes. Final renderer summaries must use all 3 trials, not this first pair.

LATEST session 50679: first Sokol before 200k trial 1 passed 6.39 FPS; after
trial 1 now live. Renderer valid rows 15. Found source-proven quadratic startup
path: create_falling_cubes -> attach_shape(first_shape) -> update_body_extents
scans entire world shapes for each body. Approx 20B shape visits at200k; not yet
runtime profiled. Documented in README + startup-source-finding.json. DO NOT
change frozen engine mid-comparison. Strong future startup optimization target.

LATEST: session 50679 remains live. First resumed 200k direct renderer pair
passed: before 128.3849448 ms / 7.79 FPS, after 111.1151535 ms / 9.00 FPS,
about +15.5% FPS. Both 2040x1148 and 330 steps. matched-renderers now 14 valid
rows; current Sokol before 200k trial 1. Do not restart. README now includes
verified physics results/ranges/small-scene median slowdowns and startup black
window explanation. Final charts/profile/recording/archive still pending.
physics-verification.json independently verifies all 30 raw physics hashes,
settings, awake/contact counts, measured samples/means, profiling off, unchanged
allocation per count (200k 3674669472 bytes). No engine changes/commits.

LATEST after reboot: user resumed goal (get_goal active), ACAD=1 Charging.
NEW LIVE session 50679: resume-after-reboot.py. Physics is complete: 30/30 valid;
all raw hashes and frozen engine inputs verified. Renderer has 12 valid 100k
trials. First 200k direct baseline previously failed physics_step=321 (expected
330), log lacks matched-window-end; consistent with viewer closed early, not
accepted. compare-falling-renderers.py now has --resume, verified 12 completed
trials skipped and settings mismatch rejected without benchmark launch. Failed
200k directory/log archived under matched-renderers/resume-history before retry.
Active log matched-renderers-resume.log. Remaining 12 renderer trials then
finish-profiles-recordings-recovered.py (6 stage profiles + 19 recordings) queued
sequentially. Old sessions 56946/41578/46708/78296 no longer live after reboot.
Do not rerun completed physics; summary matched-physics-complete-summary.json.
Still need audit, render plots + visual review, recording review, docs and archive.
No commits/push. Engine source frozen; only renderer runner changed this turn.

LATEST LIVE RECOVERY: session 56946 runs resume-pipeline.py. Previous sessions
41578/46708/78296 are terminal; do not poll them. No user stop instruction arrived,
so original goal authorization was used to resume after optional clarification
wait. User was informed before launch. matched-hash-resume.log is active log.
26 completed rows/hash identities verified unchanged; partial candidate trial 2
log preserved byte-for-byte under matched-hash/resume-history/. Retrying only
four missing 200k trials in original order. Same frozen binaries and 156 engine
source hashes verified before launch. Recovery then sequentially invokes
renderers-after-matched-recovered.py and finish-profiles-recordings-recovered.py
(no obsolete PID waits), covering renderer build/24 trials, 6 candidate stage
profiles, 19 recordings. Watch session 56946; do not start overlapping heavy work.
Resume tests: resume-check-results.json (all-complete skips, settings mismatch),
resume-interruption-check-results.json (simulated retry failure, archive retention).
No real benchmark was launched by tests. README documents --resume.

LATEST recovery prepared, no benchmark restarted: compare-falling-binaries.py
now supports --resume with settings/helper/binary/order/raw-hash validation,
skips completed rows and archives unfinished output/previous rows/runner identity
under resume-history before retry. README updated. Non-GPU test copied six real
completed 5-cube trials and verified no launch/no raw changes plus rejection of
changed counts (resume-check-results.json). Interrupted-attempt archive branch
still deserves direct exercise before actual resume. User answer remains pending.
All original sessions terminal; no new queues. Engine sources remain frozen.

LATEST: ALL THREE QUEUES TERMINAL. Physics session 41578 exited 143 (SIGTERM),
no benchmark/oracle child remains. 26 completed rows retained; candidate 200k
trial 2 interrupted in host-mirror pass after headline timing, no final JSON.
Renderer session 46708 exited 1 (incomplete physics); tail session 78296 exited 1
(missing renderer data). Do not poll these sessions or treat them live.
User was asked asynchronously whether stop was intentional / resume unfinished
trials or keep stopped. Response pending. Do not restart dependent work before
answer. Termination details in interruption-2026-09-24.json. Sender unknown.
On resume, preserve 26 completed rows and original partial log, run only missing
trials in original order with frozen binaries/settings. Comparison runner does
not currently support resume; prepare safe recovery without overwriting evidence.
Requeue renderers/profiles/recordings only after matched physics completes.

LATEST live check: session 41578, candidate 200k trial 2 still running after its
timed physics section. Log reports p50 104.997 ms, p95 138.893 ms, bp p50 25.443 ms
(not mean and not yet final JSON). src/headless.rs:1228 starts a SECOND world for
host-mirror measurements after the headline run, explaining fresh GPU init and
long CPU setup. Do not restart. Preserve the slower trial and inspect all three
paired runs/telemetry before attributing variability. User suspected crash:
PID 1725056 confirmed alive with CPU ticks advancing; no recent kernel GPU-reset,
OOM or crash entries; NVIDIA responds normally. No crash was observed.

LATEST: first uninstrumented 200k pair complete: 101.218854 -> 94.228427 ms, +7.42% throughput (below target so far), broadphase 29.035147 -> 19.139058 ms (-34.08%). Other phases increased by about 3 ms combined; retain all data, no causal assumption. Trial 2 candidate live in session 41578. Interim evidence in matched-200k-first-pair.json. Remaining queues unchanged.

LATEST: matched physics session 41578 remains live, first 200k baseline finished
101.219 ms; first 200k candidate underway. Renderer queue 46708 and profile/video
queue 78296 confirmed live and waiting. Do not restart any run on poll timeout.
All three 100k pairs complete: median throughput +3.85%, broadphase about -22%.

Prepared package-evidence.py (not run): packages raw runs, failures, scripts,
patches, recording metadata, published JSON; verifies archive member contents and
SHA256. Requires completed datasets, measurement-audit.json, recording-review.json
and 19 new clips. Reproduction commands cleaned up and syntax checked.
Audit-measurements.py now also verifies renderer full trial grid, binary hashes,
matching settings/environment, and re-reads raw cadence/presentation/contact
checks through benchmark metrics helper. Syntax checked; cannot run until all
physics/render/profile trials complete. Both helpers are ignored local artifacts
and will be included in final raw archive. Engine source remains frozen.

LATEST plot-falling-comparison.pyadded/syntaxchecked(notrenderedyet):3columns
physics/direct/Sokolrates,latencyrowp50/p95,trialranges. Requires30physics+24
renderrows,hashesandmatchinguninstrumentedenv. READMEusageadded. Keepcounts
100k/200kchart;smallregressionrowstableinaudit. Current41578at100kbeforetrial3.
Allengineinputsfrozen;futurechartsneedrealdataandvisualQA. No commits.

LATEST100kuninstrumentedpair1:before47.1366/bp9.86865ms,after45.3913/bp7.64979ms.
Aftertrial2active41578. plot-falling-solvers.py now --countsselectionand
--variant-labelKEY=LABEL(helpnotrunmatplotlibduringtiming;astsyntaxpass),
validatesFULLtrialgridbeforeselectedplot. Usefinal --counts100000200000
--variant-labelbefore-49b024f5=Before --variant-labelafter-hash-growth=After
forreadable4barphase/memory/latencychart;allsmallresultsremaininraw/audit.
Sourceenginefrozen;onlyplot/runners/docsupdated,hashesstillmatchcompiledinput.

LATEST addedaudit-measurements.py syntaxcheckedonly(needsfull30physics/24render/12profile
rows). Reports20%bp/10%throughputtargetbooleanswithoutlooseninggates. Hashes
156engineinputsincandidate-engine-inputs.json and5passinglogsvalidation-summary.json.
First100kbaselineuninstrumented47.137ms,aftertrial1running41578.
Queues46708renderer,78296profiles/recordingsstillwait. Engine/WASMunchanged.

LATEST tailqueue78296(finish-profiles-recordings.py)waitsrendererparent1583208
(session46708). Requires24validrendererrows,thenfreshcandidateprofiles3trials
100k/200k(hash-profile-final/),then19scene300framecapture2026-09-24-spatial-hash-growth
usingfrozencandidateGPUbinary/METRIC_RUNS1/globalsettingstosamebaselineCPUcolumn.
Nooverlapwithbenchmark. Audit/videosreview/charts/docs/archiveafterqueue.
Activecompute41578matchedphysics. Otherqueues46708,78296waitonly.
Smallcountscompleted:5median~+.07%time,1000~+.8%time,trialrangesoverlap.
Nooutliersremoved. Need15000/100k/200kdata beforefinalclaims. No commits.

LATEST regression86752 terminalexit0:full268/268pass183.24s,cacheoffallpairs
andhighindexlifecyclepass. Matchedphysics41578nowactive. Rendererqueue46708
waitsitsparent1540772. Sourceengineunchanged. Needall30physicsrowsbeforeclaiming
target/smallsceneregressionresults. Candidateprofile1trialpreliminary38.3%bp,
11.4%throughput,unchanged3674669472primarybytes;notfinalpairedperformance.

LATEST rendererqueue session46708(renderers-after-matched.py)waitsmatchedparent
1540772(session41578),requires30validphysicsrows,buildsSokol+freezes
hash-candidate-sokol,thencompare-falling-renderers.py bothGPUrenderers100k/200k,
3alternatingbefore/aftertrials24total. Outputmatched-renderers/logs.
Newreusablerunner+READMEusage,parser/helpverifiedbutnotrunyet.Preservesbinary
hashesandframebuffer/rendersettings+envassertions. Nooverlapwithphysicstimings.
Fullsuite86752stillrunningatlastpoll,thenoffchecks,thenphysics41578.
Candidateenginefrozen,nochangesexceptdocumentation/measurementrunners.

LATEST candidateprofile39667 terminalexit0. First200kdiagnosticpasses:bp18.00463ms,
completed91.48176ms versusbaselineprofilemedian29.20377/101.91269. Dynamicpairs
8.391ms(vs19.905),sort8.481ms. Promising~38%bp/~11%throughput butsingleprofile
trialonly;matched30trialqueue41578mustverifytargets. Summaryhash-first-diagnostic-summary.json.
Regression86752nowrunningfull268suite(hash-library.log). Afterfullsuitecacheoff
coverage/lifecyclethenmatched41578. NewSokolbinaryoverrideaddedtobenchrunner
forupcomingrenderermatchedtrials(helpvalidated),sourceengineunchanged.

LATEST added queued matched comparisonsession41578(compare-after-regressions.py).
Waitspidfdregressionparent1531507(session86752),requiresall3stagespassed,
thenruns30uninstrumentedtrials:counts5,1000,15000,100000,200000;3alternating
pairsbaseline49b024f5/hashcandidate. Outputmatched-hash/,logmatched-hash.log.
Profilerflagabsentasserted. Do notrunotherheavyworkconcurrentlywhenitstarts.
Otheractivehandles39667(candidate200kprofile),86752(regressionqueue).
CandidateprofilelastlogstillGPUinit,~3m36processlive;noresultyet.
Baselineprofileandfocusedtestscomplete. Enginecandidatefrozen. No commits.

LATEST terminal/live handles:
-45697 terminalexit0:all6 baselineprofiletrialspass;baseline-profile-summary.json
medians100kbp9.92372/completed48.1743;200kbp29.20377/completed101.91269.
-89482 terminalexit0:hashbounds+extendedallpairscoveragepass;hash-candidate-gpu
frozenwithhashandcompiledsourcepatch. Focusedtests1.04s/.72s,268totallibrarycases.
-39667 LIVE:candidateprofile200k1trial,loghash-profile-200k.log.
-86752 LIVE waitingon39667processPID1481378:check-hash-regressions.py queues
full268nativecachelibrarywithbothNV/AMDICDsvisible(NVIDIAselected),thencacheoff
allpairscoverageand131075shapelifecycleboundary. regression-status.json/logs.
Noheavyoverlap. Candidateenginefrozen;do noteditduringqualification. No commit.
Next inspect200k candidateprofile,fullchecks,then3alternatingbefore/after100k/200k
and smallscenes/bothrenderers. Need3candidateprofiletrials100k/200k forstagecharts,
recordings,docs/rawarchive. Targets20%bp/10%completedthroughput notyetmeasured.

Latest: new scripts/plot-broadphase-stages.py syntaxchecked;requires>=3valid
profiletrials eachcount,before/aftermatching environments;validatesstagecoverage
andhashes;producesstagesbarplot+JSON. Notrenderedyet(noafter3trialdataset).
READMEhasusage. Still baselineprofile200ktrial3 session45697 atlastpoll;
qualifier89482 andcandidateprofile39667 queued. Preserveallthreehandles.

Latest queued stage:session39667 runs profile-hash-after-checks.py,waitingvia
pidfd on qualifierPID1465354(session89482). Afterall3checks/buildpassed, runs
hash-profile-200k(1trial200k withprofiling)usingfrozenhash-candidate-gpu.
Profilebaseline session45697 still200ktrial2 atlastpoll. Noheavyoverlap.
Afterqueuefinishes inspectcandidate200kstagesvsbaseline thenmatched3pairs at
100k/200k,smallcountsandrenderers,testsuitecacheon/off,recordings/charts/archive.
Do notduplicate queued jobs. No further sourceedits afterthequeuerunsbuilduntil
binary/sourceidentitycaptured;currentcandidate includesextendedcoveragefixture.

Latest:queued qualifier session89482 waits via pidfd on profileparent1397502.
After profileexit verifies6validtrials,then builds/runs hashbounds andextended
canonicalgridcoveragefixtures,then builds/freezehash-candidate-gpu. Logs
hash-bounds.log/hash-coverage.log/hash-build.log;candidate-status.json tracks.
No heavy compute while profilelive. Poll BOTH45697 and89482 afterprofiledone.
First200k stages:clear.589,staticsetup.089,staticpairs.139,insert.174,
dynamicpairs20.054,sort8.264,compact.109;outer29.435ms,completed102.350ms.
profile-partial-summary.json hashes completed diagnosticfiles,notfinal.

Latest:200k profiletrial1 completed;trial2 live same session45697. Inspect raw stage
means in profile-large/200000-physics-gpu-1.json. Shader candidate now drafted:
spatial_hash_buckets=max16384,pair_cap/4;usesunusedATOM_PAIR_SET onlarger
reservations,smalltableunchanged. Clearoldtable+enlargedprefix;alloffsetsunchanged.
NewGPUfixture spatial_hash_growth_clears_buckets_without_touching_contact_identity
checksallbucketsEMPTY andsentinelsbeforecontacthistory;notbuilt/runyet.
Extendedallpairsmatrixfixture0/8193reservations(grid/matrix/grid)alsounrun.
READMElabelsworkingtreefollowupunqualified. Avoidbuildtestuntilsession45697ends.
Next buildcandidate then focusedtests,profile andmatchedspeedchecks. Goalactive.

Latest:all3 100kprofiletrialspass~20.8steps/s. 200k trial1 live session45697.
Extended existing canonical_grid_matches_matrix_across_cells_and_hash_collisions
fixture in src/api/world.rs:world reservations0/8193,translated clusters period4x
oldhashbucket span,grid/matrix/grid pathswitch. Not built/tested yet:avoid heavy
work during profiling. Shader unchanged. Fixed Python importmath ordering to
preserve module docstring. Need profile200k results before optimizing.

Latest observation: live session45697 still running the same profiling process.
100k trial1 passed20.8steps/s. Mean stages(ms):clear.302,staticsetup.048,
staticpairs.041,insert.068,dynamic/retainedpairs5.740,sort3.660,compact.051;
outerbp9.920. Pair generation then sorting dominate; clearing minor.
Candidate to investigate after200k profiles:fixedHASH_BUCKETS16384 causes long
hash chains. ATOM_PAIR_SET reserved pair_capacity words no longer referenced
by shaders except offset layout,so could reuse prefix as larger hash table
without extra allocation. Must verify bounds/power2/matrixpath/dense chains,
allpairscorrectness,lifecycle,caches and performance. No shader change yet.

# Latest state

Release build succeeded after api path fix. Baseline profile-gpu frozen with hash.
Opt-in smoke run passed at1000cubes,90warmup/5timed,all7samples and sums match outer
broadphase within overhead. Initial2stepwarmup smoke failed correctly (no contacts);
second smoke ran profiling off because runner strips GPU env. Both preserved.
Added explicit --profile-broadphase to benchmark runner with sample validation.

LIVE session45697: python3 artifacts/broadphase-optimization/run-profile.py.
Three trials each100k/200k,original90+240window/globalsolver/no-sleep,normaldesktop.
Logprofile-large.log; outputsprofile-large/. Poll same session,do not restart.
No other jobs. No optimization implemented or performance gain claimed yet.
Next inspect stage medians and compare instrumentation overhead; then optimize
measured bottleneck. Must preserve full goal,tests,renderers,charts,archive later.

# Broadphase goal work in progress

Baseline49b024f5 frozen under baseline/: all5 executable/library files have verified
original hashes, manifest retains previous matched environment and raw settings.
Prior completed charts remain checked into benchmarks/. No commit authorized.

Current change: opt-in native Vulkan query pool in RadixCache,7stage boundaries in
native broadphase cache mode2. Query pool lifetime retained by cached owner.
Raw headless JSON gets named broadphase_profile.samples_ms after completed waits.
Normal flag-off execution emits no extra GPU commands. Small pair-matrix path not
instrumented. Need runtime validation, overhead comparison and100k/200k profile
before choosing optimization. Initial cargo check found private module path; fixed
via api re-export. Releasebuild session8895 started, logprofile-build-fixed.log.
Do not start another build until terminal. No benchmarks currently launched.

Next: poll build, smoke run cached profile at1000cubes (pair matrix bypassed),
check7nonnegative stage samples per timed step and sum versus broadphase total.
Use preserved baseline manifest environment. Then profile100k/200k with original
90warmup+240timed, sleepoff,4substeps, global solver. Preserve executable and source
hashes. Keep heavy builds/tests out of timed measurements. No CPU idle gate.
Full objective remains: measurable broadphase optimization,3alternating pairs,
smallscene regressions and both renderers100k/200k,correctnesscacheon/off,recordings,
dated charts and reproducible rawarchive. No performance gain claimed yet.
