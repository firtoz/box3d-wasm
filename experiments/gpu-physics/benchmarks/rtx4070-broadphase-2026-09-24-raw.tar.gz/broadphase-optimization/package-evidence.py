"""Package completed broadphase evidence, preserving failures and source identity."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];folder=root/'artifacts/broadphase-optimization'
for name,total in [('matched-hash',30),('matched-renderers',24),('profile-large',6),('hash-profile-final',6)]:
 rows=json.loads((folder/name/'trials.json').read_text())
 assert len(rows)==total and all(r['status']=='ok' for r in rows),name
assert (folder/'measurement-audit.json').exists(),'run numerical audit before packaging'
label='2026-09-25-spatial-hash-growth'
clips=list((root/'recordings/snapshots'/label).glob('*.mp4'));assert len(clips)==19
assert (folder/'recording-review.json').exists(),'verify recordings before packaging'
files={}
for p in folder.rglob('*'):
 if p.is_file() and p.suffix in {'.json','.log','.patch','.py','.md','.sh','.txt','.sha256'}:
  files['broadphase-optimization/'+str(p.relative_to(folder))]=p.read_bytes()
for name in ['bench-falling-cubes.py','compare-falling-binaries.py','compare-falling-renderers.py',
 'plot-falling-solvers.py','plot-falling-comparison.py','plot-broadphase-stages.py',
 'build-native-cache.sh','run-native-samples.py','native-samples-cache-env.sh',
 'record-snapshot.sh','recording-manifest.py']:
 files['scripts/'+name]=(root/'scripts'/name).read_bytes()
for name in ['000-box3d-cpu','2026-09-24-tiled-stable-buckets',label]:
 for filename in ['metrics.json','recording-manifest.json']:
  files[f'recordings/{name}/{filename}']=(root/'recordings/snapshots'/name/filename).read_bytes()
for p in (root/'benchmarks').glob('rtx4070-broadphase-*.json'):
 files['published/'+p.name]=p.read_bytes()
files['source/working-tree.patch']=subprocess.check_output(['git','diff','--binary'],cwd=root)
files['source/HEAD.txt']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root)
files['REPRODUCE.md']=b'''# Broadphase optimization evidence

Baseline source: 49b024f5. Preserve baseline and candidate native-cache GPU/direct
and Sokol executables separately. Binary hashes, source patches, engine-input
hashes, build logs and original runner copies accompany the measurements.
Executables and videos are not embedded; their hashes identify local preserved
files. Adjust original-machine paths when reproducing elsewhere.

Run commands from experiments/gpu-physics using the build prerequisites in its
README. Keep Box3D/WASM unchanged. Build direct and external-C-shim/Sokol variants
sequentially. Measurements use 8 CPU workers under normal desktop load, without
an idle gate: 90 warmup steps, 240 timed steps, dt 1/60, 4 substeps, sleep off,
and the global solver.

The two comparison scripts restore the environment from the baseline manifest.
Set BASELINE_MANIFEST, BASELINE, CANDIDATE and CANDIDATE_SOKOL to the corresponding
preserved files. The manifest must point to the preserved baseline executables.
Use a new output directory for each comparison:

```sh
python3 scripts/compare-falling-binaries.py "$BASELINE_MANIFEST" physics-output --binary "before-49b024f5=$BASELINE" --binary "after-hash-growth=$CANDIDATE" --counts 5 1000 15000 100000 200000 --trials 3 --timeout 900
python3 scripts/compare-falling-renderers.py "$BASELINE_MANIFEST" renderer-output --gpu-binary "$CANDIDATE" --sokol-gpu-binary "$CANDIDATE_SOKOL"
```

For substage diagnosis, export the baseline manifest's environment first. Set
PROFILE_BINARY to the instrumentation-only baseline build or candidate build,
and PROFILE_OUTPUT to a separate, new directory for each:

```sh
python3 scripts/bench-falling-cubes.py "$PROFILE_OUTPUT" --profile-broadphase --counts 100000 200000 --modes physics-gpu --trials 3 --workers 8 --gpu-solver global --gpu-binary "$PROFILE_BINARY" --timeout 900
```

The archived run-profile.py and finish-profiles-recordings.py retain the exact
environment restoration and commands used locally; their process-wait IDs are
session-specific and must not be reused. Before profiling uses the
instrumentation-only source patch/profile-gpu binary; after uses the candidate.
Profiling timestamps are OFF in the paired headline measurements. Raw profile
datasets retain exact stage samples; timing can include instrumentation overhead.

Use plot-falling-comparison.py for throughput/latency across physics/renderers,
plot-falling-solvers.py for GPU phases and primary memory, and
plot-broadphase-stages.py for diagnostic stage costs. Plotters need matplotlib.
The original scripts and commands in trial manifests are authoritative.

All failed/intermediate runs are retained, including the initial smoke with
insufficient warmup and the initial compile error. They are not performance
results. Primary allocations exclude driver/render/staging memory. No other GPU
or arbitrary workload scaling claim is implied by these falling-cube results.
'''
files['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
out=root/'benchmarks/rtx4070-broadphase-2026-09-24-raw.tar.gz'
with out.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(out) as tar:
 assert len(tar.getmembers())==len(files)
 for name,data in files.items():assert tar.extractfile(name).read()==data,name
out.with_suffix('.gz.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print(f'Verified {len(files)} archive members, {out.stat().st_size} compressed bytes.')
