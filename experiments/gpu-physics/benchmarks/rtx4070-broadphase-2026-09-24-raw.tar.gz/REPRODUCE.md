# Broadphase optimization evidence

Baseline source: 49b024f5. Preserve baseline and candidate native-cache GPU/direct
and Sokol executables separately. Binary hashes, source patches, engine-input
hashes, build logs and original runner copies accompany the measurements.
Executables and videos are not embedded; their hashes identify local preserved
files. Adjust original-machine paths when reproducing elsewhere.

Run commands from experiments/gpu-physics using the build prerequisites in its
README. Keep Box3D/WASM unchanged. Build direct and external-C-shim/Sokol variants
sequentially. Measurements use 8 CPU workers under normal desktop load, without
an idle gate: 90 warmup steps, 240 timed steps, dt 1/60, 4 substeps, sleep off,
and the global solver.

The two comparison scripts restore the environment from the baseline manifest.
Set BASELINE_MANIFEST, BASELINE, CANDIDATE and CANDIDATE_SOKOL to the corresponding
preserved files. The manifest must point to the preserved baseline executables.
Use a new output directory for each comparison:

```sh
python3 scripts/compare-falling-binaries.py "$BASELINE_MANIFEST" physics-output --binary "before-49b024f5=$BASELINE" --binary "after-hash-growth=$CANDIDATE" --counts 5 1000 15000 100000 200000 --trials 3 --timeout 900
python3 scripts/compare-falling-renderers.py "$BASELINE_MANIFEST" renderer-output --gpu-binary "$CANDIDATE" --sokol-gpu-binary "$CANDIDATE_SOKOL"
```

For substage diagnosis, export the baseline manifest's environment first. Set
PROFILE_BINARY to the instrumentation-only baseline build or candidate build,
and PROFILE_OUTPUT to a separate, new directory for each:

```sh
python3 scripts/bench-falling-cubes.py "$PROFILE_OUTPUT" --profile-broadphase --counts 100000 200000 --modes physics-gpu --trials 3 --workers 8 --gpu-solver global --gpu-binary "$PROFILE_BINARY" --timeout 900
```

The archived run-profile.py and finish-profiles-recordings.py retain the exact
environment restoration and commands used locally; their process-wait IDs are
session-specific and must not be reused. Before profiling uses the
instrumentation-only source patch/profile-gpu binary; after uses the candidate.
Profiling timestamps are OFF in the paired headline measurements. Raw profile
datasets retain exact stage samples; timing can include instrumentation overhead.

Use plot-falling-comparison.py for throughput/latency across physics/renderers,
plot-falling-solvers.py for GPU phases and primary memory, and
plot-broadphase-stages.py for diagnostic stage costs. Plotters need matplotlib.
The original scripts and commands in trial manifests are authoritative.

All failed/intermediate runs are retained, including the initial smoke with
insufficient warmup and the initial compile error. They are not performance
results. Primary allocations exclude driver/render/staging memory. No other GPU
or arbitrary workload scaling claim is implied by these falling-cube results.
