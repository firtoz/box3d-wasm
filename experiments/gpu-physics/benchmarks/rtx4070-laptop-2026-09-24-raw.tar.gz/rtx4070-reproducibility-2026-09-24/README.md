# Falling-cubes measurements, 2026-09-24

The main sweep and CPU extension have 288 valid trials and three rejected GPU
trials, summarized into 96 complete count/path groups. The separate direct-viewer
repeat check has 18 valid trials; it does not replace any original measurements.

- `rtx4070-quiet-2026-09-24`: main sweep, historical directory name. CPU-load gating
  was removed during the run; `load-policy-user-update.json`, `resume-history.json`
  and per-trial fields record this. Do not describe the entire run as isolated/idle.
- `rtx4070-cpu-extension-2026-09-24`: CPU counts through 150,000; stops each mode at
  <=10 FPS or the direct viewer's 65,535-dynamic-body limit.
- `rtx4070-repeat-check-2026-09-24`: three additional direct CPU/GPU trials at
  5, 100 and 1,000 cubes to investigate wide presentation-time ranges.

Earlier September 20 diagnostic datasets are excluded. Manifests retain all
binary SHA-256 hashes, selected driver/runtime settings and exact commands.
Each trial retains before/after power, clocks, temperature and load telemetry.
Raw JSON/logs include the three rejected 20,000-cube GPU cases. Their spatial-hash
insertion failures are engine capacity limits, not valid throughput measurements.

The checked-in chart uses the main and extension datasets only. The repeat check
is a separately labeled follow-up, with all slower valid trials retained.

## Replot without a GPU

From the directory containing the extracted folders, create a Python environment
and install `-r rtx4070-reproducibility-2026-09-24/plot-requirements.txt`, then run:

```sh
python rtx4070-reproducibility-2026-09-24/source/scripts/plot-falling-cubes.py \
  rtx4070-quiet-2026-09-24 output \
  --additional-input rtx4070-cpu-extension-2026-09-24 \
  --title 'Ryzen 9 8945HS / RTX 4070 Laptop • desktop load'
```

The plotter revalidates raw measurements, rejects duplicate trials and asserts
that the cached summary timings match their raw source. It requires identical
binaries, runtime environment, framebuffers and timing settings when combining
non-overlapping continuation counts. `check-falling-report.py` fault-injects
summary timing changes and duplicate trials to exercise the publication checks.

To repeat on another machine, build the repository at `source-base.txt` with the
included source patch/tooling, follow the experiment README's Linux native-cache
build instructions, and start fresh output directories. Preserve the fixture,
90 warmup + 240 timed steps, 1/60 s, four substeps, sleep off, eight CPU workers,
renderer and actual 2040x1148 framebuffer. Record the new hardware/power/driver
conditions. Do not resume these archived directories with different binaries.
One GPU/platform measurement cannot establish FLOPS scaling; compare measured
rates at matching counts and retain the CPU control for the second machine.
