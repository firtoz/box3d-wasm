# Connected-scene scheduling qualification, 2026-09-25

RTX 4070 Laptop / Ryzen 9 8945HS; baseline c46b81e2. Candidate source hashes
and binary SHA-256 identities are in qualification-build.json. The included
changes-from-c46b81e2.patch uses repository-relative paths. Runtime git/source
fields identify the checkout during measurement, not the frozen executable.
Binaries, caches and MP4s are excluded; recording identities and decoded-frame
comparisons are included. Earlier charts/evidence remain separate history.

Extract into an empty directory. Verify SHA256SUMS.json against every payload.
Revalidate the raw grids without GPU or matplotlib:

    python3 scripts/plot-small-scene.py artifacts/connected-scheduling/qualification-physics unused --title validation --validate-only
    python3 scripts/plot-small-scene.py artifacts/connected-scheduling/qualification-renderers unused --title validation --validate-only --renderers

The initial 100k slowdown triggered nine balanced baseline/register-only/adaptive
follow-up runs. Both rounds are retained. Revalidate their raw hashes with:

    python3 artifacts/connected-scheduling/plot-large-regression.py unused --validate-only

The shader-identity report uses the actual viewer Cargo dependency fingerprint
for Naga, including island and mesh overrides. The exploratory report used a
different dependency and is superseded by report.json. The included emitter
source and run.py reproduce the comparison after rebuilding the dependency.

Install matplotlib, omit --validate-only and provide an output prefix to regenerate
charts. Shading is the full trial range, not confidence intervals. p50/p95 are
medians of per-trial percentiles. Phase timestamps overlap host work and are not
an additive completed-step decomposition. Headline GPU runs retain ordinary
phase timestamps; extra host/broadphase instrumentation is disabled.

Hardware replication: build both source revisions with scripts/build-native-cache.sh
build --release. For Sokol, also build --features external-c-shim and the samples_gpu
CMake target. Freeze binaries and update paths/hashes in the included runners.
Use fresh output directories. Both variants use global solving, automatic color
prefix and global replay enabled. Four substeps, dt=1/60, no sleep, 90 warmup +
240 timed steps, eight CPU workers. Three alternating before/after/CPU trials.
Normal desktop load; no idle gate. Renderer runs use the recorded Xvfb configuration,
NVIDIA hardware and matched actual viewport/settings. Their FPS describes this
display setup and is distinct from physics-only completed steps per second.

275 native-cache tests passed across two invocations: the NVIDIA-only invocation
passed 274, with the cross-adapter test failing because its AMD destination was
hidden by VK_DRIVER_FILES. Retained failure log plus successful exact test rerun
with VK_DRIVER_FILES/VK_ICD_FILENAMES unset document that environment correction.
Cache-off logs cover mutation/switching, stale hints, color tails and growth/reuse.
No test thresholds were weakened. Pilot and rejected-prototype data are diagnostic,
not extra qualification trials. CHECKPOINT.md/CONTINUE.md are historical notes.
