from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();base=root/'artifacts/connected-scheduling';new=root/'recordings/snapshots/2026-09-25-connected-scheduling-checkpoint';old=root/'recordings/snapshots/2026-09-25-small-scene-after'
def frames(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-f','framemd5','-'])
 return [l.split(b',')[-1].strip().decode() for l in raw.splitlines() if l.strip() and not l.startswith(b'#')]
report={}
for p in sorted(new.glob('*.mp4')):
 a=frames(old/p.name);b=frames(p);assert len(a)==len(b)==300
 report[p.stem]={'frames':300,'different_frames':sum(x!=y for x,y in zip(a,b)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert len(report)==19
(base/'checkpoint-recordings-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
assert all(v['different_frames']==0 for v in report.values())
