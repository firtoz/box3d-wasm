"""Run after the qualification runner exits successfully; no background overlap."""
from pathlib import Path
import json,os,subprocess,hashlib
root=Path.cwd();base=root/'artifacts/connected-scheduling'
for kind,expected in [('physics',108),('renderers',72)]:
 rows=json.loads((base/('qualification-'+kind)/'jobs.json').read_text())
 assert len(rows)==expected and all(r['status']=='ok' for r in rows),(kind,len(rows))
py=base.parent/'startup-optimization/plot-env/bin/python'
for kind in ['physics','renderers']:
 subprocess.run([str(py),'scripts/plot-small-scene.py',str(base/('qualification-'+kind)),f'benchmarks/rtx4070-connected-scheduling-{kind}-2026-09-25','--title','RTX 4070 Laptop / Ryzen 9 8945HS — connected scheduling, 2026-09-25',*(['--renderers'] if kind=='renderers' else [])],check=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|json.loads((base/'baseline.json').read_text())['environment']
label='2026-09-25-connected-scheduling-after'
assert not (root/'recordings/snapshots'/label).exists()
env.update({'GPU_RECORD_BIN':str(base/'qualified-candidate-gpu'),'GPU_PHYSICS_COMPONENT_TGS':'0','GPU_PHYSICS_IDLE':'0','FRAMES':'300','METRIC_RUNS':'1'})
with (base/'record-after.log').open('w') as f:subprocess.run(['./scripts/record-snapshot.sh',label],env=env,stdout=f,stderr=f,check=True)
# Prior qualified "after" is this goal's baseline with identical settings.
old=root/'recordings/snapshots/2026-09-25-small-scene-after';new=root/'recordings/snapshots'/label
assert json.loads((old/'recording-manifest.json').read_text())['viewer']['sha256']==json.loads((base/'baseline.json').read_text())['binaries']['gpu']['sha256']
def frames(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-f','framemd5','-'])
 return [l.split(b',')[-1].strip().decode() for l in raw.splitlines() if l.strip() and not l.startswith(b'#')]
report={}
for p in sorted(new.glob('*.mp4')):
 a=frames(old/p.name);b=frames(p);assert len(a)==len(b)==300
 cpu=root/'recordings/snapshots/000-box3d-cpu'/p.name;assert len(frames(cpu))==300
 report[p.stem]={'frames':300,'different_frames':sum(x!=y for x,y in zip(a,b)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'baseline_sha256':hashlib.sha256((old/p.name).read_bytes()).hexdigest(),'cpu_sha256':hashlib.sha256(cpu.read_bytes()).hexdigest()}
assert len(report)==19
(base/'recordings-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Recordings decoded; different frames:',sum(r['different_frames'] for r in report.values()),flush=True)
