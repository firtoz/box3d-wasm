"""Three-way causal probe after qualification stops. Never overlap GPU runners."""
from pathlib import Path
import hashlib,json,os,statistics,subprocess,runpy,time,fcntl
root=Path.cwd();base=root/'artifacts/connected-scheduling'
lock=(base/'qualification-physics/runner.lock').open('r');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
qualified=json.loads((base/'qualification-physics/jobs.json').read_text())
assert len(qualified)==108 and all(r['status']=='ok' for r in qualified), 'Wait for the full physics grid'
out=base/'large-regression-probe';out.mkdir(exist_ok=False)
m=json.loads((base/'baseline.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|m['environment']
variants={'baseline':base/'baseline-gpu','register-only':base/'register-tail-gpu','adaptive':base/'qualified-candidate-gpu'}
expected={'baseline':m['binaries']['gpu']['sha256'],'register-only':json.loads((base/'register-tail-build.json').read_text())['binary_sha256'],'adaptive':json.loads((base/'qualification-build.json').read_text())['binaries']['qualified-candidate-gpu']}
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==expected[v] for v,p in variants.items())
bench=runpy.run_path('scripts/bench-falling-cubes.py');snapshot=bench['system']
(out/'manifest.json').write_text(json.dumps({'variants':{v:{'path':str(p),'sha256':expected[v]} for v,p in variants.items()},'environment':m['environment'],'count':100000,'trials':3,'warmup':90,'timed':240,'purpose':'Isolate consistent 100k regression: baseline vs solver-only checkpoint vs adaptive graph candidate. Cyclic order balances position; no idle gate.'},indent=2)+'\n')
rows=[];names=list(variants)
for t in range(3):
 for v in names[t:]+names[:t]:
  p=out/f'{t+1}-{v}.json';cmd=[str(variants[v]),'--scene','falling-cubes','--bodies','100000','--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1']
  row={'trial':t+1,'variant':v,'command':cmd,'started':time.time()};print('Starting',t+1,v,flush=True)
  if snapshot:row['before']=snapshot()
  with p.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=f,check=True,timeout=900)
  if snapshot:row['after']=snapshot()
  d=json.loads(p.read_text());r=d['raw_runs'][0];assert d['scene']=='falling-cubes' and d['bodies']==100001 and d['sub_steps']==4 and not d['sleep'] and r['physics_step']==330 and len(r['completed_step_ms'])==240 and r['live_contacts']>0
  row.update(finished=time.time(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),**{k:statistics.mean(r[k]) for k in ['completed_step_ms','broadphase_ms','graph_ms','solve_ms','device_ms','encode_ms']});rows.append(row)
  (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print({k:row[k] for k in ['trial','variant','completed_step_ms','broadphase_ms','graph_ms','solve_ms']},flush=True)
