from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
m=json.loads((base/'baseline.json').read_text());binary=Path(m['binaries']['gpu']['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==m['binaries']['gpu']['sha256']
out=base/'graph-pilot';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|m['environment']
variants={'shared-memo':{'GPU_PHYSICS_GRAPH_BATCHED':'0'},'batched-memo':{'GPU_PHYSICS_GRAPH_BATCHED':'1'},'batched-no-memo':{'GPU_PHYSICS_GRAPH_BATCHED':'1','GPU_PHYSICS_GRAPH_MEMO':'0'}}
(out/'manifest.json').write_text(json.dumps({'baseline':m,'variants':variants,'counts':[1000,5000],'trials':2,'warmup':90,'timed':240},indent=2)+'\n')
rows=[]
for n in [1000,5000]:
 for trial in [1,2]:
  order=list(variants) if trial==1 else list(reversed(variants))
  for variant in order:
   p=out/f'{n}-{trial}-{variant}.json'
   cmd=[str(binary),'--scene','falling-cubes','--bodies',str(n),'--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1']
   with p.with_suffix('.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env|variants[variant],stdout=log,stderr=log,check=True,timeout=300)
   d=json.loads(p.read_text());r=d['raw_runs'][0]
   assert len(r['completed_step_ms'])==240 and r['live_contacts']>0 and d['sub_steps']==4 and not d['sleep']
   row={'count':n,'trial':trial,'variant':variant,**{k:statistics.mean(r[k]) for k in ['completed_step_ms','graph_ms','solve_ms','device_ms','encode_ms']}}
   rows.append(row);(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
