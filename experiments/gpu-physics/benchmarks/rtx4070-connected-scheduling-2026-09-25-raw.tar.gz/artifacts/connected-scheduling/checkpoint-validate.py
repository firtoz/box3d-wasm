from pathlib import Path
import os,json,subprocess
root=Path.cwd();base=root/'artifacts/connected-scheduling'
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))};env.update(json.loads((base/'baseline.json').read_text())['environment'])
def run(cmd,name):
 with (base/name).open('w') as f: subprocess.run(cmd,env=env,stdout=f,stderr=f,check=True)
for case in ['graph_mutations_match_canonical','color_tail_tests','global_physics_replay_connected_pile_state_and_reentry','batched_graph_preserves_dense_overflow_and_partial_batches']:
 run(['target/native-cache-build/release/deps/gpu_physics-f43e538e836f4d30',case,'--test-threads=1','--nocapture'],'checkpoint-'+case+'.log')
 print('PASS '+case,flush=True)
env.update({'GPU_RECORD_BIN':str(base/'register-tail-gpu'),'GPU_PHYSICS_COMPONENT_TGS':'0','GPU_PHYSICS_IDLE':'0','FRAMES':'300','METRIC_RUNS':'1'})
run(['./scripts/record-snapshot.sh','2026-09-25-connected-scheduling-checkpoint'],'checkpoint-record.log')
print('Recordings complete',flush=True)
