from pathlib import Path
import json,os,subprocess,hashlib,shutil
root=Path.cwd();base=root/'artifacts/connected-scheduling'
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|json.loads((base/'baseline.json').read_text())['environment']
for case in ['graph_density_status','graph_mutations_match_canonical','contact_metrics_distinguish','occupied_publication_parallel','full_replay_long_probe']:
 with (base/('adaptive-'+case+'.log')).open('w') as f:subprocess.run(['target/native-cache-build/release/deps/gpu_physics-f43e538e836f4d30',case,'--test-threads=1','--nocapture'],env=env,stdout=f,stderr=f,check=True)
 print('PASS '+case,flush=True)
with (base/'adaptive-build.log').open('w') as f:subprocess.run(['./scripts/build-native-cache.sh','build','--release'],stdout=f,stderr=f,check=True)
bin=base/'adaptive-gpu';shutil.copy2('target/native-cache-build/release/gpu-physics',bin)
files=['src/sim.rs','src/api/world.rs','shaders/physics/solve.wgsl','shaders/physics/broadphase.wgsl']
(base/'adaptive-build.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'sources':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}},indent=2)+'\n')
print('Candidate frozen',flush=True)
