from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
m=json.loads((base/'baseline.json').read_text());binary=Path(m['binaries']['gpu']['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==m['binaries']['gpu']['sha256']
out=base/'graph-crossover-pilot';out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|m['environment']
variants={'shared':{'GPU_PHYSICS_GRAPH_BATCHED':'0'},'batched':{'GPU_PHYSICS_GRAPH_BATCHED':'1'}}
candidate=base/'register-tail-gpu'
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==json.loads((base/'register-tail-build.json').read_text())['binary_sha256']
(out/'manifest.json').write_text(json.dumps({'candidate':json.loads((base/'register-tail-build.json').read_text()),'baseline':m,'variants':variants,'counts':[100,500,1000], 'scenes':['falling-cubes','mixed-stacks'],'trials':2,'warmup':90,'timed':240},indent=2)+'\n')
rows=[]
for scene,n in [(s,n) for s in ['falling-cubes','mixed-stacks'] for n in [100,500,1000]]:
 for trial in [1,2]:
  order=list(variants) if trial==1 else list(reversed(variants))
  for variant in order:
   p=out/f'{scene}-{n}-{trial}-{variant}.json'
   cmd=[str(candidate),'--scene',scene,'--bodies',str(n),'--warmup','90','--frames','240','--no-sleep','--bench',str(p),'--metric-runs','1']
   with p.with_suffix('.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env|variants[variant],stdout=log,stderr=log,check=True,timeout=300)
   d=json.loads(p.read_text());r=d['raw_runs'][0]
   assert len(r['completed_step_ms'])==240 and r['live_contacts']>0 and d['sub_steps']==4 and not d['sleep']
   row={'scene':scene,'count':n,'trial':trial,'variant':variant,**{k:statistics.mean(r[k]) for k in ['completed_step_ms','graph_ms','solve_ms','device_ms','encode_ms']}}
   rows.append(row);(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
