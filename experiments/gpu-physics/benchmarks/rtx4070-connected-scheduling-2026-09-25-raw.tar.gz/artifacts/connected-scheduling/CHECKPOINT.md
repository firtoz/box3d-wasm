Checkpoint on 2026-09-25, baseline c46b81e2. User requested commit before continuing the broader active goal.
Selected runtime change: register-local grouped solver body loads with barriers only between colors, 64 lanes. Default graph selection unchanged. New shared/batched mutation tests and memo counter reader are test-only.
Five focused tests passed. All 19 scenes have 300 decoded frames identical to the previous qualified baseline. Frozen register-tail-gpu shader hash matches committed shader; subsequent source changes are tests only.
Pilot results are diagnostic, not final qualification. Wave256 and fixed-prefix prototypes rejected. Density-driven scheduling remains unimplemented. Next: implement and validate adaptive graph scheduling; repeated CPU/GPU and renderer comparisons, sparse and 100k/200k regression checks, dated charts. No GPU jobs remain.
CONTINUE.md is historical scratch notes; its live-job claims and no-commit instruction are superseded by this checkpoint.
Binary files and videos remain local; archived manifests retain SHA-256 identities. Existing qualified charts remain unchanged.
