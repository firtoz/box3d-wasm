fn parse_and_validate(source: &str) -> (naga::Module, naga::valid::ModuleInfo) {
    let parsed = naga::front::wgsl::parse_str(source).expect("physics WGSL");
    let info = naga::valid::Validator::new(
        naga::valid::ValidationFlags::all(),
        naga::valid::Capabilities::all(),
    ).validate(&parsed).expect("validated physics WGSL");
    (parsed, info)
}

fn compile_parsed(parsed: &naga::Module, info: &naga::valid::ModuleInfo,
    entry: &str, constants: &[(&str, f64)]) -> Vec<u32> {
    let validated_at = std::time::Instant::now();
    let constants = constants.iter().map(|(k, v)| (k.to_string(), *v)).collect();
    let (parsed, info) = naga::back::pipeline_constants::process_overrides(
        parsed,
        info,
        Some((naga::ShaderStage::Compute, entry)),
        &constants,
    )
    .expect("physics pipeline constants");
    let overrides_at = std::time::Instant::now();
    let mut options = naga::back::spv::Options::default();
    options.flags.insert(naga::back::spv::WriterFlags::DEBUG);
    // Passthrough must not silently drop the bounds protection provided by wgpu.
    // Use software checks rather than depending on adapter-private robustness flags.
    options.bounds_check_policies = naga::proc::BoundsCheckPolicies {
        index: naga::proc::BoundsCheckPolicy::Restrict,
        buffer: naga::proc::BoundsCheckPolicy::Restrict,
        image_load: naga::proc::BoundsCheckPolicy::Restrict,
        binding_array: naga::proc::BoundsCheckPolicy::Restrict,
    };
    let words = naga::back::spv::write_vec(
        &parsed,
        &info,
        &options,
        Some(&naga::back::spv::PipelineOptions {
            shader_stage: naga::ShaderStage::Compute,
            entry_point: entry.into(),
        }),
    )
    .expect("physics SPIR-V");
    let decorated = decorate(&words);
    if std::env::var_os("GPU_PHYSICS_TRACE_PIPELINES").is_some() {
        eprintln!("gpu-frontend {entry} parse_ms={:.3} validate_ms={:.3} overrides_ms={:.3} emit_ms={:.3}",
            0.0,
            0.0,
            overrides_at.duration_since(validated_at).as_secs_f64()*1000.0,
            overrides_at.elapsed().as_secs_f64()*1000.0);
    }
    decorated
}

fn decorate(words: &[u32]) -> Vec<u32> {
    let mut glsl_set = None;
    let mut insert = None;
    let mut annotations = Vec::new();
    let mut inside = false;
    let mut pos = 5;
    while pos < words.len() {
        let count = (words[pos] >> 16) as usize;
        let op = words[pos] & 65535;
        assert!(count > 0 && pos + count <= words.len());
        match op {
            11 => {
                let bytes: Vec<_> = words[pos + 2..pos + count]
                    .iter()
                    .flat_map(|v| v.to_le_bytes())
                    .take_while(|b| *b != 0)
                    .collect();
                if bytes == b"GLSL.std.450" {
                    glsl_set = Some(words[pos + 1]);
                }
            }
            12 if inside && Some(words[pos + 3]) == glsl_set && words[pos + 4] == 50 => {
                // GLSL Fma needs NoContraction to preserve single-operation semantics.
                annotations.extend_from_slice(&[(3 << 16) | 71, words[pos + 2], 42]);
            }
            19..=39 if insert.is_none() => insert = Some(pos), // type declarations
            54 => inside = true,                               // OpFunction
            56 => inside = false,                              // OpFunctionEnd
            129 | 131 | 133 | 136 | 142..=148 if inside => {
                // OpDecorate result-id NoContraction (42).
                annotations.extend_from_slice(&[(3 << 16) | 71, words[pos + 2], 42]);
            }
            _ => {}
        }
        pos += count;
    }
    let insert = insert.expect("SPIR-V types");
    let mut out = words[..insert].to_vec();
    out.extend(annotations);
    out.extend_from_slice(&words[insert..]);
    out
}

fn main() {
 let a:Vec<_>=std::env::args().collect();
 let source=std::fs::read_to_string(&a[1]).unwrap();
 let (parsed, info)=parse_and_validate(&source);
 std::fs::create_dir_all(&a[2]).unwrap();
 for entry in &parsed.entry_points {
  let words=compile_parsed(&parsed,&info,&entry.name,&[]);
  let bytes:Vec<u8>=words.into_iter().flat_map(|w|w.to_le_bytes()).collect();
  std::fs::write(std::path::Path::new(&a[2]).join(format!("{}.spv",entry.name)),bytes).unwrap();
  if ["island_init","island_union_edges","island_accumulate_wake","island_apply_wake","island_reset_ready","island_accumulate_ready","island_apply_sleep","color_and_compact"].contains(&entry.name.as_str()) {
   let words=compile_parsed(&parsed,&info,&entry.name,&[("ISLAND_WORKGROUP_SIZE",128.0)]);
   let bytes:Vec<u8>=words.into_iter().flat_map(|w|w.to_le_bytes()).collect();
   std::fs::write(std::path::Path::new(&a[2]).join(format!("{}-island128.spv",entry.name)),bytes).unwrap();
  }
  if entry.name == "collide_pairs" {
   let words=compile_parsed(&parsed,&info,&entry.name,&[("COLLISION_MESH_ENABLED",0.0)]);
   let bytes:Vec<u8>=words.into_iter().flat_map(|w|w.to_le_bytes()).collect();
   std::fs::write(std::path::Path::new(&a[2]).join("collide_pairs-no-mesh.spv"),bytes).unwrap();
  }
 }
 println!("{} entries emitted",parsed.entry_points.len());
}
