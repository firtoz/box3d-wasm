// Keep this convention in sync with src/dispatch.rs. Existing 1D grids stay
// unchanged. Only grids exceeding 65,535 groups use rows of 256 workgroups.
const LINEAR_DISPATCH_LIMIT: u32 = 65535u;
const LINEAR_DISPATCH_TILE: u32 = 256u;

fn linear_dispatch_groups(groups: u32) -> vec3<u32> {
    if (groups <= LINEAR_DISPATCH_LIMIT) {
        return vec3<u32>(groups, 1u, 1u);
    }
    return vec3<u32>(LINEAR_DISPATCH_TILE, (groups + LINEAR_DISPATCH_TILE - 1u) / LINEAR_DISPATCH_TILE, 1u);
}

fn linear_workgroup_id(group: vec3<u32>) -> u32 {
    return group.x + group.y * LINEAR_DISPATCH_TILE;
}

fn linear_invocation_id(id: vec3<u32>, workgroup_size: u32) -> u32 {
    return id.x + id.y * LINEAR_DISPATCH_TILE * workgroup_size;
}
// Bind group 0 layouts. Concatenated with the rest of shaders/physics/ in sim.rs.

struct Body {
    pos: vec3<f32>,
    inv_mass: f32,
    vel: vec3<f32>,
    kind: u32,
    half: vec3<f32>,
    flags: u32,
    rot: vec4<f32>,
    omega: vec3<f32>,
    restitution: f32,
    inv_inertia: vec3<f32>,
    inv_inertia_offdiag: vec3<f32>,
    friction: f32,
    gravity_scale: f32,
    linear_damping: f32,
    angular_damping: f32,
    rolling: f32,
    dp: vec3<f32>,
    sleep_time: f32,
    dq: vec4<f32>,
    island_id: u32,
    sleep_velocity: f32,
    _pad_island: vec2<u32>,
}

struct BodyState {
    pos: vec3<f32>,
    inv_mass: f32,
    vel: vec3<f32>,
    flags: u32,
    rot: vec4<f32>,
    omega: vec3<f32>,
    sleep_velocity: f32,
    dp: vec3<f32>,
    sleep_time: f32,
    dq: vec4<f32>,
}

struct BodyCold {
    half: vec3<f32>,
    kind: u32,
    inv_inertia: vec3<f32>,
    restitution: f32,
    gravity_scale: f32,
    linear_damping: f32,
    angular_damping: f32,
    friction: f32,
    rolling: f32,
    local_center: vec3<f32>,
}

struct Shape {
    body_index: u32,
    plane_slot: u32,
    kind: u32,
    topology_counts: u32,
    local_center: vec3<f32>,
    topology_slot: u32,
    half: vec3<f32>,
    rolling: f32,
    axis: vec3<f32>,
    friction: f32,
    restitution: f32,
    inner_radius: f32,
    hull_slot: u32,
    edge_slot: u32,
    category_bits_lo: u32,
    category_bits_hi: u32,
    mask_bits_lo: u32,
    mask_bits_hi: u32,
    group_index: i32,
    event_flags: u32,
    material_slot: u32,
    material_count: u32,
    tangent_velocity: vec3<f32>,
    custom_color: u32,
    user_material_id: vec2<u32>,
    _pad_filter: vec2<u32>,
    instance_position: vec3<f32>,
    instance_flags: u32,
    instance_rotation: vec4<f32>,
}

struct SurfaceMaterial {
    friction: f32,
    restitution: f32,
    rolling_resistance: f32,
    _pad0: f32,
    tangent_velocity: vec3<f32>,
    custom_color: u32,
    user_material_id: vec2<u32>,
    _pad1: vec2<u32>,
}

struct ContactHot {
    a: u32,
    b: u32,
    color: u32,
    count: u32,
    n: vec3<f32>,
    friction: f32,
    ra0: vec4<f32>,
    ra1: vec4<f32>,
    ra2: vec4<f32>,
    ra3: vec4<f32>,
    rb0: vec4<f32>,
    rb1: vec4<f32>,
    rb2: vec4<f32>,
    rb3: vec4<f32>,
    friction_impulse: vec2<f32>,
    twist_impulse: f32,
    rolling: f32,
    center_a: vec3<f32>,
    _pad_ca: f32,
    center_b: vec3<f32>,
    _pad_cb: f32,
    rolling_impulse: vec3<f32>,
    restitution: f32,
    tangent_velocity: vec3<f32>,
    material_index: u32,
    manifold_link: vec4<u32>,
}

struct ContactPrepared {
    relative_velocity: vec4<u32>,
    normal_mass: vec4<f32>,
    lever_arm: vec4<f32>,
    total_normal_impulse: vec4<f32>,
    tangent_inv: vec4<f32>,
    softness: vec4<f32>,
}

struct ContactPersistent {
    feature_ids: vec4<u32>,
    cached_relative: vec4<f32>,
    cached_rotation_a: vec4<f32>,
    cached_rotation_b: vec4<f32>,
    lifecycle: vec4<u32>,
    pair: vec4<u32>,
    persistent_ra0: vec4<f32>,
    persistent_ra1: vec4<f32>,
    persistent_ra2: vec4<f32>,
    persistent_ra3: vec4<f32>,
    persistent_rb0: vec4<f32>,
    persistent_rb1: vec4<f32>,
    persistent_rb2: vec4<f32>,
    persistent_rb3: vec4<f32>,
    point_triangles: vec4<u32>,
}

struct Contact {
    a: u32,
    b: u32,
    color: u32,
    count: u32,
    n: vec3<f32>,
    friction: f32,
    ra0: vec4<f32>,
    ra1: vec4<f32>,
    ra2: vec4<f32>,
    ra3: vec4<f32>,
    rb0: vec4<f32>,
    rb1: vec4<f32>,
    rb2: vec4<f32>,
    rb3: vec4<f32>,
    friction_impulse: vec2<f32>,
    twist_impulse: f32,
    rolling: f32,
    center_a: vec3<f32>,
    _pad_ca: f32,
    center_b: vec3<f32>,
    _pad_cb: f32,
    rolling_impulse: vec3<f32>,
    _pad_end: f32,
    tangent_velocity: vec3<f32>,
    material_index: u32,
    _tail0: vec4<u32>,
    _tail1: vec4<u32>,
    cached_relative: vec4<f32>,
    cached_rotation_a: vec4<f32>,
    cached_rotation_b: vec4<f32>,
    lifecycle: vec4<u32>,
    pair: vec4<u32>,
    prepared_normal_mass: vec4<f32>,
    prepared_lever_arm: vec4<f32>,
    total_normal_impulse: vec4<f32>,
    prepared_tangent_inv: vec4<f32>,
    prepared_softness: vec4<f32>,
    persistent_ra0: vec4<f32>,
    persistent_ra1: vec4<f32>,
    persistent_ra2: vec4<f32>,
    persistent_ra3: vec4<f32>,
    persistent_rb0: vec4<f32>,
    persistent_rb1: vec4<f32>,
    persistent_rb2: vec4<f32>,
    persistent_rb3: vec4<f32>,
    manifold_link: vec4<u32>,
    point_triangles: vec4<u32>,
}

struct Joint {
    a: u32,
    b: u32,
    kind: u32,
    _pad0: u32,
    anchor_a: vec3<f32>,
    hertz: f32,
    anchor_b: vec3<f32>,
    damping: f32,
    axis: vec3<f32>,
    impulse: f32,
    frame_a_rotation: vec4<f32>,
    frame_b_rotation: vec4<f32>,
    perp_impulse: vec2<f32>,
    flags: u32,
    _pad1: u32,
    angular_impulse: vec3<f32>,
    spring_impulse: f32,
    motor_impulse: f32,
    lower_impulse: f32,
    upper_impulse: f32,
    spring_hertz: f32,
    spring_damping: f32,
    target_translation: f32,
    lower_translation: f32,
    upper_translation: f32,
    max_motor_force: f32,
    motor_speed: f32,
    _pad2: vec2<f32>,
    motor_angular_velocity: vec3<f32>,
    _pad3: f32,
    target_rotation: vec4<f32>,
    spring_angular_impulse: vec3<f32>,
    swing_impulse: f32,
    motor_angular_impulse: vec3<f32>,
    _pad4: f32,
    weld_linear_hertz: f32,
    weld_linear_damping: f32,
    weld_angular_hertz: f32,
    weld_angular_damping: f32,
    weld_linear_impulse: vec3<f32>,
    _pad_weld_linear: f32,
    weld_angular_impulse: vec3<f32>,
    _pad_weld_angular: f32,
}

struct SimParams {
    dt: f32,
    gravity_x: f32,
    gravity_y: f32,
    gravity_z: f32,
    color_select: u32,
    enable_contacts: u32,
    max_contacts: u32,
    body_count: u32,
    cell_size: f32,
    bias_rate: f32,
    mass_scale: f32,
    impulse_scale: f32,
    contact_speed: f32,
    sleep_threshold: f32,
    use_bias: u32,
    joint_count: u32,
    solver_mode: u32,
    enable_sleep: u32,
    step_dt: f32,
    diagnostic_flags: u32,
    contact_hertz: f32,
    contact_damping: f32,
    contact_capacity: u32,
    shape_count: u32,
    shape_base_u32: u32,
    hull_point_count: u32,
    hull_base_u32: u32,
    hull_plane_count: u32,
    hull_plane_base_u32: u32,
    hull_edge_count: u32,
    hull_edge_base_u32: u32,
    hull_topology_count: u32,
    hull_topology_base_u32: u32,
    mesh_vertex_count: u32,
    mesh_vertex_base_u32: u32,
    mesh_triangle_count: u32,
    mesh_triangle_base_u32: u32,
    mesh_node_count: u32,
    mesh_node_base_u32: u32,
    surface_material_count: u32,
    surface_material_base_u32: u32,
    sub_step_count: u32,
    physics_step: u32,
    mix_pair_count: u32,
    mix_pair_base_u32: u32,
    enable_continuous: u32,
    contact_recycle_distance: f32,
    fat_bounds_base: u32,
    fat_bounds_epoch: u32,
    fat_commands_base: u32,
    fat_commands_epoch: u32,
    fat_commands_count: u32,
    remap_old_count: u32,
    remap_capture: u32,
    remap_history_step: u32,
    maximum_linear_speed: f32,
    restitution_threshold: f32,
    insert_base: u32,
    insert_capacity: u32,
    pair_capacity: u32,
}

const KIND_SPHERE: u32 = 0u;
const KIND_BOX: u32 = 1u;
const KIND_CAPSULE: u32 = 2u;
const KIND_CONVEX_HULL: u32 = 3u;
const KIND_MESH: u32 = 4u;
const FLAG_STATIC: u32 = 1u;
const FLAG_SLEEP: u32 = 4u;
const FLAG_SLEEP_ENABLED: u32 = 8u;
const FLAG_LOCK_ANG_X: u32 = 2048u;
const FLAG_LOCK_ANG_Y: u32 = 4096u;
const FLAG_LOCK_ANG_Z: u32 = 8192u;
const FLAG_FIXED_ROTATION: u32 = FLAG_LOCK_ANG_X | FLAG_LOCK_ANG_Y | FLAG_LOCK_ANG_Z;
const FLAG_KINEMATIC: u32 = 16u;
const FLAG_BULLET: u32 = 32u;
const FLAG_ALLOW_FAST_ROTATION: u32 = 64u;
const FLAG_DISABLED: u32 = 128u;
const FLAG_DISABLE_CONTACT_RECYCLING: u32 = 16384u;
const FLAG_FAST: u32 = 32768u;
const JOINT_NONE: u32 = 0u;
const JOINT_REVOLUTE: u32 = 1u;
const JOINT_WELD: u32 = 2u;
const JOINT_SPHERICAL: u32 = 3u;
const JOINT_PRISMATIC: u32 = 4u;
const JOINT_FILTER: u32 = 5u;
const JOINT_DISTANCE: u32 = 6u;
const JOINT_PARALLEL: u32 = 7u;
const JOINT_MOTOR: u32 = 8u;
const JOINT_WHEEL: u32 = 9u;
const TIME_TO_SLEEP: f32 = 0.5;
const EMPTY: u32 = 0xffffffffu;
const TOMBSTONE: u32 = 0xfffffffeu;
const OVERFLOW_COLOR: u32 = 23u;
const DYNAMIC_COLOR_COUNT: u32 = 20u;
const REVOLUTE_ENABLE_SPRING: u32 = 1u;
const REVOLUTE_ENABLE_LIMIT: u32 = 2u;
const REVOLUTE_ENABLE_MOTOR: u32 = 4u;
const SPHERICAL_ENABLE_SPRING: u32 = 1u;
const SPHERICAL_ENABLE_CONE_LIMIT: u32 = 2u;
const SPHERICAL_ENABLE_TWIST_LIMIT: u32 = 4u;
const SPHERICAL_ENABLE_MOTOR: u32 = 8u;
const PRISMATIC_ENABLE_SPRING: u32 = 1u;
const PRISMATIC_ENABLE_LIMIT: u32 = 2u;
const PRISMATIC_ENABLE_MOTOR: u32 = 4u;
const DISTANCE_ENABLE_SPRING: u32 = 1u;
const DISTANCE_ENABLE_LIMIT: u32 = 2u;
const DISTANCE_ENABLE_MOTOR: u32 = 4u;
const WHEEL_ENABLE_SUSPENSION_SPRING: u32 = 1u;
const WHEEL_ENABLE_SUSPENSION_LIMIT: u32 = 2u;
const WHEEL_ENABLE_SPIN_MOTOR: u32 = 4u;
const WHEEL_ENABLE_STEERING: u32 = 8u;
const WHEEL_ENABLE_STEERING_LIMIT: u32 = 16u;
const JOINT_COLLIDE_CONNECTED: u32 = 0x80000000u;
const SPECULATIVE: f32 = 0.02;
const LINEAR_SLOP: f32 = 0.005;
const CONTACT_RECYCLE: f32 = 0.05;
const CONTACT_RECYCLE_ANG: f32 = 0.99240388;
const CONTACT_ALIVE: u32 = 1u;
// Bits 16..19 record point matching independently of impulse magnitude.
const CONTACT_PERSISTED_SHIFT: u32 = 16u;
const CONTACT_PERSISTED_MASK: u32 = 0x000f0000u;
const CONTACT_TOUCHING: u32 = 2u;
const CONTACT_RECYCLED: u32 = 4u;
const CONTACT_START_TOUCHING: u32 = 8u;
const CONTACT_STOP_TOUCHING: u32 = 16u;
const SHAPE_ENABLE_CONTACT_EVENTS: u32 = 1u;
const SHAPE_ENABLE_SENSOR_EVENTS: u32 = 2u;
const SHAPE_IS_SENSOR: u32 = 4u;
const SHAPE_ENABLE_HIT_EVENTS: u32 = 8u;
const SHAPE_DISABLE_SPECULATIVE: u32 = 64u;
const SHAPE_PUBLIC_PROXY: u32 = 128u;
const SHAPE_COMPOUND_CHILD: u32 = 256u;
const DIAG_DISABLE_RECYCLING: u32 = 1u;
const DIAG_DISABLE_SAT_CACHE: u32 = 2u;
const DIAG_DISABLE_ROLLING: u32 = 4u;
const DIAG_REBUILD_GRAPH: u32 = 8u;
const DIAG_DISABLE_SLEEP: u32 = 16u;
const DIAG_PHASE_CAPTURE: u32 = 32u;
const DIAG_FORCE_CAPACITY_LOSS: u32 = 64u;
const DIAG_GENERAL_SOLVER: u32 = 128u;
const DIAG_FORCE_GENERAL_STATIC_SORT: u32 = 256u;
const DIAG_RECOMPUTE_TOPOLOGY: u32 = 512u;
const DIAG_STATIC_DEGREE_ONE_PROOF: u32 = 1024u;
const DIAG_JOINT_FILTER_SCAN: u32 = 2048u;
const DIAG_JOINT_FILTER_OVERFLOW: u32 = 4096u;
const DIAG_SERIAL_JOINTS: u32 = 8192u;
const DIAG_PARALLEL_JOINTS: u32 = 16384u;
const DIAG_MESH_CANDIDATES: u32 = 32768u;
const MESH_TRACE_WORDS: u32 = 32769u;
const JOINT_FILTER_CAP: u32 = 4096u;
const JOINT_FILTER_PROBE: u32 = 32u;
const HASH_BUCKETS: u32 = 16384u;
fn pair_cap() -> u32 { return params.pair_capacity; }
fn contact_hash_cap() -> u32 { return 2u * pair_cap(); }
// Monotonic exclusive slot bound; survives retirement and scene-buffer growth.
const QUERY_CONTACT_HIGH_WATER: u32 = 73u;
const SCR_PAIR_N: u32 = 0u;
const SCR_INSERT_N: u32 = 1u;
const SCR_UNIQUE_N: u32 = 2u;
const SCR_NCONTACTS: u32 = 3u;
const SCR_POW2: u32 = 4u;
const SCR_OCCUPIED_N: u32 = 5u;
const SCR_BSTRIDE: u32 = 6u;
const SCR_STATIC_N: u32 = 7u;
const SCR_INDIRECT_COLLIDE: u32 = 8u;
const SCR_INDIRECT_OCCUPIED: u32 = 12u;
const SCR_COLOR: u32 = 16u;
const SCR_INDIRECT_PREPARE: u32 = 40u;
const SCR_INDIRECT_ISLAND: u32 = 44u;
const SCR_INDIRECT_RADIX: u32 = 48u;
const SCR_RADIX_GROUP_N: u32 = 52u;
const SCR_FREE_N: u32 = 53u;
const SCR_MISSING_N: u32 = 54u;
const SCR_FUSED_N: u32 = 55u;
const SCR_DYN_DYN_N: u32 = 56u;
const SCR_GRAPH_STATIC_N: u32 = 57u;
const SCR_GRAPH_STATIC_MAX: u32 = 58u;
const SCR_INDIRECT_STATIC: u32 = 59u;
const SCR_JOINT_LIST_OK: u32 = 62u;
const SCR_JOINT_COMP_N: u32 = 63u;
const SCR_INDIRECT_COLOR: u32 = 64u;
const SCR_HASH: u32 = 64u;
fn scr_ins_body() -> u32 { return params.insert_base; }
fn scr_ins_next() -> u32 { return params.insert_base + params.insert_capacity; }
fn scr_ins_cell() -> u32 { return params.insert_base + 2u * params.insert_capacity; }
const SCR_PAIRS: u32 = SCR_HASH + HASH_BUCKETS;
// Two-word keys are ordered by high shape index, then low shape index.
fn load_pair_words(base: u32, index: u32) -> vec2<u32> {
    return vec2<u32>(scratch[base + 2u * index], scratch[base + 2u * index + 1u]);
}
fn store_pair_words(base: u32, index: u32, key: vec2<u32>) {
    scratch[base + 2u * index] = key.x;
    scratch[base + 2u * index + 1u] = key.y;
}
fn pair_digit(key: vec2<u32>, shift: u32) -> u32 {
    return (key[shift / 32u] >> (shift % 32u)) & 255u;
}
fn scr_color_list() -> u32 { return SCR_PAIRS + 2u * pair_cap(); }
fn scr_contact_mark() -> u32 { return scr_color_list(); }
fn scr_active_contact() -> u32 { return scr_contact_mark() + pair_cap(); }
fn scr_occupied_contact() -> u32 { return scr_active_contact() + pair_cap(); }
// Graph dynamic-pair workspace becomes next occupied roots after graph assignment.
// The previous occupied roots stay immutable through parallel retirement.
fn scr_next_occupied() -> u32 { return scr_occupied_contact() + pair_cap(); }
fn scr_previous_touching() -> u32 { return scr_next_occupied() + pair_cap(); }
fn scr_radix_out() -> u32 { return scr_previous_touching() + 2u * pair_cap(); }
const RADIX_GROUP_SIZE: u32 = 256u;
fn radix_groups() -> u32 { return pair_cap() / RADIX_GROUP_SIZE; }
const RADIX_BUCKETS: u32 = 256u;
fn scr_radix_hist() -> u32 { return scr_radix_out() + 2u * pair_cap(); }
fn scr_radix_base() -> u32 { return scr_radix_hist() + radix_groups() * RADIX_BUCKETS; }
fn scr_graph() -> u32 { return scr_radix_base() + max(RADIX_BUCKETS, radix_groups()); }
fn color_body_base() -> u32 {
    return scr_graph() + 6u * params.body_count;
}
fn fused_flag_base() -> u32 {
    return color_body_base() + params.body_count;
}
fn fused_slots_base() -> u32 {
    return fused_flag_base() + params.body_count;
}
fn phase_summary_base() -> u32 {
    return fused_slots_base() + 8u * params.body_count;
}
fn atom_graph_color() -> u32 {
    return atom_jacobi() + 9u * params.body_count;
}
fn atom_dyn_dyn() -> u32 {
    return atom_graph_color() + 24u;
}
fn phase_body_base() -> u32 {
    return phase_summary_base() + 24u * 8u;
}
fn color_contact_base() -> u32 {
    return phase_body_base() + 24u * 8u * params.body_count;
}
fn joint_filter_base() -> u32 {
    return color_contact_base() + 24u * params.contact_capacity;
}
fn joint_head_base() -> u32 {
    return joint_filter_base() + JOINT_FILTER_CAP * 3u;
}
fn joint_comp_base() -> u32 {
    return joint_head_base() + params.body_count;
}
fn joint_list_off_base() -> u32 {
    return joint_comp_base() + params.body_count;
}
fn joint_list_count_base() -> u32 {
    return joint_list_off_base() + params.body_count;
}
fn joint_list_base() -> u32 {
    return joint_list_count_base() + params.body_count;
}
const SOLVER_TGS: u32 = 0u;
const SOLVER_JACOBI: u32 = 1u;
const MIN_FRICTION_WEIGHT: f32 = 1e-10;
const SAT_FACE_A: u32 = 1u;
const SAT_FACE_B: u32 = 2u;
const SAT_EDGE: u32 = 3u;
override ISLAND_WORKGROUP_SIZE: u32 = 64u;

const ATOM_PAIR_N: u32 = 0u;
const ATOM_INSERT_N: u32 = 1u;
const ATOM_PAIR_DROPPED: u32 = 2u;
const ATOM_INSERT_DROPPED: u32 = 3u;
const ATOM_CONTACT_DROPPED: u32 = 4u;
const ATOM_HASH_HOP_DROPPED: u32 = 5u;
const ATOM_OCCUPIED_N: u32 = 6u;
const ATOM_STATIC_N: u32 = 7u;
const ATOM_STICKY_PAIR_DROPPED: u32 = 8u;
const ATOM_STICKY_INSERT_DROPPED: u32 = 9u;
const ATOM_STICKY_CONTACT_DROPPED: u32 = 10u;
const ATOM_STICKY_HASH_HOP_DROPPED: u32 = 11u;
const ATOM_STICKY_FIRST_STEP: u32 = 12u;
const ATOM_GRAPH_PROOF_FAIL: u32 = 13u;
const ATOM_JOINT_LIST_DROPPED: u32 = 14u;
const ATOM_MANIFOLD_ALLOC: u32 = 15u;
const ATOM_HASH: u32 = 16u;
const ATOM_PAIR_SET: u32 = ATOM_HASH + HASH_BUCKETS;
// Hash buckets hold slot references; identity storage has two words per slot.
fn atom_contact_key() -> u32 { return ATOM_PAIR_SET + pair_cap(); }
fn atom_contact_identity() -> u32 { return atom_contact_key() + contact_hash_cap(); }
fn atom_jacobi() -> u32 { return atom_contact_identity() + contact_hash_cap(); }
fn atom_island_label() -> u32 {
    return atom_jacobi() + 6u * params.body_count;
}
fn atom_island_wake() -> u32 {
    return atom_island_label() + params.body_count;
}
fn atom_island_ready() -> u32 {
    return atom_island_wake() + params.body_count;
}

@group(0) @binding(0) var<uniform> params: SimParams;
@group(0) @binding(1) var<storage, read_write> body_states: array<BodyState>;
@group(0) @binding(2) var<storage, read> scene_words: array<u32>;
@group(0) @binding(3) var<storage, read_write> contacts: array<ContactHot>;
@group(0) @binding(4) var<storage, read_write> joints: array<Joint>;
@group(0) @binding(5) var<storage, read_write> scratch: array<u32>;
@group(0) @binding(6) var<storage, read_write> atom: array<atomic<u32>>;
@group(0) @binding(7) var<storage, read_write> contact_persistent: array<ContactPersistent>;
@group(0) @binding(8) var<storage, read_write> contact_prepared: array<ContactPrepared>;
@group(0) @binding(9) var<storage, read_write> query: array<atomic<u32>>;

fn island_root(body: u32) -> u32 {
    let base = atom_island_label();
    var root = body;
    loop {
        let parent = atomicLoad(&atom[base + root]);
        if (parent == root || parent == EMPTY) {
            return parent;
        }
        root = parent;
    }
    return root;
}

fn island_union(a: u32, b: u32) {
    let base = atom_island_label();
    var ra = island_root(a);
    var rb = island_root(b);
    loop {
        if (ra == EMPTY || rb == EMPTY || ra == rb) {
            return;
        }
        let lo = min(ra, rb);
        let hi = max(ra, rb);
        // Only attach a root that is still a root. An unconditional atomicMin
        // can overwrite a concurrent hi -> other link and disconnect `other`
        // from this union. Component solvers would then race on shared bodies.
        let link = atomicCompareExchangeWeak(&atom[base + hi], hi, lo);
        if (link.exchanged) {
            return;
        }
        ra = island_root(lo);
        rb = island_root(hi);
    }
}

fn record_capacity_drop_n(per_step: u32, sticky: u32, n: u32) {
    if (n == 0u) {
        return;
    }
    atomicAdd(&atom[per_step], n);
    atomicAdd(&atom[sticky], n);
    let sid = max(params.physics_step, 1u);
    loop {
        let r = atomicCompareExchangeWeak(&atom[ATOM_STICKY_FIRST_STEP], 0u, sid);
        if (r.exchanged || r.old_value != 0u) {
            break;
        }
    }
}

fn record_capacity_drop(per_step: u32, sticky: u32) {
    record_capacity_drop_n(per_step, sticky, 1u);
}

fn write_group_indirect(base: u32, groups: u32) {
    let grid = linear_dispatch_groups(groups);
    scratch[base] = grid.x;
    scratch[base + 1u] = grid.y;
    scratch[base + 2u] = grid.z;
    scratch[base + 3u] = 0u;
}

fn write_count_indirect(base: u32, count: u32, workgroup_size: u32) {
    let wg = max(workgroup_size, 1u);
    write_group_indirect(base, max((count + wg - 1u) / wg, 1u));
}

fn scene_f32(word: u32) -> f32 {
    return bitcast<f32>(scene_words[word]);
}

fn load_body_cold(i: u32) -> BodyCold {
    let w = 16u * i;
    return BodyCold(
        vec3<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u)),
        scene_words[w + 3u],
        vec3<f32>(scene_f32(w + 4u), scene_f32(w + 5u), scene_f32(w + 6u)),
        scene_f32(w + 7u),
        scene_f32(w + 8u),
        scene_f32(w + 9u),
        scene_f32(w + 10u),
        scene_f32(w + 11u),
        scene_f32(w + 12u),
        vec3<f32>(scene_f32(w + 13u), scene_f32(w + 14u), scene_f32(w + 15u)),
    );
}

fn load_shape(i: u32) -> Shape {
    let w = params.shape_base_u32 + 44u * i;
    return Shape(
        scene_words[w],
        scene_words[w + 1u],
        scene_words[w + 2u],
        scene_words[w + 3u],
        vec3<f32>(scene_f32(w + 4u), scene_f32(w + 5u), scene_f32(w + 6u)),
        scene_words[w + 7u],
        vec3<f32>(scene_f32(w + 8u), scene_f32(w + 9u), scene_f32(w + 10u)),
        scene_f32(w + 11u),
        vec3<f32>(scene_f32(w + 12u), scene_f32(w + 13u), scene_f32(w + 14u)),
        scene_f32(w + 15u),
        scene_f32(w + 16u),
        scene_f32(w + 17u),
        scene_words[w + 18u],
        scene_words[w + 19u],
        scene_words[w + 20u],
        scene_words[w + 21u],
        scene_words[w + 22u],
        scene_words[w + 23u],
        bitcast<i32>(scene_words[w + 24u]),
        scene_words[w + 25u],
        scene_words[w + 26u],
        scene_words[w + 27u],
        vec3<f32>(scene_f32(w + 28u), scene_f32(w + 29u), scene_f32(w + 30u)),
        scene_words[w + 31u],
        vec2<u32>(scene_words[w + 32u], scene_words[w + 33u]),
        vec2<u32>(scene_words[w + 34u], scene_words[w + 35u]),
        vec3<f32>(scene_f32(w + 36u), scene_f32(w + 37u), scene_f32(w + 38u)),
        scene_words[w + 39u],
        vec4<f32>(scene_f32(w + 40u), scene_f32(w + 41u), scene_f32(w + 42u), scene_f32(w + 43u)),
    );
}

fn load_surface_material(shape: Shape, index: u32) -> SurfaceMaterial {
    let count = max(shape.material_count, 1u);
    let material = min(
        shape.material_slot + min(index, count - 1u),
        params.surface_material_count - 1u,
    );
    let w = params.surface_material_base_u32 + 12u * material;
    return SurfaceMaterial(
        scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u), scene_f32(w + 3u),
        vec3<f32>(scene_f32(w + 4u), scene_f32(w + 5u), scene_f32(w + 6u)),
        scene_words[w + 7u],
        vec2<u32>(scene_words[w + 8u], scene_words[w + 9u]),
        vec2<u32>(scene_words[w + 10u], scene_words[w + 11u]),
    );
}

fn load_hull_point(shape: Shape, i: u32) -> vec3<f32> {
    if (shape.kind == KIND_BOX) { return BOX_PT[i] * shape.half + shape.local_center; }
    let point = min(shape.hull_slot + i, params.hull_point_count - 1u);
    let w = params.hull_base_u32 + 4u * point;
    return vec3<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u));
}

fn hull_point_count(shape: Shape) -> u32 {
    if (shape.kind == KIND_BOX) { return 8u; }
    return shape.topology_counts & 0xffu;
}

fn hull_plane_count(shape: Shape) -> u32 {
    if (shape.kind == KIND_BOX) { return 6u; }
    return (shape.topology_counts >> 8u) & 0xffu;
}

fn hull_edge_count(shape: Shape) -> u32 {
    return (shape.topology_counts >> 16u) & 0xffu;
}

fn hull_topology_count(shape: Shape) -> u32 {
    if (shape.kind == KIND_BOX) { return 24u; }
    return (shape.topology_counts >> 24u) & 0xffu;
}

fn load_hull_plane(shape: Shape, i: u32) -> vec4<f32> {
    if (shape.kind == KIND_BOX) { let n = BOX_FACE_N[i]; return vec4<f32>(n, dot(abs(n), shape.half) + dot(n, shape.local_center)); }
    let plane = min(shape.plane_slot + i, params.hull_plane_count - 1u);
    let w = params.hull_plane_base_u32 + 4u * plane;
    return vec4<f32>(
        scene_f32(w),
        scene_f32(w + 1u),
        scene_f32(w + 2u),
        scene_f32(w + 3u),
    );
}

fn load_hull_edge(shape: Shape, i: u32) -> vec3<f32> {
    let edge = min(shape.edge_slot + i, params.hull_edge_count - 1u);
    let w = params.hull_edge_base_u32 + 4u * edge;
    return vec3<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u));
}

fn load_hull_topology(shape: Shape, i: u32) -> vec4<u32> {
    if (shape.kind == KIND_BOX) { return vec4<u32>(BOX_EDGE_NEXT[i], BOX_EDGE_TWIN[i], BOX_EDGE_ORIGIN[i], BOX_EDGE_FACE[i]); }
    let edge = min(shape.topology_slot + i, params.hull_topology_count - 1u);
    let w = params.hull_topology_base_u32 + 4u * edge;
    return vec4<u32>(scene_words[w], scene_words[w + 1u], scene_words[w + 2u], scene_words[w + 3u]);
}

fn mesh_to_body_point(shape: Shape, raw: vec3<f32>) -> vec3<f32> {
    if (shape.instance_flags == 0u) { return raw; }
    return shape.instance_position + quat_rotate(shape.instance_rotation, shape.axis * raw);
}
fn mesh_to_raw_vector(shape: Shape, body_vector: vec3<f32>) -> vec3<f32> {
    if (shape.instance_flags == 0u) { return body_vector; }
    return quat_inv_rotate(shape.instance_rotation, body_vector) / shape.axis;
}
fn mesh_to_raw_point(shape: Shape, body_point: vec3<f32>) -> vec3<f32> {
    if (shape.instance_flags == 0u) { return body_point; }
    return mesh_to_raw_vector(shape, body_point - shape.instance_position);
}

fn load_mesh_vertex(shape: Shape, i: u32) -> vec3<f32> {
    let vertex = min(shape.hull_slot + i, params.mesh_vertex_count - 1u);
    let w = params.mesh_vertex_base_u32 + 4u * vertex;
    return mesh_to_body_point(shape, vec3<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u)));
}

fn load_mesh_triangle(shape: Shape, i: u32) -> vec4<u32> {
    let triangle = min(shape.plane_slot + i, params.mesh_triangle_count - 1u);
    let w = params.mesh_triangle_base_u32 + 4u * triangle;
    let tri = vec4<u32>(scene_words[w], scene_words[w + 1u], scene_words[w + 2u], scene_words[w + 3u]);
    if (shape.instance_flags != 0u && shape.axis.x * shape.axis.y * shape.axis.z < 0.0) {
        return vec4<u32>(tri.x, tri.z, tri.y, (tri.w & 0xffffff00u) | ((tri.w >> 4u) & 7u));
    }
    return tri;
}

fn load_mesh_node_lower(shape: Shape, i: u32) -> vec4<f32> {
    let node = min(shape.edge_slot + i, params.mesh_node_count - 1u);
    let w = params.mesh_node_base_u32 + 8u * node;
    return vec4<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u), scene_f32(w + 3u));
}

fn load_mesh_node_upper(shape: Shape, i: u32) -> vec4<f32> {
    let node = min(shape.edge_slot + i, params.mesh_node_count - 1u);
    let w = params.mesh_node_base_u32 + 8u * node + 4u;
    return vec4<f32>(scene_f32(w), scene_f32(w + 1u), scene_f32(w + 2u), scene_f32(w + 3u));
}

// BodyCold (16 words) and body-extra (16 words) are capacity-sized arrays.
// shape_base_u32 follows both arrays; body_count is only the live slot span.
fn body_extra_offset(i: u32) -> u32 {
    let body_capacity = params.shape_base_u32 / 32u;
    return 16u * body_capacity + 16u * i;
}

fn load_body(i: u32) -> Body {
    let s = body_states[i];
    let c = load_body_cold(i);
    let extra = body_extra_offset(i);
    return Body(
        s.pos,
        s.inv_mass,
        s.vel,
        c.kind,
        c.half,
        s.flags,
        s.rot,
        s.omega,
        c.restitution,
        c.inv_inertia,
        vec3<f32>(
            scene_f32(extra),
            scene_f32(extra + 1u),
            scene_f32(extra + 2u),
        ),
        c.friction,
        c.gravity_scale,
        c.linear_damping,
        c.angular_damping,
        c.rolling,
        s.dp,
        s.sleep_time,
        s.dq,
        EMPTY,
        s.sleep_velocity,
        vec2<u32>(i),
    );
}

fn store_body(i: u32, b: Body) {
    body_states[i] = BodyState(
        b.pos,
        b.inv_mass,
        b.vel,
        b.flags,
        b.rot,
        b.omega,
        b.sleep_velocity,
        b.dp,
        b.sleep_time,
        b.dq,
    );
}

fn assemble_contact(h: ContactHot, p: ContactPersistent, f: ContactPrepared) -> Contact {
    return Contact(
        h.a, h.b, h.color, h.count,
        h.n, h.friction,
        h.ra0, h.ra1, h.ra2, h.ra3,
        h.rb0, h.rb1, h.rb2, h.rb3,
        h.friction_impulse, h.twist_impulse, h.rolling,
        h.center_a, h._pad_ca,
        h.center_b, h._pad_cb,
        h.rolling_impulse, h.restitution, h.tangent_velocity, h.material_index,
        f.relative_velocity, p.feature_ids,
        p.cached_relative, p.cached_rotation_a, p.cached_rotation_b, p.lifecycle, p.pair,
        f.normal_mass, f.lever_arm, f.total_normal_impulse, f.tangent_inv, f.softness,
        p.persistent_ra0, p.persistent_ra1, p.persistent_ra2, p.persistent_ra3,
        p.persistent_rb0, p.persistent_rb1, p.persistent_rb2, p.persistent_rb3, h.manifold_link, p.point_triangles,
    );
}

fn load_contact(slot: u32) -> Contact {
    return assemble_contact(
        contacts[slot],
        contact_persistent[slot],
        contact_prepared[slot],
    );
}

fn load_solve_contact(slot: u32) -> Contact {
    let h = contacts[slot];
    let f = contact_prepared[slot];
    var p: ContactPersistent;
    p.feature_ids = vec4<u32>(0u);
    p.cached_relative = vec4<f32>(0.0);
    p.cached_rotation_a = vec4<f32>(0.0);
    p.cached_rotation_b = vec4<f32>(0.0);
    p.lifecycle = vec4<u32>(0u);
    p.pair = vec4<u32>(EMPTY);
    p.persistent_ra0 = vec4<f32>(0.0);
    p.persistent_ra1 = vec4<f32>(0.0);
    p.persistent_ra2 = vec4<f32>(0.0);
    p.persistent_ra3 = vec4<f32>(0.0);
    p.persistent_rb0 = vec4<f32>(0.0);
    p.persistent_rb1 = vec4<f32>(0.0);
    p.persistent_rb2 = vec4<f32>(0.0);
    p.persistent_rb3 = vec4<f32>(0.0);
    return assemble_contact(h, p, f);
}

fn store_hot(slot: u32, c: Contact) {
    contacts[slot] = ContactHot(
        c.a, c.b, c.color, c.count,
        c.n, c.friction,
        c.ra0, c.ra1, c.ra2, c.ra3,
        c.rb0, c.rb1, c.rb2, c.rb3,
        c.friction_impulse, c.twist_impulse, c.rolling,
        c.center_a, c._pad_ca, c.center_b, c._pad_cb,
        c.rolling_impulse, c._pad_end, c.tangent_velocity, c.material_index, c.manifold_link,
    );
}

fn store_prepared(slot: u32, c: Contact) {
    contact_prepared[slot] = ContactPrepared(
        c._tail0,
        c.prepared_normal_mass,
        c.prepared_lever_arm,
        c.total_normal_impulse,
        c.prepared_tangent_inv,
        c.prepared_softness,
    );
}

fn store_graph_meta(slot: u32, color: u32, local: u32) {
    contacts[slot].color = color;
    contact_persistent[slot].lifecycle.z = local;
}

fn store_contact(slot: u32, c: Contact) {
    store_hot(slot, c);
    store_prepared(slot, c);
    contact_persistent[slot] = ContactPersistent(
        c._tail1,
        c.cached_relative,
        c.cached_rotation_a,
        c.cached_rotation_b,
        c.lifecycle,
        c.pair,
        c.persistent_ra0, c.persistent_ra1, c.persistent_ra2, c.persistent_ra3,
        c.persistent_rb0, c.persistent_rb1, c.persistent_rb2, c.persistent_rb3, c.point_triangles,
    );
}

fn store_solve_contact(slot: u32, c: Contact) {
    store_hot(slot, c);
    store_prepared(slot, c);
}

const DIAG_STATIC_DEGREE_TWO_PROOF:u32=65536u;

// Solve phases mutate impulses only; preparation still stores the full record.
fn store_contact_impulses(slot: u32, c: Contact) {
    contacts[slot].rb0.w = c.rb0.w;
    contacts[slot].rb1.w = c.rb1.w;
    contacts[slot].rb2.w = c.rb2.w;
    contacts[slot].rb3.w = c.rb3.w;
    contacts[slot].friction_impulse = c.friction_impulse;
    contacts[slot].twist_impulse = c.twist_impulse;
    contacts[slot].rolling_impulse = c.rolling_impulse;
    contact_prepared[slot].total_normal_impulse = c.total_normal_impulse;
}
// Quats, inertia, contact accessors, Box3D-style softness.

fn is_disabled(b: Body) -> bool {
    return (b.flags & FLAG_DISABLED) != 0u;
}

fn is_static(b: Body) -> bool {
    return (b.flags & FLAG_STATIC) != 0u;
}

fn is_non_dynamic(b: Body) -> bool {
    return is_static(b) || (b.flags & FLAG_KINEMATIC) != 0u || is_disabled(b);
}

fn is_immovable(b: Body) -> bool {
    return is_non_dynamic(b) || (b.flags & FLAG_SLEEP) != 0u;
}

fn joint_endpoint_writable(b: Body) -> bool {
    return !is_immovable(b);
}

fn apply_joint_torque(body: ptr<function, Body>, torque: vec3<f32>) {
    if (!joint_endpoint_writable(*body)) {
        return;
    }
    (*body).omega = (*body).omega + world_inv_inertia(*body, torque);
}

fn body_inv_mass(b: Body) -> f32 {
    return select(b.inv_mass, 0.0, is_immovable(b));
}

fn quat_rotate(q: vec4<f32>, v: vec3<f32>) -> vec3<f32> {
    return gyro_quat_rotate(q,v);
}

fn quat_inv(q: vec4<f32>) -> vec4<f32> {
    return vec4<f32>(-q.xyz, q.w);
}

fn quat_mul(a: vec4<f32>, b: vec4<f32>) -> vec4<f32> {
    return gyro_quat_mul(a,b);
}

fn quat_from_x_axis(axis: vec3<f32>) -> vec4<f32> {
    let n = normalize(axis);
    if (n.x < -0.999999) {
        return vec4<f32>(0.0, 1.0, 0.0, 0.0);
    }
    return normalize(vec4<f32>(0.0, -n.z, n.y, 1.0 + n.x));
}

fn load_collider(i: u32) -> Body {
    let shape = load_shape(i);
    var body = load_body(shape.body_index);
    let cold = load_body_cold(shape.body_index);
    body.pos = body.pos + quat_rotate(body.rot, shape.local_center - cold.local_center);
    if (shape.kind == KIND_CAPSULE && dot(shape.axis, shape.axis) > 1e-12) {
        body.rot = normalize(quat_mul(body.rot, quat_from_x_axis(shape.axis)));
    }
    body.kind = shape.kind;
    body.half = shape.half;
    body.restitution = shape.restitution;
    body.friction = shape.friction;
    body.rolling = shape.rolling;
    body._pad_island = vec2<u32>(i, shape.body_index);
    return body;
}

fn quat_inv_rotate(q: vec4<f32>, v: vec3<f32>) -> vec3<f32> {
    return quat_rotate(quat_inv(q), v);
}

fn solve3(col0: vec3<f32>, col1: vec3<f32>, col2: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    let det = gyro_dot3(col0, gyro_cross(col1, col2));
    if (abs(det) < 1e-12) {
        return vec3<f32>(0.0);
    }
    let inv = gyro_recip(det);
    return vec3<f32>(
        gyro_dot3(b, gyro_cross(col1, col2)) * inv,
        gyro_dot3(gyro_cross(col2, col0), b) * inv,
        gyro_dot3(gyro_cross(col0, col1), b) * inv,
    );
}

fn box_axis(b: Body, i: u32) -> vec3<f32> {
    var e = vec3<f32>(0.0);
    if (i == 0u) { e = vec3<f32>(1.0, 0.0, 0.0); }
    else if (i == 1u) { e = vec3<f32>(0.0, 1.0, 0.0); }
    else { e = vec3<f32>(0.0, 0.0, 1.0); }
    return quat_rotate(b.rot, e);
}

fn bound_radius(b: Body) -> f32 {
    if (b.kind == KIND_SPHERE) {
        return b.half.x;
    }
    if (b.kind == KIND_CAPSULE) {
        return b.half.x + b.half.y;
    }
    return length(b.half);
}

fn native_rotation_matrix(q: vec4<f32>) -> mat3x3<f32> {
    let xx=q.x*q.x; let yy=q.y*q.y; let zz=q.z*q.z;
    let xy=q.x*q.y; let xz=q.x*q.z; let xw=q.x*q.w;
    let yz=q.y*q.z; let yw=q.y*q.w; let zw=q.z*q.w;
    return mat3x3<f32>(
        vec3<f32>(1.0-2.0*(yy+zz),2.0*(xy+zw),2.0*(xz-yw)),
        vec3<f32>(2.0*(xy-zw),1.0-2.0*(xx+zz),2.0*(yz+xw)),
        vec3<f32>(2.0*(xz+yw),2.0*(yz-xw),1.0-2.0*(xx+yy)));
}

fn native_mul_mv(m: mat3x3<f32>, v: vec3<f32>) -> vec3<f32> {
    return (m[0]*v.x + m[1]*v.y) + m[2]*v.z;
}

fn world_inv_inertia_matrix(b: Body) -> mat3x3<f32> {
    if (is_immovable(b) || (b.flags & FLAG_FIXED_ROTATION) == FLAG_FIXED_ROTATION) {
        return mat3x3<f32>(vec3<f32>(0.0),vec3<f32>(0.0),vec3<f32>(0.0));
    }
    let r = native_rotation_matrix(b.rot);
    let o = b.inv_inertia_offdiag;
    let il = mat3x3<f32>(
        vec3<f32>(b.inv_inertia.x,o.x,o.y),
        vec3<f32>(o.x,b.inv_inertia.y,o.z),
        vec3<f32>(o.y,o.z,b.inv_inertia.z));
    let ri = mat3x3<f32>(native_mul_mv(r,il[0]),native_mul_mv(r,il[1]),native_mul_mv(r,il[2]));
    let rt = transpose(r);
    let iw = mat3x3<f32>(native_mul_mv(ri,rt[0]),native_mul_mv(ri,rt[1]),native_mul_mv(ri,rt[2]));
    return iw;
}

fn world_inv_inertia(b: Body, t: vec3<f32>) -> vec3<f32> {
    return native_mul_mv(world_inv_inertia_matrix(b),t);
}

// The native SIMD contact solver stores six symmetric coefficients and
// accumulates the last two products first; scalar joint math differs.
fn contact_inv_inertia(b: Body, v: vec3<f32>) -> vec3<f32> {
    let m = world_inv_inertia_matrix(b);
    return vec3<f32>(
        m[0].x*v.x + (m[0].y*v.y + m[0].z*v.z),
        m[0].y*v.x + (m[1].y*v.y + m[1].z*v.z),
        m[0].z*v.x + (m[1].z*v.y + m[2].z*v.z));
}

fn apply_contact_P(body: ptr<function, Body>, r: vec3<f32>, P: vec3<f32>, sign: f32) {
    if (is_immovable(*body)) { return; }
    (*body).vel = (*body).vel + sign * P * (*body).inv_mass;
    (*body).omega = (*body).omega + sign * contact_inv_inertia(*body, gyro_cross(r,P));
}

fn apply_P(body: ptr<function, Body>, r: vec3<f32>, P: vec3<f32>, sign: f32) {
    if (is_immovable(*body)) {
        return;
    }
    (*body).vel = (*body).vel + sign * P * (*body).inv_mass;
    (*body).omega = (*body).omega + sign * world_inv_inertia(*body, gyro_cross(r, P));
}

fn ra_at(c: Contact, i: u32) -> vec4<f32> {
    if (i == 0u) { return c.ra0; }
    if (i == 1u) { return c.ra1; }
    if (i == 2u) { return c.ra2; }
    return c.ra3;
}

fn rb_at(c: Contact, i: u32) -> vec4<f32> {
    if (i == 0u) { return c.rb0; }
    if (i == 1u) { return c.rb1; }
    if (i == 2u) { return c.rb2; }
    return c.rb3;
}

fn set_point(c: ptr<function, Contact>, i: u32, ra: vec4<f32>, rb: vec4<f32>) {
    if (i == 0u) { (*c).ra0 = ra; (*c).rb0 = rb; }
    else if (i == 1u) { (*c).ra1 = ra; (*c).rb1 = rb; }
    else if (i == 2u) { (*c).ra2 = ra; (*c).rb2 = rb; }
    else { (*c).ra3 = ra; (*c).rb3 = rb; }
}

fn capsule_axis(b: Body) -> vec3<f32> {
    return quat_rotate(b.rot, vec3<f32>(1.0, 0.0, 0.0)) * b.half.y;
}

fn closest_on_obb(world_p: vec3<f32>, box_b: Body) -> vec3<f32> {
    let d = world_p - box_b.pos;
    let local = quat_rotate(quat_inv(box_b.rot), d);
    var c = clamp(local, -box_b.half, box_b.half);
    // Interior: clamp is identity, dist=0, and sphere–box collide would drop the pair.
    if (all(c == local)) {
        let dx = box_b.half.x - abs(local.x);
        let dy = box_b.half.y - abs(local.y);
        let dz = box_b.half.z - abs(local.z);
        if (dx <= dy && dx <= dz) {
            c.x = select(-box_b.half.x, box_b.half.x, local.x >= 0.0);
        } else if (dy <= dz) {
            c.y = select(-box_b.half.y, box_b.half.y, local.y >= 0.0);
        } else {
            c.z = select(-box_b.half.z, box_b.half.z, local.z >= 0.0);
        }
    }
    return box_b.pos + quat_rotate(box_b.rot, c);
}

fn closest_on_segment(p: vec3<f32>, a: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    let ab = b - a;
    let t = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-8), 0.0, 1.0);
    return a + ab * t;
}

fn contact_softness(static_pair: bool) -> vec3<f32> {
    let h = params.dt;
    var hertz = params.contact_hertz;
    if (h > 1e-8) {
        hertz = min(hertz, 0.125 / h);
    }
    var zeta = params.contact_damping;
    if (static_pair) {
        hertz = 2.0 * hertz;
        zeta = 0.5 * zeta;
    }
    let omega = 6.28318530718 * hertz;
    let a1 = 2.0 * zeta + h * omega;
    let a2 = h * omega * a1;
    let a3 = 1.0 / (1.0 + a2);
    return vec3<f32>(omega / a1, a2 * a3, a3);
}

fn empty_contact() -> Contact {
    var c: Contact;
    c.a = EMPTY;
    c.b = EMPTY;
    c.color = 0u;
    c.count = 0u;
    c.n = vec3<f32>(0.0);
    c.friction = 0.0;
    c.ra0 = vec4<f32>(0.0);
    c.ra1 = vec4<f32>(0.0);
    c.ra2 = vec4<f32>(0.0);
    c.ra3 = vec4<f32>(0.0);
    c.rb0 = vec4<f32>(0.0);
    c.rb1 = vec4<f32>(0.0);
    c.rb2 = vec4<f32>(0.0);
    c.rb3 = vec4<f32>(0.0);
    c.friction_impulse = vec2<f32>(0.0);
    c.twist_impulse = 0.0;
    c.rolling = 0.0;
    c.center_a = vec3<f32>(0.0);
    c._pad_ca = 0.0;
    c.center_b = vec3<f32>(0.0);
    c._pad_cb = 0.0;
    c.rolling_impulse = vec3<f32>(0.0);
    c._pad_end = 0.0;
    c.tangent_velocity = vec3<f32>(0.0);
    c.material_index = 0u;
    c._tail0 = vec4<u32>(0u);
    c._tail1 = vec4<u32>(0u);
    c.cached_relative = vec4<f32>(0.0);
    c.cached_rotation_a = vec4<f32>(0.0);
    c.cached_rotation_b = vec4<f32>(0.0);
    c.lifecycle = vec4<u32>(0u);
    c.pair = vec4<u32>(EMPTY);
    c.prepared_normal_mass = vec4<f32>(0.0);
    c.prepared_lever_arm = vec4<f32>(0.0);
    c.total_normal_impulse = vec4<f32>(0.0);
    c.prepared_tangent_inv = vec4<f32>(0.0);
    c.prepared_softness = vec4<f32>(0.0);
    c.persistent_ra0 = vec4<f32>(0.0);
    c.persistent_ra1 = vec4<f32>(0.0);
    c.persistent_ra2 = vec4<f32>(0.0);
    c.persistent_ra3 = vec4<f32>(0.0);
    c.persistent_rb0 = vec4<f32>(0.0);
    c.persistent_rb1 = vec4<f32>(0.0);
    c.persistent_rb2 = vec4<f32>(0.0);
    c.persistent_rb3 = vec4<f32>(0.0);
    return c;
}

fn persistent_ra_at(c: Contact, i: u32) -> vec4<f32> {
    if (i == 0u) { return c.persistent_ra0; }
    if (i == 1u) { return c.persistent_ra1; }
    if (i == 2u) { return c.persistent_ra2; }
    return c.persistent_ra3;
}

fn persistent_rb_at(c: Contact, i: u32) -> vec4<f32> {
    if (i == 0u) { return c.persistent_rb0; }
    if (i == 1u) { return c.persistent_rb1; }
    if (i == 2u) { return c.persistent_rb2; }
    return c.persistent_rb3;
}

fn pack_sat(typ: u32, index_a: u32, index_b: u32) -> u32 {
    return typ | (index_a << 8u) | (index_b << 16u);
}

fn sat_type(p: u32) -> u32 {
    return p & 255u;
}

fn sat_index_a(p: u32) -> u32 {
    return (p >> 8u) & 255u;
}

fn sat_index_b(p: u32) -> u32 {
    return (p >> 16u) & 255u;
}

fn pack_feature(owner1: u32, index1: u32, owner2: u32, index2: u32) -> u32 {
    return (owner1 << 24u) | (index1 << 16u) | (owner2 << 8u) | index2;
}

fn flip_feature(p: u32) -> u32 {
    let o1 = (p >> 24u) & 1u;
    let i1 = (p >> 16u) & 255u;
    let o2 = (p >> 8u) & 1u;
    let i2 = p & 255u;
    return ((1u - o2) << 24u) | (i2 << 16u) | ((1u - o1) << 8u) | i1;
}

fn feat_at(c: Contact, i: u32) -> u32 {
    if (i == 0u) { return c._tail1.z; }
    if (i == 1u) { return c._tail1.w; }
    if (i == 2u) { return bitcast<u32>(c._pad_ca); }
    return bitcast<u32>(c._pad_cb);
}

fn set_feat_at(c: ptr<function, Contact>, i: u32, id: u32) {
    if (i == 0u) { (*c)._tail1.z = id; }
    else if (i == 1u) { (*c)._tail1.w = id; }
    else if (i == 2u) { (*c)._pad_ca = bitcast<f32>(id); }
    else { (*c)._pad_cb = bitcast<f32>(id); }
}

fn manifold_min_sep(c: Contact) -> f32 {
    var m = 1e9;
    for (var i = 0u; i < c.count; i++) {
        let ra = ra_at(c, i);
        let rb = rb_at(c, i);
        m = min(m, ra.w + dot(rb.xyz - ra.xyz, c.n));
    }
    return m;
}

fn point_feature(r: vec3<f32>, n: vec3<f32>) -> u32 {
    var t = vec3<f32>(1.0, 0.0, 0.0);
    if (abs(n.x) > 0.9) {
        t = vec3<f32>(0.0, 1.0, 0.0);
    }
    t = normalize(cross(n, t));
    let b = cross(n, t);
    let su = select(0u, 1u, dot(r, t) >= 0.0);
    let sv = select(0u, 2u, dot(r, b) >= 0.0);
    return su | sv;
}

fn pack_point_features(c: ptr<function, Contact>) {
    if ((*c)._tail1.z != 0u || (*c)._tail1.w != 0u
        || bitcast<u32>((*c)._pad_ca) != 0u || bitcast<u32>((*c)._pad_cb) != 0u) {
        return;
    }
    for (var i = 0u; i < (*c).count; i++) {
        let id = point_feature(ra_at(*c, i).xyz, (*c).n);
        set_feat_at(c, i, id);
    }
}

fn write_sat_cache(c: ptr<function, Contact>, typ: u32, index_a: u32, index_b: u32) {
    (*c)._tail1.x = pack_sat(typ, index_a, index_b);
    (*c)._tail1.y = bitcast<u32>(manifold_min_sep(*c));
}

fn pair_hash_mix(key: u32) -> u32 {
    var x = key;
    x = (x ^ (x >> 16u)) * 0x7feb352du;
    x = (x ^ (x >> 15u)) * 0x846ca68bu;
    return x ^ (x >> 16u);
}

// Identity words are prepared in a separate dispatch before publishing a slot.
// Hash entries contain only slot references: no partially published two-word key
// can become visible under WGSL relaxed atomics. Retired identities stay intact
// until the next allocation phase, after all readers have completed.
fn prepare_contact_identity(dense: u32, key: vec2<u32>) {
    atomicMax(&query[QUERY_CONTACT_HIGH_WATER], dense + 1u);
    atomicStore(&atom[atom_contact_identity() + 2u * dense], key.x);
    atomicStore(&atom[atom_contact_identity() + 2u * dense + 1u], key.y);
}

fn contact_identity(dense: u32) -> vec2<u32> {
    return vec2<u32>(atomicLoad(&atom[atom_contact_identity() + 2u * dense]),
        atomicLoad(&atom[atom_contact_identity() + 2u * dense + 1u]));
}

fn contact_identity_hash(key: vec2<u32>) -> u32 {
    return pair_hash_mix(pair_hash_mix(key.x) ^ key.y) & (contact_hash_cap() - 1u);
}

fn find_contact_identity(key: vec2<u32>) -> u32 {
    var hash_slot = contact_identity_hash(key);
    for (var probe = 0u; probe < contact_hash_cap(); probe++) {
        let stored = atomicLoad(&atom[atom_contact_key() + hash_slot]);
        if (stored < params.contact_capacity) {
            if (all(contact_identity(stored) == key)) { return stored; }
        }
        if (stored == EMPTY) { return EMPTY; }
        hash_slot = (hash_slot + 1u) & (contact_hash_cap() - 1u);
    }
    return EMPTY;
}

// Publication inputs contain one unique root per identity. Identity storage for
// every candidate must already be initialized, including competing publishers.
fn publish_contact_identity(key: vec2<u32>, dense: u32) -> bool {
    // Search past tombstones before insertion so republishing an existing key
    // cannot create a second reference hidden behind a retired bucket.
    loop {
        var hash_slot = contact_identity_hash(key);
        var vacant = EMPTY;
        var expected = EMPTY;
        for (var probe = 0u; probe < contact_hash_cap(); probe++) {
            let stored = atomicLoad(&atom[atom_contact_key() + hash_slot]);
            if (stored < params.contact_capacity) {
                if (all(contact_identity(stored) == key)) {
                    atomicStore(&atom[atom_contact_key() + hash_slot], dense);
                    return true;
                }
            } else if (vacant == EMPTY) {
                vacant = hash_slot;
                expected = stored;
            }
            if (stored == EMPTY) { break; }
            hash_slot = (hash_slot + 1u) & (contact_hash_cap() - 1u);
        }
        if (vacant == EMPTY) { return false; }
        let claimed = atomicCompareExchangeWeak(
            &atom[atom_contact_key() + vacant], expected, dense);
        if (claimed.exchanged) { return true; }
        // Re-probe after contention or a spurious weak-CAS failure.
    }
    return false;
}

fn retire_contact_identity(key: vec2<u32>) {
    var hash_slot = contact_identity_hash(key);
    for (var probe = 0u; probe < contact_hash_cap(); probe++) {
        let stored = atomicLoad(&atom[atom_contact_key() + hash_slot]);
        if (stored < params.contact_capacity) {
            if (all(contact_identity(stored) == key)) {
                atomicStore(&atom[atom_contact_key() + hash_slot], TOMBSTONE);
                return;
            }
        }
        if (stored == EMPTY) { return; }
        hash_slot = (hash_slot + 1u) & (contact_hash_cap() - 1u);
    }
}

fn find_contact_slot(key: vec2<u32>) -> u32 { return find_contact_identity(key); }
fn publish_contact_slot(key: vec2<u32>, dense: u32) -> bool { return publish_contact_identity(key, dense); }
fn retire_contact_key(key: vec2<u32>) { retire_contact_identity(key); }

fn find_prev_contact_key(key: vec2<u32>, a: u32, b: u32) -> Contact {
    let slot = find_contact_slot(key);
    if (slot == EMPTY) {
        return empty_contact();
    }
    let p = load_contact(slot);
    if ((p.a == a && p.b == b) || (p.a == b && p.b == a)) {
        return p;
    }
    return empty_contact();
}

fn find_prev_contact(a: u32, b: u32) -> Contact {
    return find_prev_contact_key(vec2<u32>(min(a, b), max(a, b)), a, b);
}

struct PointMatch { impulses: vec4<f32>, persisted: u32 }

fn persisted_point_bits(count: u32) -> u32 {
    return ((1u << min(count, 4u)) - 1u) << CONTACT_PERSISTED_SHIFT;
}

fn match_previous_points(c: Contact, p: Contact) -> PointMatch {
    var out = vec4<f32>(0.0);
    var persisted = 0u;
    if (p.a == EMPTY) {
        return PointMatch(out, persisted);
    }
    let swapped = p.a == c.b && p.b == c.a;
    let mesh_identity = any(c.point_triangles != vec4<u32>(0u)) || any(p.point_triangles != vec4<u32>(0u));
    let use_id = mesh_identity || ((c._tail1.z != 0u || c._tail1.w != 0u
            || bitcast<u32>(c._pad_ca) != 0u || bitcast<u32>(c._pad_cb) != 0u)
        && (p._tail1.z != 0u || p._tail1.w != 0u
            || bitcast<u32>(p._pad_ca) != 0u || bitcast<u32>(p._pad_cb) != 0u));
    var claimed = vec4<bool>(false);
    for (var k = 0u; k < c.count; k++) {
        var jn = 0.0;
        var matched = false;
        if (use_id) {
            let want = feat_at(c, k);
            for (var j = 0u; j < p.count; j++) {
                if (claimed[j]) {
                    continue;
                }
                var have = feat_at(p, j);
                if (swapped) {
                    have = flip_feature(have);
                }
                if (have == want && (!mesh_identity || (c.point_triangles[k] != 0u
                    && c.point_triangles[k] == p.point_triangles[j]))) {
                    jn = rb_at(p, j).w;
                    claimed[j] = true;
                    matched = true;
                    break;
                }
            }
        }
        // Hull clip ids change when SAT flips face A/B. Box3D still warm-starts
        // nearby points; skipping that fallback walks a stacked column.
        if (!matched && !mesh_identity) {
            let ra = ra_at(c, k).xyz;
            var best = 0.15;
            var best_j = EMPTY;
            for (var j = 0u; j < p.count; j++) {
                if (claimed[j]) {
                    continue;
                }
                var pra = ra_at(p, j).xyz;
                if (swapped) {
                    pra = rb_at(p, j).xyz;
                }
                let d = length(ra - pra);
                if (d < best) {
                    best = d;
                    jn = rb_at(p, j).w;
                    best_j = j;
                }
            }
            if (best_j != EMPTY) {
                claimed[best_j] = true;
                matched = true;
            }
        }
        if (matched) { persisted |= 1u << (CONTACT_PERSISTED_SHIFT + k); }
        if (k == 0u) { out.x = jn; }
        else if (k == 1u) { out.y = jn; }
        else if (k == 2u) { out.z = jn; }
        else { out.w = jn; }
    }
    return PointMatch(out, persisted);
}

fn warm_jn_from_previous(c: Contact, p: Contact) -> vec4<f32> {
    return match_previous_points(c, p).impulses;
}

// Structural validation also permits obsolete body IDs during retirement.
fn contact_chain_structure_valid(root: u32) -> bool {
    if (root >= params.contact_capacity) {
        record_contact_drop(0u);
        return false;
    }
    let first = contacts[root];
    let count = max(first.manifold_link.z, 1u);
    var valid = first.manifold_link.y == 0u && count <= params.contact_capacity;
    var slot = root;
    for (var i = 0u; i < min(count, params.contact_capacity) && valid; i++) {
        if (slot >= params.contact_capacity) { valid = false; break; }
        let c = contacts[slot];
        let parent = select(root + 1u, 0u, i == 0u);
        if (c.a != first.a || c.b != first.b || c.manifold_link.y != parent) {
            valid = false; break;
        }
        let next = c.manifold_link.x;
        if (i + 1u == count) { valid = next == 0u; }
        else if (next == 0u) { valid = false; }
        else { slot = next - 1u; }
    }
    if (!valid) { record_contact_drop(1u); }
    return valid;
}

// The root remains unchanged until cache transfer from all old patches is done.
// Slots retired here cannot re-enter this dispatch's free-list snapshot.
fn retire_manifold_children(root: u32) -> bool {
    if (!contact_chain_structure_valid(root)) { return false; }
    let first = contacts[root];
    var next = first.manifold_link.x;
    for (var i = 1u; i < max(first.manifold_link.z, 1u); i++) {
        let slot = next - 1u;
        let old = load_contact(slot);
        next = old.manifold_link.x;
        var empty = empty_contact();
        empty.lifecycle.x = old.lifecycle.x;
        store_contact(slot, empty);
        scratch[scr_contact_mark() + slot] = 0u;
    }
    contacts[root].manifold_link = vec4<u32>(0u);
    return true;
}

fn allocate_manifold_slot(root: u32) -> u32 {
    if (root >= params.contact_capacity) {
        record_contact_drop(2u);
        return EMPTY;
    }
    let index = atomicAdd(&atom[ATOM_MANIFOLD_ALLOC], 1u);
    if (index >= min(scratch[SCR_FREE_N], params.contact_capacity)) {
        record_contact_drop(3u);
        return EMPTY;
    }
    let slot = scratch[scr_radix_out() + index];
    if (slot >= params.contact_capacity || slot == root || contacts[slot].a != EMPTY) {
        record_contact_drop(4u);
        return EMPTY;
    }
    atomicMax(&query[QUERY_CONTACT_HIGH_WATER], slot + 1u);
    scratch[scr_contact_mark() + slot] = 1u;
    return slot;
}

// Sticky cause bits share the existing tiny status readback. Ray state occupies
// words 0..31 and joint-pair mutation words 64/65; word 66 is reserved here.
fn record_contact_drop(reason: u32) {
    atomicOr(&query[66u], 1u << reason);
    record_capacity_drop(ATOM_CONTACT_DROPPED, ATOM_STICKY_CONTACT_DROPPED);
}
// CPU-ordered rotational integration. Native Vulkan adds NoContraction only
// to these gyro_* functions; contact and joint math retain their normal compilation.
fn gyro_quat_rotate(q: vec4<f32>, v: vec3<f32>) -> vec3<f32> {
    // Native b3RotateVector form. Unlike the homogeneous expansion, this
    // preserves the vector along the rotation axis when |q| rounds off unity.
    return v + 2.0 * gyro_cross(q.xyz, gyro_cross(q.xyz, v) + q.w * v);
}

fn gyro_quat_mul(a: vec4<f32>, b: vec4<f32>) -> vec4<f32> {
    return vec4<f32>(
        (gyro_cross(a.xyz, b.xyz) + a.w * b.xyz) + b.w * a.xyz,
        a.w * b.w - gyro_dot3(a.xyz, b.xyz),
    );
}

fn gyro_quat_inv_rotate(q: vec4<f32>, v: vec3<f32>) -> vec3<f32> {
    return v + 2.0 * gyro_cross(q.xyz, gyro_cross(q.xyz,v) - q.w*v);
}

fn gyro_solve3(col0: vec3<f32>, col1: vec3<f32>, col2: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    let det = gyro_dot3(col0, gyro_cross(col1, col2));
    if (abs(det) < 1e-12) {
        return vec3<f32>(0.0);
    }
    let inv = gyro_recip(det);
    return vec3<f32>(
        gyro_dot3(b, gyro_cross(col1, col2)) * inv,
        gyro_dot3(gyro_cross(col2,col0), b) * inv,
        gyro_dot3(gyro_cross(col0,col1), b) * inv,
    );
}

fn gyro_local_inertia_matrix(b: Body) -> mat3x3<f32> {
    let m0=vec3<f32>(b.inv_inertia.x,b.inv_inertia_offdiag.x,b.inv_inertia_offdiag.y);
    let m1=vec3<f32>(b.inv_inertia_offdiag.x,b.inv_inertia.y,b.inv_inertia_offdiag.z);
    let m2=vec3<f32>(b.inv_inertia_offdiag.y,b.inv_inertia_offdiag.z,b.inv_inertia.z);
    let det=gyro_dot3(m0,gyro_cross(m1,m2));
    if (abs(det)<1e-12) {return mat3x3<f32>(vec3<f32>(0.0),vec3<f32>(0.0),vec3<f32>(0.0));}
    let invDet=gyro_recip(det);
    return transpose(mat3x3<f32>(invDet*gyro_cross(m1,m2),invDet*gyro_cross(m2,m0),invDet*gyro_cross(m0,m1)));
}

fn gyro_apply_gyro(b: ptr<function, Body>, h: f32) {
    let inv = (*b).inv_inertia;
    if (inv.x < 1e-12 || inv.y < 1e-12 || inv.z < 1e-12) {
        return;
    }
    let inertia = gyro_local_inertia_matrix(*b);
    let q = gyro_quat_mul((*b).dq, (*b).rot);
    var omega1 = gyro_quat_inv_rotate(q, (*b).omega);
    var omega2 = omega1;
    for (var it = 0u; it < 1u; it++) {
        let i00=inertia[0].x;let i01=inertia[1].x;let i02=inertia[2].x;
        let i11=inertia[1].y;let i12=inertia[2].y;let i22=inertia[2].z;
        let w1=omega2.x;let w2=omega2.y;let w3=omega2.z;
        let Iw1=i00*w1+i01*w2+i02*w3;
        let Iw2=i01*w1+i11*w2+i12*w3;
        let Iw3=i02*w1+i12*w2+i22*w3;
        let dw=omega2-omega1;
        let residual=vec3<f32>(i00*dw.x+i01*dw.y+i02*dw.z+h*(w2*Iw3-w3*Iw2),i01*dw.x+i11*dw.y+i12*dw.z+h*(w3*Iw1-w1*Iw3),i02*dw.x+i12*dw.y+i22*dw.z+h*(w1*Iw2-w2*Iw1));
        let j0=vec3<f32>(i00+h*(w2*i02-w3*i01),i01+h*(w3*i00-w1*i02-Iw3),i02+h*(w1*i01-w2*i00+Iw2));
        let j1=vec3<f32>(i01+h*(w2*i12-w3*i11+Iw3),i11+h*(w3*i01-w1*i12),i12+h*(w1*i11-w2*i01-Iw1));
        let j2=vec3<f32>(i02+h*(w2*i22-w3*i12-Iw2),i12+h*(w3*i02-w1*i22+Iw1),i22+h*(w1*i12-w2*i02));
        omega2 = omega2 - gyro_solve3(j0, j1, j2, residual);
    }
    (*b).omega = gyro_quat_rotate(q, omega2);
}

// Match CPU normalization: rounded sqrt, then rounded reciprocal, then scale.
// A residual correction removes the native shader sqrt/divide approximation.
// This is not an added damping term or a change to the Newton iteration count.
fn gyro_norm3(v: vec3<f32>) -> vec3<f32> {
    let squared = gyro_dot3(v, v);
    if (squared <= 1.17549435e-35) {
        return vec3<f32>(0.0);
    }
    return gyro_recip(gyro_sqrt(squared)) * v;
}

fn gyro_norm4(q: vec4<f32>) -> vec4<f32> {
    let length_squared = ((q.x*q.x + q.y*q.y) + q.z*q.z) + q.w*q.w;
    if (length_squared <= 1.17549435e-35) {
        return vec4<f32>(0.0, 0.0, 0.0, 1.0);
    }
    let scale = gyro_recip(gyro_sqrt(length_squared));
    return scale * q;
}

fn gyro_dot3(a: vec3<f32>, b: vec3<f32>) -> f32 {
    return (a.x*b.x + a.y*b.y) + a.z*b.z;
}

fn gyro_recip(x: f32) -> f32 {
    let estimate = 1.0 / x;
    let residual = fma(-estimate, x, 1.0);
    return fma(residual, estimate, estimate);
}

fn gyro_divide(a: f32, b: f32) -> f32 {
    let estimate = a / b;
    let residual = fma(-estimate, b, a);
    return fma(residual, gyro_recip(b), estimate);
}

fn gyro_sqrt(x: f32) -> f32 {
    let bits = bitcast<u32>(x);
    let exponent = (bits >> 23u) & 255u;
    if (x <= 0.0 || exponent == 0u || exponent == 255u) { return sqrt(x); }
    // Scale by an even power of two so midpoint residuals cannot underflow.
    let e = i32(exponent) - 127;
    let half_e = e >> 1;
    let scaled = bitcast<f32>((bits & 0x007fffffu) | (u32(e - 2 * half_e + 127) << 23u));
    let estimate = sqrt(scaled);
    let residual = fma(-estimate, estimate, scaled);
    let root = fma(residual, 0.5 / estimate, estimate);
    // A rounded Newton update can land on the wrong side of a sqrt midpoint.
    // Compare squared midpoints using residuals rather than rounding the midpoint.
    let root_bits = bitcast<u32>(root);
    let upper = bitcast<f32>(root_bits + 1u);
    let lower = bitcast<f32>(root_bits - 1u);
    let up_gap = upper - root;
    let down_gap = root - lower;
    let remainder = fma(-root, root, scaled);
    let above = fma(-root, up_gap, remainder) - 0.25 * up_gap * up_gap;
    let below = fma(root, down_gap, remainder) - 0.25 * down_gap * down_gap;
    let odd = (root_bits & 1u) != 0u;
    var rounded = root;
    if (above > 0.0 || (above == 0.0 && odd)) { rounded = upper; }
    else if (below < 0.0 || (below == 0.0 && odd)) { rounded = lower; }
    return rounded * bitcast<f32>(u32(half_e + 127) << 23u);
}

// Keep component operations explicit: a native cross builtin can contract its
// products even when neighboring arithmetic has NoContraction decorations.
fn gyro_cross(a: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    return vec3<f32>(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x);
}

fn gyro_integrate_rotation(q:vec4<f32>,w:vec3<f32>,h:f32)->vec4<f32> {
    let qd=gyro_quat_mul(vec4<f32>(0.5*(h*w),0.0),q);
    return gyro_norm4(q+qd);
}
fn gyro_finish_rotation(dq:vec4<f32>,q:vec4<f32>)->vec4<f32> {
    return gyro_norm4(gyro_quat_mul(dq,q));
}

// Box3D `s_boxHull` topology (8 verts, 24 half-edges, 6 faces).

const BOX_PT: array<vec3<f32>, 8> = array<vec3<f32>, 8>(
    vec3<f32>(1.0, 1.0, 1.0),
    vec3<f32>(-1.0, 1.0, 1.0),
    vec3<f32>(-1.0, -1.0, 1.0),
    vec3<f32>(1.0, -1.0, 1.0),
    vec3<f32>(1.0, 1.0, -1.0),
    vec3<f32>(-1.0, 1.0, -1.0),
    vec3<f32>(-1.0, -1.0, -1.0),
    vec3<f32>(1.0, -1.0, -1.0),
);

const BOX_FACE_N: array<vec3<f32>, 6> = array<vec3<f32>, 6>(
    vec3<f32>(-1.0, 0.0, 0.0),
    vec3<f32>(1.0, 0.0, 0.0),
    vec3<f32>(0.0, -1.0, 0.0),
    vec3<f32>(0.0, 1.0, 0.0),
    vec3<f32>(0.0, 0.0, -1.0),
    vec3<f32>(0.0, 0.0, 1.0),
);

const BOX_EDGE_NEXT: array<u32, 24> = array<u32, 24>(
    2u, 17u, 4u, 20u, 6u, 23u, 0u, 18u, 10u, 21u, 12u, 16u,
    14u, 19u, 8u, 22u, 7u, 9u, 11u, 5u, 15u, 1u, 3u, 13u,
);
const BOX_EDGE_TWIN: array<u32, 24> = array<u32, 24>(
    1u, 0u, 3u, 2u, 5u, 4u, 7u, 6u, 9u, 8u, 11u, 10u,
    13u, 12u, 15u, 14u, 17u, 16u, 19u, 18u, 21u, 20u, 23u, 22u,
);
const BOX_EDGE_ORIGIN: array<u32, 24> = array<u32, 24>(
    2u, 1u, 1u, 5u, 5u, 6u, 6u, 2u, 0u, 3u, 3u, 7u,
    7u, 4u, 4u, 0u, 3u, 2u, 6u, 7u, 1u, 0u, 4u, 5u,
);
const BOX_EDGE_FACE: array<u32, 24> = array<u32, 24>(
    0u, 5u, 0u, 3u, 0u, 4u, 0u, 2u, 1u, 5u, 1u, 2u,
    1u, 4u, 1u, 3u, 2u, 5u, 2u, 4u, 3u, 5u, 3u, 4u,
);
const BOX_FACE_EDGE: array<u32, 6> = array<u32, 6>(0u, 8u, 16u, 20u, 19u, 21u);
const BOX_VERT_EDGE: array<u32, 8> = array<u32, 8>(8u, 1u, 0u, 9u, 13u, 3u, 5u, 11u);
const AABB_MARGIN_FRAC: f32 = 0.125;
const MAX_AABB_MARGIN: f32 = 0.05;
const PARALLEL_EDGE_TOL: f32 = 0.005;

fn box_point_local(b: Body, i: u32) -> vec3<f32> {
    return BOX_PT[i] * b.half;
}

fn box_point(b: Body, i: u32) -> vec3<f32> {
    return b.pos + quat_rotate(b.rot, box_point_local(b, i));
}

fn to_body_local(b: Body, world: vec3<f32>) -> vec3<f32> {
    return quat_inv_rotate(b.rot, world - b.pos);
}

fn from_body_local(b: Body, local: vec3<f32>) -> vec3<f32> {
    return b.pos + quat_rotate(b.rot, local);
}

fn hull_face_n(b: Body, face: u32) -> vec3<f32> {
    return quat_rotate(b.rot, BOX_FACE_N[face]);
}

fn hull_face_half(b: Body, face: u32) -> f32 {
    let ax = face / 2u;
    if (ax == 1u) {
        return b.half.y;
    }
    if (ax == 2u) {
        return b.half.z;
    }
    return b.half.x;
}

fn box_aabb_extent(b: Body) -> vec3<f32> {
    return abs(box_axis(b, 0u)) * b.half.x
        + abs(box_axis(b, 1u)) * b.half.y
        + abs(box_axis(b, 2u)) * b.half.z;
}

fn body_aabb_pad(b: Body) -> f32 {
    // Box3D tight AABB includes speculative; fat AABB adds per-shape margin on dynamics.
    if (is_static(b)) {
        return SPECULATIVE;
    }
    return SPECULATIVE + min(MAX_AABB_MARGIN, AABB_MARGIN_FRAC * bound_radius(b));
}

fn collider_aabb_extent(b: Body) -> vec3<f32> {
    if (b.kind == KIND_BOX || b.kind == KIND_MESH || b.kind == KIND_CONVEX_HULL) {
        return box_aabb_extent(b);
    }
    if (b.kind == KIND_SPHERE) {
        return vec3<f32>(b.half.x);
    }
    return vec3<f32>(b.half.x + b.half.y);
}

fn aabb_overlap(a: Body, b: Body) -> bool {
    return all(fat_lower(a) <= fat_upper(b)) && all(fat_lower(b) <= fat_upper(a));
}

fn to_a(a: Body, p: vec3<f32>) -> vec3<f32> {
    return quat_inv_rotate(a.rot, p - a.pos);
}

fn dir_to_a(a: Body, d: vec3<f32>) -> vec3<f32> {
    return quat_inv_rotate(a.rot, d);
}

fn box_support_vertex(b: Body, dir: vec3<f32>) -> u32 {
    var best = 0u;
    var best_d = -1e9;
    for (var i = 0u; i < 8u; i++) {
        let s = dot(box_point(b, i), dir);
        if (s > best_d) {
            best_d = s;
            best = i;
        }
    }
    return best;
}

fn find_incident_face(b: Body, ref_n: vec3<f32>, vertex: u32) -> u32 {
    var min_edge = BOX_VERT_EDGE[vertex];
    var min_proj = 1e9;
    var edge_i = BOX_VERT_EDGE[vertex];
    let origin_p = box_point(b, vertex);
    for (var k = 0u; k < 8u; k++) {
        let twin_i = BOX_EDGE_TWIN[edge_i];
        let twin_o = BOX_EDGE_ORIGIN[twin_i];
        let axis = box_point(b, twin_o) - origin_p;
        let al = length(axis);
        if (al > 1e-12) {
            let proj = abs(dot(axis / al, ref_n));
            if (proj < min_proj) {
                min_proj = proj;
                min_edge = edge_i;
            }
        }
        edge_i = BOX_EDGE_NEXT[twin_i];
        if (edge_i == BOX_VERT_EDGE[vertex]) {
            break;
        }
    }
    let f1 = BOX_EDGE_FACE[min_edge];
    let f2 = BOX_EDGE_FACE[BOX_EDGE_TWIN[min_edge]];
    if (dot(hull_face_n(b, f1), ref_n) < dot(hull_face_n(b, f2), ref_n)) {
        return f1;
    }
    return f2;
}

fn hull_face_verts(b: Body, face: u32) -> array<vec3<f32>, 4> {
    var outv: array<vec3<f32>, 4>;
    var e = BOX_FACE_EDGE[face];
    for (var i = 0u; i < 4u; i++) {
        let nxt = BOX_EDGE_NEXT[e];
        // Box3D `b3BuildPolygon`: vertex at next->origin.
        outv[i] = box_point(b, BOX_EDGE_ORIGIN[nxt]);
        e = nxt;
    }
    return outv;
}

fn hull_face_edge_ids(face: u32) -> array<u32, 4> {
    var ids: array<u32, 4>;
    var e = BOX_FACE_EDGE[face];
    for (var i = 0u; i < 4u; i++) {
        ids[i] = e;
        e = BOX_EDGE_NEXT[e];
    }
    return ids;
}

struct EdgeQuery {
    n: vec3<f32>,
    sep: f32,
    index_a: u32,
    index_b: u32,
}

// Box3D `b3QueryEdgeDirections`: Gauss-map test in A, axis from B→A, store A→B.
fn gauss_edge_query(a: Body, b: Body) -> EdgeQuery {
    var q: EdgeQuery;
    q.n = vec3<f32>(0.0, 1.0, 0.0);
    q.sep = -1e9;
    q.index_a = EMPTY;
    q.index_b = EMPTY;
    let squared_tol = PARALLEL_EDGE_TOL * PARALLEL_EDGE_TOL;
    for (var i = 0u; i < 12u; i++) {
        let ea = 2u * i;
        let ta = BOX_EDGE_TWIN[ea];
        let qA = to_a(a, box_point(a, BOX_EDGE_ORIGIN[ta]));
        let eA = qA - to_a(a, box_point(a, BOX_EDGE_ORIGIN[ea]));
        let uA = BOX_FACE_N[BOX_EDGE_FACE[ea]];
        let vA = BOX_FACE_N[BOX_EDGE_FACE[ta]];
        for (var j = 0u; j < 12u; j++) {
            let eb = 2u * j;
            let tb = BOX_EDGE_TWIN[eb];
            let qB = to_a(a, box_point(b, BOX_EDGE_ORIGIN[tb]));
            let eB = qB - to_a(a, box_point(b, BOX_EDGE_ORIGIN[eb]));
            let uB = dir_to_a(a, hull_face_n(b, BOX_EDGE_FACE[eb]));
            let vB = dir_to_a(a, hull_face_n(b, BOX_EDGE_FACE[tb]));
            let cba = dot(uB, eA);
            let dba = dot(vB, eA);
            let adc = -dot(uA, eB);
            let bdc = -dot(vA, eB);
            if (cba * dba >= 0.0 || adc * bdc >= 0.0 || cba * bdc <= 0.0) {
                continue;
            }
            if (max(cba * cba, dba * dba) < squared_tol * dot(eA, eA)) {
                continue;
            }
            let t = cba / (cba - dba);
            var axis = mix(uB, vB, t);
            let len2 = dot(axis, axis);
            if (len2 < 1e-20) {
                continue;
            }
            axis = axis / sqrt(len2);
            let sep = dot(axis, qA - qB);
            if (sep > q.sep) {
                q.sep = sep;
                q.n = -axis;
                q.index_a = ea;
                q.index_b = eb;
            }
        }
    }
    return q;
}

fn closest_segments(p1: vec3<f32>, d1: vec3<f32>, p2: vec3<f32>, d2: vec3<f32>) -> vec2<f32> {
    let r = p1 - p2;
    let a = dot(d1, d1);
    let e = dot(d2, d2);
    let f = dot(d2, r);
    var s = 0.0;
    var t = 0.0;
    if (a <= 1e-12 && e <= 1e-12) {
        return vec2<f32>(0.0, 0.0);
    }
    if (a <= 1e-12) {
        t = clamp(f / e, 0.0, 1.0);
    } else {
        let c = dot(d1, r);
        if (e <= 1e-12) {
            s = clamp(-c / a, 0.0, 1.0);
        } else {
            let b = dot(d1, d2);
            let denom = a * e - b * b;
            if (denom != 0.0) {
                s = clamp((b * f - c * e) / denom, 0.0, 1.0);
            }
            t = (b * s + f) / e;
            if (t < 0.0) {
                t = 0.0;
                s = clamp(-c / a, 0.0, 1.0);
            } else if (t > 1.0) {
                t = 1.0;
                s = clamp((b - c) / a, 0.0, 1.0);
            }
        }
    }
    return vec2<f32>(s, t);
}
override COLLISION_MESH_ENABLED: bool = true;

// Box–box follows Box3D `b3CollideHulls`: SAT face cache, then OBB SAT (clip-before-edge).

fn box_support_radius(b: Body, axis: vec3<f32>) -> f32 {
    return b.half.x * abs(dot(axis, box_axis(b, 0u)))
        + b.half.y * abs(dot(axis, box_axis(b, 1u)))
        + b.half.z * abs(dot(axis, box_axis(b, 2u)));
}

fn box_interval(b: Body, axis: vec3<f32>) -> vec2<f32> {
    let r = box_support_radius(b, axis);
    let m = dot(b.pos, axis);
    return vec2<f32>(m - r, m + r);
}

fn interval_overlap(a: vec2<f32>, b: vec2<f32>) -> f32 {
    return min(a.y, b.y) - max(a.x, b.x);
}

fn face_verts(b: Body, ax: u32, sgn: f32) -> array<vec3<f32>, 4> {
    let n = box_axis(b, ax) * sgn;
    var u_i = (ax + 1u) % 3u;
    var v_i = (ax + 2u) % 3u;
    let u = box_axis(b, u_i);
    let v = box_axis(b, v_i);
    var hu = b.half.x;
    var hv = b.half.y;
    if (u_i == 1u) { hu = b.half.y; }
    if (u_i == 2u) { hu = b.half.z; }
    if (v_i == 0u) { hv = b.half.x; }
    if (v_i == 1u) { hv = b.half.y; }
    if (v_i == 2u) { hv = b.half.z; }
    let c = b.pos + n * hull_face_half(b, 2u * ax);
    return array<vec3<f32>, 4>(
        c + u * hu + v * hv,
        c + u * hu - v * hv,
        c - u * hu - v * hv,
        c - u * hu + v * hv,
    );
}

fn box_face_n(b: Body, face: u32) -> vec3<f32> {
    return hull_face_n(b, face);
}

fn box_face_half(b: Body, face: u32) -> f32 {
    return hull_face_half(b, face);
}

fn hull_face_sep(ref_b: Body, other: Body, face: u32) -> f32 {
    let n = box_face_n(ref_b, face);
    let max_ref = dot(ref_b.pos, n) + box_face_half(ref_b, face);
    return (dot(other.pos, n) - box_support_radius(other, n)) - max_ref;
}

fn box_support_index(b: Body, dir: vec3<f32>) -> u32 {
    let local = quat_inv_rotate(b.rot, dir);
    var idx = 0u;
    if (local.x >= 0.0) { idx = idx | 1u; }
    if (local.y >= 0.0) { idx = idx | 2u; }
    if (local.z >= 0.0) { idx = idx | 4u; }
    return idx;
}

fn rolling_radius(b: Body) -> f32 {
    if (b.kind == KIND_SPHERE) {
        return b.half.x;
    }
    if (b.kind == KIND_CAPSULE) {
        return b.half.x;
    }
    // Collider proxies carry the live shape slot, including compound children.
    // A hull's inner radius need not equal its smallest bounding-box extent.
    if (b.kind == KIND_CONVEX_HULL) {
        return 0.25 * load_shape(b._pad_island.x).inner_radius;
    }
    if (b.kind == KIND_BOX) {
        return 0.25 * min(b.half.x, min(b.half.y, b.half.z));
    }
    return 0.0;
}

const MIX_PAIR_CAP: u32 = 4096u;

// Native mesh contacts use the full hull inner radius; the quarter-radius
// rule belongs to convex-convex contacts only.
fn mesh_rolling_radius(shape: Shape) -> f32 {
    if (shape.kind == KIND_CONVEX_HULL) { return shape.inner_radius; }
    if (shape.kind == KIND_BOX) { return min(shape.half.x, min(shape.half.y, shape.half.z)); }
    if (shape.kind == KIND_SPHERE || shape.kind == KIND_CAPSULE) { return shape.half.x; }
    return 0.0;
}

fn mixed_friction_of(a: Body, b: Body) -> f32 {
    let geometric = sqrt(max(a.friction * b.friction, 0.0));
    if (params.mix_pair_count == 0u) {
        return geometric;
    }
    let ia = a._pad_island.x;
    let ib = b._pad_island.x;
    let key = vec2<u32>(min(ia, ib), max(ia, ib));
    var slot = pair_hash_mix(pair_hash_mix(key.x) ^ key.y) & (MIX_PAIR_CAP - 1u);
    for (var probe = 0u; probe < 32u; probe++) {
        let base = params.mix_pair_base_u32 + slot * 8u;
        if (scene_words[base + 4u] == 0u) {
            break;
        }
        if (scene_words[base] == key.x && scene_words[base + 1u] == key.y) {
            return bitcast<f32>(scene_words[base + 2u]);
        }
        slot = (slot + 1u) & (MIX_PAIR_CAP - 1u);
    }
    return geometric;
}

fn mixed_restitution_of(a: Body, b: Body) -> f32 {
    let geometric = max(a.restitution, b.restitution);
    if (params.mix_pair_count == 0u) {
        return geometric;
    }
    let ia = a._pad_island.x;
    let ib = b._pad_island.x;
    let key = vec2<u32>(min(ia, ib), max(ia, ib));
    var slot = pair_hash_mix(pair_hash_mix(key.x) ^ key.y) & (MIX_PAIR_CAP - 1u);
    for (var probe = 0u; probe < 32u; probe++) {
        let base = params.mix_pair_base_u32 + slot * 8u;
        if (scene_words[base + 4u] == 0u) {
            break;
        }
        if (scene_words[base] == key.x && scene_words[base + 1u] == key.y) {
            return bitcast<f32>(scene_words[base + 3u]);
        }
        slot = (slot + 1u) & (MIX_PAIR_CAP - 1u);
    }
    return geometric;
}

fn finish_manifold(c: ptr<function, Contact>, a: Body, b: Body, ia: u32, ib: u32) {
    let key = vec2<u32>(min(a._pad_island.x, b._pad_island.x), max(a._pad_island.x, b._pad_island.x));
    let previous = find_prev_contact_key(key, ia, ib);
    finish_manifold_from_previous(c, a, b, ia, ib, previous);
}

// Mesh piece matching selects a distinct old manifold before calling this.
// No implicit root lookup may duplicate the root's impulse into its children.
fn finish_manifold_from_previous(c: ptr<function, Contact>, a: Body, b: Body, ia: u32, ib: u32, p: Contact) {
    // Colliders are shape-origin; the solver uses body COM lever arms.
    // Packed ra.w is the COM-relative base so
    //   s = ra.w + gyro_dot3(rb.xyz - ra.xyz, n)
    // equals world separation along n:
    //   gyro_dot3((com_b + rb) - (com_a + ra), n).
    // Shifting xyz by shape-to-COM therefore subtracts the same projection
    // from ra.w so s, friction weights, and cached reconstruction stay invariant.
    // Box-face clipping supplies the original separation before solver-base
    // packing. The marker is transient; finalization writes cache validity 1.
    let has_raw_separations = (*c).cached_relative.w == 2.0;
    let raw_separations = vec4<f32>((*c).persistent_rb0.w, (*c).persistent_rb1.w,
        (*c).persistent_rb2.w, (*c).persistent_rb3.w);
    var separations = vec4<f32>(0.0);
    let com_a = load_body(ia);
    let com_b = load_body(ib);
    let da = a.pos - com_a.pos;
    let db = b.pos - com_b.pos;
    let base_shift = gyro_dot3(db - da, (*c).n);
    for (var i = 0u; i < (*c).count; i++) {
        let ra = ra_at(*c, i);
        let rb = rb_at(*c, i);
        set_point(c, i, vec4<f32>(ra.xyz + da, ra.w - base_shift), vec4<f32>(rb.xyz + db, rb.w));
    }
    let inv_tau = 1.0 / SPECULATIVE;
    var center_a = vec3<f32>(0.0);
    var center_b = vec3<f32>(0.0);
    var wsum = 0.0;
    var rel = vec4<f32>(0.0);
    for (var i = 0u; i < (*c).count; i++) {
        let ra = ra_at(*c, i);
        let rb = rb_at(*c, i);
        let s = select(ra.w + gyro_dot3(rb.xyz - ra.xyz, (*c).n), raw_separations[i], has_raw_separations);
        separations[i] = s;
        let weight = clamp(2.0 - s * inv_tau, MIN_FRICTION_WEIGHT, 1.0);
        center_a = center_a + ra.xyz * weight;
        center_b = center_b + rb.xyz * weight;
        wsum = wsum + weight;
        let vA = com_a.vel + gyro_cross(com_a.omega, ra.xyz);
        let vB = com_b.vel + gyro_cross(com_b.omega, rb.xyz);
        let vn = gyro_dot3(vB - vA, (*c).n);
        if (i == 0u) { rel.x = vn; }
        else if (i == 1u) { rel.y = vn; }
        else if (i == 2u) { rel.z = vn; }
        else { rel.w = vn; }
    }
    let inv = gyro_recip(max(wsum, MIN_FRICTION_WEIGHT));
    (*c).center_a = center_a * inv;
    (*c).center_b = center_b * inv;
    (*c)._pad_end = mixed_restitution_of(a, b);
    // Box3D contact.c: max(material) * max(shape radius).
    (*c).rolling = select(
        0.0,
        max(a.rolling, b.rolling) * max(rolling_radius(a), rolling_radius(b)),
        (params.diagnostic_flags & DIAG_DISABLE_ROLLING) == 0u,
    );
    (*c)._tail0 = vec4<u32>(bitcast<u32>(rel.x), bitcast<u32>(rel.y), bitcast<u32>(rel.z), bitcast<u32>(rel.w));
    pack_point_features(c);
    let matched = match_previous_points(*c, p);
    let jn = matched.impulses;
    (*c).lifecycle.y = ((*c).lifecycle.y & ~CONTACT_PERSISTED_MASK) | matched.persisted;
    (*c).rb0.w = jn.x;
    if ((*c).count > 1u) { (*c).rb1.w = jn.y; }
    if ((*c).count > 2u) { (*c).rb2.w = jn.z; }
    if ((*c).count > 3u) { (*c).rb3.w = jn.w; }
    if (p.a != EMPTY) {
        (*c).color = p.color;
    }
    if (p.a != EMPTY && p.count > 0u) {
        let old_t1 = perp(p.n);
        let old_t2 = gyro_cross(old_t1, p.n);
        let sign = select(-1.0, 1.0, p.a == ia && p.b == ib);
        let old_friction = sign * (old_t1 * p.friction_impulse.x + old_t2 * p.friction_impulse.y);
        let new_t1 = perp((*c).n);
        let new_t2 = gyro_cross(new_t1, (*c).n);
        (*c).friction_impulse = vec2<f32>(gyro_dot3(old_friction, new_t1), gyro_dot3(old_friction, new_t2));
        (*c).twist_impulse = p.twist_impulse;
        (*c).rolling_impulse = sign * p.rolling_impulse;
    }
    (*c).cached_relative = vec4<f32>(relative_com(com_a, com_b), 1.0);
    (*c).cached_rotation_a = com_a.rot;
    (*c).cached_rotation_b = com_b.rot;
    (*c).persistent_ra0 = (*c).ra0;
    (*c).persistent_ra1 = (*c).ra1;
    (*c).persistent_ra2 = (*c).ra2;
    (*c).persistent_ra3 = (*c).ra3;
    (*c).persistent_rb0 = vec4<f32>((*c).rb0.xyz, separations.x);
    (*c).persistent_rb1 = vec4<f32>((*c).rb1.xyz, separations.y);
    (*c).persistent_rb2 = vec4<f32>((*c).rb2.xyz, separations.z);
    (*c).persistent_rb3 = vec4<f32>((*c).rb3.xyz, separations.w);
}

// Box3D `b3ClipPolygon`: keep/intersect and stamp reference-edge feature ids.
// Refine the shader division before constructing a clipped intersection.
// A one-ulp fraction error moves endpoints on long edges by several ulps.
fn clip_divide(a: f32, b: f32) -> f32 {
    let estimate = a / b;
    let residual = fma(-estimate,b,a);
    return fma(residual,gyro_recip(b),estimate);
}

fn clip_feat(
    pts: array<vec3<f32>, 8>,
    n_in: u32,
    plane_n: vec3<f32>,
    plane_c: f32,
) -> array<vec3<f32>, 8> {
    var outp: array<vec3<f32>, 8>;
    if (n_in == 0u) {
        return outp;
    }
    var n_out = 0u;
    var prev = pts[n_in - 1u];
    var d1 = dot(prev, plane_n) - plane_c;
    for (var i = 0u; i < n_in; i++) {
        let cur = pts[i];
        let d2 = dot(cur, plane_n) - plane_c;
        if (d1 <= 0.0 && d2 <= 0.0) {
            if (n_out < 8u) {
                outp[n_out] = cur;
                n_out = n_out + 1u;
            }
        } else if (d1 <= 0.0 && d2 > 0.0) {
            let t = clip_divide(d1,d1-d2);
            if (n_out < 8u) {
                // Preserve the native clip interpolation order.
                outp[n_out] = prev + t * (cur - prev);
                n_out = n_out + 1u;
            }
        } else if (d2 <= 0.0 && d1 > 0.0) {
            let t = clip_divide(d1,d1-d2);
            if (n_out < 8u) {
                // Preserve the native clip interpolation order.
                outp[n_out] = prev + t * (cur - prev);
                n_out = n_out + 1u;
            }
            if (n_out < 8u) {
                outp[n_out] = cur;
                n_out = n_out + 1u;
            }
        }
        prev = cur;
        d1 = d2;
    }
    return outp;
}

fn clip_feat_ids(
    pts: array<vec3<f32>, 8>,
    feats: array<u32, 8>,
    n_in: u32,
    plane_n: vec3<f32>,
    plane_c: f32,
    edge: u32,
    ref_owner: u32,
) -> array<u32, 8> {
    var outf: array<u32, 8>;
    if (n_in == 0u) {
        return outf;
    }
    var n_out = 0u;
    var prev = pts[n_in - 1u];
    var prev_f = feats[n_in - 1u];
    var d1 = dot(prev, plane_n) - plane_c;
    for (var i = 0u; i < n_in; i++) {
        let cur = pts[i];
        let cur_f = feats[i];
        let d2 = dot(cur, plane_n) - plane_c;
        if (d1 <= 0.0 && d2 <= 0.0) {
            if (n_out < 8u) {
                outf[n_out] = cur_f;
                n_out = n_out + 1u;
            }
        } else if (d1 <= 0.0 && d2 > 0.0) {
            if (n_out < 8u) {
                outf[n_out] = pack_feature(
                    (cur_f >> 24u) & 1u,
                    (cur_f >> 16u) & 255u,
                    ref_owner,
                    edge,
                );
                n_out = n_out + 1u;
            }
        } else if (d2 <= 0.0 && d1 > 0.0) {
            if (n_out < 8u) {
                outf[n_out] = pack_feature(ref_owner, edge, (prev_f >> 8u) & 1u, prev_f & 255u);
                n_out = n_out + 1u;
            }
            if (n_out < 8u) {
                outf[n_out] = cur_f;
                n_out = n_out + 1u;
            }
        }
        prev = cur;
        prev_f = cur_f;
        d1 = d2;
    }
    return outf;
}

fn clip_feat_count(
    pts: array<vec3<f32>, 8>,
    n_in: u32,
    plane_n: vec3<f32>,
    plane_c: f32,
) -> u32 {
    if (n_in == 0u) {
        return 0u;
    }
    var n_out = 0u;
    var prev = pts[n_in - 1u];
    var d1 = dot(prev, plane_n) - plane_c;
    for (var i = 0u; i < n_in; i++) {
        let cur = pts[i];
        let d2 = dot(cur, plane_n) - plane_c;
        if (d1 <= 0.0 && d2 <= 0.0) {
            n_out = n_out + 1u;
        } else if (d1 <= 0.0 && d2 > 0.0) {
            n_out = n_out + 1u;
        } else if (d2 <= 0.0 && d1 > 0.0) {
            n_out = n_out + 2u;
        }
        prev = cur;
        d1 = d2;
        if (n_out >= 8u) {
            return 8u;
        }
    }
    return n_out;
}

fn add_clip_points(
    c: ptr<function, Contact>,
    a: Body,
    b: Body,
    n: vec3<f32>,
    pts: array<vec3<f32>, 8>,
    feats: array<u32, 8>,
    np: u32,
    ref_half: f32,
    flip_ids: bool,
) {
    var cand_s: array<f32, 8>;
    var cand_p: array<vec3<f32>, 8>;
    var cand_f: array<u32, 8>;
    var n_cand = 0u;
    for (var i = 0u; i < np; i++) {
        let raw = pts[i];
        var s = gyro_dot3(raw, n) - ref_half;
        // Box3D keeps every clipped vertex; the manifold is rejected only if
        // min separation ≥ speculative (see `b3BuildFaceAContact`).
        cand_s[n_cand] = s;
        cand_p[n_cand] = raw - 0.5 * s * n;
        var fid = feats[i];
        if (flip_ids) {
            fid = flip_feature(fid);
        }
        cand_f[n_cand] = fid;
        n_cand = n_cand + 1u;
        if (n_cand == 8u) {
            break;
        }
    }
    if (n_cand == 0u) {
        (*c).count = 0u;
        return;
    }
    var min_s = cand_s[0];
    for (var i = 1u; i < n_cand; i++) {
        min_s = min(min_s, cand_s[i]);
    }
    if (min_s >= SPECULATIVE) {
        (*c).count = 0u;
        return;
    }
    var pick_s: array<f32, 4>;
    var pick_p: array<vec3<f32>, 4>;
    var pick_f: array<u32, 4>;
    var n_pick = 0u;
    if (n_cand <= 4u) {
        for (var i = 0u; i < n_cand; i++) {
            pick_s[i] = cand_s[i];
            pick_p[i] = cand_p[i];
            pick_f[i] = cand_f[i];
        }
        n_pick = n_cand;
    } else {
        // Box3D `b3ArbitraryPerp`: preserve its branch constants and operation
        // order because this direction decides which four face points survive.
        var search: vec3<f32>;
        if (n.x < -0.5 || n.x > 0.5) {
            search = vec3<f32>(0.67 * n.y - 0.42 * n.z, -0.67 * n.x, 0.42 * n.x);
        } else if (n.y < -0.5 || n.y > 0.5) {
            search = vec3<f32>(0.67 * n.y, -0.67 * n.x - 0.42 * n.z, 0.42 * n.y);
        } else {
            search = vec3<f32>(0.67 * n.z, -0.42 * n.z, -0.67 * n.x + 0.42 * n.y);
        }
        search = normalize(search);
        let bias = 0.95;
        let tol_sqr = SPECULATIVE * SPECULATIVE;
        var best = EMPTY;
        var best_score = -1e9;
        for (var i = 0u; i < n_cand; i++) {
            if (cand_s[i] > SPECULATIVE) { continue; }
            let score = -cand_s[i] + gyro_dot3(search, cand_p[i]);
            if (bias * score > best_score) {
                best_score = score;
                best = i;
            }
        }
        if (best == EMPTY) {
            (*c).count = 0u;
            return;
        }
        pick_s[0] = cand_s[best];
        pick_p[0] = cand_p[best];
        pick_f[0] = cand_f[best];
        n_pick = 1u;
        let pa = pick_p[0];
        n_cand = n_cand - 1u;
        cand_s[best] = cand_s[n_cand];
        cand_p[best] = cand_p[n_cand];
        cand_f[best] = cand_f[n_cand];
        best = EMPTY;
        best_score = 0.0;
        for (var i = 0u; i < n_cand; i++) {
            let d = cand_p[i] - pa;
            let v = d - n * gyro_dot3(d, n);
            let d2 = gyro_dot3(v, v);
            let sep = max(0.0, -cand_s[i]);
            let score = d2 + 4.0 * sep * sep;
            if (bias * score > best_score) {
                best_score = score;
                best = i;
            }
        }
        if (best != EMPTY && best_score >= tol_sqr) {
            pick_s[1] = cand_s[best];
            pick_p[1] = cand_p[best];
            pick_f[1] = cand_f[best];
            n_pick = 2u;
            let pb = pick_p[1];
            n_cand = n_cand - 1u;
            cand_s[best] = cand_s[n_cand];
            cand_p[best] = cand_p[n_cand];
            cand_f[best] = cand_f[n_cand];
            let ba = pb - pa;
            best = EMPTY;
            best_score = tol_sqr;
            var best_area = 0.0;
            for (var i = 0u; i < n_cand; i++) {
                let area = gyro_dot3(n, gyro_cross(ba, cand_p[i] - pa));
                let score = abs(area);
                if (bias * score >= best_score) {
                    best_score = score;
                    best = i;
                    best_area = area;
                }
            }
            if (best != EMPTY) {
                pick_s[2] = cand_s[best];
                pick_p[2] = cand_p[best];
                pick_f[2] = cand_f[best];
                n_pick = 3u;
                let pc = pick_p[2];
                n_cand = n_cand - 1u;
                cand_s[best] = cand_s[n_cand];
                cand_p[best] = cand_p[n_cand];
                cand_f[best] = cand_f[n_cand];
                let sgn = select(1.0, -1.0, best_area < 0.0);
                best = EMPTY;
                best_score = tol_sqr;
                for (var i = 0u; i < n_cand; i++) {
                    let p = cand_p[i];
                    let u1 = sgn * gyro_dot3(n, gyro_cross(p - pa, ba));
                    let u2 = sgn * gyro_dot3(n, gyro_cross(p - pb, pc - pb));
                    let u3 = sgn * gyro_dot3(n, gyro_cross(p - pc, pa - pc));
                    let score = max(u1, max(u2, u3));
                    if (bias * score > best_score) {
                        best_score = score;
                        best = i;
                    }
                }
                if (best != EMPTY) {
                    pick_s[3] = cand_s[best];
                    pick_p[3] = cand_p[best];
                    pick_f[3] = cand_f[best];
                    n_pick = 4u;
                }
            }
        }
    }
    for (var i = 0u; i < n_pick; i++) {
        let s = pick_s[i];
        var point_a = pick_p[i];
        if (flip_ids) {
            let relative_q = box_relative_rotation(a.rot, b.rot);
            let relative_p = quat_inv_rotate(a.rot, b.pos - a.pos);
            point_a = recycle_rotate(relative_q, point_a) + relative_p;
        }
        let rA = recycle_rotate(a.rot, point_a);
        let rB = rA + (a.pos - b.pos);
        // Offset is along the manifold normal (`c.n` = A→B), not the clip plane.
        let base = s - gyro_dot3(rB - rA, (*c).n);
        set_point(c, i, vec4<f32>(rA, base), vec4<f32>(rB, 0.0));
        set_feat_at(c, i, pick_f[i]);
        if (i == 0u) { (*c).persistent_rb0.w = s; }
        else if (i == 1u) { (*c).persistent_rb1.w = s; }
        else if (i == 2u) { (*c).persistent_rb2.w = s; }
        else { (*c).persistent_rb3.w = s; }

    }
    (*c).count = n_pick;
    (*c).cached_relative.w = 2.0;
}

fn box_relative_rotation(a: vec4<f32>, b: vec4<f32>) -> vec4<f32> {
    let t1 = gyro_cross(b.xyz, a.xyz);
    let t2 = t1 + a.w * b.xyz;
    return vec4<f32>(t2 - b.w * a.xyz, a.w * b.w + gyro_dot3(a.xyz, b.xyz));
}

fn clip_box_face(a: Body, b: Body, ia: u32, ib: u32, best_kind: u32, best_face: u32, best_n: vec3<f32>) -> Contact {
    var c = empty_contact();
    c.a = ia;
    c.b = ib;
    c.friction = mixed_friction_of(a, b);
    c.n = best_n;

    var incident_body = b;
    var incident_face = 0u;
    var inc_edges: array<u32, 4>;
    var ref_edges: array<u32, 4>;
    var ref_body = a;
    var ref_n = best_n;
    var inc_owner = 1u;
    var ref_owner = 0u;
    var ref_half = 0.0;
    if (best_kind == 0u) {
        let sup = box_support_vertex(b, -best_n);
        let inc_face = find_incident_face(b, best_n, sup);
        incident_body = b;
        incident_face = inc_face;
        inc_edges = hull_face_edge_ids(inc_face);
        ref_edges = hull_face_edge_ids(best_face);
        ref_body = a;
        ref_n = hull_face_n(a, best_face);
        if (dot(ref_n, best_n) < 0.0) {
            ref_n = -ref_n;
        }
        ref_half = hull_face_half(a, best_face);
        inc_owner = 1u;
        ref_owner = 0u;
    } else {
        let sup = box_support_vertex(a, best_n);
        let inc_face = find_incident_face(a, -best_n, sup);
        incident_body = a;
        incident_face = inc_face;
        inc_edges = hull_face_edge_ids(inc_face);
        ref_edges = hull_face_edge_ids(best_face);
        ref_body = b;
        ref_n = hull_face_n(b, best_face);
        if (dot(ref_n, -best_n) < 0.0) {
            ref_n = -ref_n;
        }
        ref_half = hull_face_half(b, best_face);
        // Box3D builds face-B by swapping the hulls, running the face-A
        // builder (incident features are shape B, reference features shape A),
        // then flipping the completed feature pair back to the original order.
        inc_owner = 1u;
        ref_owner = 0u;
    }

    var poly: array<vec3<f32>, 8>;
    var feats: array<u32, 8>;
    // Box3D clips in the reference hull's local frame so a box face is an exact
    // rectangle. World-space clipping shears that square as soon as either box
    // has a tiny rotation, which is what walks a column.
    let b_to_a_q = box_relative_rotation(a.rot, b.rot);
    let b_to_a_p = quat_inv_rotate(a.rot, b.pos - a.pos);
    // Native face manifolds transform the local plane normal without
    // renormalizing it. Preserve the same two transforms for face B.
    var normal_a = BOX_FACE_N[best_face];
    if (best_kind != 0u) { normal_a = -recycle_rotate(b_to_a_q, normal_a); }
    c.n = recycle_rotate(a.rot, normal_a);

    var incident_q = b_to_a_q;
    var incident_p = b_to_a_p;
    if (best_kind != 0u) {
        incident_q = quat_inv(b_to_a_q);
        incident_p = quat_inv_rotate(b_to_a_q, -b_to_a_p);
    }
    var incident_edge = BOX_FACE_EDGE[incident_face];
    for (var i = 0u; i < 4u; i++) {
        let next = BOX_EDGE_NEXT[incident_edge];
        let point = box_point_local(incident_body, BOX_EDGE_ORIGIN[next]);
        poly[i] = recycle_rotate(incident_q, point) + incident_p;
        incident_edge = next;
    }
    feats[0] = pack_feature(inc_owner, inc_edges[0], inc_owner, inc_edges[1]);
    feats[1] = pack_feature(inc_owner, inc_edges[1], inc_owner, inc_edges[2]);
    feats[2] = pack_feature(inc_owner, inc_edges[2], inc_owner, inc_edges[3]);
    feats[3] = pack_feature(inc_owner, inc_edges[3], inc_owner, inc_edges[0]);
    var np = 4u;
    let ref_n_local = BOX_FACE_N[best_face];
    for (var p = 0u; p < 4u; p++) {
        let e = ref_edges[p];
        let v1 = box_point_local(ref_body, BOX_EDGE_ORIGIN[e]);
        let v2 = box_point_local(ref_body, BOX_EDGE_ORIGIN[BOX_EDGE_NEXT[e]]);
        var tangent = v2 - v1;
        let tl = length(tangent);
        if (tl < 1e-12) {
            continue;
        }
        tangent = tangent / tl;
        let binormal = cross(tangent, ref_n_local);
        let plane_c = dot(v1, binormal);
        let next_f = clip_feat_ids(poly, feats, np, binormal, plane_c, e, ref_owner);
        let next = clip_feat(poly, np, binormal, plane_c);
        np = clip_feat_count(poly, np, binormal, plane_c);
        poly = next;
        feats = next_f;
        if (np < 3u) {
            c.a = EMPTY;
            return c;
        }
    }
    add_clip_points(&c, a, b, ref_n_local, poly, feats, np, ref_half, best_kind != 0u);
    if (c.count == 0u) {
        c.a = EMPTY;
    }
    return c;
}

fn try_cached_face(a: Body, b: Body, ia: u32, ib: u32) -> Contact {
    let p = find_prev_contact(ia, ib);
    if (p.a == EMPTY) {
        return empty_contact();
    }
    let typ = sat_type(p._tail1.x);
    var kind = 0u;
    var face = sat_index_a(p._tail1.x);
    var n = vec3<f32>(0.0);
    if (typ == SAT_FACE_A) {
        if (face > 5u) {
            return empty_contact();
        }
        n = box_face_n(a, face);
        kind = 0u;
    } else if (typ == SAT_FACE_B) {
        face = sat_index_b(p._tail1.x);
        if (face > 5u) {
            return empty_contact();
        }
        n = -box_face_n(b, face);
        kind = 1u;
    } else {
        return empty_contact();
    }
    var c = clip_box_face(a, b, ia, ib, kind, face, n);
    if (c.a == EMPTY || c.count == 0u) {
        return empty_contact();
    }
    if (manifold_min_sep(c) >= SPECULATIVE) {
        return empty_contact();
    }
    let cache_sep = bitcast<f32>(p._tail1.y);
    if (abs(manifold_min_sep(c) - cache_sep) >= LINEAR_SLOP) {
        return empty_contact();
    }
    // A cache hit retains the original SAT baseline, as b3BuildFace*Contact's
    // localCache does. Rebasing on each hit admits unlimited incremental drift
    // and can keep a tilted box face instead of switching to its support plane.
    c._tail1.x = p._tail1.x;
    c._tail1.y = p._tail1.y;
    finish_manifold(&c, a, b, ia, ib);
    return c;
}

fn collide_boxes(a: Body, b: Body, ia: u32, ib: u32) -> Contact {
    if ((params.diagnostic_flags & DIAG_DISABLE_SAT_CACHE) == 0u) {
        let cached = try_cached_face(a, b, ia, ib);
        if (cached.a != EMPTY) {
            return cached;
        }
    }
    var c = empty_contact();
    c.a = ia;
    c.b = ib;
    c.friction = mixed_friction_of(a, b);

    var sep_a = -1e9;
    var face_a = 0u;
    var n_a = vec3<f32>(0.0, 1.0, 0.0);
    for (var f = 0u; f < 6u; f++) {
        let sep = hull_face_sep(a, b, f);
        if (sep >= SPECULATIVE) {
            c.a = EMPTY;
            return c;
        }
        if (sep > sep_a) {
            sep_a = sep;
            face_a = f;
            n_a = box_face_n(a, f);
        }
    }
    var sep_b = -1e9;
    var face_b = 0u;
    var n_b = vec3<f32>(0.0, 1.0, 0.0);
    for (var f = 0u; f < 6u; f++) {
        let sep = hull_face_sep(b, a, f);
        if (sep >= SPECULATIVE) {
            c.a = EMPTY;
            return c;
        }
        if (sep > sep_b) {
            sep_b = sep;
            face_b = f;
            n_b = -box_face_n(b, f);
        }
    }
    // Box3D: face A only if it has strictly greater separation (tie → B).
    var best_kind = 0u;
    var best_n = n_a;
    var best_face = face_a;
    if (sep_a <= sep_b) {
        best_kind = 1u;
        best_n = n_b;
        best_face = face_b;
    }

    let eq = gauss_edge_query(a, b);
    // The cold SAT query may early-out on a valid separating edge, matching
    // `b3ComputeSeparatingAxis(..., earlyReturn=true)`. Cached face validation
    // deliberately does not repeat this test.
    if (eq.index_a != EMPTY && eq.sep >= SPECULATIVE) {
        c.a = EMPTY;
        return c;
    }
    c = clip_box_face(a, b, ia, ib, best_kind, best_face, best_n);
    let clip_sep = select(-1e9, manifold_min_sep(c), c.a != EMPTY && c.count > 0u);
    // Box3D replaces a face manifold when the edge axis is better by one slop.
    let want_edge =
        eq.index_a != EMPTY
        && (c.a == EMPTY || c.count == 0u || eq.sep > clip_sep + LINEAR_SLOP);
    if (want_edge) {
        let ea = eq.index_a;
        let eb = eq.index_b;
        let pA0 = box_point(a, BOX_EDGE_ORIGIN[ea]);
        let pA1 = box_point(a, BOX_EDGE_ORIGIN[BOX_EDGE_TWIN[ea]]);
        let pB0 = box_point(b, BOX_EDGE_ORIGIN[eb]);
        let pB1 = box_point(b, BOX_EDGE_ORIGIN[BOX_EDGE_TWIN[eb]]);
        let dA = pA1 - pA0;
        let dB = pB1 - pB0;
        let st = closest_segments(pA0, dA, pB0, dB);
        if (st.x >= 0.0 && st.x <= 1.0 && st.y >= 0.0 && st.y <= 1.0) {
            let q1 = pA0 + st.x * dA;
            let q2 = pB0 + st.y * dB;
            var n_edge = quat_rotate(a.rot, eq.n);
            let nl = length(n_edge);
            if (nl > 1e-8) {
                n_edge = n_edge / nl;
            }
            let p = 0.5 * (q1 + q2);
            let s = dot(n_edge, q2 - q1);
            var edge_c = empty_contact();
            edge_c.a = ia;
            edge_c.b = ib;
            edge_c.friction = mixed_friction_of(a, b);
            edge_c.n = n_edge;
            edge_c.count = 1u;
            let rA = p - a.pos;
            let rB = p - b.pos;
            let base = s - dot(rB - rA, n_edge);
            set_point(&edge_c, 0u, vec4<f32>(rA, base), vec4<f32>(rB, 0.0));
            set_feat_at(&edge_c, 0u, pack_feature(0u, ea, 1u, eb));
            write_sat_cache(&edge_c, SAT_EDGE, ea, eb);
            c = edge_c;
        }
    } else if (c.a != EMPTY) {
        let typ = select(SAT_FACE_A, SAT_FACE_B, best_kind == 1u);
        if (best_kind == 0u) {
            write_sat_cache(&c, typ, best_face, box_support_vertex(b, -best_n));
        } else {
            write_sat_cache(&c, typ, box_support_vertex(a, best_n), best_face);
        }
    }
    if (c.a == EMPTY || c.count == 0u) {
        c.a = EMPTY;
        return c;
    }
    finish_manifold(&c, a, b, ia, ib);
    return c;
}

struct Seg2 {
    p0: vec3<f32>,
    p1: vec3<f32>,
    n: u32,
}

fn clip_seg(s: Seg2, plane_n: vec3<f32>, plane_c: f32) -> Seg2 {
    var outp: Seg2;
    outp.n = 0u;
    if (s.n < 2u) {
        return outp;
    }
    let d1 = dot(s.p0, plane_n) - plane_c;
    let d2 = dot(s.p1, plane_n) - plane_c;
    if (d1 <= 0.0) {
        outp.p0 = s.p0;
        outp.n = 1u;
    }
    if (d2 <= 0.0) {
        if (outp.n == 0u) {
            outp.p0 = s.p1;
        } else {
            outp.p1 = s.p1;
        }
        outp.n = outp.n + 1u;
    }
    if (d1 * d2 < 0.0) {
        let t = clip_divide(d1,d1-d2);
        let hit = mix(s.p0, s.p1, t);
        if (outp.n == 0u) {
            outp.p0 = hit;
        } else if (outp.n == 1u) {
            outp.p1 = hit;
        }
        outp.n = min(outp.n + 1u, 2u);
    }
    return outp;
}

fn clip_seg_to_hull_face(hull: Body, face: u32, p0: vec3<f32>, p1: vec3<f32>) -> Seg2 {
    var s: Seg2;
    s.p0 = p0;
    s.p1 = p1;
    s.n = 2u;
    let ref_n = hull_face_n(hull, face);
    let edges = hull_face_edge_ids(face);
    for (var i = 0u; i < 4u; i++) {
        let e = edges[i];
        let v1 = box_point(hull, BOX_EDGE_ORIGIN[e]);
        let v2 = box_point(hull, BOX_EDGE_ORIGIN[BOX_EDGE_NEXT[e]]);
        var tangent = v2 - v1;
        let tl = length(tangent);
        if (tl < 1e-12) {
            continue;
        }
        tangent = tangent / tl;
        let binormal = cross(tangent, ref_n);
        s = clip_seg(s, binormal, dot(v1, binormal));
        if (s.n < 2u) {
            return s;
        }
    }
    return s;
}

fn hull_capsule_face_sep(hull: Body, cap: Body, face: u32) -> f32 {
    let n = hull_face_n(hull, face);
    let plane_c = dot(hull.pos, n) + hull_face_half(hull, face);
    let ax = capsule_axis(cap);
    return min(dot(cap.pos - ax, n), dot(cap.pos + ax, n)) - plane_c;
}

fn add_sep_point(c: ptr<function, Contact>, a: Body, b: Body, n: vec3<f32>, p: vec3<f32>, s: f32, i: u32) {
    let rA = p - a.pos;
    let rB = p - b.pos;
    let base = s - dot(rB - rA, n);
    set_point(c, i, vec4<f32>(rA, base), vec4<f32>(rB, 0.0));
}

fn collide_capsules(a: Body, b: Body, ia: u32, ib: u32) -> Contact {
    var c = empty_contact();
    let ax = capsule_axis(a);
    let bx = capsule_axis(b);
    let a0 = a.pos - ax;
    let a1 = a.pos + ax;
    let b0 = b.pos - bx;
    let b1 = b.pos + bx;
    let da = a1 - a0;
    let db = b1 - b0;
    let st = closest_segments(a0, da, b0, db);
    let pA = a0 + st.x * da;
    let pB = b0 + st.y * db;
    let offset = pB - pA;
    let dist2 = dot(offset, offset);
    let radius = a.half.x + b.half.x;
    let max_d = radius + SPECULATIVE;
    if (dist2 > max_d * max_d) {
        return c;
    }
    let min_d = 0.01 * LINEAR_SLOP;
    if (dist2 < min_d * min_d) {
        return c;
    }
    let la = length(da);
    let lb = length(db);
    if (la < 1e-4 || lb < 1e-4) {
        return c;
    }
    let eA = da / la;
    let eB = db / lb;
    let cr = cross(eA, eB);
    c.a = ia;
    c.b = ib;
    c.friction = mixed_friction_of(a, b);
    if (dot(cr, cr) < 0.0025) {
        var seg: Seg2;
        seg.p0 = b0;
        seg.p1 = b1;
        seg.n = 2u;
        seg = clip_seg(seg, -eA, -dot(eA, a0));
        if (seg.n == 2u) {
            seg = clip_seg(seg, eA, dot(eA, a1));
        }
        if (seg.n == 2u) {
            let q0 = a0 + eA * clamp(dot(seg.p0 - a0, eA), 0.0, la);
            let q1 = a0 + eA * clamp(dot(seg.p1 - a0, eA), 0.0, la);
            let d0 = length(seg.p0 - q0);
            let d1 = length(seg.p1 - q1);
            if (d0 <= radius && d1 <= radius && d0 >= min_d && d1 >= min_d) {
                let n0 = (seg.p0 - q0) / d0;
                let n1 = (seg.p1 - q1) / d1;
                var n = n0 + n1;
                let nl = length(n);
                if (nl > 1e-8) {
                    n = n / nl;
                } else {
                    n = n0;
                }
                c.n = n;
                c.count = 2u;
                let p0 = 0.5 * ((seg.p0 + n0 * a.half.x + q0) - n * b.half.x);
                let p1 = 0.5 * ((seg.p1 + n1 * a.half.x + q1) - n * b.half.x);
                add_sep_point(&c, a, b, n, p0, d0 - radius, 0u);
                add_sep_point(&c, a, b, n, p1, d1 - radius, 1u);
                finish_manifold(&c, a, b, ia, ib);
                return c;
            }
        }
    }
    var dist = sqrt(dist2);
    var n = offset / dist;
    c.n = n;
    c.count = 1u;
    let p = 0.5 * ((pA + n * a.half.x + pB) - n * b.half.x);
    add_sep_point(&c, a, b, n, p, dist - radius, 0u);
    finish_manifold(&c, a, b, ia, ib);
    return c;
}

fn collide_capsule_box(cap: Body, hull: Body, ic: u32, ih: u32) -> Contact {
    var c = empty_contact();
    let rad = cap.half.x;
    var best_sep = -1e9;
    var best_face = 0u;
    for (var f = 0u; f < 6u; f++) {
        let sep = hull_capsule_face_sep(hull, cap, f);
        if (sep > rad + SPECULATIVE) {
            return c;
        }
        if (sep > best_sep) {
            best_sep = sep;
            best_face = f;
        }
    }
    let ax = capsule_axis(cap);
    let p0 = cap.pos - ax;
    let p1 = cap.pos + ax;
    let seg = clip_seg_to_hull_face(hull, best_face, p0, p1);
    let hn = hull_face_n(hull, best_face);
    let plane_c = dot(hull.pos, hn) + hull_face_half(hull, best_face);
    let n = -hn;
    c.a = ic;
    c.b = ih;
    c.friction = mixed_friction_of(cap, hull);
    if (seg.n == 2u) {
        let s0 = (dot(seg.p0, hn) - plane_c) - rad;
        let s1 = (dot(seg.p1, hn) - plane_c) - rad;
        if (s0 < SPECULATIVE || s1 < SPECULATIVE) {
            c.n = n;
            c.count = 2u;
            let q0 = seg.p0 - 0.5 * (s0 + 2.0 * rad) * hn;
            let q1 = seg.p1 - 0.5 * (s1 + 2.0 * rad) * hn;
            add_sep_point(&c, cap, hull, n, q0, s0, 0u);
            add_sep_point(&c, cap, hull, n, q1, s1, 1u);
            finish_manifold(&c, cap, hull, ic, ih);
            return c;
        }
    }
    let closest = closest_on_obb(cap.pos, hull);
    let mid = closest_on_segment(closest, p0, p1);
    let delta = mid - closest;
    let dist = length(delta);
    if (dist > 1e-8 && dist < rad + SPECULATIVE) {
        var nn = delta / dist;
        if (dot(hull.pos - cap.pos, nn) < 0.0) {
            nn = -nn;
        }
        c.n = nn;
        c.count = 1u;
        add_sep_point(&c, cap, hull, nn, closest, dist - rad, 0u);
        finish_manifold(&c, cap, hull, ic, ih);
        return c;
    }
    return empty_contact();
}

fn project_collider(shape: Shape, body: Body, axis: vec3<f32>) -> vec2<f32> {
    if (body.kind == KIND_CONVEX_HULL) {
        var lo = 1e30;
        var hi = -1e30;
        let count = hull_point_count(shape);
        for (var i = 0u; i < count; i++) {
            let local = load_hull_point(shape, i) - shape.local_center;
            let value = dot(body.pos + quat_rotate(body.rot, local), axis);
            lo = min(lo, value);
            hi = max(hi, value);
        }
        return vec2<f32>(lo, hi);
    }
    if (body.kind == KIND_SPHERE) {
        let center = dot(body.pos, axis);
        return vec2<f32>(center - body.half.x, center + body.half.x);
    }
    if (body.kind == KIND_CAPSULE) {
        let extent = abs(dot(capsule_axis(body), axis)) + body.half.x;
        let center = dot(body.pos, axis);
        return vec2<f32>(center - extent, center + extent);
    }
    let extent = abs(dot(box_axis(body, 0u), axis)) * body.half.x
        + abs(dot(box_axis(body, 1u), axis)) * body.half.y
        + abs(dot(box_axis(body, 2u), axis)) * body.half.z;
    let center = dot(body.pos, axis);
    return vec2<f32>(center - extent, center + extent);
}

fn support_collider(shape: Shape, body: Body, direction: vec3<f32>) -> vec3<f32> {
    if (body.kind == KIND_CONVEX_HULL) {
        var point = body.pos;
        var best = -1e30;
        let count = hull_point_count(shape);
        for (var i = 0u; i < count; i++) {
            let local = load_hull_point(shape, i) - shape.local_center;
            let world = body.pos + quat_rotate(body.rot, local);
            let value = dot(world, direction);
            if (value > best) {
                best = value;
                point = world;
            }
        }
        return point;
    }
    if (body.kind == KIND_SPHERE) {
        return body.pos + normalize(direction) * body.half.x;
    }
    if (body.kind == KIND_CAPSULE) {
        let half_axis = capsule_axis(body);
        let end = select(-half_axis, half_axis, dot(half_axis, direction) >= 0.0);
        return body.pos + end + normalize(direction) * body.half.x;
    }
    return body.pos
        + box_axis(body, 0u) * select(-body.half.x, body.half.x, dot(box_axis(body, 0u), direction) >= 0.0)
        + box_axis(body, 1u) * select(-body.half.y, body.half.y, dot(box_axis(body, 1u), direction) >= 0.0)
        + box_axis(body, 2u) * select(-body.half.z, body.half.z, dot(box_axis(body, 2u), direction) >= 0.0);
}

fn test_convex_axis(
    shape_a: Shape,
    shape_b: Shape,
    a: Body,
    b: Body,
    candidate: vec3<f32>,
    best_separation: ptr<function, f32>,
    best_normal: ptr<function, vec3<f32>>,
) -> bool {
    if (dot(candidate, candidate) < 1e-12) {
        return true;
    }
    var axis = normalize(candidate);
    if (dot(b.pos - a.pos, axis) < 0.0) {
        axis = -axis;
    }
    let pa = project_collider(shape_a, a, axis);
    let pb = project_collider(shape_b, b, axis);
    let separation = pb.x - pa.y;
    if (separation > SPECULATIVE) {
        return false;
    }
    if (separation > (*best_separation)) {
        (*best_separation) = separation;
        (*best_normal) = axis;
    }
    return true;
}

fn point_inside_collider(shape: Shape, body: Body, point: vec3<f32>, slop: f32) -> bool {
    if (body.kind == KIND_CONVEX_HULL) {
        let local = quat_inv_rotate(body.rot, point - body.pos) + shape.local_center;
        for (var i = 0u; i < hull_plane_count(shape); i++) {
            let plane = load_hull_plane(shape, i);
            if (dot(plane.xyz, local) - plane.w > slop) {
                return false;
            }
        }
        return true;
    }
    if (body.kind == KIND_BOX) {
        let local = quat_inv_rotate(body.rot, point - body.pos);
        return all(abs(local) <= body.half + vec3<f32>(slop));
    }
    if (body.kind == KIND_SPHERE) {
        let d = point - body.pos;
        return dot(d, d) <= (body.half.x + slop) * (body.half.x + slop);
    }
    let axis = capsule_axis(body);
    let closest = closest_on_segment(point, body.pos - axis, body.pos + axis);
    let d = point - closest;
    return dot(d, d) <= (body.half.x + slop) * (body.half.x + slop);
}

fn consider_convex_manifold_point(
    point: vec3<f32>,
    tangent1: vec3<f32>,
    tangent2: vec3<f32>,
    points: ptr<function, array<vec3<f32>, 4>>,
    scores: ptr<function, vec4<f32>>,
    valid: ptr<function, vec4<bool>>,
) {
    let values = vec4<f32>(
        dot(point, tangent1),
        -dot(point, tangent1),
        dot(point, tangent2),
        -dot(point, tangent2),
    );
    for (var i = 0u; i < 4u; i++) {
        if (!(*valid)[i] || values[i] > (*scores)[i]) {
            (*scores)[i] = values[i];
            (*points)[i] = point;
            (*valid)[i] = true;
        }
    }
}

struct ClipPolygon {
    points: array<vec3<f32>, 32>,
    features: array<u32, 32>,
    count: u32,
}

fn clip_polygon(input: ClipPolygon, plane_normal: vec3<f32>, plane_offset: f32) -> ClipPolygon {
    return clip_polygon_with_features(input, plane_normal, plane_offset, EMPTY, 0u);
}

fn clip_polygon_with_features(input: ClipPolygon, plane_normal: vec3<f32>, plane_offset: f32, edge: u32, ref_owner: u32) -> ClipPolygon {
    var output: ClipPolygon;
    output.count = 0u;
    if (input.count == 0u) {
        return output;
    }
    var previous = input.points[input.count - 1u];
    var previous_distance = dot(previous, plane_normal) - plane_offset;
    var previous_feature = input.features[input.count - 1u];
    // Preserve the existing generic clip tolerance; feature clips follow CPU planes.
    let tolerance = select(0.0, 1e-6, edge == EMPTY);
    for (var i = 0u; i < input.count; i++) {
        let current = input.points[i];
        let current_distance = dot(current, plane_normal) - plane_offset;
        let current_feature = input.features[i];
        if ((previous_distance <= tolerance) != (current_distance <= tolerance)) {
            let t = clip_divide(previous_distance,previous_distance-current_distance);
            if (output.count < 32u) {
                // Match b3ClipPolygon: weighted endpoints round differently.
                output.points[output.count] = previous + t * (current - previous);
                var feature = 0u;
                if (edge != EMPTY) {
                    if (previous_distance <= tolerance) {
                        feature = pack_feature((current_feature >> 24u) & 1u, (current_feature >> 16u) & 255u, ref_owner, edge);
                    } else {
                        feature = pack_feature(ref_owner, edge, (previous_feature >> 8u) & 1u, previous_feature & 255u);
                    }
                }
                output.features[output.count] = feature;
                output.count = output.count + 1u;
            }
        }
        if (current_distance <= tolerance && output.count < 32u) {
            output.points[output.count] = current;
            output.features[output.count] = current_feature;
            output.count = output.count + 1u;
        }
        previous = current;
        previous_feature = current_feature;
        previous_distance = current_distance;
    }
    return output;
}

fn find_face_edge(shape: Shape, face: u32) -> u32 {
    for (var i = 0u; i < hull_topology_count(shape); i++) {
        if (load_hull_topology(shape, i).w == face) {
            return i;
        }
    }
    return EMPTY;
}

fn hull_reduction_perp(v: vec3<f32>) -> vec3<f32> {
    if (abs(v.x) > 0.5) { return normalize(vec3<f32>(0.67*v.y - 0.42*v.z, -0.67*v.x, 0.42*v.x)); }
    if (abs(v.y) > 0.5) { return normalize(vec3<f32>(0.67*v.y, -0.67*v.x - 0.42*v.z, 0.42*v.y)); }
    return normalize(vec3<f32>(0.67*v.z, -0.42*v.z, -0.67*v.x + 0.42*v.y));
}

// Box3D's face-manifold reduction: preserve small polygons, otherwise retain
// an extreme touching point, a distant point, and points that expand the area.
// Score in the reference body's local frame, as the CPU does.
fn reduce_hull_polygon(polygon: ClipPolygon, body: Body, normal: vec3<f32>, reference_point: vec3<f32>) -> vec4<u32> {
    var chosen = vec4<u32>(EMPTY);
    var points: array<vec4<f32>, 32>;
    var remaining: array<u32, 32>;
    let local_normal = quat_rotate(quat_inv(body.rot), normal);
    for (var i = 0u; i < polygon.count; i++) {
        let separation = dot(polygon.points[i] - reference_point, normal);
        let midpoint = polygon.points[i] - 0.5 * separation * normal;
        points[i] = vec4<f32>(quat_rotate(quat_inv(body.rot), midpoint - body.pos), separation);
        remaining[i] = i;
    }
    if (polygon.count <= 4u) {
        for (var i = 0u; i < polygon.count; i++) { chosen[i] = i; }
        return chosen;
    }
    var count = polygon.count;
    let tol = SPECULATIVE * SPECULATIVE;
    let bias = 0.95;
    var signed_area = 0.0;
    for (var stage = 0u; stage < 4u; stage++) {
        var best = EMPTY;
        var best_score = select(select(tol, 0.0, stage == 1u), -1e30, stage == 0u);
        for (var i = 0u; i < count; i++) {
            let point = points[remaining[i]];
            var score = 0.0;
            var area = 0.0;
            if (stage == 0u) {
                if (point.w > SPECULATIVE) { continue; }
                score = -point.w + dot(hull_reduction_perp(local_normal), point.xyz);
            } else {
                let a = points[chosen[0]].xyz;
                let d = point.xyz - a;
                if (stage == 1u) {
                    let v = d - dot(d, local_normal) * local_normal;
                    let depth = max(0.0, -point.w);
                    score = dot(v, v) + 4.0 * depth * depth;
                } else {
                    let b = points[chosen[1]].xyz;
                    let ba = b - a;
                    if (stage == 2u) {
                        area = dot(local_normal, cross(ba, d));
                        score = abs(area);
                    } else {
                        let c = points[chosen[2]].xyz;
                        let sign = select(1.0, -1.0, signed_area < 0.0);
                        let u1 = sign * dot(local_normal, cross(d, ba));
                        let u2 = sign * dot(local_normal, cross(point.xyz - b, c - b));
                        let u3 = sign * dot(local_normal, cross(point.xyz - c, a - c));
                        score = max(u1, max(u2, u3));
                    }
                }
            }
            if (bias * score > best_score || (stage == 2u && bias * score == best_score)) {
                best_score = score;
                best = i;
                if (stage == 2u) { signed_area = area; }
            }
        }
        if (best == EMPTY || (stage == 1u && best_score < tol)) { break; }
        chosen[stage] = remaining[best];
        count = count - 1u;
        remaining[best] = remaining[count];
    }
    return chosen;
}

fn clipped_hull_manifold(
    shape_a: Shape,
    shape_b: Shape,
    a: Body,
    b: Body,
    ia: u32,
    ib: u32,
    reference_is_b: bool,
    reference_face: u32,
) -> Contact {
    var reference_shape = shape_a;
    var incident_shape = shape_b;
    var reference_body = a;
    var incident_body = b;
    if (reference_is_b) {
        reference_shape = shape_b;
        incident_shape = shape_a;
        reference_body = b;
        incident_body = a;
    }

    let reference_plane = load_hull_plane(reference_shape, reference_face);
    let reference_normal = quat_rotate(reference_body.rot, reference_plane.xyz);
    var incident_face = 0u;
    var incident_alignment = 1e30;
    for (var i = 0u; i < hull_plane_count(incident_shape); i++) {
        let candidate = quat_rotate(incident_body.rot, load_hull_plane(incident_shape, i).xyz);
        let alignment = dot(candidate, reference_normal);
        if (alignment < incident_alignment) {
            incident_alignment = alignment;
            incident_face = i;
        }
    }

    let reference_start = find_face_edge(reference_shape, reference_face);
    let incident_start = find_face_edge(incident_shape, incident_face);
    if (reference_start == EMPTY || incident_start == EMPTY) {
        return empty_contact();
    }

    var polygon: ClipPolygon;
    polygon.count = 0u;
    var edge = incident_start;
    for (var i = 0u; i < 32u; i++) {
        let topology = load_hull_topology(incident_shape, edge);
        let local = load_hull_point(incident_shape, topology.z) - incident_shape.local_center;
        polygon.points[polygon.count] = incident_body.pos + quat_rotate(incident_body.rot, local);
        polygon.count = polygon.count + 1u;
        edge = topology.x;
        if (edge == incident_start || polygon.count == 32u) {
            break;
        }
    }

    edge = reference_start;
    for (var i = 0u; i < 32u; i++) {
        let topology = load_hull_topology(reference_shape, edge);
        let next_topology = load_hull_topology(reference_shape, topology.x);
        let local_a = load_hull_point(reference_shape, topology.z) - reference_shape.local_center;
        let local_b = load_hull_point(reference_shape, next_topology.z) - reference_shape.local_center;
        let world_a = reference_body.pos + quat_rotate(reference_body.rot, local_a);
        let world_b = reference_body.pos + quat_rotate(reference_body.rot, local_b);
        let tangent = world_b - world_a;
        var side_normal = normalize(cross(tangent, reference_normal));
        if (dot(reference_body.pos - world_a, side_normal) > 0.0) {
            side_normal = -side_normal;
        }
        polygon = clip_polygon(polygon, side_normal, dot(side_normal, world_a) + 1e-6);
        edge = topology.x;
        if (edge == reference_start || polygon.count == 0u) {
            break;
        }
    }

    var c = empty_contact();
    c.a = ia;
    c.b = ib;
    c.n = select(reference_normal, -reference_normal, reference_is_b);
    c.friction = mixed_friction_of(a, b);
    let reference_topology = load_hull_topology(reference_shape, reference_start);
    let reference_local =
        load_hull_point(reference_shape, reference_topology.z) - reference_shape.local_center;
    let reference_point = reference_body.pos + quat_rotate(reference_body.rot, reference_local);
    var min_separation = 1e30;
    for (var i = 0u; i < polygon.count; i++) {
        min_separation = min(min_separation, dot(polygon.points[i] - reference_point, reference_normal));
    }
    if (min_separation >= SPECULATIVE) { return empty_contact(); }
    let selected = reduce_hull_polygon(polygon, reference_body, reference_normal, reference_point);
    for (var i = 0u; i < 4u; i++) {
        if (selected[i] == EMPTY) { continue; }
        let candidate = polygon.points[selected[i]];
        let point_separation = dot(candidate - reference_point, reference_normal);
        let point = candidate - 0.5 * point_separation * reference_normal;
        var duplicate = false;
        for (var j = 0u; j < c.count; j++) {
            let old = ra_at(c, j).xyz + a.pos;
            let d = point - old;
            duplicate = duplicate || dot(d, d) < 1e-8;
        }
        if (duplicate) {
            continue;
        }
        let r_a = point - a.pos;
        let r_b = point - b.pos;
        let base = point_separation - dot(r_b - r_a, c.n);
        set_point(&c, c.count, vec4<f32>(r_a, base), vec4<f32>(r_b, 0.0));
        c.count = c.count + 1u;
    }
    if (c.count > 0u) {
        finish_manifold(&c, a, b, ia, ib);
    }
    return c;
}

fn hull_world_point(shape: Shape, body: Body, vertex: u32) -> vec3<f32> {
    let local = load_hull_point(shape, vertex) - shape.local_center;
    return body.pos + quat_rotate(body.rot, local);
}

struct GaussEdge {
    q: vec3<f32>,
    e: vec3<f32>,
    u: vec3<f32>,
    v: vec3<f32>,
    valid: bool,
}

fn gauss_hull_edge(shape: Shape, body: Body, edge_index: u32) -> GaussEdge {
    var edge: GaussEdge;
    edge.valid = false;
    let count = hull_topology_count(shape);
    if (edge_index >= count) {
        return edge;
    }
    let half = load_hull_topology(shape, edge_index);
    if (half.y >= count || half.z >= hull_point_count(shape) || half.w >= hull_plane_count(shape)) {
        return edge;
    }
    let twin = load_hull_topology(shape, half.y);
    if (twin.z >= hull_point_count(shape) || twin.w >= hull_plane_count(shape)) {
        return edge;
    }
    let origin = hull_world_point(shape, body, half.z);
    edge.q = hull_world_point(shape, body, twin.z);
    edge.e = edge.q - origin;
    edge.u = quat_rotate(body.rot, load_hull_plane(shape, half.w).xyz);
    edge.v = quat_rotate(body.rot, load_hull_plane(shape, twin.w).xyz);
    edge.valid = true;
    return edge;
}

fn gauss_box_edge(body: Body, undirected: u32) -> GaussEdge {
    var edge: GaussEdge;
    edge.valid = false;
    if (undirected >= 12u) {
        return edge;
    }
    let index = 2u * undirected;
    let twin = BOX_EDGE_TWIN[index];
    let origin = box_point(body, BOX_EDGE_ORIGIN[index]);
    edge.q = box_point(body, BOX_EDGE_ORIGIN[twin]);
    edge.e = edge.q - origin;
    edge.u = hull_face_n(body, BOX_EDGE_FACE[index]);
    edge.v = hull_face_n(body, BOX_EDGE_FACE[twin]);
    edge.valid = true;
    return edge;
}

fn gauss_minkowski_axis(edge_a: GaussEdge, edge_b: GaussEdge) -> vec3<f32> {
    let cba = dot(edge_b.u, edge_a.e);
    let dba = dot(edge_b.v, edge_a.e);
    let adc = -dot(edge_a.u, edge_b.e);
    let bdc = -dot(edge_a.v, edge_b.e);
    if (cba * dba >= 0.0 || adc * bdc >= 0.0 || cba * bdc <= 0.0) {
        return vec3<f32>(0.0);
    }
    let squared_tol = PARALLEL_EDGE_TOL * PARALLEL_EDGE_TOL;
    if (max(cba * cba, dba * dba) < squared_tol * dot(edge_a.e, edge_a.e)) {
        return vec3<f32>(0.0);
    }
    let t = cba / (cba - dba);
    var axis = mix(edge_b.u, edge_b.v, t);
    let len2 = dot(axis, axis);
    if (len2 < 1e-20) {
        return vec3<f32>(0.0);
    }
    return axis;
}

fn best_hull_face(shape: Shape, body: Body, outward: vec3<f32>) -> u32 {
    var best = EMPTY;
    var best_alignment = -1e30;
    for (var i = 0u; i < hull_plane_count(shape); i++) {
        let alignment = dot(quat_rotate(body.rot, load_hull_plane(shape, i).xyz), outward);
        if (alignment > best_alignment) {
            best_alignment = alignment;
            best = i;
        }
    }
    return best;
}

fn test_gauss_edge_pair(
    shape_a: Shape,
    shape_b: Shape,
    a: Body,
    b: Body,
    edge_a: GaussEdge,
    edge_b: GaussEdge,
    best_separation: ptr<function, f32>,
    best_normal: ptr<function, vec3<f32>>,
) -> bool {
    if (!edge_a.valid || !edge_b.valid) {
        return true;
    }
    let axis = gauss_minkowski_axis(edge_a, edge_b);
    if (dot(axis, axis) < 1e-20) {
        return true;
    }
    return test_convex_axis(shape_a, shape_b, a, b, axis, best_separation, best_normal);
}

// A separated segment's closest polyhedron feature is an endpoint/face or
// segment/edge pair. Work in hull-local coordinates to retain small witnesses
// on off-center compound children. Core intersections retain the penetration
// path below; this result does not invent a normal for a zero-distance core.
struct HullCapsuleWitnessResult {
    contact: Contact,
    core_overlap: bool,
}
fn hull_capsule_witness(hull: Body, cap: Body, ih: u32, ic: u32) -> HullCapsuleWitnessResult {
    let shape = load_shape(hull._pad_island.x);
    let planes = hull_plane_count(shape);
    let edges = hull_topology_count(shape);
    var result: HullCapsuleWitnessResult;
    result.contact = empty_contact();
    result.core_overlap = false;
    if (planes == 0u || edges == 0u) { result.core_overlap = true; return result; }
    let axis = capsule_axis(cap);
    let p0 = quat_inv_rotate(hull.rot, cap.pos - axis - hull.pos) + shape.local_center;
    let p1 = quat_inv_rotate(hull.rot, cap.pos + axis - hull.pos) + shape.local_center;
    let segment = p1 - p0;
    let radius = cap.half.x;
    let limit = radius + SPECULATIVE;
    var enter = 0.0;
    var leave = 1.0;
    for (var f = 0u; f < planes; f++) {
        let plane = load_hull_plane(shape, f);
        let d0 = dot(plane.xyz, p0) - plane.w;
        let d1 = dot(plane.xyz, p1) - plane.w;
        if (min(d0, d1) > limit) { return result; }
        if (d0 > 0.0 && d1 > 0.0) { enter = 2.0; }
        else if (d0 > 0.0) { enter = max(enter, d0 / (d0 - d1)); }
        else if (d1 > 0.0) { leave = min(leave, d0 / (d0 - d1)); }
    }
    if (enter <= leave) { result.core_overlap = true; return result; }
    var best2 = limit * limit;
    var point_h = vec3<f32>(0.0);
    var point_c = vec3<f32>(0.0);
    var found = false;
    for (var f = 0u; f < planes; f++) {
        let plane = load_hull_plane(shape, f);
        for (var endpoint = 0u; endpoint < 2u; endpoint++) {
            let p = select(p0, p1, endpoint == 1u);
            let d = dot(plane.xyz, p) - plane.w;
            if (d * d >= best2) { continue; }
            let q = p - d * plane.xyz;
            var inside = true;
            for (var g = 0u; g < planes; g++) {
                let side = load_hull_plane(shape, g);
                if (dot(side.xyz, q) - side.w > 1e-6) { inside = false; break; }
            }
            if (inside) { best2 = d*d; point_h = q; point_c = p; found = true; }
        }
    }
    for (var e = 0u; e < edges; e++) {
        let half = load_hull_topology(shape, e);
        if (e >= half.y || half.y >= edges) { continue; }
        let twin = load_hull_topology(shape, half.y);
        let q0 = load_hull_point(shape, half.z);
        let q1 = load_hull_point(shape, twin.z);
        let st = closest_segments(q0, q1-q0, p0, segment);
        let q = q0 + st.x * (q1-q0);
        let p = p0 + st.y * segment;
        let d2 = dot(p-q, p-q);
        if (d2 < best2) { best2 = d2; point_h = q; point_c = p; found = true; }
    }
    if (!found) { return result; }
    if (best2 <= 1e-10) { result.core_overlap = true; return result; }
    let distance = sqrt(best2);
    let local_n = (point_c - point_h) / distance;
    let n = quat_rotate(hull.rot, local_n);
    var c = empty_contact();
    c.a = ih; c.b = ic; c.n = n; c.friction = mixed_friction_of(hull, cap);
    var face = EMPTY;
    var alignment = 0.998;
    for (var f = 0u; f < planes; f++) {
        let value = dot(load_hull_plane(shape, f).xyz, local_n);
        if (value > alignment) { face = f; alignment = value; }
    }
    if (face != EMPTY) {
        let plane = load_hull_plane(shape, face);
        let d0 = dot(plane.xyz, p0) - plane.w;
        let d1 = dot(plane.xyz, p1) - plane.w;
        // Clip the projected segment to the reference polygon. Evaluating all
        // hull planes on that face gives exactly its polygon half-spaces.
        let q0 = p0 - d0 * plane.xyz;
        let q1 = p1 - d1 * plane.xyz;
        var lo = 0.0;
        var hi = 1.0;
        for (var f = 0u; f < planes; f++) {
            if (f == face) { continue; }
            let side = load_hull_plane(shape, f);
            let a = dot(side.xyz, q0) - side.w;
            let b = dot(side.xyz, q1) - side.w;
            if (a > 0.0 && b > 0.0) { lo = 2.0; break; }
            if (a > 0.0) { lo = max(lo, a / (a-b)); }
            else if (b > 0.0) { hi = min(hi, a / (a-b)); }
        }
        if (lo <= hi) {
            let x0 = p0 + lo * segment;
            let x1 = p0 + hi * segment;
            let s0 = dot(plane.xyz, x0) - plane.w - radius;
            let s1 = dot(plane.xyz, x1) - plane.w - radius;
            if (min(s0,s1) <= SPECULATIVE) {
                c.n = quat_rotate(hull.rot, plane.xyz);
                let w0 = hull.pos + quat_rotate(hull.rot, x0 - 0.5*(s0+2.0*radius)*plane.xyz - shape.local_center);
                let w1 = hull.pos + quat_rotate(hull.rot, x1 - 0.5*(s1+2.0*radius)*plane.xyz - shape.local_center);
                add_sep_point(&c, hull, cap, c.n, w0, s0, 0u);
                c.count = 1u;
                if (dot(w1-w0,w1-w0) > 1e-10) { add_sep_point(&c, hull, cap, c.n, w1, s1, 1u); c.count = 2u; }
            }
        }
    }
    if (c.count == 0u) {
        let local_point = 0.5 * (point_h + point_c - radius * local_n);
        let point = hull.pos + quat_rotate(hull.rot, local_point - shape.local_center);
        c.count = 1u;
        add_sep_point(&c, hull, cap, n, point, distance-radius, 0u);
    }
    finish_manifold(&c, hull, cap, ih, ic);
    result.contact = c;
    return result;
}

struct HullEdgeQuery {
    separation: f32,
    normal: vec3<f32>,
    edge_a: u32,
    edge_b: u32,
}

fn query_hull_edges(sa: Shape, sb: Shape, a: Body, b: Body) -> HullEdgeQuery {
    var result: HullEdgeQuery;
    result.separation = -1e30;
    result.edge_a = EMPTY;
    result.edge_b = EMPTY;
    // CPU Gauss-map query uses B's negated normals and edge directions.
    for (var j = 0u; j < hull_topology_count(sb); j++) {
        if (j >= load_hull_topology(sb, j).y) { continue; }
        let eb = gauss_hull_edge(sb, b, j);
        if (!eb.valid) { continue; }
        let C = -eb.u;
        let D = -eb.v;
        let dc = -eb.e;
        for (var i = 0u; i < hull_topology_count(sa); i++) {
            if (i >= load_hull_topology(sa, i).y) { continue; }
            let ea = gauss_hull_edge(sa, a, i);
            if (!ea.valid) { continue; }
            let cba = dot(C, ea.e);
            let dba = dot(D, ea.e);
            let adc = dot(ea.u, dc);
            let bdc = dot(ea.v, dc);
            if (cba*dba >= -0.0001 || adc*bdc >= -0.0001 || cba*bdc >= -0.0001) { continue; }
            let tol = PARALLEL_EDGE_TOL * PARALLEL_EDGE_TOL * dot(ea.e, ea.e);
            if (max(cba*cba, dba*dba) <= tol) { continue; }
            let n = normalize(mix(C, D, cba / (cba - dba)));
            let separation = dot(n, eb.q - ea.q);
            if (separation > result.separation) {
                result.separation = separation;
                result.normal = n;
                result.edge_a = i;
                result.edge_b = j;
                if (separation > SPECULATIVE) { return result; }
            }
        }
    }
    return result;
}

fn hull_edge_manifold(sa: Shape, sb: Shape, a: Body, b: Body, ia: u32, ib: u32, query: HullEdgeQuery) -> Contact {
    if (query.edge_a == EMPTY) { return empty_contact(); }
    let ea = gauss_hull_edge(sa, a, query.edge_a);
    let eb = gauss_hull_edge(sb, b, query.edge_b);
    let pa = ea.q - ea.e;
    let pb = eb.q - eb.e;
    let w = pa - pb;
    let a11 = dot(ea.e, ea.e);
    let a12 = -dot(ea.e, eb.e);
    let a21 = -a12;
    let a22 = -dot(eb.e, eb.e);
    let b1 = -dot(ea.e, w);
    let b2 = -dot(eb.e, w);
    let det = a11*a22 - a12*a21;
    var s = 0.0;
    var t = 0.0;
    if (det*det < 1.17549435e-35) {
        s = dot(pb-pa, ea.e) / a11;
    } else {
        s = (a22*b1 - a12*b2) / det;
        t = (a11*b2 - a21*b1) / det;
    }
    if (s < 0.0 || s > 1.0 || t < 0.0 || t > 1.0) { return empty_contact(); }
    let p = pa + s*ea.e;
    let q = pb + t*eb.e;
    let separation = dot(query.normal, q-p);
    var c = empty_contact();
    c.a = ia; c.b = ib; c.count = 1u; c.n = query.normal; c.friction = mixed_friction_of(a,b);
    add_sep_point(&c, a, b, query.normal, 0.5*(p+q), separation, 0u);
    finish_manifold(&c, a, b, ia, ib);
    return c;
}

fn collide_convex_pair(a: Body, b: Body, ia: u32, ib: u32) -> Contact {
    if (a.kind == KIND_CONVEX_HULL && b.kind == KIND_CAPSULE) {
        let witness = hull_capsule_witness(a, b, ia, ib);
        if (!witness.core_overlap) { return witness.contact; }
    } else if (b.kind == KIND_CONVEX_HULL && a.kind == KIND_CAPSULE) {
        let witness = hull_capsule_witness(b, a, ib, ia);
        if (!witness.core_overlap) { return witness.contact; }
    }
    let shape_a = load_shape(a._pad_island.x);
    let shape_b = load_shape(b._pad_island.x);
    var face_separation_a = -1e30;
    var face_normal_a = vec3<f32>(0.0, 1.0, 0.0);
    var face_index_a = EMPTY;
    var face_separation_b = -1e30;
    var face_normal_b = vec3<f32>(0.0, 1.0, 0.0);
    var face_index_b = EMPTY;
    var edge_separation = -1e30;
    var edge_normal = vec3<f32>(0.0, 1.0, 0.0);
    var has_edge_axis = false;
    for (var i = 0u; i < hull_plane_count(shape_a); i++) {
        let plane = load_hull_plane(shape_a, i);
        let axis = quat_rotate(a.rot, plane.xyz);
        let old_separation = face_separation_a;
        if (!test_convex_axis(shape_a, shape_b, a, b, axis, &face_separation_a, &face_normal_a)) {
            return empty_contact();
        }
        if (face_separation_a > old_separation) {
            face_index_a = i;
        }
    }
    for (var i = 0u; i < hull_plane_count(shape_b); i++) {
        let plane = load_hull_plane(shape_b, i);
        let axis = -quat_rotate(b.rot, plane.xyz);
        let old_separation = face_separation_b;
        if (!test_convex_axis(shape_a, shape_b, a, b, axis, &face_separation_b, &face_normal_b)) {
            return empty_contact();
        }
        if (face_separation_b > old_separation) {
            face_index_b = i;
        }
    }
    if (a.kind == KIND_BOX) {
        for (var i = 0u; i < 3u; i++) {
            if (!test_convex_axis(shape_a, shape_b, a, b, box_axis(a, i), &face_separation_a, &face_normal_a)) {
                return empty_contact();
            }
        }
    }
    if (b.kind == KIND_BOX) {
        for (var i = 0u; i < 3u; i++) {
            if (!test_convex_axis(shape_a, shape_b, a, b, box_axis(b, i), &face_separation_b, &face_normal_b)) {
                return empty_contact();
            }
        }
    }
    // Boxes expose implicit hull topology so mixed box/hull faces get a full manifold.
    let hull_hull = (a.kind == KIND_CONVEX_HULL || a.kind == KIND_BOX)
        && (b.kind == KIND_CONVEX_HULL || b.kind == KIND_BOX)
        && hull_topology_count(shape_a) > 0u && hull_topology_count(shape_b) > 0u;
    var hull_edges: HullEdgeQuery;
    hull_edges.edge_a = EMPTY;
    if (hull_hull) {
        hull_edges = query_hull_edges(shape_a, shape_b, a, b);
        if (hull_edges.separation > SPECULATIVE) { return empty_contact(); }
    }
    if (!hull_hull && a.kind == KIND_CONVEX_HULL && hull_topology_count(shape_a) > 0u) {
        for (var i = 0u; i < hull_topology_count(shape_a); i++) {
            let twin_a = load_hull_topology(shape_a, i).y;
            if (i >= twin_a) {
                continue;
            }
            let edge_a = gauss_hull_edge(shape_a, a, i);
            if (!edge_a.valid) {
                continue;
            }
            if (b.kind == KIND_BOX) {
                for (var j = 0u; j < 12u; j++) {
                    has_edge_axis = true;
                    if (!test_gauss_edge_pair(
                        shape_a, shape_b, a, b, edge_a, gauss_box_edge(b, j),
                        &edge_separation, &edge_normal,
                    )) {
                        return empty_contact();
                    }
                }
            } else if (b.kind == KIND_CAPSULE) {
                has_edge_axis = true;
                if (!test_convex_axis(
                    shape_a, shape_b, a, b, cross(edge_a.e, capsule_axis(b)),
                    &edge_separation, &edge_normal,
                )) {
                    return empty_contact();
                }
            }
        }
    } else if (!hull_hull && b.kind == KIND_CONVEX_HULL && hull_topology_count(shape_b) > 0u) {
        for (var j = 0u; j < hull_topology_count(shape_b); j++) {
            let twin_b = load_hull_topology(shape_b, j).y;
            if (j >= twin_b) {
                continue;
            }
            let edge_b = gauss_hull_edge(shape_b, b, j);
            if (!edge_b.valid) {
                continue;
            }
            if (a.kind == KIND_BOX) {
                for (var i = 0u; i < 12u; i++) {
                    has_edge_axis = true;
                    if (!test_gauss_edge_pair(
                        shape_a, shape_b, a, b, gauss_box_edge(a, i), edge_b,
                        &edge_separation, &edge_normal,
                    )) {
                        return empty_contact();
                    }
                }
            } else if (a.kind == KIND_CAPSULE) {
                has_edge_axis = true;
                if (!test_convex_axis(
                    shape_a, shape_b, a, b, cross(capsule_axis(a), edge_b.e),
                    &edge_separation, &edge_normal,
                )) {
                    return empty_contact();
                }
            }
        }
    }
    var separation = face_separation_a;
    var normal = face_normal_a;
    // Match Box3D hull face selection; an added bias can choose a very different
    // normal for nearly tied penetration depths in overlapping asymmetric hulls.
    let reference_is_b = select(face_separation_b > face_separation_a + 0.5 * LINEAR_SLOP,
        face_separation_b >= face_separation_a, hull_hull);
    if (reference_is_b) {
        separation = face_separation_b;
        normal = face_normal_b;
    }
    let use_edge = has_edge_axis && !hull_hull && edge_separation > separation + 0.005;
    if (use_edge) {
        separation = edge_separation;
        normal = edge_normal;
    }
    if (!use_edge && hull_hull) {
        // SAT orients every face axis toward B-A, so opposite caps share the same
        // separation. Pick the face whose outward normal matches that axis (A's top
        // and B's bottom for a stack), not the first face that tied after flipping.
        let reference_face = select(
            best_hull_face(shape_a, a, normal),
            best_hull_face(shape_b, b, -normal),
            reference_is_b,
        );
        if (reference_face != EMPTY) {
            let clipped = clipped_hull_manifold(
                shape_a, shape_b, a, b, ia, ib, reference_is_b, reference_face,
            );
            var clip_separation = 1e30;
            for (var i = 0u; i < clipped.count; i++) {
                clip_separation = min(clip_separation, ra_at(clipped, i).w
                    + dot(rb_at(clipped, i).xyz - ra_at(clipped, i).xyz, clipped.n));
            }
            if (hull_edges.edge_a != EMPTY && (clipped.count == 0u || hull_edges.separation > clip_separation + LINEAR_SLOP)) {
                let edge_contact = hull_edge_manifold(shape_a, shape_b, a, b, ia, ib, hull_edges);
                if (edge_contact.count > 0u) { return edge_contact; }
            }
            return clipped;
        }
    }
    var c = empty_contact();
    c.a = ia;
    c.b = ib;
    c.count = 1u;
    c.n = normal;
    c.friction = mixed_friction_of(a, b);
    let projection_a = project_collider(shape_a, a, normal);
    let projection_b = project_collider(shape_b, b, normal);
    let midpoint = 0.5 * (a.pos + b.pos);
    let surface = 0.5 * (projection_a.y + projection_b.x);
    let center_point = midpoint + normal * (surface - dot(midpoint, normal));
    let tangent1 = perp(normal);
    let tangent2 = cross(tangent1, normal);
    var candidates: array<vec3<f32>, 4>;
    var scores = vec4<f32>(-1e30);
    var valid = vec4<bool>(false);
    let face_slop = max(0.01, 2.0 * SPECULATIVE);
    if (a.kind == KIND_CONVEX_HULL) {
        for (var i = 0u; i < hull_point_count(shape_a); i++) {
            let local = load_hull_point(shape_a, i) - shape_a.local_center;
            let point = a.pos + quat_rotate(a.rot, local);
            if (dot(point, normal) >= projection_a.y - face_slop
                && point_inside_collider(shape_b, b, point, face_slop)) {
                consider_convex_manifold_point(
                    point,
                    tangent1,
                    tangent2,
                    &candidates,
                    &scores,
                    &valid,
                );
            }
        }
    }
    if (b.kind == KIND_CONVEX_HULL) {
        for (var i = 0u; i < hull_point_count(shape_b); i++) {
            let local = load_hull_point(shape_b, i) - shape_b.local_center;
            let point = b.pos + quat_rotate(b.rot, local);
            if (dot(point, normal) <= projection_b.x + face_slop
                && point_inside_collider(shape_a, a, point, face_slop)) {
                consider_convex_manifold_point(
                    point,
                    tangent1,
                    tangent2,
                    &candidates,
                    &scores,
                    &valid,
                );
            }
        }
    }
    c.count = 0u;
    for (var i = 0u; i < 4u; i++) {
        if (!valid[i]) {
            continue;
        }
        let candidate = candidates[i]
            + normal * (surface - dot(candidates[i], normal));
        var duplicate = false;
        for (var j = 0u; j < c.count; j++) {
            let old = ra_at(c, j).xyz + a.pos;
            let d = candidate - old;
            duplicate = duplicate || dot(d, d) < 1e-8;
        }
        if (duplicate) {
            continue;
        }
        let r_a = candidate - a.pos;
        let r_b = candidate - b.pos;
        let base = separation - dot(r_b - r_a, normal);
        set_point(&c, c.count, vec4<f32>(r_a, base), vec4<f32>(r_b, 0.0));
        c.count = c.count + 1u;
    }
    if (c.count == 0u) {
        let r_a = center_point - a.pos;
        let r_b = center_point - b.pos;
        let base = separation - dot(r_b - r_a, normal);
        set_point(&c, 0u, vec4<f32>(r_a, base), vec4<f32>(r_b, 0.0));
        c.count = 1u;
    }
    finish_manifold(&c, a, b, ia, ib);
    return c;
}

struct TriangleClosest {
    point: vec3<f32>,
    feature: u32,
}

fn closest_triangle_point(p: vec3<f32>, a: vec3<f32>, b: vec3<f32>, c: vec3<f32>) -> TriangleClosest {
    let ab = b - a;
    let ac = c - a;
    let ap = p - a;
    let d1 = dot(ab, ap);
    let d2 = dot(ac, ap);
    if (d1 <= 0.0 && d2 <= 0.0) { return TriangleClosest(a, 4u); }
    let bp = p - b;
    let d3 = dot(ab, bp);
    let d4 = dot(ac, bp);
    if (d3 >= 0.0 && d4 <= d3) { return TriangleClosest(b, 5u); }
    let vc = d1 * d4 - d3 * d2;
    if (vc <= 0.0 && d1 >= 0.0 && d3 <= 0.0) {
        return TriangleClosest(a + ab * d1 / (d1 - d3), 0u);
    }
    let cp = p - c;
    let d5 = dot(ab, cp);
    let d6 = dot(ac, cp);
    if (d6 >= 0.0 && d5 <= d6) { return TriangleClosest(c, 6u); }
    let vb = d5 * d2 - d1 * d6;
    if (vb <= 0.0 && d2 >= 0.0 && d6 <= 0.0) {
        return TriangleClosest(a + ac * d2 / (d2 - d6), 2u);
    }
    let va = d3 * d6 - d5 * d4;
    if (va <= 0.0 && d4 - d3 >= 0.0 && d5 - d6 >= 0.0) {
        return TriangleClosest(b + (c - b) * (d4 - d3) / ((d4 - d3) + (d5 - d6)), 1u);
    }
    let inv = 1.0 / (va + vb + vc);
    return TriangleClosest(a + ab * vb * inv + ac * vc * inv, 3u);
}

fn mesh_vertex_allowed(vertex: u32, flags: u32) -> bool {
    let mask = (1u << vertex) | (1u << (vertex + 4u));
    return (flags & mask) == 0u;
}

fn mesh_feature_allowed(feature: u32, flags: u32) -> bool {
    if (feature < 3u) {
        return mesh_vertex_allowed(feature, flags);
    }
    if (feature == 4u) { return mesh_vertex_allowed(0u, flags) && mesh_vertex_allowed(2u, flags); }
    if (feature == 5u) { return mesh_vertex_allowed(0u, flags) && mesh_vertex_allowed(1u, flags); }
    if (feature == 6u) { return mesh_vertex_allowed(1u, flags) && mesh_vertex_allowed(2u, flags); }
    return true;
}

fn mesh_local_vertex(mesh_shape: Shape, mesh: Body, index: u32) -> vec3<f32> {
    let local = load_mesh_vertex(mesh_shape, index) - mesh_shape.local_center;
    return mesh.pos + quat_rotate(mesh.rot, local);
}

fn mesh_node_overlaps(mesh_shape: Shape, mesh: Body, convex: Body, node_index: u32) -> bool {
    let lower = load_mesh_node_lower(mesh_shape, node_index).xyz;
    let upper = load_mesh_node_upper(mesh_shape, node_index).xyz;
    let center = mesh_to_raw_point(mesh_shape, quat_inv_rotate(mesh.rot, convex.pos - mesh.pos) + mesh_shape.local_center);
    let radius = bound_radius(convex) + SPECULATIVE + length(convex.half);
    var extent = vec3<f32>(radius);
    if (mesh_shape.instance_flags != 0u) { extent = extent / abs(mesh_shape.axis); }
    return all(center + extent >= lower) && all(center - extent <= upper);
}

fn mesh_speculative_keep(convex: Shape, mesh: Shape) -> f32 {
    // Native's experimental switch applies only to hull/triangle contacts,
    // and either endpoint may disable it. Sphere/capsule speculation is retained.
    let hull = convex.kind == KIND_BOX || convex.kind == KIND_CONVEX_HULL;
    let disabled = ((convex.event_flags | mesh.event_flags) & SHAPE_DISABLE_SPECULATIVE) != 0u;
    return select(SPECULATIVE, 0.0, hull && disabled);
}

fn mesh_push_child(
    stack: ptr<function, array<u32, 64>>,
    stack_count: ptr<function, u32>,
    mesh_shape: Shape,
    mesh: Body,
    convex: Body,
    node_index: u32,
) {
    if (!mesh_node_overlaps(mesh_shape, mesh, convex, node_index)) {
        return;
    }
    if (*stack_count < 64u) {
        (*stack)[*stack_count] = node_index;
        *stack_count = *stack_count + 1u;
        return;
    }
    record_contact_drop(12u);
}

// Bounded persistent-manifold reduction: maximize tangent-plane coverage
// with native separation hysteresis. A later triangle may replace an old point;
// visitation order must not lock the manifold to its first four vertices.
fn append_mesh_point(result: ptr<function, Contact>, ra: vec4<f32>, rb: vec4<f32>, n: vec3<f32>) -> bool {
    return append_mesh_point_with_identity(result, ra, rb, n, 0u, 0u);
}

fn append_mesh_point_with_identity(result: ptr<function, Contact>, ra: vec4<f32>, rb: vec4<f32>, n: vec3<f32>, triangle: u32, feature: u32) -> bool {
    if ((*result).count < 4u) {
        set_point(result, (*result).count, ra, rb);
        set_feat_at(result, (*result).count, feature);
        (*result).point_triangles[(*result).count] = triangle;
        (*result).count += 1u;
        return true;
    }
    var aa: array<vec4<f32>, 5>;
    var bb: array<vec4<f32>, 5>;
    var pp: array<vec3<f32>, 5>;
    var triangles: array<u32, 5>;
    var features: array<u32, 5>;
    var selected: array<bool, 5>;
    var deepest = 0u;
    var depth = 1e30;
    for (var i = 0u; i < 5u; i++) {
        if (i < 4u) { aa[i] = ra_at(*result, i); bb[i] = rb_at(*result, i); }
        else { aa[i] = ra; bb[i] = rb; }
        if (i < 4u) { triangles[i] = (*result).point_triangles[i]; features[i] = feat_at(*result, i); }
        else { triangles[i] = triangle; features[i] = feature; }
        let separation = aa[i].w + dot(bb[i].xyz - aa[i].xyz, n);
        if (separation < depth) { depth = separation; deepest = i; }
        pp[i] = aa[i].xyz - dot(aa[i].xyz, n) * n;
        selected[i] = false;
    }
    // Match native's coverage/separation priorities on this bounded candidate
    // set. Deepest-first greedily loses a second penetrating edge witness.
    var order: array<u32, 4>;
    var selected_count = 0u;
    let tolerance2 = 0.0625 * LINEAR_SLOP * LINEAR_SLOP;
    var first = 0u;
    var second = 1u;
    var score = 0.0;
    var best_depth = 1e30;
    for (var i = 0u; i < 5u; i++) {
        for (var j = i + 1u; j < 5u; j++) {
            let delta = pp[i] - pp[j];
            let candidate = dot(delta, delta);
            let separation = aa[i].w + dot(bb[i].xyz-aa[i].xyz,n)
                + aa[j].w + dot(bb[j].xyz-aa[j].xyz,n);
            if (candidate > score + tolerance2 ||
                (candidate >= score - tolerance2 && separation < best_depth - LINEAR_SLOP)) {
                first = i; second = j; score = candidate; best_depth = separation;
            }
        }
    }
    if (score < tolerance2) {
        selected[deepest] = true;
        order[0] = deepest;
        selected_count = 1u;
    } else {
        selected[first] = true;
        selected[second] = true;
        order[0] = first; order[1] = second;
        selected_count = 2u;
        var third = EMPTY;
        score = 0.0;
        best_depth = 1e30;
        let edge = pp[second] - pp[first];
        for (var i = 0u; i < 5u; i++) {
            if (selected[i]) { continue; }
            let candidate = abs(dot(cross(edge, pp[i]-pp[first]), n));
            let separation = aa[i].w + dot(bb[i].xyz-aa[i].xyz,n);
            if (candidate > score + tolerance2 ||
                (candidate >= score - tolerance2 && separation < best_depth - LINEAR_SLOP)) {
                third = i; score = candidate; best_depth = separation;
            }
        }
        if (third != EMPTY) {
            selected[third] = true;
            order[2] = third; selected_count = 3u;
            let a = pp[first];
            var b = pp[second];
            var c = pp[third];
            if (dot(cross(b-a,c-a), n) < 0.0) { let temp = b; b = c; c = temp; }
            var fourth = EMPTY;
            score = 0.0;
            best_depth = 1e30;
            for (var i = 0u; i < 5u; i++) {
                if (selected[i]) { continue; }
                let candidate = max(dot(cross(pp[i]-a,b-a),n),
                    max(dot(cross(pp[i]-b,c-b),n),dot(cross(pp[i]-c,a-c),n)));
                let separation = aa[i].w + dot(bb[i].xyz-aa[i].xyz,n);
                if (candidate > score + tolerance2 ||
                    (candidate >= score - tolerance2 && separation < best_depth - LINEAR_SLOP)) {
                    fourth = i; score = candidate; best_depth = separation;
                }
            }
            if (fourth != EMPTY) { selected[fourth] = true; order[3] = fourth; selected_count = 4u; }
        }
    }
    // Coverage must not erase a deeper interior penetration. Preserve the
    // existing deepest-witness safety invariant even for nonplanar candidates.
    if (!selected[deepest]) {
        var replace = 0u;
        var shallowest = -1e30;
        for (var i = 0u; i < selected_count; i++) {
            let j = order[i];
            let separation = aa[j].w + dot(bb[j].xyz-aa[j].xyz,n);
            if (separation > shallowest) { replace = i; shallowest = separation; }
        }
        selected[order[replace]] = false;
        order[replace] = deepest;
        selected[deepest] = true;
    }
    for (var out = 0u; out < selected_count; out++) {
        let i = order[out];
        set_point(result, out, aa[i], bb[i]);
        set_feat_at(result, out, features[i]);
        (*result).point_triangles[out] = triangles[i];
    }
    (*result).count = selected_count;
    return selected[4];
}

// Diagnostic-only bounded append buffer, allocated only with mesh-candidates.
// Records world-space points before reduction; overflow invalidates the run.
fn trace_solver_words(words: array<u32,16>) {
    if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) == 0u) { return; }
    let start = arrayLength(&atom) - MESH_TRACE_WORDS;
    let index = atomicAdd(&atom[start], 1u);
    if (index >= 2048u) {
        record_contact_drop(13u);
        return;
    }
    let base = start + 1u + 16u * index;
    for (var i=0u; i<16u; i++) { atomicStore(&atom[base+i],words[i]); }
}

fn trace_solver_values(stage: u32, a: u32, b: u32, x: vec4<f32>, y: vec4<f32>, z: vec4<f32>) {
    trace_solver_words(array<u32,16>(params.physics_step,stage,a,b,
        bitcast<u32>(x.x),bitcast<u32>(x.y),bitcast<u32>(x.z),bitcast<u32>(x.w),
        bitcast<u32>(y.x),bitcast<u32>(y.y),bitcast<u32>(y.z),bitcast<u32>(y.w),
        bitcast<u32>(z.x),bitcast<u32>(z.y),bitcast<u32>(z.z),bitcast<u32>(z.w)));
}

fn trace_mesh_candidate(stage: u32, mesh: Shape, convex: Shape, triangle: u32,
    point: vec3<f32>, separation: f32, normal: vec3<f32>, patch_depth: f32, feature: u32) {
    if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) == 0u) { return; }
    let words = array<u32,16>(params.physics_step, stage, mesh.body_index, convex.body_index,
        bitcast<u32>(point.x), bitcast<u32>(point.y), bitcast<u32>(point.z), bitcast<u32>(separation),
        bitcast<u32>(normal.x), bitcast<u32>(normal.y), bitcast<u32>(normal.z), bitcast<u32>(patch_depth),
        triangle, feature, 0u, 0u);
    trace_solver_words(words);
}

fn consider_mesh_manifold_point(
    result: ptr<function, Contact>,
    mesh: Body,
    convex: Body,
    convex_shape: Shape,
    mesh_shape: Shape,
    point: vec3<f32>,
    separation: f32,
    patch_separation: f32,
    contact_normal: vec3<f32>,
    triangle_normal: vec3<f32>,
    material_index: u32,
    feature: u32,
    best_separation: ptr<function, f32>,
    best_normal: ptr<function, vec3<f32>>,
    material_samples: ptr<function, f32>,
    mixed_friction: ptr<function, f32>,
    mixed_restitution: ptr<function, f32>,
    mesh_tangent_velocity: ptr<function, vec3<f32>>,
    dominant_material: ptr<function, u32>,
) {
    trace_mesh_candidate(0u, mesh_shape, convex_shape, (*result).manifold_link.w,
        point, separation, contact_normal, patch_separation, feature);
    // Admit a clipped face by its nearest point. Other vertices can become
    // active as the body rotates during TGS; discarding them here changes torque.
    if (patch_separation > mesh_speculative_keep(convex_shape, mesh_shape)
        || (mesh_speculative_keep(convex_shape, mesh_shape) == 0.0 && separation > 0.0)
        || dot(contact_normal, triangle_normal) < -0.05) {
        return;
    }
    // Box3D mesh_contact.c classifies shallow hull-face contacts whose normal
    // differs substantially from the triangle as tentative. Prefer confirmed
    // surface/deep contacts over those edge candidates, regardless of BVH order.
    // _pad_end is temporary classification here; finish_manifold overwrites it
    // with restitution. Replace the WHOLE tentative piece, never its basis alone.
    let confirmed = dot(contact_normal, triangle_normal) > 0.5 || patch_separation < -2.0 * LINEAR_SLOP;
    if ((*result).count > 0u && (*result)._pad_end == 1.0 && !confirmed) {
        return;
    }
    if ((*result).count > 0u && (*result)._pad_end == 0.0 && confirmed) {
        (*result).count = 0u;
        for (var i = 0u; i < 4u; i++) { set_point(result, i, vec4<f32>(0.0), vec4<f32>(0.0)); }
        *best_separation = 1e30;
        *material_samples = 0.0;
        *mixed_friction = 0.0;
        *mixed_restitution = 0.0;
        *mesh_tangent_velocity = vec3<f32>(0.0);
    }
    // Never let a rejected triangle replace the basis of already packed points.
    // In particular a chamfer/wall visited after four floor points must not turn
    // those points into a wall manifold with floor-relative separation values.
    let aligned = (*result).count == 0u || dot(contact_normal, *best_normal) > 0.8;
    if (!aligned) {
        return;
    }
    for (var old = 0u; old < (*result).count; old++) {
        let d = (ra_at(*result, old).xyz + mesh.pos) - point;
        if (dot(d, d) < 1e-8) {
            return;
        }
    }
    if ((*result).count == 0u) {
        (*result)._pad_end = select(0.0, 1.0, confirmed);
        *best_normal = contact_normal;
    }
    if (separation < (*best_separation)) {
        *best_separation = separation;
        *dominant_material = material_index;
    }
    let r_a = point - mesh.pos;
    let r_b = point - convex.pos;
    // All points in this manifold must use its single, fixed normal basis.
    let base = separation * dot(contact_normal, *best_normal) - dot(r_b - r_a, *best_normal);
    trace_mesh_candidate(1u, mesh_shape, convex_shape, (*result).manifold_link.w,
        point, separation, contact_normal, patch_separation, feature);
    if (!append_mesh_point_with_identity(result, vec4<f32>(r_a, base), vec4<f32>(r_b, 0.0), *best_normal, (*result).manifold_link.w, feature)) {
        return;
    }
    let material = load_surface_material(mesh_shape, material_index);
    *material_samples = *material_samples + 1.0;
    *mixed_friction = *mixed_friction + sqrt(max(material.friction * convex_shape.friction, 0.0));
    *mixed_restitution = *mixed_restitution + max(material.restitution, convex_shape.restitution);
    *mesh_tangent_velocity = *mesh_tangent_velocity + material.tangent_velocity;
}

fn add_mesh_sample_contact(
    result: ptr<function, Contact>,
    mesh: Body,
    convex: Body,
    convex_shape: Shape,
    mesh_shape: Shape,
    sample: vec3<f32>,
    radius: f32,
    p1: vec3<f32>,
    p2: vec3<f32>,
    p3: vec3<f32>,
    triangle_normal: vec3<f32>,
    triangle_flags: u32,
    material_index: u32,
    best_separation: ptr<function, f32>,
    best_normal: ptr<function, vec3<f32>>,
    material_samples: ptr<function, f32>,
    mixed_friction: ptr<function, f32>,
    mixed_restitution: ptr<function, f32>,
    mesh_tangent_velocity: ptr<function, vec3<f32>>,
    dominant_material: ptr<function, u32>,
    sample_feature: u32,
) {
    var closest = closest_triangle_point(sample, p1, p2, p3);
    if (!mesh_feature_allowed(closest.feature, triangle_flags)) {
        let proj = sample - triangle_normal * dot(sample - p1, triangle_normal);
        closest = closest_triangle_point(proj, p1, p2, p3);
        if (closest.feature != 3u) {
            // An exact seam/vertex projection still has face support. Reject
            // outside projections, but do not discard both coplanar triangles
            // under a sphere/capsule solely because their shared edge is flat.
            let lateral = proj - closest.point;
            if (radius <= 0.0 || dot(lateral, lateral) > 1e-12) { return; }
            closest.feature = 3u;
        }
    }
    let delta = sample - closest.point;
    let distance = length(delta);
    var separation = distance - radius;
    var contact_normal = select(triangle_normal, delta / distance, distance > 1e-8);
    if (closest.feature == 3u) {
        separation = dot(delta, triangle_normal) - radius;
        contact_normal = triangle_normal;
    }
    // Hull samples and clipped hull faces must use the same surface witness.
    // Midpoints create a second representation of a penetrating hull vertex,
    // consuming manifold slots and changing its friction lever arm.
    let point = select(sample, 0.5 * (closest.point + sample - radius * contact_normal), radius > 0.0);
    consider_mesh_manifold_point(
        result, mesh, convex, convex_shape, mesh_shape, point, separation, separation, contact_normal,
        triangle_normal, material_index, pack_feature(0u, closest.feature, 1u, sample_feature), best_separation, best_normal, material_samples,
        mixed_friction, mixed_restitution, mesh_tangent_velocity, dominant_material,
    );
}

fn box_triangle_face_axis(box: Body, p1: vec3<f32>, p2: vec3<f32>, p3: vec3<f32>, normal: vec3<f32>) -> vec4<f32> {
    let axes = mat3x3<f32>(box_axis(box, 0u), box_axis(box, 1u), box_axis(box, 2u));
    let radius = dot(abs(transpose(axes) * normal), box.half);
    var best = vec4<f32>(normal, dot(box.pos - p1, normal) - radius);
    // Triangle face and OBB faces are the face-axis SAT candidates. Reject
    // separation on either side, but do not choose a back-facing response.
    for (var i = 0u; i < 3u; i++) {
        let axis = axes[i];
        let a = dot(p1 - box.pos, axis);
        let b = dot(p2 - box.pos, axis);
        let c = dot(p3 - box.pos, axis);
        let positive = -box.half[i] - max(a, max(b, c));
        let negative = min(a, min(b, c)) - box.half[i];
        let direction = select(axis, -axis, negative > positive);
        let separation = max(positive, negative);
        if (separation > SPECULATIVE) { return vec4<f32>(direction, separation); }
        if (separation > best.w && dot(direction, normal) > -0.25) {
            best = vec4<f32>(direction, separation);
        }
    }
    // Edge cross axes are required for rejection even when a face supplies
    // the manifold normal. Without these, disjoint edge pairs can collide.
    let edges = mat3x3<f32>(p2 - p1, p3 - p2, p1 - p3);
    for (var i = 0u; i < 3u; i++) {
        for (var j = 0u; j < 3u; j++) {
            let cross_axis = cross(axes[i], edges[j]);
            let length2 = dot(cross_axis, cross_axis);
            if (length2 < 1e-12) { continue; }
            let axis = cross_axis * inverseSqrt(length2);
            let extent = dot(abs(transpose(axes) * axis), box.half);
            let a = dot(p1 - box.pos, axis);
            let b = dot(p2 - box.pos, axis);
            let c = dot(p3 - box.pos, axis);
            let separation = max(-extent - max(a, max(b, c)), min(a, min(b, c)) - extent);
            if (separation > SPECULATIVE) { return vec4<f32>(axis, separation); }
        }
    }
    return best;
}

fn clip_hull_face_to_triangle(
    result: ptr<function, Contact>,
    mesh: Body,
    convex: Body,
    convex_shape: Shape,
    mesh_shape: Shape,
    p1: vec3<f32>,
    p2: vec3<f32>,
    p3: vec3<f32>,
    triangle_normal: vec3<f32>,
    material_index: u32,
    best_separation: ptr<function, f32>,
    best_normal: ptr<function, vec3<f32>>,
    material_samples: ptr<function, f32>,
    mixed_friction: ptr<function, f32>,
    mixed_restitution: ptr<function, f32>,
    mesh_tangent_velocity: ptr<function, vec3<f32>>,
    dominant_material: ptr<function, u32>,
) {
    var polygon: ClipPolygon;
    polygon.count = 0u;
    var reference_normal = triangle_normal;
    if (convex.kind == KIND_BOX) {
        let face = box_triangle_face_axis(convex, p1, p2, p3, triangle_normal);
        if (face.w > mesh_speculative_keep(convex_shape, mesh_shape)) { return; }
        reference_normal = face.xyz;
        // A triangle can lie entirely inside the incident face: no box corner
        // then projects inside it. Clip the face itself, as for a general hull.
        let local_n = quat_inv_rotate(convex.rot, reference_normal);
        var axis = 0u;
        if (abs(local_n.y) > abs(local_n.x)) { axis = 1u; }
        if (abs(local_n.z) > abs(local_n[axis])) { axis = 2u; }
        let u = (axis + 1u) % 3u;
        let v = (axis + 2u) % 3u;
        if (abs(local_n[axis]) > 0.99999) {
            // The box supplies the reference face: clip the TRIANGLE to its
            // side planes. Projecting the box face onto the triangle loses
            // edge contacts when the two planes are nearly perpendicular.
            polygon.count = 3u;
            polygon.points[0] = p1;
            polygon.points[1] = p2;
            polygon.points[2] = p3;
            polygon.features[0] = pack_feature(0u, 2u, 0u, 0u);
            polygon.features[1] = pack_feature(0u, 0u, 0u, 1u);
            polygon.features[2] = pack_feature(0u, 1u, 0u, 2u);
            let face = find_incident_face(convex, reference_normal, box_support_vertex(convex, -reference_normal));
            let edges = hull_face_edge_ids(face);
            for (var e = 0u; e < 4u; e++) {
                let edge = edges[e];
                let v1 = convex.pos + quat_rotate(convex.rot, box_point_local(convex, BOX_EDGE_ORIGIN[edge]));
                let v2 = convex.pos + quat_rotate(convex.rot, box_point_local(convex, BOX_EDGE_ORIGIN[BOX_EDGE_NEXT[edge]]));
                let side = normalize(cross(v2 - v1, -reference_normal));
                polygon = clip_polygon_with_features(polygon, side, dot(side, v1), edge, 1u);
            }
            var patch_separation = 1e30;
            for (var i = 0u; i < polygon.count; i++) {
                patch_separation = min(patch_separation,
                    dot(convex.pos - polygon.points[i], reference_normal) - convex.half[axis]);
            }
            for (var i = 0u; i < polygon.count; i++) {
                let separation = dot(convex.pos - polygon.points[i], reference_normal) - convex.half[axis];
                // Box3D projects triangle vertices onto the reference hull face.
                let point = polygon.points[i] + separation * reference_normal;
                consider_mesh_manifold_point(
                    result, mesh, convex, convex_shape, mesh_shape, point, separation, patch_separation, reference_normal,
                    triangle_normal, material_index, polygon.features[i], best_separation, best_normal, material_samples,
                    mixed_friction, mixed_restitution, mesh_tangent_velocity, dominant_material,
                );
            }
            return;
        }
        let incident_face = find_incident_face(convex, reference_normal, box_support_vertex(convex, -reference_normal));
        let verts = hull_face_verts(convex, incident_face);
        let edges = hull_face_edge_ids(incident_face);
        for (var i = 0u; i < 4u; i++) {
            polygon.points[i] = verts[i];
            polygon.features[i] = pack_feature(1u, edges[i], 1u, edges[(i + 1u) % 4u]);
        }
        polygon.count = 4u;
    } else {
    var incident_face = 0u;
    var incident_alignment = 1e30;
    for (var i = 0u; i < hull_plane_count(convex_shape); i++) {
        let candidate = quat_rotate(convex.rot, load_hull_plane(convex_shape, i).xyz);
        let alignment = dot(candidate, triangle_normal);
        if (alignment < incident_alignment) {
            incident_alignment = alignment;
            incident_face = i;
        }
    }
    let incident_start = find_face_edge(convex_shape, incident_face);
    if (incident_start == EMPTY) {
        return;
    }
    var previous_edge = incident_start;
    for (var i = 0u; i < 32u; i++) {
        let next = load_hull_topology(convex_shape, previous_edge).x;
        if (next == incident_start) { break; }
        previous_edge = next;
    }
    var edge = incident_start;
    for (var i = 0u; i < 32u; i++) {
        let topology = load_hull_topology(convex_shape, edge);
        let local = load_hull_point(convex_shape, topology.z) - convex_shape.local_center;
        polygon.points[polygon.count] = convex.pos + quat_rotate(convex.rot, local);
        polygon.features[polygon.count] = pack_feature(1u, previous_edge, 1u, edge);
        previous_edge = edge;
        polygon.count = polygon.count + 1u;
        edge = topology.x;
        if (edge == incident_start || polygon.count == 32u) {
            break;
        }
    }
    }
    var side12 = normalize(cross(p2 - p1, reference_normal));
    if (dot(p3 - p1, side12) > 0.0) {
        side12 = -side12;
    }
    polygon = clip_polygon_with_features(polygon, side12, dot(side12, p1), 0u, 0u);
    var side23 = normalize(cross(p3 - p2, reference_normal));
    if (dot(p1 - p2, side23) > 0.0) {
        side23 = -side23;
    }
    polygon = clip_polygon_with_features(polygon, side23, dot(side23, p2), 1u, 0u);
    var side31 = normalize(cross(p1 - p3, reference_normal));
    if (dot(p2 - p3, side31) > 0.0) {
        side31 = -side31;
    }
    polygon = clip_polygon_with_features(polygon, side31, dot(side31, p3), 2u, 0u);
    var patch_separation = 1e30;
    for (var i = 0u; i < polygon.count; i++) {
        patch_separation = min(patch_separation,
            dot(polygon.points[i] - p1, triangle_normal) / dot(reference_normal, triangle_normal));
    }
    for (var i = 0u; i < polygon.count; i++) {
        let separation = dot(polygon.points[i] - p1, triangle_normal) / dot(reference_normal, triangle_normal);
        // Triangle-reference contacts keep the incident hull point. Moving
        // it along the normal leaves normal torque unchanged but alters friction.
        let point = polygon.points[i];
        consider_mesh_manifold_point(
            result, mesh, convex, convex_shape, mesh_shape, point, separation, patch_separation, reference_normal,
            triangle_normal, material_index, polygon.features[i], best_separation, best_normal, material_samples,
            mixed_friction, mixed_restitution, mesh_tangent_velocity, dominant_material,
        );
    }
}

// Newly generated patches occupy disjoint free slots until every cache transfer
// is complete. The pair's original slot remains the graph/hash owner.
struct MeshPatchList { head: u32, tail: u32, count: u32 }

fn mesh_representative_normal(shape: Shape, mesh: Body, triangle_plus_one: u32) -> vec3<f32> {
    let t = load_mesh_triangle(shape, triangle_plus_one - 1u);
    let p1 = mesh_local_vertex(shape, mesh, t.x);
    let p2 = mesh_local_vertex(shape, mesh, t.y);
    let p3 = mesh_local_vertex(shape, mesh, t.z);
    return normalize(cross(p2 - p1, p3 - p1));
}

fn append_mesh_patch(list: ptr<function, MeshPatchList>, root: u32, candidate: Contact, shape: Shape, mesh: Body) -> bool {
    if (candidate.a == EMPTY || candidate.count == 0u) { return true; }
    let triangle_normal = mesh_representative_normal(shape, mesh, candidate.manifold_link.w);
    var slot = (*list).head;
    for (var i = 0u; i < (*list).count; i++) {
        var piece = load_contact(slot);
        if (piece.lifecycle.y == candidate.lifecycle.y && dot(piece.n, candidate.n) > 0.996
            && dot(mesh_representative_normal(shape, mesh, piece.manifold_link.w), triangle_normal) > 0.996) {
            for (var j = 0u; j < candidate.count; j++) {
                let ra = ra_at(candidate, j);
                let rb = rb_at(candidate, j);
                var duplicate = false;
                for (var k = 0u; k < piece.count; k++) {
                    let delta = ra_at(piece, k).xyz - ra.xyz;
                    duplicate = duplicate || dot(delta, delta) < 1e-8;
                }
                if (duplicate) { continue; }
                let separation = ra.w + dot(rb.xyz - ra.xyz, candidate.n);
                let base = separation * dot(candidate.n, piece.n) - dot(rb.xyz - ra.xyz, piece.n);
                append_mesh_point_with_identity(&piece, vec4<f32>(ra.xyz, base), rb, piece.n,
                    candidate.point_triangles[j], feat_at(candidate, j));
            }
            piece._pad_end = max(piece._pad_end, candidate._pad_end);
            store_contact(slot, piece);
            return true;
        }
        slot = piece.manifold_link.x - 1u;
    }
    let allocated = allocate_manifold_slot(root);
    if (allocated == EMPTY) { return false; }
    var added = candidate;
    added.manifold_link.x = 0u;
    added.manifold_link.y = root + 1u;
    added.manifold_link.z = 0u;
    store_contact(allocated, added);
    if ((*list).count == 0u) { (*list).head = allocated; }
    else { contacts[(*list).tail].manifold_link.x = allocated + 1u; }
    (*list).tail = allocated;
    (*list).count += 1u;
    return true;
}

fn discard_mesh_patch_list(list: MeshPatchList) {
    var slot = list.head;
    for (var i = 0u; i < list.count; i++) {
        let next = contacts[slot].manifold_link.x;
        store_contact(slot, empty_contact());
        scratch[scr_contact_mark() + slot] = 0u;
        slot = next - 1u;
    }
}

fn select_old_mesh_patch(root: u32, fresh: Contact) -> Contact {
    let count = max(contacts[root].manifold_link.z, 1u);
    var slot = root;
    var best = EMPTY;
    var best_dot = 0.995;
    for (var i = 0u; i < count; i++) {
        let old = load_contact(slot);
        if (old.a == fresh.a && old.b == fresh.b && old.count > 0u
            && (scratch[scr_contact_mark() + slot] & 2u) == 0u) {
            let alignment = dot(old.n, fresh.n);
            if (alignment > best_dot) { best = slot; best_dot = alignment; }
        }
        slot = old.manifold_link.x - 1u;
    }
    if (best == EMPTY) { return empty_contact(); }
    scratch[scr_contact_mark() + best] |= 2u;
    return load_contact(best);
}

fn finalize_mesh_patch_list(list: MeshPatchList, root: u32, mesh: Body, convex: Body, ia: u32, ib: u32) -> Contact {
    if (!contact_chain_structure_valid(root)) {
        discard_mesh_patch_list(list);
        return load_contact(root);
    }
    let old_color = contacts[root].color;
    var slot = list.head;
    for (var i = 0u; i < list.count; i++) {
        var piece = load_contact(slot);
        let previous = select_old_mesh_patch(root, piece);
        let friction = piece.friction;
        let restitution = piece._pad_end;
        let rolling = piece.rolling;
        // Native applies B3_MESH_REST_OFFSET after clustering, for every mesh
        // manifold. Keep admission/geometric witness coordinates unchanged.
        for (var j = 0u; j < piece.count; j++) {
            let ra = ra_at(piece, j);
            set_point(&piece, j, vec4<f32>(ra.xyz, ra.w - LINEAR_SLOP), rb_at(piece, j));
        }
        finish_manifold_from_previous(&piece, mesh, convex, ia, ib, previous);
        piece.friction = friction;
        piece._pad_end = restitution;
        piece.rolling = rolling;
        piece.color = old_color;
        store_contact(slot, piece);
        slot = piece.manifold_link.x - 1u;
    }
    if (!retire_manifold_children(root)) {
        discard_mesh_patch_list(list);
        return load_contact(root);
    }
    scratch[scr_contact_mark() + root] = 1u;
    if (list.count == 0u) { return empty_contact(); }
    var result = load_contact(list.head);
    result.manifold_link.y = 0u;
    result.manifold_link.z = list.count;
    store_contact(list.head, empty_contact());
    scratch[scr_contact_mark() + list.head] = 0u;
    return result;
}

// Box3D b3FindIncidentFace chooses between faces adjacent to the support
// vertex's most perpendicular edge. A global normal search can choose a face
// that does not contain the support vertex, producing an unrelated clip polygon.
fn hull_triangle_incident_face(shape: Shape, body: Body, normal: vec3<f32>) -> u32 {
    var vertex = EMPTY;
    var minimum = 1e30;
    for (var i = 0u; i < hull_point_count(shape); i++) {
        let projection = dot(hull_world_point(shape, body, i), normal);
        if (projection < minimum) {
            minimum = projection;
            vertex = i;
        }
    }
    var best_edge = EMPTY;
    var best_projection = 1e30;
    for (var i = 0u; i < hull_topology_count(shape); i++) {
        let edge = load_hull_topology(shape, i);
        if (edge.z != vertex) { continue; }
        let twin = load_hull_topology(shape, edge.y);
        let direction = hull_world_point(shape, body, twin.z) - hull_world_point(shape, body, vertex);
        let length_squared = dot(direction, direction);
        if (length_squared <= 1e-24) { continue; }
        let projection = abs(dot(direction * inverseSqrt(length_squared), normal));
        if (projection < best_projection) {
            best_projection = projection;
            best_edge = i;
        }
    }
    if (best_edge == EMPTY) { return EMPTY; }
    let edge = load_hull_topology(shape, best_edge);
    let twin = load_hull_topology(shape, edge.y);
    let n1 = quat_rotate(body.rot, load_hull_plane(shape, edge.w).xyz);
    let n2 = quat_rotate(body.rot, load_hull_plane(shape, twin.w).xyz);
    return select(twin.w, edge.w, dot(n1, normal) < dot(n2, normal));
}

struct TriangleHullResult { contact: Contact, separated: bool, }

fn hull_triangle_manifold(shape: Shape, body: Body, p1: vec3<f32>, p2: vec3<f32>, p3: vec3<f32>, normal: vec3<f32>, keep: f32) -> TriangleHullResult {
    var result: TriangleHullResult;
    result.contact = empty_contact();
    let tri = array<vec3<f32>,3>(p1,p2,p3);
    let edges = array<vec3<f32>,3>(p2-p1,p3-p2,p1-p3);
    let triangle_sep = dot(support_collider(shape,body,-normal)-p1,normal);
    if (triangle_sep > keep) { result.separated=true; return result; }
    var face_sep = -1e30;
    var face_index = EMPTY;
    var face_normal = normal;
    var face_point = body.pos;
    for (var i=0u; i<hull_plane_count(shape); i++) {
        let out = quat_rotate(body.rot,load_hull_plane(shape,i).xyz);
        let point = support_collider(shape,body,out);
        let separation = min(dot(p1-point,out),min(dot(p2-point,out),dot(p3-point,out)));
        if (separation > face_sep) {
            face_sep=separation; face_index=i; face_normal=-out; face_point=point;
        }
    }
    if (face_sep > keep) { result.separated=true; return result; }
    var edge_sep = -1e30;
    var edge_normal = normal;
    var hull_edge = EMPTY;
    var tri_edge = EMPTY;
    for (var i=0u; i<hull_topology_count(shape); i++) {
        if (i>=load_hull_topology(shape,i).y) { continue; }
        let edge=gauss_hull_edge(shape,body,i);
        if (!edge.valid) { continue; }
        for (var j=0u; j<3u; j++) {
            let cab=dot(edge.u,edges[j]);
            let dab=dot(edge.v,edges[j]);
            let bcd=dot(normal,edge.e);
            if (cab*dab>=0.0 || cab*bcd<=0.0) { continue; }
            if (max(cab*cab,dab*dab)<0.005*0.005*dot(edges[j],edges[j])) { continue; }
            let axis=normalize(mix(edge.u,edge.v,cab/(cab-dab)));
            let separation=dot(axis,tri[j]-edge.q);
            if (separation>edge_sep) {
                edge_sep=separation; edge_normal=-axis; hull_edge=i; tri_edge=j;
            }
        }
    }
    if (edge_sep>keep) { result.separated=true; return result; }
    var polygon: ClipPolygon;
    let hull_reference=face_index!=EMPTY && face_sep>=triangle_sep && dot(face_normal,normal)>=-0.25;
    var reference_normal=normal;
    var reference_point=p1;
    if (hull_reference) {
        reference_normal=face_normal;
        reference_point=face_point;
        polygon.count=3u;
        for(var i=0u;i<3u;i++) {
            polygon.points[i]=tri[i];
            polygon.features[i]=pack_feature(0u,(i+2u)%3u,0u,i);
        }
        let start=find_face_edge(shape,face_index);
        if(start!=EMPTY) {
            var edge=start;
            for(var i=0u;i<32u;i++) {
                let half=load_hull_topology(shape,edge);
                let next=load_hull_topology(shape,half.x);
                let a=hull_world_point(shape,body,half.z);
                let b=hull_world_point(shape,body,next.z);
                let side=normalize(cross(b-a,-reference_normal));
                polygon=clip_polygon_with_features(polygon,side,dot(side,a),edge,1u);
                edge=half.x;
                if(edge==start || polygon.count<3u) { break; }
            }
        } else { polygon.count=0u; }
        if(polygon.count<3u) { polygon.count=0u; }
    } else {
        let incident=hull_triangle_incident_face(shape,body,normal);
        let start=find_face_edge(shape,incident);
        if(start!=EMPTY) {
            var edge=start;
            for(var i=0u;i<32u;i++) {
                let half=load_hull_topology(shape,edge);
                let next=load_hull_topology(shape,half.x);
                polygon.points[polygon.count]=hull_world_point(shape,body,next.z);
                polygon.features[polygon.count]=pack_feature(1u,edge,1u,half.x);
                polygon.count++;
                edge=half.x;
                if(edge==start) { break; }
            }
        }
        for(var i=0u;i<3u;i++) {
            let side=normalize(cross(edges[i],normal));
            polygon=clip_polygon_with_features(polygon,side,dot(side,tri[i]),i,0u);
        }
    }
    var clipped=empty_contact();
    clipped.n=reference_normal;
    var clip_sep=select(1e30,face_sep,hull_reference);
    if(polygon.count>0u) {
        clip_sep=1e30;
        // Visit the complete clipped polygon before reducing to four contacts.
        // A fifth/later vertex may be the only penetrating support witness.
        for(var i=0u;i<polygon.count;i++) {
            let separation=select(dot(polygon.points[i]-reference_point,normal),
                dot(reference_point-polygon.points[i],reference_normal),hull_reference);
            clip_sep=min(clip_sep,separation);
            if(keep==0.0 && separation>0.0) { continue; }
            let point=select(polygon.points[i],polygon.points[i]+separation*reference_normal,hull_reference);
            // Equal temporary anchors make the reducer's separation equal
            // to the raw signed distance; callers rebase these world points.
            append_mesh_point_with_identity(&clipped, vec4<f32>(point,separation),
                vec4<f32>(point,0.0), reference_normal, 0u, polygon.features[i]);
        }
        if(clip_sep>keep) { clipped.count=0u; }
    }
    if(hull_edge!=EMPTY && ((clipped.count==0u && edge_sep>max(face_sep,triangle_sep)) || (clipped.count==1u && edge_sep>clip_sep+LINEAR_SLOP))) {
        clipped=empty_contact();
        let he=gauss_hull_edge(shape,body,hull_edge);
        let pa=tri[tri_edge]; let ea=edges[tri_edge];
        let pb=he.q-he.e; let eb=he.e;
        let w=pa-pb;
        let a11=dot(ea,ea); let a12=-dot(ea,eb); let a21=-a12; let a22=-dot(eb,eb);
        let b1=-dot(ea,w); let b2=-dot(eb,w);
        let det=a11*a22-a12*a21;
        var s=0.0; var t=0.0;
        if(det*det<1.17549435e-35) { s=dot(pb-pa,ea)/a11; }
        else { s=(a22*b1-a12*b2)/det; t=(a11*b2-a21*b1)/det; }
        if(s>=0.0 && s<=1.0 && t>=0.0 && t<=1.0) {
            clipped.count=1u; clipped.n=edge_normal;
            let point=0.5*(pa+s*ea+pb+t*eb);
            set_point(&clipped,0u,vec4<f32>(point,dot(edge_normal,pb-pa)),vec4<f32>(0.0));
            set_feat_at(&clipped,0u,pack_feature(0u,tri_edge,1u,hull_edge));
        }
    }
    result.contact=clipped;
    return result;
}

fn collide_mesh_triangle(mesh_shape: Shape, convex_shape: Shape, mesh: Body, convex: Body,
    mesh_body_index: u32, convex_body_index: u32, triangle_index: u32) -> Contact {
    var result = empty_contact();
    result.a = mesh_body_index;
    result.b = convex_body_index;
    result.friction = mixed_friction_of(mesh, convex);
    result.manifold_link.w = triangle_index + 1u;
    var best_separation = 1e30;
    var best_normal = vec3<f32>(0.0, 1.0, 0.0);
    var material_samples = 0.0;
    var mixed_friction = 0.0;
    var mixed_restitution = 0.0;
    var mesh_tangent_velocity = vec3<f32>(0.0);
    var dominant_material = 0u;
    let triangle = load_mesh_triangle(mesh_shape, triangle_index);
    let p1 = mesh_local_vertex(mesh_shape, mesh, triangle.x);
    let p2 = mesh_local_vertex(mesh_shape, mesh, triangle.y);
    let p3 = mesh_local_vertex(mesh_shape, mesh, triangle.z);
    let normal = normalize(cross(p2 - p1, p3 - p1));
    // Hulls retain shallow backside overlap, as triangle_manifold.c.
    // Sphere/capsule routines use a strict zero-side test instead.
    let backside_limit = select(0.0, -LINEAR_SLOP,
        convex.kind == KIND_BOX || convex.kind == KIND_CONVEX_HULL);
    if (dot(convex.pos - p1, normal) < backside_limit) { return empty_contact(); }
    let material_index = triangle.w >> 8u;
    let flags = triangle.w & 0xffu;
    var radius = 0.0;
    if (convex.kind == KIND_SPHERE) {
        add_mesh_sample_contact(
            &result, mesh, convex, convex_shape, mesh_shape, convex.pos, convex.half.x,
            p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
            &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
            &dominant_material, 0u,
        );
    } else if (convex.kind == KIND_CAPSULE) {
        let axis = capsule_axis(convex);
        radius = convex.half.x;
        add_mesh_sample_contact(
            &result, mesh, convex, convex_shape, mesh_shape, convex.pos - axis, radius,
            p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
            &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
            &dominant_material, 0u,
        );
        add_mesh_sample_contact(
            &result, mesh, convex, convex_shape, mesh_shape, convex.pos, radius,
            p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
            &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
            &dominant_material, 2u,
        );
        add_mesh_sample_contact(
            &result, mesh, convex, convex_shape, mesh_shape, convex.pos + axis, radius,
            p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
            &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
            &dominant_material, 1u,
        );
    } else if (convex.kind == KIND_CONVEX_HULL) {
        let query=hull_triangle_manifold(convex_shape,convex,p1,p2,p3,normal,mesh_speculative_keep(convex_shape,mesh_shape));
        if(query.separated) { return empty_contact(); }
        let raw=query.contact;
        if(raw.count>0u) {
            var patch_separation=1e30;
            for(var i=0u;i<raw.count;i++) { patch_separation=min(patch_separation,ra_at(raw,i).w); }
            for(var i=0u;i<raw.count;i++) {
                let point=ra_at(raw,i);
                consider_mesh_manifold_point(&result,mesh,convex,convex_shape,mesh_shape,
                    point.xyz,point.w,patch_separation,raw.n,normal,material_index,feat_at(raw,i),
                    &best_separation,&best_normal,&material_samples,&mixed_friction,&mixed_restitution,
                    &mesh_tangent_velocity,&dominant_material);
            }
        } else {
        let count = hull_point_count(convex_shape);
        for (var hull_index = 0u; hull_index < count; hull_index++) {
            let local = load_hull_point(convex_shape, hull_index) - convex_shape.local_center;
            let sample = convex.pos + quat_rotate(convex.rot, local);
            add_mesh_sample_contact(
                &result, mesh, convex, convex_shape, mesh_shape, sample, 0.0,
                p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
                &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
                &dominant_material, hull_index,
            );
        }
        if (count == 0u) {
            add_mesh_sample_contact(
                &result, mesh, convex, convex_shape, mesh_shape,
                support_collider(convex_shape, convex, -normal), 0.0,
                p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
                &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
                &dominant_material, 0u,
            );
        }
        clip_hull_face_to_triangle(
            &result, mesh, convex, convex_shape, mesh_shape, p1, p2, p3, normal,
            material_index, &best_separation, &best_normal, &material_samples,
            &mixed_friction, &mixed_restitution, &mesh_tangent_velocity, &dominant_material,
        );
        }
    } else if (convex.kind == KIND_BOX) {
        clip_hull_face_to_triangle(
            &result, mesh, convex, convex_shape, mesh_shape, p1, p2, p3, normal,
            material_index, &best_separation, &best_normal, &material_samples,
            &mixed_friction, &mixed_restitution, &mesh_tangent_velocity, &dominant_material,
        );
    } else {
        add_mesh_sample_contact(
            &result, mesh, convex, convex_shape, mesh_shape,
            support_collider(convex_shape, convex, -normal), 0.0,
            p1, p2, p3, normal, flags, material_index, &best_separation, &best_normal,
            &material_samples, &mixed_friction, &mixed_restitution, &mesh_tangent_velocity,
            &dominant_material, 0u,
        );
    }
    if (result.count == 0u) { return empty_contact(); }
    result.n = best_normal;
    result.lifecycle.y = u32(result._pad_end); // Temporary confirmed/tentative classification.
    if (material_samples > 0.0) {
        let inv_material_samples = 1.0 / material_samples;
        result.friction = mixed_friction * inv_material_samples;
        result._pad_end = mixed_restitution * inv_material_samples;
        result.tangent_velocity =
            quat_rotate(mesh.rot, mesh_tangent_velocity * inv_material_samples)
            - quat_rotate(convex.rot, convex_shape.tangent_velocity);
        result.material_index = min(dominant_material, max(mesh_shape.material_count, 1u) - 1u);
        result.rolling = select(
            0.0,
            convex_shape.rolling * mesh_rolling_radius(convex_shape),
            (params.diagnostic_flags & DIAG_DISABLE_ROLLING) == 0u,
        );
    }
    return result;
}

fn collide_mesh_convex(
    mesh_shape: Shape,
    convex_shape: Shape,
    mesh: Body,
    convex: Body,
    mesh_body_index: u32,
    convex_body_index: u32,
    root_slot: u32,
) -> Contact {
    var list = MeshPatchList(EMPTY, EMPTY, 0u);
    var stack: array<u32, 64>;
    var stack_count = 1u;
    stack[0] = 0u;
    for (var visit = 0u; visit < 2048u && stack_count > 0u; visit++) {
        stack_count = stack_count - 1u;
        let node_index = stack[stack_count];
        if (node_index >= mesh_shape.topology_counts
            || !mesh_node_overlaps(mesh_shape, mesh, convex, node_index)) {
            continue;
        }
        let lower = load_mesh_node_lower(mesh_shape, node_index);
        let upper = load_mesh_node_upper(mesh_shape, node_index);
        let data = bitcast<u32>(lower.w);
        if ((data & 3u) != 3u) {
            let right = node_index + (data >> 2u);
            let left = node_index + 1u;
            mesh_push_child(&stack, &stack_count, mesh_shape, mesh, convex, right);
            mesh_push_child(&stack, &stack_count, mesh_shape, mesh, convex, left);
            continue;
        }
        let triangle_count = data >> 2u;
        let triangle_offset = bitcast<u32>(upper.w);
        for (var leaf_index = 0u; leaf_index < triangle_count; leaf_index++) {
            let triangle_index = triangle_offset + leaf_index;
            if (triangle_index >= mesh_shape.topology_slot) { continue; }
            let candidate = collide_mesh_triangle(mesh_shape, convex_shape, mesh, convex,
                mesh_body_index, convex_body_index, triangle_index);
            if (candidate.count > 0u) {
                let appended = append_mesh_patch(&list, root_slot, candidate, mesh_shape, mesh);
                if (!appended) {
                    discard_mesh_patch_list(list);
                    return load_contact(root_slot);
                }
            }
        }
    }
    if (stack_count > 0u) {
        record_capacity_drop_n(ATOM_CONTACT_DROPPED, ATOM_STICKY_CONTACT_DROPPED, stack_count);
    }
    return finalize_mesh_patch_list(list, root_slot, mesh, convex, mesh_body_index, convex_body_index);
}

fn collide_pair(a_in: Body, b_in: Body, ia_in: u32, ib_in: u32, root_slot: u32) -> Contact {
    if (a_in.kind == KIND_MESH || b_in.kind == KIND_MESH) {
        if (!COLLISION_MESH_ENABLED) {
            // Empty mesh geometry has no triangles. A nonempty mesh reaching
            // this variant is a scheduling error and must fail closed.
            if (params.mesh_triangle_count != 0u) { record_contact_drop(14u); }
            return empty_contact();
        }
        if (a_in.kind == KIND_MESH && b_in.kind != KIND_MESH) {
            return collide_mesh_convex(
                load_shape(a_in._pad_island.x),
                load_shape(b_in._pad_island.x),
                a_in,
                b_in,
                ia_in,
                ib_in, root_slot,
            );
        }
        if (b_in.kind == KIND_MESH && a_in.kind != KIND_MESH) {
            return collide_mesh_convex(
                load_shape(b_in._pad_island.x),
                load_shape(a_in._pad_island.x),
                b_in,
                a_in,
                ib_in,
                ia_in, root_slot,
            );
        }
        return empty_contact();
    }
    if (a_in.kind == KIND_CONVEX_HULL || b_in.kind == KIND_CONVEX_HULL) {
        return collide_convex_pair(a_in, b_in, ia_in, ib_in);
    }
    var a = a_in;
    var b = b_in;
    var ia = ia_in;
    var ib = ib_in;
    if ((b.kind == KIND_SPHERE && a.kind != KIND_SPHERE)
        || (a.kind == KIND_BOX && b.kind == KIND_CAPSULE)) {
        let tmpb = a;
        a = b;
        b = tmpb;
        let tmpi = ia;
        ia = ib;
        ib = tmpi;
    }

    if (a.kind == KIND_BOX && b.kind == KIND_BOX) {
        return collide_boxes(a, b, ia, ib);
    }
    if (a.kind == KIND_CAPSULE && b.kind == KIND_CAPSULE) {
        return collide_capsules(a, b, ia, ib);
    }
    if (a.kind == KIND_CAPSULE && b.kind == KIND_BOX) {
        return collide_capsule_box(a, b, ia, ib);
    }

    var c = empty_contact();
    c.a = ia;
    c.b = ib;
    c.friction = mixed_friction_of(a, b);
    var n = vec3<f32>(0.0, 1.0, 0.0);
    var depth = -1.0;
    var p = 0.5 * (a.pos + b.pos);
    let ka = a.kind;
    let kb = b.kind;
    if (ka == KIND_SPHERE && kb == KIND_SPHERE) {
        let offset = b.pos - a.pos;
        let dist2 = dot(offset, offset);
        let min_d = a.half.x + b.half.x;
        if (dist2 <= min_d * min_d) {
            var dist = sqrt(dist2);
            n = vec3<f32>(0.0, 1.0, 0.0);
            if (dist2 > 1000.0 * 1.175494e-38) {
                n = offset / dist;
            } else {
                dist = 0.0;
            }
            depth = min_d - dist;
            p = 0.5 * ((a.pos + n * a.half.x) + (b.pos - n * b.half.x));
        }
    } else if (ka == KIND_SPHERE && kb != KIND_SPHERE) {
        var closest: vec3<f32>;
        if (kb == KIND_CAPSULE) {
            let ax = capsule_axis(b);
            closest = closest_on_segment(a.pos, b.pos - ax, b.pos + ax);
        } else {
            closest = closest_on_obb(a.pos, b);
        }
        let delta = a.pos - closest;
        let dist = length(delta);
        let rad = a.half.x + select(0.0, b.half.x, kb == KIND_CAPSULE);
        if (dist > 1e-8 && dist <= rad + SPECULATIVE) {
            n = delta / dist;
            depth = rad - dist;
            p = closest + n * select(0.0, b.half.x, kb == KIND_CAPSULE);
        }
    }

    if (depth > -SPECULATIVE) {
        c.count = 1u;
        if (dot(b.pos - a.pos, n) < 0.0) {
            n = -n;
        }
        c.n = n;
        let rA = p - a.pos;
        let rB = p - b.pos;
        let s = -depth;
        let base = s - dot(rB - rA, n);
        set_point(&c, 0u, vec4<f32>(rA, base), vec4<f32>(rB, 0.0));
        finish_manifold(&c, a, b, ia, ib);
    } else {
        c.a = EMPTY;
    }
    return c;
}

fn pair_already(ia: u32, ib: u32, filled: u32) -> bool {
    for (var k = 0u; k < filled; k++) {
        let c = load_contact(k);
        if ((c.a == ia && c.b == ib) || (c.a == ib && c.b == ia)) {
            return true;
        }
    }
    return false;
}

fn pair_queued(ia: u32, ib: u32, npairs: u32) -> bool {
    for (var k = 0u; k < npairs; k++) {
        let packed = load_pair_words(SCR_PAIRS, k);
        let a = packed.y;
        let b = packed.x;
        if ((a == ia && b == ib) || (a == ib && b == ia)) {
            return true;
        }
    }
    return false;
}

fn relative_com(a: Body, b: Body) -> vec3<f32> {
    return quat_inv_rotate(a.rot, b.pos - a.pos);
}

fn recycle_rotation_arc(q: vec4<f32>, extent: vec3<f32>) -> vec3<f32> {
    let v = abs(q.xyz);
    return vec3<f32>(
        v.y * extent.z + v.z * extent.y,
        v.z * extent.x + v.x * extent.z,
        v.x * extent.y + v.y * extent.x,
    );
}

fn make_ghost_pair(ia: u32, ib: u32, a: Body, b: Body) -> Contact {
    var g = empty_contact();
    g.a = ia;
    g.b = ib;
    g.count = 0u;
    g.cached_relative = vec4<f32>(relative_com(a, b), 1.0);
    g.cached_rotation_a = a.rot;
    g.cached_rotation_b = b.rot;
    return g;
}

// Contact invariant: `c.a`/`c.b`, anchors, normal, cached rotations/relative COM,
// and impulse signs all describe the *manifold* endpoint order. Packed pair keys
// stay canonical (min,max shape ids) and do not define manifold orientation.
fn contact_pair_bodies_match(c: Contact, body_a: u32, body_b: u32) -> bool {
    return c.a != EMPTY && c.a == body_a && c.b == body_b;
}

fn contact_pair_bodies_reversed(c: Contact, body_a: u32, body_b: u32) -> bool {
    return c.a != EMPTY && c.a == body_b && c.b == body_a;
}

fn recycle_skip(p: Contact, a: Body, b: Body) -> bool {
    if (((a.flags | b.flags) & FLAG_DISABLE_CONTACT_RECYCLING) != 0u) {
        return false;
    }
    if ((params.diagnostic_flags & DIAG_DISABLE_RECYCLING) != 0u) {
        return false;
    }
    if (((a.flags | b.flags) & FLAG_FIXED_ROTATION) == FLAG_FIXED_ROTATION) {
        return false;
    }
    if (p.a == EMPTY || p.cached_relative.w < 0.5) {
        return false;
    }
    let angle_a = dot(a.rot, p.cached_rotation_a);
    let angle_b = dot(b.rot, p.cached_rotation_b);
    let angular = min(angle_a * angle_a, angle_b * angle_b);
    if (angular <= CONTACT_RECYCLE_ANG) {
        return false;
    }
    let current_relative = relative_com(a, b);
    let d = current_relative - p.cached_relative.xyz;
    let d2 = dot(d, d);
    let was_touching = p.count > 0u && (p.lifecycle.y & CONTACT_TOUCHING) != 0u;
    let recycle_tolerance = select(min(params.contact_recycle_distance, SPECULATIVE), params.contact_recycle_distance, was_touching);
    if (d2 >= recycle_tolerance * recycle_tolerance) {
        return false;
    }
    let distance = sqrt(d2);
    let slack = recycle_tolerance - distance;
    let cached_relative_rotation =
        quat_mul(quat_inv(p.cached_rotation_a), p.cached_rotation_b);
    let current_relative_rotation = quat_mul(quat_inv(a.rot), b.rot);
    let qr = quat_mul(quat_inv(cached_relative_rotation), current_relative_rotation);
    let extent_a = select(a.half, vec3<f32>(0.0), is_static(a));
    let extent_b = select(b.half, vec3<f32>(0.0), is_static(b));
    let arc = 2.0 * length(recycle_rotation_arc(qr, max(extent_a, extent_b)));
    return arc < slack;
}

// Native recycling uses b3MakeMatrixFromQuat followed by b3MulMV.
fn recycle_rotate(q: vec4<f32>, v: vec3<f32>) -> vec3<f32> {
    let xx=q.x*q.x; let yy=q.y*q.y; let zz=q.z*q.z;
    let xy=q.x*q.y; let xz=q.x*q.z; let xw=q.x*q.w;
    let yz=q.y*q.z; let yw=q.y*q.w; let zw=q.z*q.w;
    let cx=vec3<f32>(1.0-2.0*(yy+zz),2.0*(xy+zw),2.0*(xz-yw));
    let cy=vec3<f32>(2.0*(xy-zw),1.0-2.0*(xx+zz),2.0*(yz+xw));
    let cz=vec3<f32>(2.0*(xz+yw),2.0*(yz-xw),1.0-2.0*(xx+yy));
    return (v.x*cx + v.y*cy) + v.z*cz;
}

fn recycle_contact(p: Contact, a: Body, b: Body) -> Contact {
    if (p.count == 0u) {
        return p;
    }
    var c = p;
    let qa = quat_mul(a.rot, quat_inv(p.cached_rotation_a));
    let qb = quat_mul(b.rot, quat_inv(p.cached_rotation_b));
    let dc = b.pos - a.pos;
    // Box3D recycle keeps the cached world normal and original COM anchors,
    // then updates only `mp->separation` (see physics_world.c). Rotating those
    // into the solver double-counts TGS deltas and tilts stacked columns.
    let n = p.n;
    c.n = n;
    var center_a = vec3<f32>(0.0);
    var center_b = vec3<f32>(0.0);
    var weight_sum = 0.0;
    for (var i = 0u; i < p.count; i++) {
        let ra0 = persistent_ra_at(p, i);
        let rb0 = persistent_rb_at(p, i);
        let rotated_a = recycle_rotate(qa, ra0.xyz);
        let rotated_b = recycle_rotate(qb, rb0.xyz);
        let old_s = rb0.w;
        let s = old_s + gyro_dot3(dc + (rotated_b - rotated_a), n);
        let base = s - gyro_dot3(rb0.xyz - ra0.xyz, n);
        let weight = clamp(2.0 - s * (1.0 / SPECULATIVE), MIN_FRICTION_WEIGHT, 1.0);
        center_a = center_a + weight * ra0.xyz;
        center_b = center_b + weight * rb0.xyz;
        weight_sum = weight_sum + weight;
        set_point(&c, i, vec4<f32>(ra0.xyz, base), vec4<f32>(rb0.xyz, rb_at(p, i).w));
    }
    let inv_weight = gyro_recip(max(weight_sum, MIN_FRICTION_WEIGHT));
    c.center_a = inv_weight * center_a;
    c.center_b = inv_weight * center_b;
    return c;
}

fn store_pair(slot: u32, key: vec2<u32>, man: Contact, ia: u32, ib: u32, a: Body, b: Body) {
    let previous = load_contact(slot);
    let generation = select(previous.lifecycle.x + 1u, previous.lifecycle.x, previous.a != EMPTY);
    let local_order = select(
        EMPTY,
        previous.lifecycle.z,
        previous.a != EMPTY && (previous.lifecycle.y & CONTACT_TOUCHING) != 0u,
    );
    let was_touching =
        previous.a != EMPTY && (previous.lifecycle.y & CONTACT_TOUCHING) != 0u;
    if (man.a != EMPTY && man.count > 0u) {
        var touching = man;
        var flags = CONTACT_ALIVE | CONTACT_TOUCHING | (man.lifecycle.y & CONTACT_PERSISTED_MASK);
        if (!was_touching) {
            flags = flags | CONTACT_START_TOUCHING;
        }
        touching.lifecycle = vec4<u32>(
            generation,
            flags,
            local_order,
            0u,
        );
        touching.pair = vec4<u32>(key, 0u, 0u);
        store_contact(slot, touching);
        var child = touching.manifold_link.x;
        for (var i = 1u; i < max(touching.manifold_link.z, 1u); i++) {
            let child_slot = child - 1u;
            var piece = load_contact(child_slot);
            piece.lifecycle = vec4<u32>(generation, CONTACT_ALIVE | CONTACT_TOUCHING | (piece.lifecycle.y & CONTACT_PERSISTED_MASK), EMPTY, 0u);
            piece.pair = vec4<u32>(key, 0u, 0u);
            piece.color = touching.color;
            child = piece.manifold_link.x;
            store_contact(child_slot, piece);
        }
        return;
    }
    var ghost = make_ghost_pair(ia, ib, a, b);
    if (previous.a != EMPTY) {
        ghost.color = previous.color;
    }
    var flags = CONTACT_ALIVE;
    if (was_touching) {
        flags = flags | CONTACT_STOP_TOUCHING;
    }
    ghost.lifecycle = vec4<u32>(generation, flags, local_order, 0u);
    ghost.pair = vec4<u32>(key, 0u, 0u);
    store_contact(slot, ghost);
}

var<workgroup> wg_body_a: array<Body, 64>;
var<workgroup> wg_body_b: array<Body, 64>;

@compute @workgroup_size(64)
fn collide_pairs(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let k = gid.x;
    let npairs = scratch[SCR_UNIQUE_N];
    var ia = 0u;
    var ib = 0u;
    var valid = false;
    if (k < npairs) {
        let packed = load_pair_words(SCR_PAIRS, k);
        ia = packed.x;
        ib = packed.y;
        valid = ia != ib && ia != EMPTY && ib != EMPTY
            && ia < params.shape_count && ib < params.shape_count
            && load_shape(ia).body_index != load_shape(ib).body_index;
    }
    if (valid) {
        wg_body_a[lid] = load_collider(ia);
        wg_body_b[lid] = load_collider(ib);
    }
    workgroupBarrier();
    if (!valid) {
        return;
    }
    let a = wg_body_a[lid];
    let b = wg_body_b[lid];
    let packed = load_pair_words(SCR_PAIRS, k);
    let shape_a = load_shape(ia);
    let shape_b = load_shape(ib);
    let body_a = load_body(shape_a.body_index);
    let body_b = load_body(shape_b.body_index);
    let sensor_pair = ((shape_a.event_flags | shape_b.event_flags) & SHAPE_IS_SENSOR) != 0u;
    let slot = scratch[scr_active_contact() + k];
    if (slot == EMPTY) {
        return;
    }
    let previous = find_prev_contact_key(packed, shape_a.body_index, shape_b.body_index);
    let prev_order_ok = contact_pair_bodies_match(previous, shape_a.body_index, shape_b.body_index)
        || contact_pair_bodies_reversed(previous, shape_a.body_index, shape_b.body_index);
    // physics_world.c: fast mesh contacts must refresh their triangle manifold.
    // The fast flag comes from the preceding GPU step, without a body download.
    let fast_mesh = params.enable_continuous != 0u
        && (shape_a.kind == KIND_MESH || shape_b.kind == KIND_MESH)
        && ((body_a.flags | body_b.flags) & FLAG_FAST) != 0u;
    if (!sensor_pair && prev_order_ok && !fast_mesh && contact_chain_structure_valid(slot)) {
        let recycle_a = load_body(previous.a);
        let recycle_b = load_body(previous.b);
        let count = max(previous.manifold_link.z, 1u);
        var member = slot;
        var can_recycle = true;
        for (var i = 0u; i < count; i++) {
            let old = load_contact(member);
            can_recycle = can_recycle && recycle_skip(old, recycle_a, recycle_b);
            member = old.manifold_link.x - 1u;
        }
        if (can_recycle) {
            member = slot;
            for (var i = 0u; i < count; i++) {
                let old = load_contact(member);
                var recycled = recycle_contact(old, recycle_a, recycle_b);
                recycled.lifecycle.y = CONTACT_ALIVE | CONTACT_RECYCLED | persisted_point_bits(recycled.count);
                if (recycled.count > 0u && (old.lifecycle.y & CONTACT_TOUCHING) != 0u) {
                    recycled.lifecycle.y |= CONTACT_TOUCHING;
                }
                recycled.pair = vec4<u32>(packed, 0u, 0u);
                store_contact(member, recycled);
                member = old.manifold_link.x - 1u;
            }
            return;
        }
    }
    var man = collide_pair(a, b, shape_a.body_index, shape_b.body_index, slot);
    let contained = sensor_pair
        && (point_inside_collider(shape_a, a, b.pos, 0.0)
            || point_inside_collider(shape_b, b, a.pos, 0.0));
    if (contained && man.a == EMPTY) {
        man.a = shape_a.body_index;
        man.b = shape_b.body_index;
        man.count = 1u;
        man.n = vec3<f32>(1.0, 0.0, 0.0);
        man.ra0 = vec4<f32>(0.0, 0.0, 0.0, -1.0);
        man.rb0 = vec4<f32>(0.0);
    }
    if (sensor_pair && man.a != EMPTY) {
        var overlaps = contained;
        var witness = man;
        var piece = man;
        let manifold_count = max(man.manifold_link.z, 1u);
        for (var m = 0u; m < manifold_count; m++) {
            for (var j = 0u; j < piece.count; j++) {
                let ra = ra_at(piece, j);
                let rb = rb_at(piece, j);
                if (ra.w + dot(rb.xyz - ra.xyz, piece.n) <= 0.0) {
                    if (!overlaps) { witness = piece; }
                    overlaps = true;
                }
            }
            if (m + 1u < manifold_count) { piece = load_contact(piece.manifold_link.x - 1u); }
        }
        // Sensors expose a pair overlap, not solver manifolds. Reclaim generated
        // children after considering all normals, including speculative-only roots.
        if (manifold_count > 1u) {
            discard_mesh_patch_list(MeshPatchList(man.manifold_link.x - 1u, EMPTY, manifold_count - 1u));
        }
        if (overlaps) { man = witness; man.manifold_link = vec4<u32>(0u); }
        else { man = empty_contact(); }
    }
    // collide_pair finalizes fresh contacts in body COM coordinates exactly
    // once. Recycled contacts above already carry that same representation.
    // Empty pairs must cache COM transforms too: collider positions can differ
    // by local shape/COM offsets and cannot be compared with recycle_skip's bodies.
    store_pair(
        slot,
        packed,
        man,
        shape_a.body_index,
        shape_b.body_index,
        body_a,
        body_b,
    );
}
// Uniform-grid hash, atomic pair append, radix sort, unique compact.

// The retired packed-pair set already reserves pair_cap() atomic words before
// contact history. Reuse a quarter for spatial buckets in larger worlds. Both
// capacities are powers of two; no identities or contact-history offsets move.
// Small worlds keep their original table and the matrix path keeps ATOM_HASH.
fn spatial_hash_buckets() -> u32 { return max(HASH_BUCKETS, pair_cap() / 4u); }
fn spatial_hash_base() -> u32 {
    return select(ATOM_HASH, ATOM_PAIR_SET, spatial_hash_buckets() > HASH_BUCKETS);
}

fn cell_hash(ix: i32, iy: i32, iz: i32) -> u32 {
    let x = u32(ix) * 73856093u;
    let y = u32(iy) * 19349663u;
    let z = u32(iz) * 83492791u;
    return (x ^ y ^ z) & (spatial_hash_buckets() - 1u);
}

fn cell_coord(v: f32, cs: f32) -> i32 {
    return i32(floor(v / max(cs, 1e-4)));
}

fn body_extent(b: Body) -> vec3<f32> {
    return collider_aabb_extent(b);
}

fn pack_pair(ia: u32, ib: u32) -> vec2<u32> {
    let lo = min(ia, ib);
    let hi = max(ia, ib);
    return vec2<u32>(lo, hi);
}

fn broadphase_pair_allowed(a: Body, b: Body, shape_a: Shape, shape_b: Shape) -> bool {
    if (is_disabled(a) || is_disabled(b)) {
        return false;
    }
    let sensor_a = (shape_a.event_flags & SHAPE_IS_SENSOR) != 0u;
    let sensor_b = (shape_b.event_flags & SHAPE_IS_SENSOR) != 0u;
    if (sensor_a != sensor_b) {
        var sensor = shape_b;
        var visitor = shape_a;
        var visitor_body = a;
        if (sensor_a) {
            sensor = shape_a;
            visitor = shape_b;
            visitor_body = b;
        }
        return (sensor.event_flags & SHAPE_ENABLE_SENSOR_EVENTS) != 0u
            && (visitor.event_flags & SHAPE_ENABLE_SENSOR_EVENTS) != 0u
            && !is_static(visitor_body);
    }
    if (sensor_a) {
        return false;
    }
    if ((shape_a.kind == KIND_MESH && !is_non_dynamic(a))
        || (shape_b.kind == KIND_MESH && !is_non_dynamic(b))) {
        return false;
    }
    return params.enable_contacts != 0u && !(is_non_dynamic(a) && is_non_dynamic(b));
}

// Native child contacts are discovered against child geometry but retained
// while the outer public shape proxies overlap. The original child still owns
// narrowphase, its manifold chain, and the GPU contact generation.
fn pair_lifetime_overlap(a: Body, b: Body, shape_a: Shape, shape_b: Shape) -> bool {
    var bounds_a = a;
    var bounds_b = b;
    if ((shape_a.event_flags & SHAPE_COMPOUND_CHILD) != 0u) {
        bounds_a = load_collider(shape_a._pad_filter.x);
    }
    if ((shape_b.event_flags & SHAPE_COMPOUND_CHILD) != 0u) {
        bounds_b = load_collider(shape_b._pad_filter.x);
    }
    return aabb_overlap(bounds_a, bounds_b);
}

fn contact_has_sensor(c: Contact) -> bool {
    let ia = c.pair.x;
    let ib = c.pair.y;
    return ia < params.shape_count && ib < params.shape_count
        && ((load_shape(ia).event_flags | load_shape(ib).event_flags) & SHAPE_IS_SENSOR) != 0u;
}

fn joint_disables_collision_scan(body_a: u32, body_b: u32) -> bool {
    for (var i = 0u; i < params.joint_count; i++) {
        let joint = joints[i];
        if ((joint.a == body_a && joint.b == body_b)
            || (joint.a == body_b && joint.b == body_a)) {
            if ((joint.flags & JOINT_COLLIDE_CONNECTED) == 0u) {
                return true;
            }
        }
    }
    return false;
}

fn joint_disables_collision(body_a: u32, body_b: u32) -> bool {
    if (params.joint_count == 0u) {
        return false;
    }
    if ((params.diagnostic_flags & (DIAG_JOINT_FILTER_SCAN | DIAG_JOINT_FILTER_OVERFLOW)) != 0u) {
        return joint_disables_collision_scan(body_a, body_b);
    }
    let key_a = min(body_a, body_b);
    let key_b = max(body_a, body_b);
    var h = pair_hash_mix(pair_hash_mix(key_a) ^ key_b);
    let base = joint_filter_base();
    for (var probe = 0u; probe < JOINT_FILTER_PROBE; probe++) {
        let idx = h & (JOINT_FILTER_CAP - 1u);
        let stored = scratch[base + idx * 3u];
        if (stored == EMPTY) {
            return false;
        }
        if (stored == key_a && scratch[base + idx * 3u + 1u] == key_b) {
            return scratch[base + idx * 3u + 2u] != 0u;
        }
        h = h + 1u;
    }
    return joint_disables_collision_scan(body_a, body_b);
}

fn shapes_collide(a: Shape, b: Shape) -> bool {
    if (a.group_index == b.group_index && a.group_index != 0) {
        return a.group_index > 0;
    }
    let a_accepts_b =
        (a.mask_bits_lo & b.category_bits_lo) != 0u
        || (a.mask_bits_hi & b.category_bits_hi) != 0u;
    let b_accepts_a =
        (a.category_bits_lo & b.mask_bits_lo) != 0u
        || (a.category_bits_hi & b.mask_bits_hi) != 0u;
    return a_accepts_b && b_accepts_a;
}

fn append_pair(packed: vec2<u32>) {
    let i = atomicAdd(&atom[ATOM_PAIR_N], 1u);
    if (i < pair_cap()) {
        store_pair_words(SCR_PAIRS, i, packed);
    } else {
        record_capacity_drop(ATOM_PAIR_DROPPED, ATOM_STICKY_PAIR_DROPPED);
    }
}

fn append_new_pair(packed: vec2<u32>) {
    // A retained root emits its pair exactly once in emit_prev_pairs. The hash
    // is immutable throughout candidate generation and supports full identities.
    let previous = find_contact_slot(packed);
    if (previous != EMPTY) {
        if (all(previous_pair_key_for_slot(previous) == packed)) { return; }
    }
    append_pair(packed);
}

fn lower_cell(b: Body) -> vec3<i32> {
    return vec3<i32>(floor(fat_lower(b) / max(params.cell_size, 0.25)));
}

fn cell_span(b: Body, lower: vec3<i32>) -> vec3<u32> {
    let upper = vec3<i32>(floor(fat_upper(b) / max(params.cell_size, 0.25)));
    return vec3<u32>(upper - lower + vec3<i32>(1));
}

fn insertion_cell(b: Body, ordinal: u32) -> vec3<i32> {
    let lower = lower_cell(b);
    let span = cell_span(b, lower);
    return lower + vec3<i32>(i32(ordinal / (span.y * span.z)),
        i32((ordinal / span.z) % span.y), i32(ordinal % span.z));
}

fn insertion_ordinal(b: Body, lower: vec3<i32>, cell: vec3<i32>) -> u32 {
    let span = cell_span(b, lower);
    let offset = vec3<u32>(cell - lower);
    return (offset.x * span.y + offset.y) * span.z + offset.z;
}

// Eight words per allocated shape, after the existing scratch work arrays.
fn fat_lower(b: Body) -> vec3<f32> {
    let base = params.fat_bounds_base + 8u * b._pad_island.x;
    return bitcast<vec3<f32>>(vec3<u32>(scratch[base], scratch[base+1u], scratch[base+2u]));
}
fn fat_upper(b: Body) -> vec3<f32> {
    let base = params.fat_bounds_base + 8u * b._pad_island.x;
    return bitcast<vec3<f32>>(vec3<u32>(scratch[base+4u], scratch[base+5u], scratch[base+6u]));
}
fn update_fat_collider(i: u32, shape: Shape, b: Body) {
    let child = (shape.event_flags & SHAPE_COMPOUND_CHILD) != 0u;
    // Compound child trees contain raw child bounds; public proxies include
    // speculative distance and preserve their larger box until it is escaped.
    let tight_pad = select(SPECULATIVE, 0.0, child);
    let e = collider_aabb_extent(b) + vec3<f32>(tight_pad);
    let lo = b.pos - e;
    let hi = b.pos + e;
    let base = params.fat_bounds_base + 8u * i;
    let initialized = scratch[base+3u] == params.fat_bounds_epoch;
    if (!child && initialized && all(lo >= fat_lower(b)) && all(hi <= fat_upper(b))) { return; }
    var margin = min(MAX_AABB_MARGIN, AABB_MARGIN_FRAC * bound_radius(b));
    if (is_static(b) && !initialized) { margin = SPECULATIVE; }
    if (child) { margin = 0.0; }
    let lower = bitcast<vec3<u32>>(lo - vec3<f32>(margin));
    let upper = bitcast<vec3<u32>>(hi + vec3<f32>(margin));
    scratch[base] = lower.x; scratch[base+1u] = lower.y; scratch[base+2u] = lower.z;
    scratch[base+4u] = upper.x; scratch[base+5u] = upper.y; scratch[base+6u] = upper.z;
    scratch[base+3u] = params.fat_bounds_epoch;
}

fn update_fat_bounds(i: u32) {
    let shape = load_shape(i);
    let current = load_collider(i);
    let base = params.fat_bounds_base + 8u * i;
    if (params.fat_commands_count != 0u && scratch[base+7u] != params.fat_commands_epoch) {
        let heads = params.fat_commands_base + 2u * shape.body_index;
        let first = params.fat_commands_base + scratch[heads];
        let count = scratch[heads+1u];
        for (var j = 0u; j < count; j++) {
            let cmd = first + 8u * j;
            let origin = bitcast<vec3<f32>>(vec3<u32>(scratch[cmd], scratch[cmd+1u], scratch[cmd+2u]));
            let rotation = bitcast<vec4<f32>>(vec4<u32>(scratch[cmd+4u], scratch[cmd+5u], scratch[cmd+6u], scratch[cmd+7u]));
            var pose = current;
            pose.pos = origin + quat_rotate(rotation, shape.local_center);
            pose.rot = rotation;
            if (shape.kind == KIND_CAPSULE && dot(shape.axis, shape.axis) > 1e-12) {
                pose.rot = normalize(quat_mul(rotation, quat_from_x_axis(shape.axis)));
            }
            update_fat_collider(i, shape, pose);
        }
        scratch[base+7u] = params.fat_commands_epoch;
    }
    update_fat_collider(i, shape, current);
}

@compute @workgroup_size(64)
fn clear_broadphase(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i < params.shape_count) { update_fat_bounds(i); }
    if (i < HASH_BUCKETS) {
        atomicStore(&atom[ATOM_HASH + i], EMPTY);
    }
    if (spatial_hash_buckets() > HASH_BUCKETS && i < spatial_hash_buckets()) {
        atomicStore(&atom[spatial_hash_base() + i], EMPTY);
    }
    // Pair producers overwrite every live key; radix consumers are count-bounded.
    // Keep the dirty contact range monotonic: retired slots can still contain
    // previous-touching event keys that must be cleared on the following step.
    let dirty_end = min(atomicLoad(&query[QUERY_CONTACT_HIGH_WATER]), params.contact_capacity);
    if (i < dirty_end) {
        scratch[scr_contact_mark() + i] = 0u;
        // Latest-step event history must survive retirement and slot reuse.
        // Capture before narrowphase writes; child patches share their pair key.
        var previous_key = vec2<u32>(EMPTY);
        if (i < params.contact_capacity) {
            let old = contacts[i];
            if (old.a != EMPTY && old.count > 0u
                && (contact_persistent[i].lifecycle.y & CONTACT_TOUCHING) != 0u) {
                previous_key = contact_persistent[i].pair.xy;
            }
        }
        if (params.remap_history_step != params.physics_step) {
            store_pair_words(scr_previous_touching(), i, previous_key);
        }
    }
    if (i == 0u) {
        if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) != 0u) {
            atomicStore(&atom[arrayLength(&atom) - MESH_TRACE_WORDS], 0u);
        }
        atomicStore(&atom[ATOM_PAIR_N], 0u);
        atomicStore(&atom[ATOM_INSERT_N], 0u);
        atomicStore(&atom[ATOM_PAIR_DROPPED], 0u);
        atomicStore(&atom[ATOM_INSERT_DROPPED], 0u);
        atomicStore(&atom[ATOM_CONTACT_DROPPED], 0u);
        atomicStore(&atom[ATOM_HASH_HOP_DROPPED], 0u);
        if ((params.diagnostic_flags & DIAG_FORCE_CAPACITY_LOSS) != 0u) {
            record_capacity_drop(ATOM_PAIR_DROPPED, ATOM_STICKY_PAIR_DROPPED);
            record_capacity_drop(ATOM_INSERT_DROPPED, ATOM_STICKY_INSERT_DROPPED);
            record_contact_drop(6u);
            record_capacity_drop(ATOM_HASH_HOP_DROPPED, ATOM_STICKY_HASH_HOP_DROPPED);
        }
        atomicStore(&atom[ATOM_STATIC_N], 0u);
        scratch[SCR_PAIR_N] = 0u;
        scratch[SCR_INSERT_N] = 0u;
        scratch[SCR_UNIQUE_N] = 0u;
        scratch[SCR_NCONTACTS] = 0u;
        scratch[SCR_STATIC_N] = 0u;
    }
}

const MAX_STATIC_HASH_CELLS: u32 = 8u;
fn scr_static_list() -> u32 { return scr_radix_out(); }

fn shape_insert_count(b: Body) -> u32 {
    let cs = max(params.cell_size, 0.25);
    let lo = fat_lower(b);
    let hi = fat_upper(b);
    let x0 = cell_coord(lo.x, cs);
    let x1 = cell_coord(hi.x, cs);
    let y0 = cell_coord(lo.y, cs);
    let y1 = cell_coord(hi.y, cs);
    let z0 = cell_coord(lo.z, cs);
    let z1 = cell_coord(hi.z, cs);
    return u32(x1 - x0 + 1) * u32(y1 - y0 + 1) * u32(z1 - z0 + 1);
}

@compute @workgroup_size(64)
fn collect_fat_statics(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.shape_count) {
        return;
    }
    if ((load_shape(i).event_flags & SHAPE_PUBLIC_PROXY) != 0u) { return; }
    let b = load_collider(i);
    if (!is_static(b)) {
        return;
    }
    if (shape_insert_count(b) <= MAX_STATIC_HASH_CELLS) {
        return;
    }
    let out = atomicAdd(&atom[ATOM_STATIC_N], 1u);
    if (out < pair_cap()) {
        scratch[scr_static_list() + out] = i;
    }
}

@compute @workgroup_size(1)
fn finish_fat_statics() {
    scratch[SCR_STATIC_N] = atomicLoad(&atom[ATOM_STATIC_N]);
}

@compute @workgroup_size(64)
fn hash_insert(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.shape_count || params.enable_contacts == 0u) {
        return;
    }
    if ((load_shape(i).event_flags & SHAPE_PUBLIC_PROXY) != 0u) { return; }
    let b = load_collider(i);
    if (is_static(b) && shape_insert_count(b) > MAX_STATIC_HASH_CELLS) {
        return;
    }
    let cs = max(params.cell_size, 0.25);
    let lo = fat_lower(b);
    let hi = fat_upper(b);
    let x0 = cell_coord(lo.x, cs);
    let x1 = cell_coord(hi.x, cs);
    let y0 = cell_coord(lo.y, cs);
    let y1 = cell_coord(hi.y, cs);
    let z0 = cell_coord(lo.z, cs);
    let z1 = cell_coord(hi.z, cs);
    let insert_count = u32(x1 - x0 + 1) * u32(y1 - y0 + 1) * u32(z1 - z0 + 1);
    let first_slot = atomicAdd(&atom[ATOM_INSERT_N], insert_count);
    let accepted = min(insert_count, params.insert_capacity - min(first_slot, params.insert_capacity));
    if (accepted < insert_count) {
        record_capacity_drop_n(ATOM_INSERT_DROPPED, ATOM_STICKY_INSERT_DROPPED, insert_count - accepted);
    }
    var local_slot = 0u;
    for (var ix = x0; ix <= x1; ix++) {
        for (var iy = y0; iy <= y1; iy++) {
            for (var iz = z0; iz <= z1; iz++) {
                if (local_slot >= accepted) {
                    return;
                }
                let slot = first_slot + local_slot;
                local_slot = local_slot + 1u;
                let h = cell_hash(ix, iy, iz);
                scratch[scr_ins_body() + slot] = i;
                // Preserve exact cell identity, not just its colliding hash bucket.
                scratch[scr_ins_cell() + slot] = local_slot - 1u;
                let old = atomicExchange(&atom[spatial_hash_base() + h], slot);
                scratch[scr_ins_next() + slot] = old;
            }
        }
    }
}

@compute @workgroup_size(1)
fn write_insert_indirect() {
    let n = min(atomicLoad(&atom[ATOM_INSERT_N]), params.insert_capacity);
    write_group_indirect(SCR_INDIRECT_COLLIDE, (n + 63u) / 64u);
}

@compute @workgroup_size(256)
fn write_radix_indirect(@builtin(local_invocation_index) lid: u32) {
    let n = min(atomicLoad(&atom[ATOM_PAIR_N]), pair_cap());
    if (lid == 0u) {
        scratch[SCR_PAIR_N] = n;
        let groups = max((n + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE, 1u);
        scratch[SCR_RADIX_GROUP_N] = groups;
        write_count_indirect(SCR_INDIRECT_RADIX, n, RADIX_GROUP_SIZE);
    }
    scratch[scr_radix_base() + lid] = 0u;
}

@compute @workgroup_size(64)
fn emit_hash_pairs(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let slot = gid.x;
    let nins = min(atomicLoad(&atom[ATOM_INSERT_N]), params.insert_capacity);
    if (slot >= nins) {
        return;
    }
    let ia = scratch[scr_ins_body() + slot];
    let a = load_collider(ia);
    let a_lower = lower_cell(a);
    let cell = insertion_cell(a, scratch[scr_ins_cell() + slot]);
    let h = cell_hash(cell.x, cell.y, cell.z);
    var other = atomicLoad(&atom[spatial_hash_base() + h]);
    var hops = 0u;
    loop {
        if (other == EMPTY || hops >= 2048u) {
            if (other != EMPTY) {
                record_capacity_drop(ATOM_HASH_HOP_DROPPED, ATOM_STICKY_HASH_HOP_DROPPED);
            }
            break;
        }
        let ib = scratch[scr_ins_body() + other];
        if (ib < ia) {
            let b = load_collider(ib);
            let shape_a = load_shape(ia);
            let shape_b = load_shape(ib);
            let b_lower = lower_cell(b);
            let owner = max(a_lower, b_lower);
            if (all(cell == owner)
                && scratch[scr_ins_cell() + other] == insertion_ordinal(b, b_lower, owner)
                && a._pad_island.y != b._pad_island.y
                && broadphase_pair_allowed(a, b, shape_a, shape_b)
                && !joint_disables_collision(a._pad_island.y, b._pad_island.y)
                && shapes_collide(shape_a, shape_b)
                && aabb_overlap(a, b)) {
                append_new_pair(pack_pair(ia, ib));
            }
        }
        other = scratch[scr_ins_next() + other];
        hops = hops + 1u;
    }
}

@compute @workgroup_size(64)
fn emit_static_pairs(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.shape_count) {
        return;
    }
    let a = load_collider(i);
    if (is_static(a)) {
        return;
    }
    let nstatic = min(scratch[SCR_STATIC_N], pair_cap());
    for (var j = 0u; j < nstatic; j++) {
        let jb = scratch[scr_static_list() + j];
        let b = load_collider(jb);
        if (b._pad_island.y == a._pad_island.y) {
            continue;
        }
        let shape_a = load_shape(i);
        let shape_b = load_shape(jb);
        if (!broadphase_pair_allowed(a, b, shape_a, shape_b)) {
            continue;
        }
        if (joint_disables_collision(a._pad_island.y, b._pad_island.y)) {
            continue;
        }
        if (!shapes_collide(shape_a, shape_b)) {
            continue;
        }
        if (aabb_overlap(a, b)) {
            append_new_pair(pack_pair(i, jb));
        }
    }
}

@compute @workgroup_size(1)
fn write_occupied_indirect() {
    let n = min(scratch[SCR_OCCUPIED_N], params.contact_capacity);
    write_group_indirect(SCR_INDIRECT_OCCUPIED, (n + 63u) / 64u);
}

fn previous_pair_key(i: u32) -> vec2<u32> {
    let occupied_count = min(scratch[SCR_OCCUPIED_N], params.contact_capacity);
    if (i >= occupied_count) {
        return vec2<u32>(EMPTY);
    }
    let k = scratch[scr_occupied_contact() + i];
    if (k >= params.contact_capacity) {
        return vec2<u32>(EMPTY);
    }
    return previous_pair_key_for_slot(k);
}

fn previous_pair_key_for_slot(k: u32) -> vec2<u32> {
    let p = load_contact(k);
    if (p.manifold_link.y != 0u) { return vec2<u32>(EMPTY); }
    let key = p.pair.xy;
    let ia = key.x;
    let ib = key.y;
    if (p.a == EMPTY || p.b == EMPTY || p.a == p.b
        || ia >= params.shape_count || ib >= params.shape_count) {
        return vec2<u32>(EMPTY);
    }
    let a = load_collider(ia);
    let b = load_collider(ib);
    let shape_a = load_shape(ia);
    let shape_b = load_shape(ib);
    if (!broadphase_pair_allowed(a, b, shape_a, shape_b)) {
        return vec2<u32>(EMPTY);
    }
    if (joint_disables_collision(a._pad_island.y, b._pad_island.y)) {
        return vec2<u32>(EMPTY);
    }
    if (!shapes_collide(shape_a, shape_b)) {
        return vec2<u32>(EMPTY);
    }
    if (!pair_lifetime_overlap(a, b, shape_a, shape_b)) {
        return vec2<u32>(EMPTY);
    }
    return key;
}

@compute @workgroup_size(64)
fn emit_prev_pairs(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let key=previous_pair_key(gid.x);
    if (key.x!=EMPTY) { append_pair(key); }
}

var<workgroup> radix_counts: array<atomic<u32>, 256>;
var<workgroup> radix_keys: array<u32, 256>;
var<workgroup> radix_scan_a: array<u32, 256>;
var<workgroup> radix_scan_b: array<u32, 256>;

fn retained_pair_count() -> u32 {
    return min(atomicLoad(&atom[ATOM_PAIR_N]), pair_cap());
}

fn pair_is_unique(i: u32, n: u32) -> u32 {
    if (i >= n) {
        return 0u;
    }
    let p = load_pair_words(SCR_PAIRS, i);
    if (p.x == EMPTY) {
        return 0u;
    }
    if (i == 0u) {
        return 1u;
    }
    return select(0u, 1u, any(p != load_pair_words(SCR_PAIRS, i - 1u)));
}

fn workgroup_exclusive_scan_256(lid: u32, value: u32) -> u32 {
    radix_scan_a[lid] = value;
    workgroupBarrier();
    var source_a = true;
    for (var offset = 1u; offset < 256u; offset = offset << 1u) {
        var prior = 0u;
        if (source_a) {
            if (lid >= offset) {
                prior = radix_scan_a[lid - offset];
            }
            radix_scan_b[lid] = radix_scan_a[lid] + prior;
        } else {
            if (lid >= offset) {
                prior = radix_scan_b[lid - offset];
            }
            radix_scan_a[lid] = radix_scan_b[lid] + prior;
        }
        source_a = !source_a;
        workgroupBarrier();
    }
    let inclusive = select(radix_scan_b[lid], radix_scan_a[lid], source_a);
    return inclusive - value;
}

// Prefix any number of histogram groups in uniform 256-group chunks. All
// lanes carry the same total; barriers protect scan storage between chunks.
var<workgroup> group_scan_total: u32;
fn scan_group_counts(lid: u32, groups: u32, source: u32, destination: u32) -> u32 {
    var carry = 0u;
    for (var first = 0u; first < groups; first += 256u) {
        let group = first + lid;
        var count = 0u;
        if (group < groups) { count = scratch[source + group]; }
        let exclusive = workgroup_exclusive_scan_256(lid, count);
        if (group < groups) { scratch[destination + group] = carry + exclusive; }
        if (lid == 255u) { group_scan_total = exclusive + count; }
        workgroupBarrier();
        carry += group_scan_total;
        workgroupBarrier();
    }
    return carry;
}

@compute @workgroup_size(256)
fn compact_unique_histogram(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = retained_pair_count();
    let keep = pair_is_unique(gid.x, n);
    let exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (lid == 255u) {
        scratch[scr_radix_base() + group.x] = exclusive + keep;
    }
}

@compute @workgroup_size(256)
fn compact_unique_bases(@builtin(local_invocation_index) lid: u32) {
    // compact_unique_histogram writes only the live workgroup prefix.
    // Radix leftover offsets in the unused suffix must not be scanned.
    let groups = (retained_pair_count() + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE;
    let total = scan_group_counts(lid, groups, scr_radix_base(), scr_radix_hist());
    if (lid == 255u) {
        scratch[SCR_POW2] = total;
        if (total > pair_cap()) {
            record_capacity_drop_n(ATOM_PAIR_DROPPED, ATOM_STICKY_PAIR_DROPPED, total - pair_cap());
        }
        let bounded = min(total, pair_cap());
        scratch[SCR_UNIQUE_N] = bounded;
        scratch[SCR_NCONTACTS] = bounded;
        write_count_indirect(SCR_INDIRECT_COLLIDE, bounded, 64u);
        write_count_indirect(SCR_INDIRECT_PREPARE, bounded, 64u);
    }
}

@compute @workgroup_size(256)
fn compact_unique_scatter(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = retained_pair_count();
    let keep = pair_is_unique(gid.x, n);
    let local_exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (keep != 0u) {
        let dst = scratch[scr_radix_hist() + group.x] + local_exclusive;
        store_pair_words(scr_radix_out(), dst, load_pair_words(SCR_PAIRS, gid.x));
    }
}

@compute @workgroup_size(256)
fn compact_unique_gather(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let w = min(scratch[SCR_UNIQUE_N], pair_cap());
    if (gid.x < w) {
        store_pair_words(SCR_PAIRS, gid.x, load_pair_words(scr_radix_out(), gid.x));
    }
}

fn radix_histogram_impl(gid: u32, lid: u32, group: u32, shift: u32, from_output: bool) {
    let source_output = from_output != (shift >= 32u && params.shape_count > 65536u && params.shape_count <= 16777216u);
    atomicStore(&radix_counts[lid], 0u);
    workgroupBarrier();
    let n = retained_pair_count();
    if (gid < n) {
        let key = select(
            load_pair_words(SCR_PAIRS, gid),
            load_pair_words(scr_radix_out(), gid),
            source_output,
        );
        atomicAdd(&radix_counts[pair_digit(key, shift)], 1u);
    }
    workgroupBarrier();
    scratch[scr_radix_hist() + group * RADIX_BUCKETS + lid] =
        atomicLoad(&radix_counts[lid]);
}

@compute @workgroup_size(256)
fn radix_histogram_0(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 0u, false);
}

@compute @workgroup_size(256)
fn radix_histogram_8(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 8u, true);
}

@compute @workgroup_size(256)
fn radix_histogram_16(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 16u, false);
}

@compute @workgroup_size(256)
fn radix_histogram_24(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 24u, true);
}

fn radix_live_groups() -> u32 {
    return min(scratch[SCR_RADIX_GROUP_N], radix_groups());
}

@compute @workgroup_size(256)
fn radix_bucket_bases(@builtin(local_invocation_index) bucket: u32) {
    // Sum only the groups the current histogram dispatch initialized. Inactive
    // rows keep leftover prefixes from a larger pair list or the previous digit.
    let groups = radix_live_groups();
    if (groups == 0u) {
        return;
    }
    var total = 0u;
    for (var group = 0u; group < groups; group++) {
        total = total + scratch[scr_radix_hist() + group * RADIX_BUCKETS + bucket];
    }
    radix_scan_a[bucket] = total;
    workgroupBarrier();
    var source_a = true;
    for (var offset = 1u; offset < RADIX_BUCKETS; offset = offset << 1u) {
        var prior = 0u;
        if (source_a) {
            if (bucket >= offset) {
                prior = radix_scan_a[bucket - offset];
            }
            radix_scan_b[bucket] = radix_scan_a[bucket] + prior;
        } else {
            if (bucket >= offset) {
                prior = radix_scan_b[bucket - offset];
            }
            radix_scan_a[bucket] = radix_scan_b[bucket] + prior;
        }
        workgroupBarrier();
        source_a = !source_a;
    }
    // Eight scan rounds leave the inclusive totals in scan_a.
    var base = 0u;
    if (bucket > 0u) {
        base = radix_scan_a[bucket - 1u];
    }
    scratch[scr_radix_base() + bucket] = base;
}

@compute @workgroup_size(256)
fn radix_group_prefix(@builtin(local_invocation_index) bucket: u32) {
    let groups = radix_live_groups();
    if (groups == 0u) {
        return;
    }
    var offset = scratch[scr_radix_base() + bucket];
    for (var group = 0u; group < groups; group++) {
        let at = scr_radix_hist() + group * RADIX_BUCKETS + bucket;
        let count = scratch[at];
        scratch[at] = offset;
        offset = offset + count;
    }
}

fn radix_scatter_impl(gid: u32, lid: u32, group: u32, shift: u32, from_output: bool) {
    let source_output = from_output != (shift >= 32u && params.shape_count > 65536u && params.shape_count <= 16777216u);
    let n = retained_pair_count();
    var key = vec2<u32>(EMPTY);
    if (gid < n) {
        key = select(
            load_pair_words(SCR_PAIRS, gid),
            load_pair_words(scr_radix_out(), gid),
            source_output,
        );
    }
    radix_keys[lid] = pair_digit(key, shift);
    workgroupBarrier();
    if (gid < n) {
        let bucket = pair_digit(key, shift);
        var rank = 0u;
        for (var i = 0u; i < lid; i++) {
            if (radix_keys[i] == bucket) {
                rank = rank + 1u;
            }
        }
        let out = scratch[scr_radix_hist() + group * RADIX_BUCKETS + bucket] + rank;
        if (out >= n) {
            record_capacity_drop(ATOM_PAIR_DROPPED, ATOM_STICKY_PAIR_DROPPED);
        } else if (source_output) {
            store_pair_words(SCR_PAIRS, out, key);
        } else {
            store_pair_words(scr_radix_out(), out, key);
        }
    }
}

@compute @workgroup_size(256)
fn radix_scatter_0(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 0u, false);
}

@compute @workgroup_size(256)
fn radix_scatter_8(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 8u, true);
}

@compute @workgroup_size(256)
fn radix_scatter_16(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 16u, false);
}

@compute @workgroup_size(256)
fn radix_scatter_24(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 24u, true);
}

// Read-only probes are safe in parallel. New contact-table claims remain
// ordered by the sorted pair list so tombstone reuse cannot change persistent
// pair identity with workgroup scheduling.

@compute @workgroup_size(256)
fn radix_histogram_32(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 32u, false);
}

@compute @workgroup_size(256)
fn radix_histogram_40(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 40u, true);
}

@compute @workgroup_size(256)
fn radix_histogram_48(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 48u, false);
}

@compute @workgroup_size(256)
fn radix_histogram_56(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_histogram_impl(gid.x, lid, group.x, 56u, true);
}

@compute @workgroup_size(256)
fn radix_scatter_32(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 32u, false);
}

@compute @workgroup_size(256)
fn radix_scatter_40(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 40u, true);
}

@compute @workgroup_size(256)
fn radix_scatter_48(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 48u, false);
}

@compute @workgroup_size(256)
fn radix_scatter_56(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    radix_scatter_impl(gid.x, lid, group.x, 56u, true);
}
@compute @workgroup_size(64)
fn find_existing_contact_slots(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let count = min(scratch[SCR_UNIQUE_N], pair_cap());
    if (i >= count) {
        return;
    }
    let slot = find_contact_slot(load_pair_words(SCR_PAIRS, i));
    scratch[scr_active_contact() + i] = slot;
    if (slot != EMPTY) {
        if (!contact_chain_structure_valid(slot)) { return; }
        var member = slot;
        let count = max(contacts[slot].manifold_link.z, 1u);
        for (var j = 0u; j < count; j++) {
            scratch[scr_contact_mark() + member] = 1u;
            let next = contacts[member].manifold_link.x;
            if (next != 0u) { member = next - 1u; }
        }
    }
}

fn slot_is_free(slot: u32) -> u32 {
    if (slot >= params.contact_capacity) {
        return 0u;
    }
    return select(0u, 1u, contacts[slot].a == EMPTY && scratch[scr_contact_mark() + slot] == 0u);
}

// Convex pairs need exactly SCR_MISSING_N root slots. All slots at or above
// the high-water mark have never been allocated, so this prefix contains enough
// free entries while preserving the same lowest-free-slot assignment as a full
// scan. Mesh narrowphase may allocate additional child patches: retain the full
// pool for that path until its extra demand can be bounded independently.
fn free_scan_limit() -> u32 {
    if (params.mesh_triangle_count > 0u) { return params.contact_capacity; }
    let high = min(atomicLoad(&query[QUERY_CONTACT_HIGH_WATER]), params.contact_capacity);
    return high + min(scratch[SCR_MISSING_N], params.contact_capacity - high);
}

@compute @workgroup_size(256)
fn alloc_free_histogram(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = free_scan_limit();
    let keep = select(0u, slot_is_free(gid.x), gid.x < n);
    let exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (lid == 255u) {
        scratch[scr_radix_base() + group.x] = exclusive + keep;
    }
}

@compute @workgroup_size(256)
fn alloc_free_bases(@builtin(local_invocation_index) lid: u32) {
    if (scratch[SCR_MISSING_N] == 0u && params.mesh_triangle_count == 0u) {
        if (lid == 0u) {
            scratch[SCR_FREE_N] = 0u;
        }
        return;
    }
    let groups = (free_scan_limit() + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE;
    let total = scan_group_counts(lid, groups, scr_radix_base(), scr_radix_base());
    if (lid == 255u) {
        scratch[SCR_FREE_N] = total;
    }
}

@compute @workgroup_size(256)
fn alloc_free_scatter(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = free_scan_limit();
    let keep = select(0u, slot_is_free(gid.x), gid.x < n);
    let local_exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (keep != 0u) {
        let dst = scratch[scr_radix_base() + group.x] + local_exclusive;
        scratch[scr_radix_out() + dst] = gid.x;
    }
}

fn pair_needs_slot(i: u32, n: u32) -> u32 {
    if (i >= n) {
        return 0u;
    }
    return select(0u, 1u, scratch[scr_active_contact() + i] == EMPTY);
}

@compute @workgroup_size(256)
fn alloc_missing_histogram(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = min(scratch[SCR_UNIQUE_N], pair_cap());
    let keep = pair_needs_slot(gid.x, n);
    let exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (lid == 255u) {
        scratch[scr_radix_base() + group.x] = exclusive + keep;
    }
}

@compute @workgroup_size(256)
fn alloc_missing_bases(@builtin(local_invocation_index) lid: u32) {
    let n = min(scratch[SCR_UNIQUE_N], pair_cap());
    let groups = (n + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE;
    let total = scan_group_counts(lid, groups, scr_radix_base(), scr_radix_base());
    if (lid == 255u) {
        scratch[SCR_MISSING_N] = total;
    }
}

@compute @workgroup_size(256)
fn alloc_missing_scatter(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n = min(scratch[SCR_UNIQUE_N], pair_cap());
    let keep = pair_needs_slot(gid.x, n);
    let local_exclusive = workgroup_exclusive_scan_256(lid, keep);
    if (keep != 0u) {
        let dst = scratch[scr_radix_base() + group.x] + local_exclusive;
        scratch[scr_radix_hist() + dst] = gid.x;
    }
}

@compute @workgroup_size(64)
fn alloc_prepare_keys(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= min(scratch[SCR_MISSING_N], scratch[SCR_FREE_N])) { return; }
    let pair_i = scratch[scr_radix_hist() + i];
    let slot = scratch[scr_radix_out() + i];
    prepare_contact_identity(slot, load_pair_words(SCR_PAIRS, pair_i));
}

@compute @workgroup_size(64)
fn alloc_bind_slots(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let missing = scratch[SCR_MISSING_N];
    let free_n = scratch[SCR_FREE_N];
    if (i >= missing) {
        return;
    }
    if (i >= free_n) {
        record_contact_drop(7u);
        return;
    }
    let pair_i = scratch[scr_radix_hist() + i];
    let slot = scratch[scr_radix_out() + i];
    let key = load_pair_words(SCR_PAIRS, pair_i);
    scratch[scr_active_contact() + pair_i] = slot;
    scratch[scr_contact_mark() + slot] = 1u;
    if (!publish_contact_slot(key, slot)) {
        scratch[scr_active_contact() + pair_i] = EMPTY;
        scratch[scr_contact_mark() + slot] = 0u;
        record_contact_drop(8u);
    }
}

@compute @workgroup_size(64)
fn retire_stale_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let occupied_count = min(scratch[SCR_OCCUPIED_N], params.contact_capacity);
    if (i >= occupied_count) {
        return;
    }
    let slot = scratch[scr_occupied_contact() + i];
    if (slot >= params.contact_capacity || scratch[scr_contact_mark() + slot] != 0u) {
        return;
    }
    let c = load_contact(slot);
    if (c.a == EMPTY) {
        return;
    }
    let key = c.pair.xy;
    let ia = key.x;
    let ib = key.y;
    var retire = c.a >= params.body_count || c.b >= params.body_count || c.a == c.b
        || ia >= params.shape_count || ib >= params.shape_count;
    if (!retire) {
        let a = load_collider(ia);
        let b = load_collider(ib);
        let shape_a = load_shape(ia);
        let shape_b = load_shape(ib);
        retire = !broadphase_pair_allowed(a, b, shape_a, shape_b)
            || joint_disables_collision(a._pad_island.y, b._pad_island.y)
            || !shapes_collide(shape_a, shape_b)
            || !pair_lifetime_overlap(a, b, shape_a, shape_b);
    }
    if (retire) {
        if (!retire_manifold_children(slot)) { return; }
        var retired = empty_contact();
        retired.lifecycle.x = c.lifecycle.x;
        store_contact(slot, retired);
        retire_contact_key(c.pair.xy);
    } else {
        // A retained pair can be absent from this frame's candidate list only
        // when candidate capacity was exhausted. Keep it discoverable so a
        // later non-overflowing frame can emit it again.
        atomicAdd(&query[67u], max(contacts[slot].manifold_link.z, 1u));
        if (contacts[slot].count > 0u && (contact_persistent[slot].lifecycle.y & CONTACT_TOUCHING) != 0u) {
            atomicAdd(&query[68u], 1u);
        }
        if (native_countable_root(slot)) { atomicAdd(&query[69u], 1u); }
        let out = atomicAdd(&atom[ATOM_OCCUPIED_N], 1u);
        if (out < params.contact_capacity) {
            scratch[scr_next_occupied() + out] = slot;
        }
    }
}

fn native_countable_root(slot: u32) -> bool {
    let key = contact_persistent[slot].pair.xy;
    let a = key.x;
    let b = key.y;
    if (a >= params.shape_count || b >= params.shape_count) { return false; }
    let sa = load_shape(a); let sb = load_shape(b);
    return ((sa.event_flags | sb.event_flags) & (SHAPE_IS_SENSOR | SHAPE_PUBLIC_PROXY)) == 0u
        && !(sa.kind == KIND_MESH && sb.kind == KIND_MESH);
}

@compute @workgroup_size(1)
fn begin_occupied_contacts() {
    atomicStore(&query[67u], 0u); // allocated root + child manifold slots
    atomicStore(&query[68u], 0u); // touching roots, including sensors
    atomicStore(&query[69u], 0u); // allocated non-sensor supported contact roots
    atomicStore(&atom[ATOM_OCCUPIED_N], 0u);
}

var<workgroup> metric_patch_sum: atomic<u32>;
var<workgroup> metric_touching_sum: atomic<u32>;
var<workgroup> metric_non_sensor_sum: atomic<u32>;

@compute @workgroup_size(64)
fn collect_occupied_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>,
                             @builtin(local_invocation_index) lid: u32) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if (lid == 0u) {
        atomicStore(&metric_patch_sum, 0u);
        atomicStore(&metric_touching_sum, 0u);
        atomicStore(&metric_non_sensor_sum, 0u);
    }
    workgroupBarrier();
    let i = gid.x;
    let count = min(scratch[SCR_UNIQUE_N], pair_cap());
    if (i < count) {
        let slot = scratch[scr_active_contact() + i];
        if (slot != EMPTY) {
            atomicAdd(&metric_patch_sum, max(contacts[slot].manifold_link.z, 1u));
            if (native_countable_root(slot)) { atomicAdd(&metric_non_sensor_sum, 1u); }
            if (contacts[slot].count > 0u && (contact_persistent[slot].lifecycle.y & CONTACT_TOUCHING) != 0u) {
                atomicAdd(&metric_touching_sum, 1u);
            }
            let out = atomicAdd(&atom[ATOM_OCCUPIED_N], 1u);
            if (out < params.contact_capacity) {
                scratch[scr_next_occupied() + out] = slot;
            }
        }
    }
    workgroupBarrier();
    if (lid == 0u) {
        atomicAdd(&query[67u], atomicLoad(&metric_patch_sum));
        atomicAdd(&query[68u], atomicLoad(&metric_touching_sum));
        atomicAdd(&query[69u], atomicLoad(&metric_non_sensor_sum));
    }
}

fn graph_contact_live(slot: u32) -> bool {
    if (slot == EMPTY || slot >= params.contact_capacity) {
        return false;
    }
    let h = contacts[slot];
    if (h.a == EMPTY || h.count == 0u || h.manifold_link.y != 0u) {
        return false;
    }
    let life = contact_persistent[slot].lifecycle;
    if ((life.y & CONTACT_TOUCHING) == 0u) {
        return false;
    }
    if (scratch[scr_contact_mark() + slot] == 0u) {
        return false;
    }
    let ia = contact_persistent[slot].pair.x;
    let ib = contact_persistent[slot].pair.y;
    return ia < params.shape_count && ib < params.shape_count
        && ((load_shape(ia).event_flags | load_shape(ib).event_flags) & SHAPE_IS_SENSOR) == 0u;
}

@compute @workgroup_size(1)
fn write_unique_indirect() {
    let n = min(scratch[SCR_UNIQUE_N], pair_cap());
    write_count_indirect(SCR_INDIRECT_RADIX, n, RADIX_GROUP_SIZE);
}

@compute @workgroup_size(1)
fn write_alloc_indirects() {
    let missing = scratch[SCR_MISSING_N];
    // Reserve the prefix for primary pairs; children use only the remainder.
    atomicStore(&atom[ATOM_MANIFOLD_ALLOC], missing);
    let need_free_list = missing > 0u || params.mesh_triangle_count > 0u;
    write_count_indirect(SCR_INDIRECT_PREPARE, missing, 64u);
    let free_groups = select(
        0u,
        (free_scan_limit() + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE,
        need_free_list,
    );
    write_group_indirect(SCR_INDIRECT_RADIX, free_groups);
    if (!need_free_list) {
        scratch[SCR_FREE_N] = 0u;
    }
}

@compute @workgroup_size(64)
fn graph_clear_meta(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    atomicStore(&atom[atom_jacobi() + i], 0u);
    atomicStore(&atom[atom_jacobi() + params.body_count + i], select(0u,EMPTY,(params.diagnostic_flags & DIAG_STATIC_DEGREE_TWO_PROOF)!=0u));
    atomicStore(&atom[atom_jacobi() + 2u * params.body_count + i], 0u);
    atomicStore(&atom[atom_jacobi() + 3u * params.body_count + i], 0u);
    scratch[color_body_base() + i] = 0u;
    scratch[fused_flag_base() + i] = 0u;
    let slots = fused_slots_base() + 8u * i;
    for (var k = 0u; k < 8u; k++) {
        scratch[slots + k] = EMPTY;
    }
}

@compute @workgroup_size(1)
fn graph_reset_colors() {
    for (var col = 0u; col < 24u; col++) {
        scratch[SCR_COLOR + col] = 0u;
        atomicStore(&atom[atom_graph_color() + col], 0u);
    }
    scratch[SCR_FUSED_N] = 0u;
    scratch[SCR_DYN_DYN_N] = 0u;
    scratch[SCR_GRAPH_STATIC_N] = 0u;
    scratch[SCR_GRAPH_STATIC_MAX] = 0u;
    atomicStore(&atom[atom_dyn_dyn()], 0u);
}

fn graph_kind(unique_i: u32) -> u32 {
    return scratch[scr_radix_hist() + unique_i] & 3u;
}

fn graph_dyn_body(unique_i: u32) -> u32 {
    return scratch[scr_radix_hist() + unique_i] >> 2u;
}

@compute @workgroup_size(64)
fn graph_classify(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let np = min(scratch[SCR_UNIQUE_N], pair_cap());
    if (i >= np) {
        return;
    }
    let slot = scratch[scr_active_contact() + i];
    var packed = 0u;
    if (graph_contact_live(slot)) {
        let h = contacts[slot];
        let a_dyn = !is_non_dynamic(load_body(h.a));
        let b_dyn = !is_non_dynamic(load_body(h.b));
        if (a_dyn != b_dyn) {
            let dyn = select(h.b, h.a, a_dyn);
            packed = 1u | (dyn << 2u);
        } else if (a_dyn && b_dyn) {
            packed = 2u | (h.a << 2u);
            atomicOr(&atom[atom_jacobi() + 2u * params.body_count + h.a], 1u);
            atomicOr(&atom[atom_jacobi() + 2u * params.body_count + h.b], 1u);
        }
    }
    scratch[scr_radix_hist() + i] = packed;
}

@compute @workgroup_size(64)
fn graph_mark_edges(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.joint_count) {
        return;
    }
    let j = joints[i];
    if (j.kind != JOINT_NONE && j.kind != JOINT_FILTER) {
        if (j.a < params.body_count) {
            atomicOr(&atom[atom_jacobi() + 2u * params.body_count + j.a], 1u);
        }
        if (j.b < params.body_count) {
            atomicOr(&atom[atom_jacobi() + 2u * params.body_count + j.b], 1u);
        }
    }
}

fn graph_keep_kind(i: u32, n: u32, kind: u32) -> u32 {
    if (i >= n) {
        return 0u;
    }
    return select(0u, 1u, graph_kind(i) == kind);
}

// Hash-cell IDs are dead after emit_hash_pairs. Reuse their first two group
// arrays here; neither output list may alias prefixes during parallel scatter.
fn scr_graph_paired_prefix() -> u32 { return scr_ins_cell(); }
@compute @workgroup_size(256)
fn graph_compact_paired_histogram(@builtin(global_invocation_id) dispatch_gid:vec3<u32>,
    @builtin(local_invocation_index) lid:u32,@builtin(workgroup_id) dispatch_group:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n=min(scratch[SCR_UNIQUE_N],pair_cap());
    for (var kind=1u;kind<=2u;kind++) {
        let keep=graph_keep_kind(gid.x,n,kind);
        let exclusive=workgroup_exclusive_scan_256(lid,keep);
        if (lid==255u) {scratch[scr_graph_paired_prefix()+(kind-1u)*radix_groups()+group.x]=exclusive+keep;}
    }
}
@compute @workgroup_size(256)
fn graph_compact_paired_bases(@builtin(local_invocation_index) lid:u32) {
    let n=min(scratch[SCR_UNIQUE_N],pair_cap());
    let groups=(n+RADIX_GROUP_SIZE-1u)/RADIX_GROUP_SIZE;
    for (var kind=1u;kind<=2u;kind++) {
        let base=scr_graph_paired_prefix()+(kind-1u)*radix_groups();
        let total=scan_group_counts(lid,groups,base,base);
        if (lid==255u) {scratch[select(SCR_GRAPH_STATIC_N,SCR_DYN_DYN_N,kind==2u)]=min(total,pair_cap());}
    }
}
@compute @workgroup_size(256)
fn graph_compact_paired_scatter(@builtin(global_invocation_id) dispatch_gid:vec3<u32>,
    @builtin(local_invocation_index) lid:u32,@builtin(workgroup_id) dispatch_group:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    let n=min(scratch[SCR_UNIQUE_N],pair_cap());
    for (var kind=1u;kind<=2u;kind++) {
        let keep=graph_keep_kind(gid.x,n,kind);
        let exclusive=workgroup_exclusive_scan_256(lid,keep);
        if (keep!=0u) {
            let dst=scratch[scr_graph_paired_prefix()+(kind-1u)*radix_groups()+group.x]+exclusive;
            if (dst<pair_cap()) {scratch[select(scr_radix_out(),scr_next_occupied(),kind==2u)+dst]=gid.x;}
        }
    }
}

@compute @workgroup_size(64)
fn graph_count_static_degree(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n) {
        return;
    }
    let unique_i = scratch[scr_radix_out() + i];
    let dyn = graph_dyn_body(unique_i);
    if (dyn < params.body_count) {
        let prev = atomicAdd(&atom[atom_jacobi() + 3u * params.body_count + dyn], 1u);
        atomicMax(&atom[atom_dyn_dyn()], prev + 1u);
        if ((params.diagnostic_flags & DIAG_STATIC_DEGREE_TWO_PROOF)!=0u) {
            atomicMin(&atom[atom_jacobi()+params.body_count+dyn],unique_i);
        }
    }
}

@compute @workgroup_size(1)
fn graph_finish_static_degree() {
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    let max_deg = atomicLoad(&atom[atom_dyn_dyn()]);
    scratch[SCR_GRAPH_STATIC_MAX] = max_deg;
    if ((params.diagnostic_flags & DIAG_STATIC_DEGREE_ONE_PROOF) != 0u && max_deg > 1u && n > 0u) {
        atomicStore(&atom[ATOM_GRAPH_PROOF_FAIL], 1u);
        record_contact_drop(9u);
    }
    if ((params.diagnostic_flags & DIAG_STATIC_DEGREE_TWO_PROOF)!=0u && max_deg>2u && n>0u) {
        atomicStore(&atom[ATOM_GRAPH_PROOF_FAIL],1u);record_contact_drop(9u);
    }
    if (max_deg > 1u && n > 0u) {
        let groups = (n + RADIX_GROUP_SIZE - 1u) / RADIX_GROUP_SIZE;
        scratch[SCR_RADIX_GROUP_N] = groups;
        write_count_indirect(SCR_INDIRECT_RADIX, n, RADIX_GROUP_SIZE);
    } else {
        scratch[SCR_RADIX_GROUP_N] = 0u;
        write_group_indirect(SCR_INDIRECT_RADIX, 0u);
    }
    write_count_indirect(SCR_INDIRECT_STATIC, n, 64u);
}

fn graph_sort_count() -> u32 {
    return min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
}

fn graph_sort_src(from_color: bool) -> u32 {
    return select(scr_radix_out(), color_contact_base(), from_color);
}

fn graph_sort_dst(from_color: bool) -> u32 {
    return select(color_contact_base(), scr_radix_out(), from_color);
}

fn graph_static_color(rank: u32) -> u32 {
    if (rank >= OVERFLOW_COLOR - 1u) {
        return OVERFLOW_COLOR;
    }
    return OVERFLOW_COLOR - 1u - rank;
}

// Carry full unique indices through both stable sorts. contacts[].color is a
// temporary full-width body key during the first sort, then the actual color.
// The overflow list is not populated yet; preserve the canonical input order
// there so the second stable sort has (color, unique_i) order, not (color, body).
fn graph_sort_key(unique_i: u32) -> u32 {
    return contacts[scratch[scr_active_contact() + unique_i]].color;
}
fn graph_static_order_base() -> u32 {
    return color_contact_base() + OVERFLOW_COLOR * params.contact_capacity;
}
@compute @workgroup_size(64)
fn graph_pack_static_keys(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if ((params.diagnostic_flags & DIAG_STATIC_DEGREE_TWO_PROOF)!=0u) {return;}
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n || scratch[SCR_GRAPH_STATIC_MAX] <= 1u) {
        return;
    }
    let unique_i = scratch[scr_radix_out() + i];
    let dyn = graph_dyn_body(unique_i);
    scratch[graph_static_order_base() + i] = unique_i;
    contacts[scratch[scr_active_contact() + unique_i]].color = dyn;
}

fn graph_radix_histogram_impl(gid: u32, lid: u32, group: u32, shift: u32, from_color: bool) {
    atomicStore(&radix_counts[lid], 0u);
    workgroupBarrier();
    let n = graph_sort_count();
    if (gid < n) {
        let key = graph_sort_key(scratch[graph_sort_src(from_color) + gid]);
        atomicAdd(&radix_counts[(key >> shift) & 255u], 1u);
    }
    workgroupBarrier();
    scratch[scr_radix_hist() + group * RADIX_BUCKETS + lid] =
        atomicLoad(&radix_counts[lid]);
}

@compute @workgroup_size(256)
fn graph_radix_histogram_0(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_histogram_impl(gid.x, lid, group.x, 0u, false);
}

@compute @workgroup_size(256)
fn graph_radix_histogram_8(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_histogram_impl(gid.x, lid, group.x, 8u, true);
}

@compute @workgroup_size(256)
fn graph_radix_histogram_16(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_histogram_impl(gid.x, lid, group.x, 16u, false);
}

@compute @workgroup_size(256)
fn graph_radix_histogram_24(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_histogram_impl(gid.x, lid, group.x, 24u, true);
}

fn graph_radix_scatter_impl(gid: u32, lid: u32, group: u32, shift: u32, from_color: bool) {
    let n = graph_sort_count();
    var unique_i = EMPTY;
    var key = EMPTY;
    if (gid < n) {
        unique_i = scratch[graph_sort_src(from_color) + gid];
        key = graph_sort_key(unique_i);
    }
    radix_keys[lid] = key;
    workgroupBarrier();
    if (gid < n) {
        let bucket = (key >> shift) & 255u;
        var rank = 0u;
        for (var j = 0u; j < lid; j++) {
            if (((radix_keys[j] >> shift) & 255u) == bucket) {
                rank = rank + 1u;
            }
        }
        let out = scratch[scr_radix_hist() + group * RADIX_BUCKETS + bucket] + rank;
        if (out >= n) {
            record_contact_drop(10u);
        } else {
            scratch[graph_sort_dst(from_color) + out] = unique_i;
        }
    }
}

@compute @workgroup_size(256)
fn graph_radix_scatter_0(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_scatter_impl(gid.x, lid, group.x, 0u, false);
}

@compute @workgroup_size(256)
fn graph_radix_scatter_8(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_scatter_impl(gid.x, lid, group.x, 8u, true);
}

@compute @workgroup_size(256)
fn graph_radix_scatter_16(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_scatter_impl(gid.x, lid, group.x, 16u, false);
}

@compute @workgroup_size(256)
fn graph_radix_scatter_24(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
    @builtin(workgroup_id) dispatch_group: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 256u), 0u, 0u);
    let group = vec3<u32>(linear_workgroup_id(dispatch_group), 0u, 0u);
    if (group.x >= radix_groups()) { return; }
    graph_radix_scatter_impl(gid.x, lid, group.x, 24u, true);
}

@compute @workgroup_size(64)
fn graph_mark_static_starts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n || scratch[SCR_GRAPH_STATIC_MAX] <= 1u) {
        return;
    }
    let dyn = graph_sort_key(scratch[scr_radix_out() + i]);
    var prev = EMPTY;
    if (i > 0u) {
        prev = graph_sort_key(scratch[scr_radix_out() + i - 1u]);
    }
    if (i == 0u || dyn != prev) {
        atomicStore(&atom[atom_jacobi() + params.body_count + dyn], i);
    }
}

@compute @workgroup_size(64)
fn graph_encode_static_colors(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n || scratch[SCR_GRAPH_STATIC_MAX] <= 1u) {
        return;
    }
    let unique_i = scratch[scr_radix_out() + i];
    let dyn = graph_sort_key(unique_i);
    let start = atomicLoad(&atom[atom_jacobi() + params.body_count + dyn]);
    let rank = i - start;
    let col = graph_static_color(rank);
    if (dyn < params.body_count && col < OVERFLOW_COLOR) {
        atomicOr(&atom[atom_jacobi() + dyn], 1u << col);
    }
    contacts[scratch[scr_active_contact() + unique_i]].color = col;
    scratch[scr_radix_out() + i] = scratch[graph_static_order_base() + i];
}

@compute @workgroup_size(64)
fn graph_mark_color_starts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n || scratch[SCR_GRAPH_STATIC_MAX] <= 1u) {
        return;
    }
    let col = graph_sort_key(scratch[scr_radix_out() + i]);
    var prev = EMPTY;
    if (i > 0u) {
        prev = graph_sort_key(scratch[scr_radix_out() + i - 1u]);
    }
    if (i == 0u || col != prev) {
        scratch[SCR_COLOR + col] = i;
    }
}

// Degree-one static edges share one reserved color with local index = compact i.
// Ranked edges were sorted by (body, pair) then (color, unique) so scatter is
// conflict-free without a scene-wide scalar loop.
@compute @workgroup_size(64)
fn graph_assign_static(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let n = min(scratch[SCR_GRAPH_STATIC_N], pair_cap());
    if (i >= n) {
        return;
    }
    if ((params.diagnostic_flags & DIAG_STATIC_DEGREE_TWO_PROOF)!=0u) {
        if (scratch[SCR_GRAPH_STATIC_MAX]>2u) {return;} // sticky proof failure already reported
        let unique_i=scratch[scr_radix_out()+i];
        let dyn=graph_dyn_body(unique_i);
        if (dyn>=params.body_count) {return;}
        let first=atomicLoad(&atom[atom_jacobi()+params.body_count+dyn]);
        let rank=select(1u,0u,unique_i==first);
        let col=graph_static_color(rank);
        atomicOr(&atom[atom_jacobi()+dyn],1u<<col);
        let local=atomicAdd(&atom[atom_graph_color()+col],1u);
        let slot=scratch[scr_active_contact()+unique_i];
        if (local<params.contact_capacity) {
            scratch[color_contact_base()+col*params.contact_capacity+local]=slot;
            store_graph_meta(slot,col,local);
        } else {record_contact_drop(9u);}
        return;
    }
    let max_deg = scratch[SCR_GRAPH_STATIC_MAX];
    if (max_deg <= 1u) {
        let unique_i = scratch[scr_radix_out() + i];
        let slot = scratch[scr_active_contact() + unique_i];
        let dyn = graph_dyn_body(unique_i);
        let col = OVERFLOW_COLOR - 1u;
        if (dyn < params.body_count) {
            atomicOr(&atom[atom_jacobi() + dyn], 1u << col);
        }
        if (i < params.contact_capacity) {
            scratch[color_contact_base() + col * params.contact_capacity + i] = slot;
            store_graph_meta(slot, col, i);
        }
        if (i == 0u) {
            atomicStore(&atom[atom_graph_color() + col], n);
        }
        return;
    }
    let unique_i = scratch[scr_radix_out() + i];
    let col = graph_sort_key(unique_i);
    let slot = scratch[scr_active_contact() + unique_i];
    let start = scratch[SCR_COLOR + col];
    let local = i - start;
    atomicAdd(&atom[atom_graph_color() + col], 1u);
    if (local < params.contact_capacity) {
        scratch[color_contact_base() + col * params.contact_capacity + local] = slot;
        store_graph_meta(slot, col, local);
    }
}

fn color_dynamic_contact(unique_i: u32) {
    let slot = scratch[scr_active_contact() + unique_i];
    let h = contacts[slot];
    // This entry is owned by the single canonical greedy walk. No other
    // invocation can change either occupancy mask between these loads/stores.
    let occupied = atomicLoad(&atom[atom_jacobi() + h.a])
        | atomicLoad(&atom[atom_jacobi() + h.b]);
    let available = (~occupied) & ((1u << DYNAMIC_COLOR_COUNT) - 1u);
    var col = OVERFLOW_COLOR;
    if (available != 0u) {
        col = firstTrailingBit(available);
        let bit = 1u << col;
        atomicOr(&atom[atom_jacobi() + h.a], bit);
        atomicOr(&atom[atom_jacobi() + h.b], bit);
    }
    let local = atomicAdd(&atom[atom_graph_color() + col], 1u);
    if (local < params.contact_capacity) {
        scratch[color_contact_base() + col * params.contact_capacity + local] = slot;
        store_graph_meta(slot, col, local);
    }
}

@compute @workgroup_size(1)
fn graph_assign_dynamic() {
    // Pair-key greedy walk. Per-island packing was a measured no-go: mixed
    // stacks paid extra compact cost and Dominoes is one writable component.
    let n = min(scratch[SCR_DYN_DYN_N], pair_cap());
    for (var i = 0u; i < n; i++) {
        color_dynamic_contact(scratch[scr_next_occupied() + i]);
    }
    finish_dynamic_graph();
}

// Keep the canonical greedy order, but cooperatively fetch and publish each
// batch. Only its at-most-512 endpoints occupy shared memory, so this cache does
// not impose a world-size limit. One lane makes the ordered color decisions;
// the others hide global-memory latency without racing on endpoint masks.
var<workgroup> graph_batch_keys: array<atomic<u32>, 1024>;
var<workgroup> graph_batch_masks: array<atomic<u32>, 1024>;
var<workgroup> graph_batch_a: array<u32, 256>;
var<workgroup> graph_batch_b: array<u32, 256>;
var<workgroup> graph_batch_slots: array<u32, 256>;
var<workgroup> graph_batch_choices: array<vec2<u32>, 256>;
var<workgroup> graph_batch_counts: array<u32, 24>;
var<workgroup> graph_batch_n: u32;

fn graph_batch_endpoint(body: u32) -> u32 {
    var at = pair_hash_mix(body) & 1023u;
    loop {
        let insert = atomicCompareExchangeWeak(&graph_batch_keys[at], EMPTY, body);
        if (insert.exchanged) {
            atomicStore(&graph_batch_masks[at], atomicLoad(&atom[atom_jacobi() + body]));
            return at;
        }
        if (insert.old_value == body) { return at; }
        // A weak exchange may fail spuriously on an empty entry. Retry there
        // instead of allowing duplicate owners for the same endpoint.
        if (insert.old_value != EMPTY) { at = (at + 1u) & 1023u; }
    }
    return 0u;
}

// Cache the coloring function, not contacts or solver state. Each batch stores
// its endpoints, incoming masks, chosen colors and within-batch local indices.
// Global color offsets may change and are added afresh on every invocation.
// This shares the optional memo allocation with the small-world kernel; distinct
// validity tags make switching between implementations invalidate old contents.
const GRAPH_BATCH_MEMO_TAG: u32 = 0x424b5431u;
var<workgroup> graph_batch_start_counts: array<u32, 24>;
var<workgroup> graph_batch_added: array<atomic<u32>, 24>;
var<workgroup> graph_batch_changed: atomic<u32>;
var<workgroup> graph_batch_reuse: u32;
var<workgroup> graph_batch_cache_ready: u32;
var<workgroup> graph_batch_buckets: array<u32, 256>;
var<workgroup> graph_batch_first_bucket: u32;
var<workgroup> graph_batch_partition: atomic<u32>;
var<workgroup> graph_batch_partition_count: u32;

fn graph_batch_memo_base() -> u32 {
    return 261u + 54u * (params.shape_base_u32 / 32u) + 2u * params.contact_capacity;
}
// Four cached chunks per 128-body range. Denser ranges still use the exact
// greedy fallback for their remaining chunks. Edge order is never changed.
fn graph_batch_memo_groups() -> u32 { return 4u * ((params.shape_base_u32 / 32u + 127u) / 128u); }
fn graph_batch_memo_edges() -> u32 { return graph_batch_memo_base() + 8u + graph_batch_memo_groups(); }
fn graph_batch_memo_end() -> u32 { return graph_batch_memo_edges() + 6u * 256u * graph_batch_memo_groups(); }

@compute @workgroup_size(256)
fn graph_assign_dynamic_batched(@builtin(local_invocation_index) lane: u32) {
    let memo = graph_batch_memo_base();
    let cache = arrayLength(&query) >= graph_batch_memo_end()
        && (params.diagnostic_flags & DIAG_REBUILD_GRAPH) == 0u;
    if (lane < 24u) {
        graph_batch_counts[lane] = atomicLoad(&atom[atom_graph_color() + lane]);
    }
    if (lane == 0u) {
        graph_batch_n = min(scratch[SCR_DYN_DYN_N], pair_cap());
        graph_batch_cache_ready = 0u;
        if (cache) {
            graph_batch_cache_ready = select(0u, 1u, atomicLoad(&query[memo]) == GRAPH_BATCH_MEMO_TAG);
            if (graph_batch_cache_ready == 0u) {
                atomicStore(&query[memo + 1u], 0u);
                atomicStore(&query[memo + 2u], 0u);
            }
        }
    }
    workgroupBarrier();
    let n = workgroupUniformLoad(&graph_batch_n);
    let ready = workgroupUniformLoad(&graph_batch_cache_ready) != 0u;
    if (cache && !ready) {
        // Invalidate unvisited batches too, including after switching from the
        // small-world memo layout and later growing the active edge list.
        for (var batch = lane; batch < graph_batch_memo_groups(); batch += 256u) {
            atomicStore(&query[memo + 8u + batch], 0u);
        }
    }
    storageBarrier();
    var base = 0u;
    var previous_bucket = EMPTY;
    var chunk = 0u;
    loop {
        if (base >= n) { break; }
        let remaining = min(256u, n - base);
        for (var at = lane; at < 1024u; at += 256u) {
            atomicStore(&graph_batch_keys[at], EMPTY);
        }
        if (lane < 24u) {
            graph_batch_start_counts[lane] = graph_batch_counts[lane];
            atomicStore(&graph_batch_added[lane], 0u);
        }
        if (lane == 0u) { atomicStore(&graph_batch_partition, remaining); }
        workgroupBarrier();
        if (lane < remaining) {
            let slot = scratch[scr_active_contact() + scratch[scr_next_occupied() + base + lane]];
            let h = contacts[slot];
            graph_batch_slots[lane] = slot;
            graph_batch_a[lane] = graph_batch_endpoint(h.a);
            graph_batch_b[lane] = graph_batch_endpoint(h.b);
            let bucket = (max(max(h.a, h.b), 1u) - 1u) / 128u;
            graph_batch_buckets[lane] = bucket;
            if (lane == 0u) { graph_batch_first_bucket = bucket; }
        }
        workgroupBarrier();
        let bucket = workgroupUniformLoad(&graph_batch_first_bucket);
        if (cache && lane < remaining && graph_batch_buckets[lane] != bucket) {
            atomicMin(&graph_batch_partition, lane);
        }
        workgroupBarrier();
        if (lane == 0u) { graph_batch_partition_count = atomicLoad(&graph_batch_partition); }
        workgroupBarrier();
        let count = workgroupUniformLoad(&graph_batch_partition_count);
        if (bucket == previous_bucket) { chunk++; } else { chunk = 0u; }
        previous_bucket = bucket;
        let cache_batch = 4u * bucket + chunk;
        let batch_cache = cache && chunk < 4u;
        let header = memo + 8u + cache_batch;
        if (lane == 0u) {
            atomicStore(&graph_batch_changed, 1u);
            if (batch_cache && ready) {
                atomicStore(&graph_batch_changed, select(1u, 0u, atomicLoad(&query[header]) == count));
            }
        }
        workgroupBarrier();
        if (batch_cache && lane < count) {
            let a = graph_batch_a[lane];
            let b = graph_batch_b[lane];
            let record = graph_batch_memo_edges() + 6u * (cache_batch * 256u + lane);
            let body_a = atomicLoad(&graph_batch_keys[a]);
            let body_b = atomicLoad(&graph_batch_keys[b]);
            let mask_a = atomicLoad(&graph_batch_masks[a]) & ((1u << DYNAMIC_COLOR_COUNT) - 1u);
            let mask_b = atomicLoad(&graph_batch_masks[b]) & ((1u << DYNAMIC_COLOR_COUNT) - 1u);
            if (atomicLoad(&query[record]) != body_a || atomicLoad(&query[record + 1u]) != body_b
                || atomicLoad(&query[record + 2u]) != mask_a || atomicLoad(&query[record + 3u]) != mask_b) {
                atomicStore(&graph_batch_changed, 1u);
            }
            // Each lane owns one record; no other lane reads this record.
            atomicStore(&query[record], body_a);
            atomicStore(&query[record + 1u], body_b);
            atomicStore(&query[record + 2u], mask_a);
            atomicStore(&query[record + 3u], mask_b);
        }
        workgroupBarrier();
        if (lane == 0u) { graph_batch_reuse = select(0u, 1u, atomicLoad(&graph_batch_changed) == 0u); }
        workgroupBarrier();
        let reuse = workgroupUniformLoad(&graph_batch_reuse) != 0u;
        if (reuse) {
            if (lane < count) {
                let record = graph_batch_memo_edges() + 6u * (cache_batch * 256u + lane);
                let col = atomicLoad(&query[record + 4u]);
                let local = atomicLoad(&query[record + 5u]);
                graph_batch_choices[lane] = vec2<u32>(col, graph_batch_start_counts[col] + local);
                atomicAdd(&graph_batch_added[col], 1u);
                if (col < DYNAMIC_COLOR_COUNT) {
                    atomicOr(&graph_batch_masks[graph_batch_a[lane]], 1u << col);
                    atomicOr(&graph_batch_masks[graph_batch_b[lane]], 1u << col);
                }
            }
        } else if (lane == 0u) {
            for (var i = 0u; i < count; i++) {
                let a = graph_batch_a[i];
                let b = graph_batch_b[i];
                let mask_a = atomicLoad(&graph_batch_masks[a]);
                let mask_b = atomicLoad(&graph_batch_masks[b]);
                let available = (~(mask_a | mask_b)) & ((1u << DYNAMIC_COLOR_COUNT) - 1u);
                var col = OVERFLOW_COLOR;
                if (available != 0u) {
                    col = firstTrailingBit(available);
                    // Only lane zero writes masks in the fallback walk.
                    atomicStore(&graph_batch_masks[a], mask_a | (1u << col));
                    atomicStore(&graph_batch_masks[b], mask_b | (1u << col));
                }
                graph_batch_choices[i] = vec2<u32>(col, graph_batch_counts[col]);
                graph_batch_counts[col]++;
            }
        }
        workgroupBarrier();
        if (reuse && lane < 24u) {
            graph_batch_counts[lane] += atomicLoad(&graph_batch_added[lane]);
        }
        if (lane < count) {
            let choice = graph_batch_choices[lane];
            let slot = graph_batch_slots[lane];
            if (choice.y < params.contact_capacity) {
                scratch[color_contact_base() + choice.x * params.contact_capacity + choice.y] = slot;
                store_graph_meta(slot, choice.x, choice.y);
            } else { record_contact_drop(9u); }
            if (batch_cache) {
                let record = graph_batch_memo_edges() + 6u * (cache_batch * 256u + lane);
                atomicStore(&query[record + 4u], choice.x);
                atomicStore(&query[record + 5u], choice.y - graph_batch_start_counts[choice.x]);
            }
        }
        if (batch_cache && lane == 0u) {
            atomicStore(&query[header], count);
            atomicAdd(&query[memo + select(2u, 1u, reuse)], 1u);
        }
        for (var at = lane; at < 1024u; at += 256u) {
            let body = atomicLoad(&graph_batch_keys[at]);
            if (body != EMPTY) { atomicStore(&atom[atom_jacobi() + body], atomicLoad(&graph_batch_masks[at])); }
        }
        storageBarrier();
        workgroupBarrier();
        base += count;
    }
    if (lane < 24u) {
        atomicStore(&atom[atom_graph_color() + lane], graph_batch_counts[lane]);
    }
    if (cache && lane == 0u) { atomicStore(&query[memo], GRAPH_BATCH_MEMO_TAG); }
    storageBarrier();
    workgroupBarrier();
    if (lane == 0u) { finish_dynamic_graph(); }
}

fn finish_dynamic_graph() {
    var mx = 0u;
    var colored = 0u;
    for (var col = 0u; col < 24u; col++) {
        let count = atomicLoad(&atom[atom_graph_color() + col]);
        scratch[SCR_COLOR + col] = count;
        colored = colored + count;
        if (col < OVERFLOW_COLOR) {
            mx = max(mx, (count + 63u) / 64u);
        }
    }
    let np_all = min(scratch[SCR_NCONTACTS], pair_cap());
    if (params.solver_mode == SOLVER_JACOBI) {
        write_group_indirect(SCR_INDIRECT_COLLIDE, (np_all + 63u) / 64u);
    } else {
        let use_one_group_wave = mx <= 1u;
        write_group_indirect(SCR_INDIRECT_COLLIDE, select(0u, 1u, use_one_group_wave));
        for (var c = 0u; c < 24u; c++) {
            let n_col = scratch[SCR_COLOR + c];
            var groups = (n_col + 63u) / 64u;
            if (c == OVERFLOW_COLOR) {
                groups = select(0u, 1u, n_col > 0u);
            }
            let base = SCR_INDIRECT_COLOR + c * 4u;
            write_group_indirect(base, select(groups, 0u, use_one_group_wave));
        }
    }
    scratch[SCR_INDIRECT_COLLIDE + 3u] = 0u;
    write_count_indirect(SCR_INDIRECT_PREPARE, np_all, 64u);
    write_count_indirect(
        SCR_INDIRECT_ISLAND,
        max(np_all, params.joint_count),
        ISLAND_WORKGROUP_SIZE,
    );
}

@compute @workgroup_size(64)
fn finish_occupied_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>,
                            @builtin(num_workgroups) groups: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let count = min(atomicLoad(&atom[ATOM_OCCUPIED_N]), params.contact_capacity);
    // Retirement and collection are complete before this dispatch. Publish
    // the new list without overwriting any input being read by those passes.
    // Strided ownership preserves list order across workgroups. Consumers run
    // after this dispatch completes; they cannot use the count mid-publication.
    for (var i = gid.x; i < count; i += groups.x * groups.y * 64u) {
        scratch[scr_occupied_contact() + i] = scratch[scr_next_occupied() + i];
    }
    if (gid.x != 0u) { return; }
    scratch[SCR_OCCUPIED_N] = count;
    // Dynamic colors wider than one workgroup remain parallel next step.
    // Static colors always remain parallel; query word 71 is this hint only.
    var prefix = 0u;
    for (var col = 0u; col < DYNAMIC_COLOR_COUNT; col++) {
        if (scratch[SCR_COLOR + col] > 64u) { prefix = col + 1u; }
    }
    atomicStore(&query[71u], prefix);
}

@compute @workgroup_size(1)
fn color_and_compact() {
    let np = min(scratch[SCR_NCONTACTS], pair_cap());
    let occupancy = color_body_base();
    // Box3D removes stopped constraints with swap-with-last. This preserves
    // insertion order for untouched constraints and updates exactly one moved
    // local index instead of rebuilding every color from pair-key order.
    for (var col = 0u; col < 24u; col++) {
        var i = 0u;
        loop {
            let count = scratch[SCR_COLOR + col];
            if (i >= count) {
                break;
            }
            let slot = scratch[color_contact_base() + col * params.contact_capacity + i];
            var c = load_contact(slot);
            let keep = c.a != EMPTY
                && c.manifold_link.y == 0u
                && c.count > 0u
                && (c.lifecycle.y & CONTACT_TOUCHING) != 0u
                && !contact_has_sensor(c)
                && scratch[scr_contact_mark() + slot] != 0u
                && (params.diagnostic_flags & DIAG_REBUILD_GRAPH) == 0u;
            if (keep) {
                i = i + 1u;
                continue;
            }
            if (col != OVERFLOW_COLOR && c.a != EMPTY) {
                let bit = ~(1u << col);
                if (!is_non_dynamic(load_body(c.a))) {
                    scratch[occupancy + c.a] = scratch[occupancy + c.a] & bit;
                }
                if (!is_non_dynamic(load_body(c.b))) {
                    scratch[occupancy + c.b] = scratch[occupancy + c.b] & bit;
                }
            }
            let last = count - 1u;
            if (i != last) {
                let moved_slot =
                    scratch[color_contact_base() + col * params.contact_capacity + last];
                scratch[color_contact_base() + col * params.contact_capacity + i] = moved_slot;
                var moved = load_contact(moved_slot);
                moved.lifecycle.z = i;
                store_contact(moved_slot, moved);
            }
            scratch[SCR_COLOR + col] = last;
            if (c.a != EMPTY) {
                c.lifecycle.z = EMPTY;
                store_contact(slot, c);
            }
        }
    }
    // Add only newly touching contacts. Existing contacts retain both their
    // color and local index until the stop-touching transition above.
    for (var i = 0u; i < np; i++) {
        let slot = scratch[scr_active_contact() + i];
        if (slot == EMPTY) {
            continue;
        }
        var c = load_contact(slot);
        if (c.a == EMPTY || c.count == 0u || c.manifold_link.y != 0u || contact_has_sensor(c)) {
            continue;
        }
        let local = c.lifecycle.z;
        if (local != EMPTY
            && c.color < 24u
            && local < scratch[SCR_COLOR + c.color]
            && scratch[color_contact_base() + c.color * params.contact_capacity + local] == slot) {
            continue;
        }
        let a_dyn = !is_non_dynamic(load_body(c.a));
        let b_dyn = !is_non_dynamic(load_body(c.b));
        var col = OVERFLOW_COLOR;
        if (a_dyn && b_dyn) {
            for (var i = 0u; i < DYNAMIC_COLOR_COUNT; i++) {
                let bit = 1u << i;
                if ((scratch[occupancy + c.a] & bit) != 0u
                    || (scratch[occupancy + c.b] & bit) != 0u) {
                    continue;
                }
                scratch[occupancy + c.a] = scratch[occupancy + c.a] | bit;
                scratch[occupancy + c.b] = scratch[occupancy + c.b] | bit;
                col = i;
                break;
            }
        } else {
            let dyn = select(c.b, c.a, a_dyn);
            var i = OVERFLOW_COLOR - 1u;
            loop {
                if (i < 1u) {
                    break;
                }
                let bit = 1u << i;
                if ((scratch[occupancy + dyn] & bit) == 0u) {
                    scratch[occupancy + dyn] = scratch[occupancy + dyn] | bit;
                    col = i;
                    break;
                }
                i = i - 1u;
            }
        }
        c.color = col;
        let cnt = scratch[SCR_COLOR + col];
        if (cnt < params.contact_capacity) {
            scratch[color_contact_base() + col * params.contact_capacity + cnt] = slot;
            scratch[SCR_COLOR + col] = cnt + 1u;
            c.lifecycle.z = cnt;
        }
        store_contact(slot, c);
    }
    var mx = 0u;
    for (var c = 0u; c < OVERFLOW_COLOR; c++) {
        mx = max(mx, (scratch[SCR_COLOR + c] + 63u) / 64u);
    }
    if (params.solver_mode == SOLVER_JACOBI) {
        write_group_indirect(SCR_INDIRECT_COLLIDE, (np + 63u) / 64u);
    } else {
        let use_one_group_wave = np > 0u && mx <= 1u;
        write_group_indirect(SCR_INDIRECT_COLLIDE, select(0u, 1u, use_one_group_wave));
        for (var c = 0u; c < 24u; c++) {
            let n = scratch[SCR_COLOR + c];
            var groups = (n + 63u) / 64u;
            if (c == OVERFLOW_COLOR) {
                groups = select(0u, 1u, n > 0u);
            }
            let base = SCR_INDIRECT_COLOR + c * 4u;
            write_group_indirect(base, select(groups, 0u, use_one_group_wave));
        }
    }
    scratch[SCR_INDIRECT_COLLIDE + 3u] = 0u;
    write_count_indirect(SCR_INDIRECT_PREPARE, np, 64u);
    write_count_indirect(
        SCR_INDIRECT_ISLAND,
        max(np, params.joint_count),
        ISLAND_WORKGROUP_SIZE,
    );
    if ((params.diagnostic_flags & DIAG_PHASE_CAPTURE) != 0u) {
        var errors = 0u;
        for (var col = 0u; col < 24u; col++) {
            let count = scratch[SCR_COLOR + col];
            for (var i = 0u; i < count; i++) {
                let slot = scratch[color_contact_base() + col * params.contact_capacity + i];
                let c = load_contact(slot);
                if (c.a == EMPTY || c.count == 0u || c.color != col || c.lifecycle.z != i) {
                    errors = errors + 1u;
                }
                if (col == OVERFLOW_COLOR) {
                    continue;
                }
                for (var j = i + 1u; j < count; j++) {
                    let d =
                        load_contact(
                            scratch[color_contact_base() + col * params.contact_capacity + j]
                        );
                    if ((!is_non_dynamic(load_body(c.a)) && (c.a == d.a || c.a == d.b))
                        || (!is_non_dynamic(load_body(c.b)) && (c.b == d.a || c.b == d.b))) {
                        errors = errors + 1u;
                    }
                }
            }
        }
        for (var slot = 0u; slot < params.contact_capacity; slot++) {
            let c = load_contact(slot);
            if (c.a == EMPTY || c.count == 0u
                || (c.lifecycle.y & CONTACT_TOUCHING) == 0u) {
                continue;
            }
            if (c.color >= 24u || c.lifecycle.z >= scratch[SCR_COLOR + c.color]
                || scratch[
                    color_contact_base() + c.color * params.contact_capacity + c.lifecycle.z
                ] != slot) {
                errors = errors + 1u;
            }
        }
        scratch[SCR_BSTRIDE] = errors;
    }
}

// Topology changes only: preserve physical slot ownership while replacing dense
// collider keys. Mapping entries identify exact surviving shape generations.
@compute @workgroup_size(64)
fn clear_remapped_contact_hash(@builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(num_workgroups) groups: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    for (var i = gid.x; i < contact_hash_cap(); i += groups.x * groups.y * 64u) {
        atomicStore(&atom[atom_contact_key() + i], EMPTY);
        atomicStore(&atom[atom_contact_identity() + i], EMPTY);
    }
}

@compute @workgroup_size(64)
fn remap_contact_shapes(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let slot = gid.x;
    if (slot >= params.contact_capacity) { return; }
    var c = load_contact(slot);
    if (params.remap_capture != 0u) {
        var previous = vec2<u32>(EMPTY);
        if (c.a != EMPTY && c.count != 0u && (c.lifecycle.y & CONTACT_TOUCHING) != 0u) {
            previous = c.pair.xy;
        }
        store_pair_words(scr_previous_touching(), slot, previous);
    }
    if (c.a == EMPTY) { return; }
    let old_a = c.pair.x;
    let old_b = c.pair.y;
    var a = EMPTY;
    var b = EMPTY;
    if (old_a < params.remap_old_count) { a = scratch[scr_radix_out() + old_a]; }
    if (old_b < params.remap_old_count) { b = scratch[scr_radix_out() + old_b]; }
    if (a == EMPTY || b == EMPTY) {
        // Every patch owns its slot; children retire independently in this pass.
        var retired = empty_contact();
        retired.lifecycle.x = c.lifecycle.x;
        store_contact(slot, retired);
    } else {
        c.pair = vec4<u32>(min(a, b), max(a, b), 0u, 0u);
        store_contact(slot, c);
    }
}

@compute @workgroup_size(64)
fn prepare_contact_hash_keys(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let slot = gid.x;
    if (slot >= params.contact_capacity) { return; }
    if (contacts[slot].a != EMPTY && contacts[slot].manifold_link.y == 0u) {
        prepare_contact_identity(slot, contact_persistent[slot].pair.xy);
    }
}

@compute @workgroup_size(64)
fn publish_remapped_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let slot = gid.x;
    if (slot >= params.contact_capacity) { return; }
    let c = contacts[slot];
    if (c.a != EMPTY && c.manifold_link.y == 0u) {
        if (!publish_contact_slot(contact_persistent[slot].pair.xy, slot)) {
            record_contact_drop(11u);
        }
    }
}

// Mutation command, one invocation per unique root. Children have exactly one
// root owner, so retiring a manifold chain cannot race another invocation.
@compute @workgroup_size(64)
fn retire_body_pair_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= min(scratch[SCR_UNIQUE_N], pair_cap())) { return; }
    let slot = scratch[scr_active_contact() + i];
    if (slot >= params.contact_capacity) { return; }
    let c = load_contact(slot);
    let a = atomicLoad(&query[64u]);
    let b = atomicLoad(&query[65u]);
    if (atomicLoad(&query[66u]) == 1u) {
        if ((c.pair.x) != a && (c.pair.y) != a) { return; }
    } else if (!((c.a == a && c.b == b) || (c.a == b && c.b == a))) { return; }
    if (!retire_manifold_children(slot)) { return; }
    var retired = empty_contact();
    retired.lifecycle.x = c.lifecycle.x;
    store_contact(slot, retired);
    scratch[scr_contact_mark() + slot] = 0u;
    retire_contact_key(c.pair.xy);
}

// Bounded flat-scene pair matrix: a zero bit denotes an accepted pair.
// Row is the higher shape slot, giving the same packed-key order as radix sort.
@compute @workgroup_size(64)
fn pair_matrix_build(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let stride=(params.shape_count+31u)/32u;
    let word=gid.x;
    if (word>=params.shape_count*stride) {return;}
    let hi=word/stride;let base=(word%stride)*32u;
    var rejected=EMPTY;
    if (base<hi) {
        let a=load_collider(hi);let sa=load_shape(hi);
        for(var bit=0u;bit<32u && base+bit<hi;bit++) {
            let lo=base+bit;let b=load_collider(lo);let sb=load_shape(lo);
            if (a._pad_island.y!=b._pad_island.y && broadphase_pair_allowed(a,b,sa,sb)
                && !joint_disables_collision(a._pad_island.y,b._pad_island.y)
                && shapes_collide(sa,sb) && aabb_overlap(a,b)) {
                rejected &= ~(1u<<bit);
            }
        }
    }
    atomicStore(&atom[ATOM_HASH+word],rejected);
}
@compute @workgroup_size(64)
fn pair_matrix_previous(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let key=previous_pair_key(gid.x);if(key.x==EMPTY){return;}
    let lo=key.x;let hi=key.y;
    let stride=(params.shape_count+31u)/32u;
    atomicAnd(&atom[ATOM_HASH+hi*stride+lo/32u],~(1u<<(lo%32u)));
}
@compute @workgroup_size(64)
fn pair_matrix_count(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let row=gid.x;if(row>=params.shape_count){return;}
    let stride=(params.shape_count+31u)/32u;
    var count=0u;
    for(var w=0u;w<stride;w++){count+=countOneBits(~atomicLoad(&atom[ATOM_HASH+row*stride+w]));}
    scratch[scr_ins_body()+row]=count;
}
@compute @workgroup_size(256)
fn pair_matrix_bases(@builtin(local_invocation_index) lid: u32) {
    let first=lid*3u;
    let a=select(0u,scratch[scr_ins_body()+first],first<params.shape_count);
    let b=select(0u,scratch[scr_ins_body()+first+1u],first+1u<params.shape_count);
    let c=select(0u,scratch[scr_ins_body()+first+2u],first+2u<params.shape_count);
    let base=workgroup_exclusive_scan_256(lid,a+b+c);
    if(first<params.shape_count){scratch[scr_ins_cell()+first]=base;}
    if(first+1u<params.shape_count){scratch[scr_ins_cell()+first+1u]=base+a;}
    if(first+2u<params.shape_count){scratch[scr_ins_cell()+first+2u]=base+a+b;}
    if(lid==255u){
        let total=base+a+b+c;let bounded=min(total,pair_cap());
        if(total>pair_cap()){record_capacity_drop_n(ATOM_PAIR_DROPPED,ATOM_STICKY_PAIR_DROPPED,total-pair_cap());}
        atomicStore(&atom[ATOM_PAIR_N],total);
        scratch[SCR_PAIR_N]=bounded;scratch[SCR_POW2]=total;
        scratch[SCR_UNIQUE_N]=bounded;scratch[SCR_NCONTACTS]=bounded;
        write_count_indirect(SCR_INDIRECT_COLLIDE,bounded,64u);
        write_count_indirect(SCR_INDIRECT_PREPARE,bounded,64u);
        write_count_indirect(SCR_INDIRECT_RADIX,bounded,RADIX_GROUP_SIZE);
    }
}
@compute @workgroup_size(64)
fn pair_matrix_scatter(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let hi=gid.x;if(hi>=params.shape_count){return;}
    let stride=(params.shape_count+31u)/32u;var dst=scratch[scr_ins_cell()+hi];
    for(var w=0u;w<stride;w++){
        var accepted=~atomicLoad(&atom[ATOM_HASH+hi*stride+w]);
        while(accepted!=0u){
            let bit=firstTrailingBit(accepted);accepted &= accepted-1u;
            if(dst<pair_cap()){store_pair_words(SCR_PAIRS,dst,vec2<u32>(w*32u+bit,hi));}
            dst++;
        }
    }
}
// TGS contact GS, friction/rolling, overflow, joints.

fn rolling_mass_mul(ba: Body, bb: Body, v: vec3<f32>) -> vec3<f32> {
    let c0 = world_inv_inertia(ba, vec3<f32>(1.0, 0.0, 0.0)) + world_inv_inertia(bb, vec3<f32>(1.0, 0.0, 0.0));
    let c1 = world_inv_inertia(ba, vec3<f32>(0.0, 1.0, 0.0)) + world_inv_inertia(bb, vec3<f32>(0.0, 1.0, 0.0));
    let c2 = world_inv_inertia(ba, vec3<f32>(0.0, 0.0, 1.0)) + world_inv_inertia(bb, vec3<f32>(0.0, 0.0, 1.0));
    return solve3(c0, c1, c2, v);
}

fn motor_linear_mass_mul(ba: Body, bb: Body, rA: vec3<f32>, rB: vec3<f32>, v: vec3<f32>) -> vec3<f32> {
    let m = body_inv_mass(ba) + body_inv_mass(bb);
    let e0 = vec3<f32>(1.0, 0.0, 0.0);
    let e1 = vec3<f32>(0.0, 1.0, 0.0);
    let e2 = vec3<f32>(0.0, 0.0, 1.0);
    var c0 = -(gyro_cross(rA, world_inv_inertia(ba, gyro_cross(rA, e0)))
        + gyro_cross(rB, world_inv_inertia(bb, gyro_cross(rB, e0))));
    var c1 = -(gyro_cross(rA, world_inv_inertia(ba, gyro_cross(rA, e1)))
        + gyro_cross(rB, world_inv_inertia(bb, gyro_cross(rB, e1))));
    var c2 = -(gyro_cross(rA, world_inv_inertia(ba, gyro_cross(rA, e2)))
        + gyro_cross(rB, world_inv_inertia(bb, gyro_cross(rB, e2))));
    c0.x = c0.x + m; c1.y = c1.y + m; c2.z = c2.z + m;
    return solve3(c0, c1, c2, v);
}

fn motor_angular_mass_mul(ba: Body, bb: Body, v: vec3<f32>) -> vec3<f32> {
    let c0 = world_inv_inertia(ba,vec3<f32>(1.0,0.0,0.0))+world_inv_inertia(bb,vec3<f32>(1.0,0.0,0.0));
    let c1 = world_inv_inertia(ba,vec3<f32>(0.0,1.0,0.0))+world_inv_inertia(bb,vec3<f32>(0.0,1.0,0.0));
    let c2 = world_inv_inertia(ba,vec3<f32>(0.0,0.0,1.0))+world_inv_inertia(bb,vec3<f32>(0.0,0.0,1.0));
    let det = gyro_dot3(c0,gyro_cross(c1,c2));
    if (abs(det)<=1.17549435e-35) { return vec3<f32>(0.0); }
    let inv = gyro_recip(det);
    let m = transpose(mat3x3<f32>(inv*gyro_cross(c1,c2),inv*gyro_cross(c2,c0),inv*gyro_cross(c0,c1)));
    return native_mul_mv(m,v);
}

// Native motor constraints normalize first, then multiply by the limit.
fn motor_clamp_vector_length(v: vec3<f32>, max_length: f32) -> vec3<f32> {
    let squared = gyro_dot3(v,v);
    if (squared > max_length * max_length) {
        if (squared <= 1.17549435e-35) { return vec3<f32>(0.0); }
        let length = gyro_sqrt(squared);
        let normalized = gyro_recip(length) * v;
        return max_length * normalized;
    }
    return v;
}

fn clamp_vector_length(v: vec3<f32>, max_length: f32) -> vec3<f32> {
    let length_squared = dot(v, v);
    if (length_squared > max_length * max_length) {
        return v * (max_length / sqrt(length_squared));
    }
    return v;
}

// Stored joint anchors are body-origin. Live lever arms subtract COM.
fn joint_anchor_com(body_index: u32, origin_anchor: vec3<f32>) -> vec3<f32> {
    return origin_anchor - load_body_cold(body_index).local_center;
}

fn joint_lever(body_index: u32, q: vec4<f32>, origin_anchor: vec3<f32>) -> vec3<f32> {
    return quat_rotate(q, joint_anchor_com(body_index, origin_anchor));
}

fn joint_softness(hertz: f32, damping: f32) -> vec3<f32> {
    let h = params.dt;
    let clamped_hertz = min(max(hertz, 0.0), 0.25 / max(h, 1e-8));
    let omega = 6.28318530718 * clamped_hertz;
    let a1 = 2.0 * max(damping, 0.0) + h * omega;
    let a2 = h * omega * a1;
    let a3 = 1.0 / (1.0 + a2);
    return vec3<f32>(
        select(0.0, omega / a1, a1 > 0.0),
        a2 * a3,
        a3,
    );
}

fn spring_softness(hertz: f32, damping: f32) -> vec3<f32> {
    let h = params.dt;
    let omega = 6.28318530718 * max(hertz, 0.0);
    let a1 = 2.0 * max(damping, 0.0) + h * omega;
    let a2 = h * omega * a1;
    let a3 = 1.0 / (1.0 + a2);
    return vec3<f32>(
        select(0.0, omega / a1, a1 > 0.0),
        a2 * a3,
        a3,
    );
}

fn twist_angle(q: vec4<f32>) -> f32 {
    if (q.w < 0.0) {
        return 2.0 * atan2(-q.z, -q.w);
    }
    return 2.0 * atan2(q.z, q.w);
}

fn swing_angle(q: vec4<f32>) -> f32 {
    return 2.0 * atan2(length(q.xy), length(q.zw));
}

fn normalize_or_zero(v: vec3<f32>) -> vec3<f32> {
    let length_squared = dot(v, v);
    return select(vec3<f32>(0.0), v * inverseSqrt(length_squared), length_squared > 0.0);
}

fn delta_quat_to_rotation(q: vec4<f32>, desired: vec4<f32>) -> vec3<f32> {
    let s = select(q, -q, dot(q, desired) < 0.0);
    let diff = desired - s;
    return 2.0 * quat_mul(diff, quat_inv(s)).xyz;
}

fn revolute_axes(frame_a: vec4<f32>, rel: vec4<f32>) -> mat2x3<f32> {
    let axis_x = 0.5 * quat_rotate(
        frame_a,
        rel.w * vec3<f32>(1.0, 0.0, 0.0)
            + cross(rel.xyz, vec3<f32>(1.0, 0.0, 0.0)),
    );
    let axis_y = 0.5 * quat_rotate(
        frame_a,
        rel.w * vec3<f32>(0.0, 1.0, 0.0)
            + cross(rel.xyz, vec3<f32>(0.0, 1.0, 0.0)),
    );
    // WGSL matrices store columns. Keep each Jacobian axis in one column.
    return mat2x3<f32>(axis_x, axis_y);
}

fn revolute_axis_x(axes: mat2x3<f32>) -> vec3<f32> {
    return axes[0];
}

fn revolute_axis_y(axes: mat2x3<f32>) -> vec3<f32> {
    return axes[1];
}

fn perp(n: vec3<f32>) -> vec3<f32> {
    // Box3D `b3Perp`: branch on |x| > 0.5 (not 1/sqrt(3)).
    if (n.x < -0.5 || n.x > 0.5) {
        return gyro_norm3(vec3<f32>(n.y, -n.x, 0.0));
    }
    return gyro_norm3(vec3<f32>(0.0, n.z, -n.y));
}

fn normal_mass(a: Body, b: Body, rA: vec3<f32>, rB: vec3<f32>, n: vec3<f32>) -> f32 {
    let rnA = gyro_cross(rA, n);
    let rnB = gyro_cross(rB, n);
    let k = body_inv_mass(a) + body_inv_mass(b) + gyro_dot3(rnA, world_inv_inertia(a, rnA)) + gyro_dot3(rnB, world_inv_inertia(b, rnB));
    if (k > 0.0) {
        return gyro_recip(k);
    }
    return 0.0;
}

fn current_sep(a: Body, b: Body, rA: vec3<f32>, rB: vec3<f32>, n: vec3<f32>, base: f32) -> f32 {
    let rsA = quat_rotate(a.dq, rA);
    let rsB = quat_rotate(b.dq, rB);
    let ds = (b.dp - a.dp) + (rsB - rsA);
    return base + gyro_dot3(n, ds);
}

// Validate the complete ownership chain before any impulse is applied. This
// also makes malformed/cyclic lists fail closed instead of double-solving.
fn contact_chain_valid(root: u32) -> bool {
    // The common single-manifold case needs no ownership traversal. Preserve
    // the structural/content failure categories and every general-path check.
    if (root >= params.contact_capacity) {
        record_contact_drop(0u); return false;
    }
    let head = contacts[root];
    if (head.manifold_link.z <= 1u) {
        if (head.manifold_link.y != 0u || head.manifold_link.x != 0u) {
            record_contact_drop(1u); return false;
        }
        let valid = head.a < params.body_count && head.b < params.body_count
            && head.a != head.b && head.count > 0u && head.count <= 4u;
        if (!valid) { record_contact_drop(5u); }
        return valid;
    }
    if (!contact_chain_structure_valid(root)) { return false; }
    let first = contacts[root];
    var valid = first.a < params.body_count && first.b < params.body_count && first.a != first.b;
    var slot = root;
    for (var i = 0u; i < max(first.manifold_link.z, 1u); i++) {
        let c = contacts[slot];
        valid = valid && c.count > 0u && c.count <= 4u;
        if (c.manifold_link.x != 0u) { slot = c.manifold_link.x - 1u; }
    }
    if (!valid) { record_contact_drop(5u); }
    return valid;
}

fn prepare_contact_slot(k: u32) {
    var c = load_solve_contact(k);
    if (c.a == EMPTY || c.count == 0u) {
        return;
    }
    let a = load_body(c.a);
    let b = load_body(c.b);
    c.prepared_normal_mass = vec4<f32>(0.0);
    c.prepared_lever_arm = vec4<f32>(0.0);
    c.total_normal_impulse = vec4<f32>(0.0);
    var relative_velocity = vec4<f32>(0.0);
    // Collision detection computes centers from manifold separation before
    // packing solver base separation. Reconstructing it here loses precision.
    for (var i = 0u; i < c.count; i++) {
        let rA = ra_at(c, i).xyz;
        let rB = rb_at(c, i).xyz;
        c.prepared_normal_mass[i] = normal_mass(a, b, rA, rB, c.n);
        relative_velocity[i] = gyro_dot3((b.vel + gyro_cross(b.omega, rB)) - (a.vel + gyro_cross(a.omega, rA)), c.n);
    }
    for (var i = 0u; i < c.count; i++) {
        let lever = ra_at(c, i).xyz - c.center_a;
        c.prepared_lever_arm[i] = gyro_sqrt(gyro_dot3(lever, lever));
    }
    c._tail0 = vec4<u32>(
        bitcast<u32>(relative_velocity.x),
        bitcast<u32>(relative_velocity.y),
        bitcast<u32>(relative_velocity.z),
        bitcast<u32>(relative_velocity.w),
    );
    let t1 = perp(c.n);
    let t2 = gyro_cross(t1, c.n);
    let rt1a = gyro_cross(c.center_a, t1);
    let rt1b = gyro_cross(c.center_b, t1);
    let rt2a = gyro_cross(c.center_a, t2);
    let rt2b = gyro_cross(c.center_b, t2);
    let msum = body_inv_mass(a) + body_inv_mass(b);
    let k11 = msum + gyro_dot3(rt1a, world_inv_inertia(a, rt1a)) + gyro_dot3(rt1b, world_inv_inertia(b, rt1b));
    let k22 = msum + gyro_dot3(rt2a, world_inv_inertia(a, rt2a)) + gyro_dot3(rt2b, world_inv_inertia(b, rt2b));
    let k12 = gyro_dot3(rt1a, world_inv_inertia(a, rt2a)) + gyro_dot3(rt1b, world_inv_inertia(b, rt2b));
    let det = k11 * k22 - k12 * k12;
    if (abs(det) > 1e-8) {
        let inv_det = gyro_recip(det);
        c.prepared_tangent_inv = vec4<f32>(k22 * inv_det, -k12 * inv_det, -k12 * inv_det, k11 * inv_det);
    } else {
        c.prepared_tangent_inv = vec4<f32>(
            select(0.0, 1.0 / k11, k11 > 1e-8),
            0.0,
            0.0,
            select(0.0, 1.0 / k22, k22 > 1e-8),
        );
    }
    let soft = contact_softness(is_non_dynamic(a) || is_non_dynamic(b));
    c.prepared_softness = vec4<f32>(
        soft.x,
        soft.y,
        soft.z,
        select(0.0, 1.0, is_non_dynamic(a) || is_non_dynamic(b)),
    );
    if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) != 0u) {
        trace_solver_values(20u,c.a,c.b,c.prepared_normal_mass,
            vec4<f32>(soft,c.friction),vec4<f32>(c.center_b,c.rolling));
        trace_solver_values(21u,c.a,c.b,
            vec4<f32>(world_inv_inertia(b,vec3<f32>(1.0,0.0,0.0)),0.0),
            vec4<f32>(world_inv_inertia(b,vec3<f32>(0.0,1.0,0.0)),0.0),
            vec4<f32>(world_inv_inertia(b,vec3<f32>(0.0,0.0,1.0)),0.0));
    }
    store_solve_contact(k, c);
}

@compute @workgroup_size(64)
fn prepare_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= min(scratch[SCR_NCONTACTS], pair_cap())) { return; }
    let root = scratch[scr_active_contact() + i];
    if (root >= params.contact_capacity || contacts[root].a == EMPTY || contacts[root].count == 0u) { return; }
    if (!contact_chain_valid(root)) { return; }
    let count = max(contacts[root].manifold_link.z, 1u);
    var slot = root;
    for (var j = 0u; j < count; j++) {
        prepare_contact_slot(slot);
        if (j + 1u < count) { slot = contacts[slot].manifold_link.x - 1u; }
    }
}

fn solve_manifold(c: ptr<function, Contact>, ba: ptr<function, Body>, bb: ptr<function, Body>, do_friction: bool) {
    solve_manifold_bias(c, ba, bb, do_friction, params.use_bias);
}

fn solve_manifold_bias(
    c: ptr<function, Contact>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
    do_friction: bool,
    use_bias: u32,
) {
    if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) != 0u) {
        trace_solver_values(30u+use_bias,(*c).a,(*c).b,
            vec4<f32>((*bb).vel,0.0),vec4<f32>((*bb).omega,0.0),vec4<f32>((*bb).dp,0.0));
    }
    let n = (*c).n;
    let soft = (*c).prepared_softness.xyz;
    var bias_rate = 0.0;
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (use_bias == 1u) {
        bias_rate = soft.y * soft.x;
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let inv_h = 1.0 / max(params.dt, 1e-8);
    let contact_speed = -params.contact_speed;
    var total_jn = 0.0;
    var total_twist = 0.0;
    for (var i = 0u; i < (*c).count; i++) {
        let ra = ra_at(*c, i);
        let rb = rb_at(*c, i);
        let rA = ra.xyz;
        let rB = rb.xyz;
        let s = current_sep(*ba, *bb, rA, rB, n, ra.w);
        var bias: f32;
        var pms = mass_scale;
        var pis = impulse_scale;
        if (s > 0.0) {
            bias = s * inv_h;
            pms = 1.0;
            pis = 0.0;
        } else {
            bias = max(bias_rate * s, contact_speed);
        }
        let vA = (*ba).vel + gyro_cross((*ba).omega, rA);
        let vB = (*bb).vel + gyro_cross((*bb).omega, rB);
        let vn = gyro_dot3(vB - vA, n);
        let nm = (*c).prepared_normal_mass[i];
        let j_old = rb.w;
        let neg_imp = nm * (pms * vn + bias) + pis * j_old;
        var j = max(j_old - neg_imp, 0.0);
        let dj = j - j_old;

        (*c).total_normal_impulse[i] = (*c).total_normal_impulse[i] + j;
        let P = n * dj;
        apply_contact_P(ba, rA, P, -1.0);
        apply_contact_P(bb, rB, P, 1.0);
        total_jn = total_jn + j;
        let lever = (*c).prepared_lever_arm[i];
        total_twist = total_twist + lever * j;
        set_point(c, i, ra, vec4<f32>(rB, j));
    }

    // Box3D's SIMD convex path omits friction during the biased pass.
    if (do_friction && use_bias == 0u) {
        let t1 = perp(n);
        let t2 = gyro_cross(t1, n);
        let rA = (*c).center_a;
        let rB = (*c).center_b;
        {
            let twist_speed = gyro_dot3(n, (*bb).omega - (*ba).omega);
            let max_l = (*c).friction * total_twist;
            var k_tw = gyro_dot3(n, world_inv_inertia(*ba, n) + world_inv_inertia(*bb, n));
            var tm = 0.0;
            if (k_tw > 1e-8) { tm = gyro_recip(k_tw); }
            var dtw = -tm * twist_speed;
            var tw = clamp((*c).twist_impulse + dtw, -max_l, max_l);
            dtw = tw - (*c).twist_impulse;
            (*c).twist_impulse = tw;
            let L = n * dtw;
            if (!is_immovable(*ba)) {
                (*ba).omega = (*ba).omega - contact_inv_inertia(*ba, L);
            }
            if (!is_immovable(*bb)) {
                (*bb).omega = (*bb).omega + contact_inv_inertia(*bb, L);
            }
        }
        if ((*c).rolling > 0.0) {
            // Box3D: deltaImpulse = -inv(iA+iB) * (wB - wA), clamp to rolling * Σjn.
            let dw = (*ba).omega - (*bb).omega;
            var jr = (*c).rolling_impulse + rolling_mass_mul(*ba, *bb, dw);
            let max_r = (*c).rolling * total_jn;
            let lr2 = gyro_dot3(jr, jr);
            if (lr2 > max_r * max_r + 1.1920929e-7) {
                jr = jr * (max_r / sqrt(lr2));
            }
            let djr = jr - (*c).rolling_impulse;
            (*c).rolling_impulse = jr;
            if (!is_immovable(*ba)) {
                (*ba).omega = (*ba).omega - contact_inv_inertia(*ba, djr);
            }
            if (!is_immovable(*bb)) {
                (*bb).omega = (*bb).omega + contact_inv_inertia(*bb, djr);
            }
        }
        let vA = (*ba).vel + gyro_cross((*ba).omega, rA);
        let vB = (*bb).vel + gyro_cross((*bb).omega, rB);
        let vr = vB - vA;
        let relative_tangent_velocity = vr - (*c).tangent_velocity;
        let vt = vec2<f32>(
            gyro_dot3(relative_tangent_velocity, t1),
            gyro_dot3(relative_tangent_velocity, t2),
        );
        var jn = (*c).friction_impulse;
        let mt = (*c).prepared_tangent_inv;
        jn = jn - vec2<f32>(mt.x * vt.x + mt.y * vt.y, mt.z * vt.x + mt.w * vt.y);
        let max_j = (*c).friction * total_jn;
        let mag2 = jn.x * jn.x + jn.y * jn.y;
        if (mag2 > max_j * max_j) {
            // Native SIMD contact friction includes epsilon in the denominator.
            jn = jn * gyro_divide(max_j, gyro_sqrt(mag2) + 1.1920929e-7);
        }
        let djt = jn - (*c).friction_impulse;
        (*c).friction_impulse = jn;
        let P = t1 * djt.x + t2 * djt.y;

        apply_contact_P(ba, rA, P, -1.0);
        apply_contact_P(bb, rB, P, 1.0);
    }
    if ((params.diagnostic_flags & DIAG_MESH_CANDIDATES) != 0u) {
        trace_solver_values(40u+use_bias,(*c).a,(*c).b,
            vec4<f32>((*bb).vel,0.0),vec4<f32>((*bb).omega,0.0),vec4<f32>((*bb).dp,0.0));
    }

}

fn apply_restitution(c: ptr<function, Contact>, ba: ptr<function, Body>, bb: ptr<function, Body>) {
    let rest = (*c)._pad_end;
    if (rest <= 0.0) {
        return;
    }
    let n = (*c).n;
    let threshold = params.restitution_threshold;
    let rel = vec4<f32>(
        bitcast<f32>((*c)._tail0.x),
        bitcast<f32>((*c)._tail0.y),
        bitcast<f32>((*c)._tail0.z),
        bitcast<f32>((*c)._tail0.w),
    );
    for (var i = 0u; i < (*c).count; i++) {
        var rv = rel.x;
        if (i == 1u) { rv = rel.y; }
        if (i == 2u) { rv = rel.z; }
        if (i == 3u) { rv = rel.w; }
        if (rv + threshold > 0.0) {
            continue;
        }
        let ra = ra_at(*c, i);
        let rb = rb_at(*c, i);
        if ((*c).total_normal_impulse[i] == 0.0) {
            continue;
        }
        let nm = (*c).prepared_normal_mass[i];
        let vA = (*ba).vel + gyro_cross((*ba).omega, ra.xyz);
        let vB = (*bb).vel + gyro_cross((*bb).omega, rb.xyz);
        let vn = gyro_dot3(vB - vA, n);
        let neg_imp = nm * (vn + rest * rv);
        var j = max(rb.w - neg_imp, 0.0);
        let dj = j - rb.w;
        (*c).total_normal_impulse[i] = (*c).total_normal_impulse[i] + dj;
        apply_contact_P(ba, ra.xyz, n * dj, -1.0);
        apply_contact_P(bb, rb.xyz, n * dj, 1.0);
        set_point(c, i, ra, vec4<f32>(rb.xyz, j));
    }
}

fn warm_manifold(c: Contact, ba: ptr<function, Body>, bb: ptr<function, Body>) {
    let n = c.n;
    for (var i = 0u; i < c.count; i++) {
        let rA = ra_at(c, i).xyz;
        let rB = rb_at(c, i).xyz;
        let P = n * rb_at(c, i).w;
        apply_contact_P(ba, rA, P, -1.0);
        apply_contact_P(bb, rB, P, 1.0);
    }
    let t1 = perp(n);
    let t2 = gyro_cross(t1, n);
    let Pf = t1 * c.friction_impulse.x + t2 * c.friction_impulse.y;
    apply_contact_P(ba, c.center_a, Pf, -1.0);
    apply_contact_P(bb, c.center_b, Pf, 1.0);
    if (length(c.rolling_impulse) > 0.0) {
        if (!is_immovable(*ba)) {
            (*ba).omega = (*ba).omega - contact_inv_inertia(*ba, c.rolling_impulse);
        }
        if (!is_immovable(*bb)) {
            (*bb).omega = (*bb).omega + contact_inv_inertia(*bb, c.rolling_impulse);
        }
    }
    if (abs(c.twist_impulse) > 0.0) {
        let L = c.n * c.twist_impulse;
        if (!is_immovable(*ba)) {
            (*ba).omega = (*ba).omega - contact_inv_inertia(*ba, L);
        }
        if (!is_immovable(*bb)) {
            (*bb).omega = (*bb).omega + contact_inv_inertia(*bb, L);
        }
    }
}

@compute @workgroup_size(64)
fn warm_start(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let k = gid.x;
    let maxc = params.contact_capacity;
    if (k >= maxc) {
        return;
    }
    let c = load_solve_contact(k);
    if (c.a == EMPTY || c.count == 0u || c.manifold_link.y != 0u || c.color != params.color_select) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_contact_chain(k, &ba, &bb, 2u);
    store_body(c.a, ba);
    store_body(c.b, bb);
}

@compute @workgroup_size(64)
fn solve_contacts(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let k = gid.x;
    let maxc = params.contact_capacity;
    if (k >= maxc) {
        return;
    }
    var c = load_solve_contact(k);
    if (c.a == EMPTY || c.count == 0u || c.manifold_link.y != 0u || c.color != params.color_select) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_contact_chain(k, &ba, &bb, params.use_bias);
    store_body(c.a, ba);
    store_body(c.b, bb);
}

fn listed_index(col: u32, i: u32) -> u32 {
    return scratch[color_contact_base() + col * params.contact_capacity + i];
}

fn solve_contact_chain(root: u32, ba: ptr<function, Body>, bb: ptr<function, Body>, mode: u32) {
    if (!contact_chain_valid(root)) { return; }
    solve_validated_contact_chain(root, ba, bb, mode);
}

// Caller owns an immutable, validated chain for this dispatch only.
fn solve_validated_contact_chain(root: u32, ba: ptr<function, Body>, bb: ptr<function, Body>, mode: u32) {
    solve_validated_contact_chain_store(root, ba, bb, mode, false);
}

fn solve_validated_contact_chain_store(root: u32, ba: ptr<function, Body>, bb: ptr<function, Body>, mode: u32, impulses_only: bool) {
    // Sleeping contacts retain their warm-start history, as in Box3D's sleeping
    // solver sets. Solving two immovable endpoints otherwise decays that cache.
    if (is_immovable(*ba) && is_immovable(*bb)) {return;}
    let count = max(contacts[root].manifold_link.z, 1u);
    var slot = root;
    for (var i = 0u; i < count; i++) {
        var c = load_solve_contact(slot);
        if (c.count > 0u) {
            if (mode == 2u) { warm_manifold(c, ba, bb); }
            else if (mode == 3u) {
                apply_restitution(&c, ba, bb);
                if (impulses_only) { store_contact_impulses(slot, c); }
                else { store_solve_contact(slot, c); }
            } else {
                solve_manifold_bias(&c, ba, bb, true, mode);
                if (impulses_only) { store_contact_impulses(slot, c); }
                else { store_solve_contact(slot, c); }
            }
        }
        if (i + 1u < count) { slot = c.manifold_link.x - 1u; }
    }
}

fn run_contact(k: u32) {
    var c = load_solve_contact(k);
    if (c.a == EMPTY || c.count == 0u) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_contact_chain(k, &ba, &bb, params.use_bias);
    if (!is_immovable(ba)) {
        store_body(c.a, ba);
    }
    if (!is_immovable(bb)) {
        store_body(c.b, bb);
    }
}

var<workgroup> wg_solve_a: array<Body, 64>;
var<workgroup> wg_solve_b: array<Body, 64>;

@compute @workgroup_size(64)
fn solve_color(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let col = params.color_select;
    let n = scratch[SCR_COLOR + col];
    if (col == OVERFLOW_COLOR) {
        if (gid.x == 0u) {
            for (var i = 0u; i < n; i++) {
                run_contact(listed_index(col, i));
            }
        }
        return;
    }
    let i = gid.x;
    if (i >= n) {
        return;
    }
    // Coloring grants exclusive writable endpoints across the entire color.
    // Each lane owns its bodies; no cross-lane staging or barrier is needed.
    let k = listed_index(col, i);
    var c = load_solve_contact(k);
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_contact_chain(k, &ba, &bb, params.use_bias);
    if (!is_immovable(ba)) {
        store_body(c.a, ba);
    }
    if (!is_immovable(bb)) {
        store_body(c.b, bb);
    }
}

// Low-occupancy fast path. Graph compaction enables this dispatch only when
// every non-overflow color has at most one workgroup of contacts. The barriers
// retain overflow-first, then ascending-color Gauss-Seidel ordering while
// replacing 24 separate active dispatches with one workgroup.
@compute @workgroup_size(64)
fn solve_color_wave_one_group(@builtin(local_invocation_index) lid: u32) {
    if (lid == 0u) {
        let overflow_n = scratch[SCR_COLOR + OVERFLOW_COLOR];
        for (var i = 0u; i < overflow_n; i++) {
            run_contact(listed_index(OVERFLOW_COLOR, i));
        }
    }
    storageBarrier();
    workgroupBarrier();

    solve_color_range_one_group(lid, 0u, OVERFLOW_COLOR);
}

// Jointed worlds insert anchored joints between dynamic and static contacts.
@compute @workgroup_size(64)
fn solve_color_partition_one_group(@builtin(local_invocation_index) lid: u32) {
    if (params.color_select == 0u) {
        if (lid == 0u) {
            let n = scratch[SCR_COLOR + OVERFLOW_COLOR];
            for (var i = 0u; i < n; i++) { run_contact(listed_index(OVERFLOW_COLOR, i)); }
        }
        storageBarrier();
        workgroupBarrier();
        solve_color_range_one_group(lid, 0u, DYNAMIC_COLOR_COUNT);
    } else {
        solve_color_range_one_group(lid, DYNAMIC_COLOR_COUNT, OVERFLOW_COLOR);
    }
}

// The prefix handled overflow and dynamic colors below color_select. Static
// colors are dispatched in parallel after this dynamic-color tail.
// When the existing whole-wave shortcut ran, skip this tail to avoid solving twice.
@compute @workgroup_size(64)
fn solve_color_tail_one_group(@builtin(local_invocation_index) lid: u32) {
    if (scratch[SCR_INDIRECT_COLLIDE] != 0u) { return; }
    solve_color_range_one_group(lid, params.color_select, DYNAMIC_COLOR_COUNT);
}

fn solve_color_range_one_group(lid: u32, first_color: u32, end_color: u32) {
    for (var col = first_color; col < end_color; col++) {
        let n = scratch[SCR_COLOR + col];
        if (n == 0u) {
            continue;
        }
        var base = 0u;
        loop {
            if (base >= n) {
                break;
            }
            let i = base + lid;
            var k = EMPTY;
            if (i < n) {
                k = listed_index(col, i);
                let c = load_solve_contact(k);
                wg_solve_a[lid] = load_body(c.a);
                wg_solve_b[lid] = load_body(c.b);
            }
            workgroupBarrier();
            if (i < n) {
                var c = load_solve_contact(k);
                var ba = wg_solve_a[lid];
                var bb = wg_solve_b[lid];
                solve_contact_chain(k, &ba, &bb, params.use_bias);
                if (!is_immovable(ba)) {
                    store_body(c.a, ba);
                }
                if (!is_immovable(bb)) {
                    store_body(c.b, bb);
                }
            }
            storageBarrier();
            workgroupBarrier();
            base = base + 64u;
        }
    }
}

fn jac_slot(body: u32, comp: u32) -> u32 {
    return atom_jacobi() + body * 6u + comp;
}

fn jac_add(body: u32, dv: vec3<f32>, dw: vec3<f32>) {
    if (is_immovable(load_body(body))) {
        return;
    }
    atomicAdd(&atom[jac_slot(body, 0u)], bitcast<u32>(i32(round(dv.x * 1000.0))));
    atomicAdd(&atom[jac_slot(body, 1u)], bitcast<u32>(i32(round(dv.y * 1000.0))));
    atomicAdd(&atom[jac_slot(body, 2u)], bitcast<u32>(i32(round(dv.z * 1000.0))));
    atomicAdd(&atom[jac_slot(body, 3u)], bitcast<u32>(i32(round(dw.x * 1000.0))));
    atomicAdd(&atom[jac_slot(body, 4u)], bitcast<u32>(i32(round(dw.y * 1000.0))));
    atomicAdd(&atom[jac_slot(body, 5u)], bitcast<u32>(i32(round(dw.z * 1000.0))));
}

@compute @workgroup_size(64)
fn jacobi_clear(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    for (var c = 0u; c < 6u; c++) {
        atomicStore(&atom[jac_slot(i, c)], 0u);
    }
}

@compute @workgroup_size(64)
fn solve_jacobi(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    let np = min(scratch[SCR_NCONTACTS], pair_cap());
    if (i >= np) {
        return;
    }
    let k = scratch[scr_active_contact() + i];
    var c = load_solve_contact(k);
    if (c.a == EMPTY || c.count == 0u) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    let va0 = ba.vel;
    let wa0 = ba.omega;
    let vb0 = bb.vel;
    let wb0 = bb.omega;
    solve_contact_chain(k, &ba, &bb, params.use_bias);
    jac_add(c.a, ba.vel - va0, ba.omega - wa0);
    jac_add(c.b, bb.vel - vb0, bb.omega - wb0);
}

@compute @workgroup_size(64)
fn apply_jacobi(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    var b = load_body(i);
    if (is_immovable(b)) {
        return;
    }
    let s = 0.001;
    b.vel.x = b.vel.x + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 0u)]))) * s;
    b.vel.y = b.vel.y + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 1u)]))) * s;
    b.vel.z = b.vel.z + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 2u)]))) * s;
    b.omega.x = b.omega.x + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 3u)]))) * s;
    b.omega.y = b.omega.y + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 4u)]))) * s;
    b.omega.z = b.omega.z + f32(bitcast<i32>(atomicLoad(&atom[jac_slot(i, 5u)]))) * s;
    store_body(i, b);
}

@compute @workgroup_size(1)
fn solve_overflow(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 1u), 0u, 0u);
    if (gid.x != 0u) {
        return;
    }
    let maxc = params.contact_capacity;
    for (var k = 0u; k < maxc; k++) {
        var c = load_solve_contact(k);
        if (c.a == EMPTY || c.count == 0u || c.manifold_link.y != 0u || c.color != OVERFLOW_COLOR) {
            continue;
        }
        var ba = load_body(c.a);
        var bb = load_body(c.b);
        solve_contact_chain(k, &ba, &bb, params.use_bias);
        store_body(c.a, ba);
        store_body(c.b, bb);
    }
}

fn solve_revolute(
    jn: ptr<function, Joint>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
) {
    let base_frame_a = normalize(quat_mul((*ba).rot, (*jn).frame_a_rotation));
    var base_frame_b = normalize(quat_mul((*bb).rot, (*jn).frame_b_rotation));
    if (dot(base_frame_a, base_frame_b) < 0.0) {
        base_frame_b = -base_frame_b;
    }
    let base_rel = quat_mul(quat_inv(base_frame_a), base_frame_b);
    let base_axes = revolute_axes(base_frame_a, base_rel);
    let base_axis_x = revolute_axis_x(base_axes);
    let base_axis_y = revolute_axis_y(base_axes);
    let rotation_axis = quat_rotate(base_frame_a, vec3<f32>(0.0, 0.0, 1.0));

    let qa = normalize(quat_mul((*ba).dq, (*ba).rot));
    let qb = normalize(quat_mul((*bb).dq, (*bb).rot));
    let rA = joint_lever((*jn).a, qa, (*jn).anchor_a);
    let rB = joint_lever((*jn).b, qb, (*jn).anchor_b);

    if (params.use_bias == 2u) {
        let axial_impulse =
            (*jn).spring_impulse + (*jn).motor_impulse
            + (*jn).lower_impulse - (*jn).upper_impulse;
        let angular_impulse =
            (*jn).perp_impulse.x * base_axis_x
            + (*jn).perp_impulse.y * base_axis_y
            + axial_impulse * rotation_axis;
        apply_P(ba, rA, (*jn).angular_impulse, -1.0);
        apply_P(bb, rB, (*jn).angular_impulse, 1.0);
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, angular_impulse);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, angular_impulse);
        return;
    }

    let i0 = world_inv_inertia(*ba, vec3<f32>(1.0, 0.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(1.0, 0.0, 0.0));
    let i1 = world_inv_inertia(*ba, vec3<f32>(0.0, 1.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 1.0, 0.0));
    let i2 = world_inv_inertia(*ba, vec3<f32>(0.0, 0.0, 1.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 0.0, 1.0));
    let fixed_rotation = abs(dot(i0, cross(i1, i2))) < 1e-30;
    let axial_k = dot(rotation_axis, world_inv_inertia(*ba, rotation_axis)
        + world_inv_inertia(*bb, rotation_axis));
    let axial_mass = select(0.0, 1.0 / axial_k, axial_k > 0.0);

    let frame_a = normalize(quat_mul(qa, (*jn).frame_a_rotation));
    var frame_b = normalize(quat_mul(qb, (*jn).frame_b_rotation));
    if (dot(frame_a, frame_b) < 0.0) {
        frame_b = -frame_b;
    }
    let rel = quat_mul(quat_inv(frame_a), frame_b);

    // Box3D order: spring, motor, lower/upper limits, collinearity, point-to-point.
    if (((*jn).flags & REVOLUTE_ENABLE_SPRING) != 0u && !fixed_rotation) {
        let soft = spring_softness((*jn).spring_hertz, (*jn).spring_damping);
        let c = twist_angle(rel) - (*jn).target_translation;
        let cdot = dot((*bb).omega - (*ba).omega, rotation_axis);
        let delta_impulse =
            -soft.y * axial_mass * (cdot + soft.x * c)
            - soft.z * (*jn).spring_impulse;
        (*jn).spring_impulse = (*jn).spring_impulse + delta_impulse;
        (*ba).omega =
            (*ba).omega - delta_impulse * world_inv_inertia(*ba, rotation_axis);
        (*bb).omega =
            (*bb).omega + delta_impulse * world_inv_inertia(*bb, rotation_axis);
    }

    if (((*jn).flags & REVOLUTE_ENABLE_MOTOR) != 0u && !fixed_rotation) {
        let cdot =
            dot((*bb).omega - (*ba).omega, rotation_axis) - (*jn).motor_speed;
        let old_impulse = (*jn).motor_impulse;
        let max_impulse = (*jn).max_motor_force * params.dt;
        (*jn).motor_impulse = clamp(
            old_impulse - axial_mass * cdot,
            -max_impulse,
            max_impulse,
        );
        let delta_impulse = (*jn).motor_impulse - old_impulse;
        (*ba).omega =
            (*ba).omega - delta_impulse * world_inv_inertia(*ba, rotation_axis);
        (*bb).omega =
            (*bb).omega + delta_impulse * world_inv_inertia(*bb, rotation_axis);
    }

    if (((*jn).flags & REVOLUTE_ENABLE_LIMIT) != 0u && !fixed_rotation) {
        let angle = twist_angle(rel);
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let inv_h = 1.0 / max(params.dt, 1e-8);

        let lower_c = angle - (*jn).lower_translation;
        var lower_bias = 0.0;
        var lower_mass_scale = 1.0;
        var lower_impulse_scale = 0.0;
        if (lower_c > 0.0) {
            lower_bias = lower_c * inv_h;
        } else if (params.use_bias == 1u) {
            lower_bias = soft.x * lower_c;
            lower_mass_scale = soft.y;
            lower_impulse_scale = soft.z;
        }
        let lower_cdot = dot((*bb).omega - (*ba).omega, rotation_axis);
        let old_lower = (*jn).lower_impulse;
        let lower_delta =
            -lower_mass_scale * axial_mass * (lower_cdot + lower_bias)
            - lower_impulse_scale * old_lower;
        (*jn).lower_impulse = max(old_lower + lower_delta, 0.0);
        let applied_lower = (*jn).lower_impulse - old_lower;
        (*ba).omega =
            (*ba).omega - applied_lower * world_inv_inertia(*ba, rotation_axis);
        (*bb).omega =
            (*bb).omega + applied_lower * world_inv_inertia(*bb, rotation_axis);

        let upper_c = (*jn).upper_translation - angle;
        var upper_bias = 0.0;
        var upper_mass_scale = 1.0;
        var upper_impulse_scale = 0.0;
        if (upper_c > 0.0) {
            upper_bias = upper_c * inv_h;
        } else if (params.use_bias == 1u) {
            upper_bias = soft.x * upper_c;
            upper_mass_scale = soft.y;
            upper_impulse_scale = soft.z;
        }
        let upper_cdot = dot((*ba).omega - (*bb).omega, rotation_axis);
        let old_upper = (*jn).upper_impulse;
        let upper_delta =
            -upper_mass_scale * axial_mass * (upper_cdot + upper_bias)
            - upper_impulse_scale * old_upper;
        (*jn).upper_impulse = max(old_upper + upper_delta, 0.0);
        let applied_upper = (*jn).upper_impulse - old_upper;
        (*ba).omega =
            (*ba).omega + applied_upper * world_inv_inertia(*ba, rotation_axis);
        (*bb).omega =
            (*bb).omega - applied_upper * world_inv_inertia(*bb, rotation_axis);
    }

    if (!fixed_rotation) {
        let axes = revolute_axes(frame_a, rel);
        let axis_x = revolute_axis_x(axes);
        let axis_y = revolute_axis_y(axes);
        let kxx = dot(axis_x, world_inv_inertia(*ba, axis_x)
            + world_inv_inertia(*bb, axis_x));
        let kyy = dot(axis_y, world_inv_inertia(*ba, axis_y)
            + world_inv_inertia(*bb, axis_y));
        let kxy = dot(axis_x, world_inv_inertia(*ba, axis_y)
            + world_inv_inertia(*bb, axis_y));
        let det = kxx * kyy - kxy * kxy;
        var solution = vec2<f32>(0.0);
        var bias = vec2<f32>(0.0);
        var mass_scale = 1.0;
        var impulse_scale = 0.0;
        if (params.use_bias == 1u) {
            let soft = joint_softness((*jn).hertz, (*jn).damping);
            bias = soft.x * rel.xy;
            mass_scale = soft.y;
            impulse_scale = soft.z;
        }
        let wrel = (*bb).omega - (*ba).omega;
        let rhs = vec2<f32>(
            dot(wrel, axis_x) + bias.x,
            dot(wrel, axis_y) + bias.y,
        );
        if (det > 1e-30) {
            solution = vec2<f32>(
                (kyy * rhs.x - kxy * rhs.y) / det,
                (kxx * rhs.y - kxy * rhs.x) / det,
            );
        }
        let delta_impulse =
            -mass_scale * solution - impulse_scale * (*jn).perp_impulse;
        (*jn).perp_impulse = (*jn).perp_impulse + delta_impulse;
        let angular_impulse = delta_impulse.x * axis_x + delta_impulse.y * axis_y;
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, angular_impulse);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, angular_impulse);
    }

    let cdot =
        ((*bb).vel + cross((*bb).omega, rB))
        - ((*ba).vel + cross((*ba).omega, rA));
    var bias = vec3<f32>(0.0);
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (params.use_bias == 1u) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let separation =
            ((*bb).pos + (*bb).dp + rB) - ((*ba).pos + (*ba).dp + rA);
        bias = soft.x * separation;
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let solution = motor_linear_mass_mul(*ba, *bb, rA, rB, cdot + bias);
    let impulse =
        -mass_scale * solution - impulse_scale * (*jn).angular_impulse;
    (*jn).angular_impulse = (*jn).angular_impulse + impulse;
    apply_P(ba, rA, impulse, -1.0);
    apply_P(bb, rB, impulse, 1.0);
}

fn solve_prismatic(
    jn: ptr<function, Joint>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
) {
    let qa = normalize(quat_mul((*ba).dq, (*ba).rot));
    let qb = normalize(quat_mul((*bb).dq, (*bb).rot));
    let rA = joint_lever((*jn).a, qa, (*jn).anchor_a);
    let rB = joint_lever((*jn).b, qb, (*jn).anchor_b);
    var frame_a = normalize(quat_mul(qa, (*jn).frame_a_rotation));
    var frame_b = normalize(quat_mul(qb, (*jn).frame_b_rotation));
    if (dot(frame_a, frame_b) < 0.0) {
        frame_b = -frame_b;
    }
    // The Rust API also accepts an explicit local axis; native frames agree
    // with it. Project frame Y to retain the native basis in that usual case.
    let ax = normalize(quat_rotate(qa, (*jn).axis));
    let frame_y = quat_rotate(frame_a, vec3<f32>(0.0, 1.0, 0.0));
    var ay = frame_y - dot(frame_y, ax) * ax;
    if (dot(ay, ay) < 1e-12) {
        let frame_z = quat_rotate(frame_a, vec3<f32>(0.0, 0.0, 1.0));
        ay = frame_z - dot(frame_z, ax) * ax;
    }
    ay = normalize(ay);
    let az = cross(ax, ay);
    let d = ((*bb).pos + (*bb).dp + rB) - ((*ba).pos + (*ba).dp + rA);
    let sAx = cross(d + rA, ax);
    let sBx = cross(rB, ax);
    let sAy = cross(d + rA, ay);
    let sBy = cross(rB, ay);
    let sAz = cross(d + rA, az);
    let sBz = cross(rB, az);
    let translation = dot(ax, d);

    let i0 = world_inv_inertia(*ba, vec3<f32>(1.0, 0.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(1.0, 0.0, 0.0));
    let i1 = world_inv_inertia(*ba, vec3<f32>(0.0, 1.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 1.0, 0.0));
    let i2 = world_inv_inertia(*ba, vec3<f32>(0.0, 0.0, 1.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 0.0, 1.0));
    let fixed_rotation = abs(dot(i0, cross(i1, i2))) < 1.1754944e-35;
    if (params.use_bias == 2u) {
        let axial = (*jn).spring_impulse + (*jn).motor_impulse
            + (*jn).lower_impulse - (*jn).upper_impulse;
        let p = axial * ax + (*jn).perp_impulse.x * ay + (*jn).perp_impulse.y * az;
        let la = axial * sAx + (*jn).perp_impulse.x * sAy
            + (*jn).perp_impulse.y * sAz + (*jn).angular_impulse;
        let lb = axial * sBx + (*jn).perp_impulse.x * sBy
            + (*jn).perp_impulse.y * sBz + (*jn).angular_impulse;
        (*ba).vel -= (*ba).inv_mass * p;
        (*ba).omega -= world_inv_inertia(*ba, la);
        (*bb).vel += (*bb).inv_mass * p;
        (*bb).omega += world_inv_inertia(*bb, lb);
        return;
    }
    let k = (*ba).inv_mass + (*bb).inv_mass
        + dot(sAx, world_inv_inertia(*ba, sAx)) + dot(sBx, world_inv_inertia(*bb, sBx));
    let axial_mass = select(0.0, 1.0 / k, k > 0.0);
    // Match b3SolvePrismaticJoint: spring, motor, limits, rotation, point-to-line.
    if (((*jn).flags & PRISMATIC_ENABLE_SPRING) != 0u && !fixed_rotation) {
        let soft = spring_softness((*jn).spring_hertz, (*jn).spring_damping);
        let cdot = dot(ax, (*bb).vel - (*ba).vel)
            + dot(sBx, (*bb).omega) - dot(sAx, (*ba).omega);
        let delta = -soft.y * axial_mass
            * (cdot + soft.x * (translation - (*jn).target_translation))
            - soft.z * (*jn).spring_impulse;
        (*jn).spring_impulse += delta;
        apply_P(ba, rA + d, delta * ax, -1.0);
        apply_P(bb, rB, delta * ax, 1.0);
    }
    if (((*jn).flags & PRISMATIC_ENABLE_MOTOR) != 0u && !fixed_rotation) {
        let cdot = dot(ax, (*bb).vel - (*ba).vel)
            + dot(sBx, (*bb).omega) - dot(sAx, (*ba).omega) - (*jn).motor_speed;
        let old = (*jn).motor_impulse;
        let bound = params.dt * (*jn).max_motor_force;
        (*jn).motor_impulse = clamp(old - axial_mass * cdot, -bound, bound);
        let p = ((*jn).motor_impulse - old) * ax;
        apply_P(ba, rA + d, p, -1.0);
        apply_P(bb, rB, p, 1.0);
    }
    if (((*jn).flags & PRISMATIC_ENABLE_LIMIT) != 0u && !fixed_rotation) {
        let spec = 0.25 * ((*jn).upper_translation - (*jn).lower_translation);
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        for (var side = 0u; side < 2u; side++) {
            let c = select(translation - (*jn).lower_translation,
                (*jn).upper_translation - translation, side == 1u);
            let old = select((*jn).lower_impulse, (*jn).upper_impulse, side == 1u);
            var accumulated = 0.0;
            if (c < spec) {
                var bias = 0.0;
                var ms = 1.0;
                var ips = 0.0;
                if (c > 0.0) { bias = c / params.dt; }
                else if (params.use_bias == 1u) { bias = soft.x * c; ms = soft.y; ips = soft.z; }
                let sign = select(1.0, -1.0, side == 1u);
                let cdot = sign * (dot(ax, (*bb).vel - (*ba).vel)
                    + dot(sBx, (*bb).omega) - dot(sAx, (*ba).omega));
                accumulated = max(0.0, old - ms * axial_mass * (cdot + bias) - ips * old);
                let p = sign * (accumulated - old) * ax;
                apply_P(ba, rA + d, p, -1.0);
                apply_P(bb, rB, p, 1.0);
            }
            if (side == 0u) { (*jn).lower_impulse = accumulated; }
            else { (*jn).upper_impulse = accumulated; }
        }
    }
    if (!fixed_rotation) {
        let rel = quat_mul(quat_inv(frame_a), frame_b);
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let c = -quat_rotate(frame_a,
            delta_quat_to_rotation(rel, vec4<f32>(0.0, 0.0, 0.0, 1.0)));
        let bias = select(vec3<f32>(0.0), soft.x * c, params.use_bias == 1u);
        let ms = select(1.0, soft.y, params.use_bias == 1u);
        let ips = select(0.0, soft.z, params.use_bias == 1u);
        let delta = -ms * solve3(i0, i1, i2, (*bb).omega - (*ba).omega + bias)
            - ips * (*jn).angular_impulse;
        (*jn).angular_impulse += delta;
        (*ba).omega -= world_inv_inertia(*ba, delta);
        (*bb).omega += world_inv_inertia(*bb, delta);
    }

    var bias = vec2<f32>(0.0);
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (params.use_bias == 1u) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        bias = soft.x * vec2<f32>(dot(ay, d), dot(az, d));
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let vrel = ((*bb).vel + cross((*bb).omega, rB))
        - (*ba).vel - cross((*ba).omega, rA + d);
    let rhs = vec2<f32>(dot(ay, vrel), dot(az, vrel)) + bias;
    let kyy = (*ba).inv_mass + (*bb).inv_mass
        + dot(sAy, world_inv_inertia(*ba, sAy)) + dot(sBy, world_inv_inertia(*bb, sBy));
    let kyz = dot(sAy, world_inv_inertia(*ba, sAz)) + dot(sBy, world_inv_inertia(*bb, sBz));
    let kzz = (*ba).inv_mass + (*bb).inv_mass
        + dot(sAz, world_inv_inertia(*ba, sAz)) + dot(sBz, world_inv_inertia(*bb, sBz));
    let det = kyy * kzz - kyz * kyz;
    var solution = vec2<f32>(0.0);
    if (det > 1e-30) {
        solution = vec2<f32>(
            (kzz * rhs.x - kyz * rhs.y) / det,
            (kyy * rhs.y - kyz * rhs.x) / det,
        );
    }
    let delta = -mass_scale * solution - impulse_scale * (*jn).perp_impulse;
    (*jn).perp_impulse = (*jn).perp_impulse + delta;
    let p = delta.x * ay + delta.y * az;
    (*ba).vel = (*ba).vel - (*ba).inv_mass * p;
    (*ba).omega = (*ba).omega - world_inv_inertia(*ba, delta.x * sAy + delta.y * sAz);
    (*bb).vel = (*bb).vel + (*bb).inv_mass * p;
    (*bb).omega = (*bb).omega + world_inv_inertia(*bb, delta.x * sBy + delta.y * sBz);
}

fn solve_wheel(
    jn: ptr<function, Joint>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
) {
    let qa = normalize(quat_mul((*ba).dq, (*ba).rot));
    let qb = normalize(quat_mul((*bb).dq, (*bb).rot));
    let rA = joint_lever((*jn).a, qa, (*jn).anchor_a);
    let rB = joint_lever((*jn).b, qb, (*jn).anchor_b);
    var frame_a = normalize(quat_mul(qa, (*jn).frame_a_rotation));
    var frame_b = normalize(quat_mul(qb, (*jn).frame_b_rotation));
    if (dot(frame_a, frame_b) < 0.0) {
        frame_b = -frame_b;
    }
    let ax = quat_rotate(frame_a, vec3<f32>(1.0, 0.0, 0.0));
    let ay = quat_rotate(frame_a, vec3<f32>(0.0, 1.0, 0.0));
    let az = quat_rotate(frame_a, vec3<f32>(0.0, 0.0, 1.0));
    let bz = quat_rotate(frame_b, vec3<f32>(0.0, 0.0, 1.0));
    let d = ((*bb).pos + (*bb).dp + rB) - ((*ba).pos + (*ba).dp + rA);
    let sAx = cross(d + rA, ax);
    let sBx = cross(rB, ax);
    let sAy = cross(d + rA, ay);
    let sBy = cross(rB, ay);
    let sAz = cross(d + rA, az);
    let sBz = cross(rB, az);
    let translation = dot(ax, d);

    let cs = dot(bz, az);
    let ss = -dot(bz, ay);
    let steering_den = cs * cs + ss * ss;
    let steering_axis = select(
        vec3<f32>(0.0),
        cross(bz, -cs * ay - ss * az) / steering_den,
        steering_den > 0.0,
    );
    let inv_i_x = world_inv_inertia(*ba, vec3<f32>(1.0, 0.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(1.0, 0.0, 0.0));
    let inv_i_y = world_inv_inertia(*ba, vec3<f32>(0.0, 1.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 1.0, 0.0));
    let inv_i_z = world_inv_inertia(*ba, vec3<f32>(0.0, 0.0, 1.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 0.0, 1.0));
    let fixed_rotation =
        abs(dot(inv_i_x, cross(inv_i_y, inv_i_z))) < 1.1754944e-35;
    // Prepared once-per-step quantities use the base transforms (before dq),
    // matching b3PrepareWheelJoint while current Jacobians above follow TGS.
    let prepared_frame_a = normalize(quat_mul((*ba).rot, (*jn).frame_a_rotation));
    let prepared_frame_b = normalize(quat_mul((*bb).rot, (*jn).frame_b_rotation));
    let prepared_ax = quat_rotate(prepared_frame_a, vec3<f32>(1.0, 0.0, 0.0));
    let prepared_ay = quat_rotate(prepared_frame_a, vec3<f32>(0.0, 1.0, 0.0));
    let prepared_az = quat_rotate(prepared_frame_a, vec3<f32>(0.0, 0.0, 1.0));
    let prepared_bz = quat_rotate(prepared_frame_b, vec3<f32>(0.0, 0.0, 1.0));
    let prepared_rA = joint_lever((*jn).a, (*ba).rot, (*jn).anchor_a);
    let prepared_rB = joint_lever((*jn).b, (*bb).rot, (*jn).anchor_b);
    let prepared_sAx = cross(prepared_rA, prepared_ax);
    let prepared_sBx = cross(prepared_rB, prepared_ax);
    let suspension_k = (*ba).inv_mass + (*bb).inv_mass
        + dot(prepared_sAx, world_inv_inertia(*ba, prepared_sAx))
        + dot(prepared_sBx, world_inv_inertia(*bb, prepared_sBx));
    let suspension_mass = select(0.0, 1.0 / suspension_k, suspension_k > 0.0);
    let spin_k = dot(
        prepared_bz,
        world_inv_inertia(*ba, prepared_bz) + world_inv_inertia(*bb, prepared_bz),
    );
    let spin_mass = select(0.0, 1.0 / spin_k, spin_k > 0.0);
    let prepared_cs = dot(prepared_bz, prepared_az);
    let prepared_ss = -dot(prepared_bz, prepared_ay);
    let prepared_den = prepared_cs * prepared_cs + prepared_ss * prepared_ss;
    let prepared_steering_axis = select(
        vec3<f32>(0.0),
        cross(
            prepared_bz,
            -prepared_cs * prepared_ay - prepared_ss * prepared_az,
        ) / prepared_den,
        prepared_den > 0.0,
    );
    let steering_k = dot(
        prepared_steering_axis,
        world_inv_inertia(*ba, prepared_steering_axis)
            + world_inv_inertia(*bb, prepared_steering_axis),
    );
    let steering_mass = select(0.0, 1.0 / steering_k, steering_k > 0.0);

    if (params.use_bias == 2u) {
        let suspension_impulse = (*jn).spring_impulse + (*jn).lower_impulse - (*jn).upper_impulse;
        let linear_impulse =
            suspension_impulse * ax + (*jn).perp_impulse.x * ay + (*jn).perp_impulse.y * az;
        let angular_a =
            suspension_impulse * sAx + (*jn).perp_impulse.x * sAy + (*jn).perp_impulse.y * sAz;
        let angular_b =
            suspension_impulse * sBx + (*jn).perp_impulse.x * sBy + (*jn).perp_impulse.y * sBz;
        var angular_impulse = vec3<f32>(0.0);
        if (((*jn).flags & WHEEL_ENABLE_STEERING) != 0u) {
            let perpendicular_axis = cross(bz, ax);
            let steering_impulse =
                (*jn).weld_angular_impulse.x + (*jn).weld_angular_impulse.y - (*jn).weld_angular_impulse.z;
            angular_impulse =
                (*jn).angular_impulse.x * perpendicular_axis
                + (*jn).motor_impulse * bz
                + steering_impulse * steering_axis;
        } else {
            let rel = quat_mul(quat_inv(frame_a), frame_b);
            let perp_x = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(1.0, 0.0, 0.0) + cross(rel.xyz, vec3<f32>(1.0, 0.0, 0.0)),
            );
            let perp_y = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(0.0, 1.0, 0.0) + cross(rel.xyz, vec3<f32>(0.0, 1.0, 0.0)),
            );
            // Native non-steering warm start includes both A and B spin-axis terms.
            angular_impulse = (*jn).motor_impulse * az + (
                (*jn).angular_impulse.x * perp_x
                + (*jn).angular_impulse.y * perp_y
                + (*jn).motor_impulse * bz);
        }
        (*ba).vel = (*ba).vel - (*ba).inv_mass * linear_impulse;
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, angular_a + angular_impulse);
        (*bb).vel = (*bb).vel + (*bb).inv_mass * linear_impulse;
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, angular_b + angular_impulse);
        return;
    }

    // Upstream order: spin, suspension spring, steering spring/limits,
    // suspension limits, collinearity, point-to-line.
    if (((*jn).flags & WHEEL_ENABLE_SPIN_MOTOR) != 0u && !fixed_rotation) {
        let old = (*jn).motor_impulse;
        let max_impulse = params.dt * (*jn).max_motor_force;
        let cdot = dot((*bb).omega - (*ba).omega, bz) - (*jn).motor_speed;
        (*jn).motor_impulse = clamp(old - spin_mass * cdot, -max_impulse, max_impulse);
        let impulse = (*jn).motor_impulse - old;
        (*ba).omega = (*ba).omega - impulse * world_inv_inertia(*ba, bz);
        (*bb).omega = (*bb).omega + impulse * world_inv_inertia(*bb, bz);
    }

    if (((*jn).flags & WHEEL_ENABLE_SUSPENSION_SPRING) != 0u) {
        let soft = spring_softness((*jn).spring_hertz, (*jn).spring_damping);
        let cdot = dot(ax, (*bb).vel - (*ba).vel) + dot(sBx, (*bb).omega) - dot(sAx, (*ba).omega);
        let impulse =
            -soft.y * suspension_mass * (cdot + soft.x * translation)
            - soft.z * (*jn).spring_impulse;
        (*jn).spring_impulse = (*jn).spring_impulse + impulse;
        let p = impulse * ax;
        (*ba).vel = (*ba).vel - (*ba).inv_mass * p;
        (*ba).omega = (*ba).omega - impulse * world_inv_inertia(*ba, sAx);
        (*bb).vel = (*bb).vel + (*bb).inv_mass * p;
        (*bb).omega = (*bb).omega + impulse * world_inv_inertia(*bb, sBx);
    }

    if (((*jn).flags & WHEEL_ENABLE_STEERING) != 0u && !fixed_rotation) {
        let steering_angle = atan2(ss, cs);
        let steering_soft = spring_softness((*jn).weld_linear_hertz, (*jn).weld_linear_damping);
        let old = (*jn).weld_angular_impulse.x;
        let cdot = dot(steering_axis, (*bb).omega - (*ba).omega);
        let max_impulse = params.dt * (*jn).target_rotation.y;
        (*jn).weld_angular_impulse.x = clamp(
            old - steering_soft.y * steering_mass
                * (cdot + steering_soft.x * (steering_angle - (*jn).target_rotation.x))
                - steering_soft.z * old,
            -max_impulse,
            max_impulse,
        );
        let steering_delta = (*jn).weld_angular_impulse.x - old;
        (*ba).omega = (*ba).omega - steering_delta * world_inv_inertia(*ba, steering_axis);
        (*bb).omega = (*bb).omega + steering_delta * world_inv_inertia(*bb, steering_axis);

        if (((*jn).flags & WHEEL_ENABLE_STEERING_LIMIT) != 0u) {
            let soft = joint_softness((*jn).hertz, (*jn).damping);
            let inv_h = 1.0 / max(params.dt, 1e-8);
            let lower_c = steering_angle - (*jn).target_rotation.z;
            var bias = select(0.0, lower_c * inv_h, lower_c > 0.0);
            var mass_scale = 1.0;
            var impulse_scale = 0.0;
            if (lower_c <= 0.0 && params.use_bias == 1u) {
                bias = soft.x * lower_c;
                mass_scale = soft.y;
                impulse_scale = soft.z;
            }
            let lower_old = (*jn).weld_angular_impulse.y;
            let lower_delta = -mass_scale * steering_mass
                * (dot(steering_axis, (*bb).omega - (*ba).omega) + bias)
                - impulse_scale * lower_old;
            (*jn).weld_angular_impulse.y = max(lower_old + lower_delta, 0.0);
            let lower_applied = (*jn).weld_angular_impulse.y - lower_old;
            (*ba).omega = (*ba).omega - lower_applied * world_inv_inertia(*ba, steering_axis);
            (*bb).omega = (*bb).omega + lower_applied * world_inv_inertia(*bb, steering_axis);

            let upper_c = (*jn).target_rotation.w - steering_angle;
            bias = select(0.0, upper_c * inv_h, upper_c > 0.0);
            mass_scale = 1.0;
            impulse_scale = 0.0;
            if (upper_c <= 0.0 && params.use_bias == 1u) {
                bias = soft.x * upper_c;
                mass_scale = soft.y;
                impulse_scale = soft.z;
            }
            let upper_old = (*jn).weld_angular_impulse.z;
            let upper_delta = -mass_scale * steering_mass
                * (dot(steering_axis, (*ba).omega - (*bb).omega) + bias)
                - impulse_scale * upper_old;
            (*jn).weld_angular_impulse.z = max(upper_old + upper_delta, 0.0);
            let upper_applied = (*jn).weld_angular_impulse.z - upper_old;
            (*ba).omega = (*ba).omega + upper_applied * world_inv_inertia(*ba, steering_axis);
            (*bb).omega = (*bb).omega - upper_applied * world_inv_inertia(*bb, steering_axis);
        }
    }

    if (((*jn).flags & WHEEL_ENABLE_SUSPENSION_LIMIT) != 0u) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let inv_h = 1.0 / max(params.dt, 1e-8);
        let lower_c = translation - (*jn).lower_translation;
        var bias = select(0.0, lower_c * inv_h, lower_c > 0.0);
        var mass_scale = 1.0;
        var impulse_scale = 0.0;
        if (lower_c <= 0.0 && params.use_bias == 1u) {
            bias = soft.x * lower_c;
            mass_scale = soft.y;
            impulse_scale = soft.z;
        }
        let lower_old = (*jn).lower_impulse;
        let lower_cdot =
            dot(ax, (*bb).vel - (*ba).vel) + dot(sBx, (*bb).omega) - dot(sAx, (*ba).omega);
        let lower_delta =
            -mass_scale * suspension_mass * (lower_cdot + bias) - impulse_scale * lower_old;
        (*jn).lower_impulse = max(lower_old + lower_delta, 0.0);
        let lower_applied = (*jn).lower_impulse - lower_old;
        (*ba).vel = (*ba).vel - (*ba).inv_mass * lower_applied * ax;
        (*ba).omega = (*ba).omega - lower_applied * world_inv_inertia(*ba, sAx);
        (*bb).vel = (*bb).vel + (*bb).inv_mass * lower_applied * ax;
        (*bb).omega = (*bb).omega + lower_applied * world_inv_inertia(*bb, sBx);

        let upper_c = (*jn).upper_translation - translation;
        bias = select(0.0, upper_c * inv_h, upper_c > 0.0);
        mass_scale = 1.0;
        impulse_scale = 0.0;
        if (upper_c <= 0.0 && params.use_bias == 1u) {
            bias = soft.x * upper_c;
            mass_scale = soft.y;
            impulse_scale = soft.z;
        }
        let upper_old = (*jn).upper_impulse;
        let upper_cdot =
            dot(ax, (*ba).vel - (*bb).vel) + dot(sAx, (*ba).omega) - dot(sBx, (*bb).omega);
        let upper_delta =
            -mass_scale * suspension_mass * (upper_cdot + bias) - impulse_scale * upper_old;
        (*jn).upper_impulse = max(upper_old + upper_delta, 0.0);
        let upper_applied = (*jn).upper_impulse - upper_old;
        (*ba).vel = (*ba).vel + (*ba).inv_mass * upper_applied * ax;
        (*ba).omega = (*ba).omega + upper_applied * world_inv_inertia(*ba, sAx);
        (*bb).vel = (*bb).vel - (*bb).inv_mass * upper_applied * ax;
        (*bb).omega = (*bb).omega - upper_applied * world_inv_inertia(*bb, sBx);
    }

    if (!fixed_rotation) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        if (((*jn).flags & WHEEL_ENABLE_STEERING) != 0u) {
            let u = cross(bz, ax);
            let k = dot(u, world_inv_inertia(*ba, u) + world_inv_inertia(*bb, u));
            let mass = select(0.0, 1.0 / k, k > 0.0);
            let c = dot(ax, bz);
            let bias = select(0.0, soft.x * c, params.use_bias == 1u);
            let mass_scale = select(1.0, soft.y, params.use_bias == 1u);
            let impulse_scale = select(0.0, soft.z, params.use_bias == 1u);
            let delta = -mass_scale * mass * (dot((*bb).omega - (*ba).omega, u) + bias)
                - impulse_scale * (*jn).angular_impulse.x;
            (*jn).angular_impulse.x = (*jn).angular_impulse.x + delta;
            (*ba).omega = (*ba).omega - delta * world_inv_inertia(*ba, u);
            (*bb).omega = (*bb).omega + delta * world_inv_inertia(*bb, u);
        } else {
            let rel = quat_mul(quat_inv(frame_a), frame_b);
            let px = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(1.0, 0.0, 0.0) + cross(rel.xyz, vec3<f32>(1.0, 0.0, 0.0)),
            );
            let py = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(0.0, 1.0, 0.0) + cross(rel.xyz, vec3<f32>(0.0, 1.0, 0.0)),
            );
            let kxx = dot(px, world_inv_inertia(*ba, px) + world_inv_inertia(*bb, px));
            let kyy = dot(py, world_inv_inertia(*ba, py) + world_inv_inertia(*bb, py));
            let kxy = dot(px, world_inv_inertia(*ba, py) + world_inv_inertia(*bb, py));
            let det = kxx * kyy - kxy * kxy;
            var bias = vec2<f32>(0.0);
            var mass_scale = 1.0;
            var impulse_scale = 0.0;
            if (params.use_bias == 1u) {
                bias = soft.x * rel.xy;
                mass_scale = soft.y;
                impulse_scale = soft.z;
            }
            let wrel = (*bb).omega - (*ba).omega;
            let rhs = vec2<f32>(dot(wrel, px), dot(wrel, py)) + bias;
            var solution = vec2<f32>(0.0);
            if (det > 1e-30) {
                solution = vec2<f32>(
                    (kyy * rhs.x - kxy * rhs.y) / det,
                    (kxx * rhs.y - kxy * rhs.x) / det,
                );
            }
            let old = (*jn).angular_impulse.xy;
            let delta = -mass_scale * solution - impulse_scale * old;
            (*jn).angular_impulse.x = old.x + delta.x;
            (*jn).angular_impulse.y = old.y + delta.y;
            let impulse = delta.x * px + delta.y * py;
            (*ba).omega = (*ba).omega - world_inv_inertia(*ba, impulse);
            (*bb).omega = (*bb).omega + world_inv_inertia(*bb, impulse);
        }
    }

    var bias = vec2<f32>(0.0);
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (params.use_bias == 1u) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        bias = soft.x * vec2<f32>(dot(ay, d), dot(az, d));
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let vrel = ((*bb).vel + cross((*bb).omega, rB))
        - (*ba).vel - cross((*ba).omega, rA + d);
    let rhs = vec2<f32>(dot(ay, vrel), dot(az, vrel)) + bias;
    let kyy = (*ba).inv_mass + (*bb).inv_mass
        + dot(sAy, world_inv_inertia(*ba, sAy)) + dot(sBy, world_inv_inertia(*bb, sBy));
    let kyz = dot(sAy, world_inv_inertia(*ba, sAz)) + dot(sBy, world_inv_inertia(*bb, sBz));
    let kzz = (*ba).inv_mass + (*bb).inv_mass
        + dot(sAz, world_inv_inertia(*ba, sAz)) + dot(sBz, world_inv_inertia(*bb, sBz));
    let det = kyy * kzz - kyz * kyz;
    var solution = vec2<f32>(0.0);
    if (det > 1e-30) {
        solution = vec2<f32>(
            (kzz * rhs.x - kyz * rhs.y) / det,
            (kyy * rhs.y - kyz * rhs.x) / det,
        );
    }
    let delta = -mass_scale * solution - impulse_scale * (*jn).perp_impulse;
    (*jn).perp_impulse = (*jn).perp_impulse + delta;
    let p = delta.x * ay + delta.y * az;
    (*ba).vel = (*ba).vel - (*ba).inv_mass * p;
    (*ba).omega = (*ba).omega - world_inv_inertia(*ba, delta.x * sAy + delta.y * sAz);
    (*bb).vel = (*bb).vel + (*bb).inv_mass * p;
    (*bb).omega = (*bb).omega + world_inv_inertia(*bb, delta.x * sBy + delta.y * sBz);
}

fn solve_spherical(
    jn: ptr<function, Joint>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
) {
    let base_frame_a = normalize(quat_mul((*ba).rot, (*jn).frame_a_rotation));
    let base_frame_b = normalize(quat_mul((*bb).rot, (*jn).frame_b_rotation));
    let cone_axis = quat_rotate(base_frame_a, vec3<f32>(0.0, 0.0, 1.0));
    let twist_axis = quat_rotate(base_frame_b, vec3<f32>(0.0, 0.0, 1.0));
    let swing_axis = normalize_or_zero(cross(cone_axis, twist_axis));
    let base_rel = quat_mul(quat_inv(base_frame_a), base_frame_b);
    let tangent_denominator = base_rel.z * base_rel.z + base_rel.w * base_rel.w;
    let tan_half_swing = select(
        0.0,
        sqrt((base_rel.x * base_rel.x + base_rel.y * base_rel.y) / tangent_denominator),
        tangent_denominator > 0.0,
    );
    let twist_jacobian =
        tan_half_swing * cone_axis + cross(swing_axis, cone_axis);

    let swing_k = dot(swing_axis, world_inv_inertia(*ba, swing_axis)
        + world_inv_inertia(*bb, swing_axis));
    let swing_mass = select(0.0, 1.0 / swing_k, swing_k > 0.0);
    let twist_k = dot(twist_jacobian, world_inv_inertia(*ba, twist_jacobian)
        + world_inv_inertia(*bb, twist_jacobian));
    let twist_mass = select(0.0, 1.0 / twist_k, twist_k > 0.0);

    let i0 = world_inv_inertia(*ba, vec3<f32>(1.0, 0.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(1.0, 0.0, 0.0));
    let i1 = world_inv_inertia(*ba, vec3<f32>(0.0, 1.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 1.0, 0.0));
    let i2 = world_inv_inertia(*ba, vec3<f32>(0.0, 0.0, 1.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 0.0, 1.0));
    let fixed_rotation = abs(dot(i0, cross(i1, i2))) < 1e-30;

    let qa = normalize(quat_mul((*ba).dq, (*ba).rot));
    let qb = normalize(quat_mul((*bb).dq, (*bb).rot));
    let rA = joint_lever((*jn).a, qa, (*jn).anchor_a);
    let rB = joint_lever((*jn).b, qb, (*jn).anchor_b);

    if (params.use_bias == 2u) {
        var angular_impulse =
            (*jn).spring_angular_impulse + (*jn).motor_angular_impulse;
        angular_impulse = angular_impulse
            - (*jn).swing_impulse * swing_axis
            + ((*jn).lower_impulse - (*jn).upper_impulse) * twist_jacobian;
        apply_P(ba, rA, (*jn).angular_impulse, -1.0);
        apply_P(bb, rB, (*jn).angular_impulse, 1.0);
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, angular_impulse);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, angular_impulse);
        return;
    }

    let frame_a = normalize(quat_mul(qa, (*jn).frame_a_rotation));
    let frame_b = normalize(quat_mul(qb, (*jn).frame_b_rotation));
    let rel = quat_mul(quat_inv(frame_a), frame_b);

    // Box3D order: spring, motor, lower/upper twist, cone, point-to-point.
    if (((*jn).flags & SPHERICAL_ENABLE_SPRING) != 0u && !fixed_rotation) {
        let soft = spring_softness((*jn).spring_hertz, (*jn).spring_damping);
        let local_error = delta_quat_to_rotation(rel, (*jn).target_rotation);
        let c = -quat_rotate(frame_a, local_error);
        let cdot = (*bb).omega - (*ba).omega;
        let delta_impulse =
            -soft.y * rolling_mass_mul(*ba, *bb, cdot + soft.x * c)
            - soft.z * (*jn).spring_angular_impulse;
        (*jn).spring_angular_impulse =
            (*jn).spring_angular_impulse + delta_impulse;
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, delta_impulse);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, delta_impulse);
    }

    if (((*jn).flags & SPHERICAL_ENABLE_MOTOR) != 0u && !fixed_rotation) {
        let cdot =
            ((*bb).omega - (*ba).omega) - (*jn).motor_angular_velocity;
        let delta = -rolling_mass_mul(*ba, *bb, cdot);
        let old_impulse = (*jn).motor_angular_impulse;
        (*jn).motor_angular_impulse = clamp_vector_length(
            old_impulse + delta,
            (*jn).max_motor_force * params.dt,
        );
        let applied = (*jn).motor_angular_impulse - old_impulse;
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, applied);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, applied);
    }

    if (((*jn).flags & SPHERICAL_ENABLE_TWIST_LIMIT) != 0u && !fixed_rotation) {
        let angle = twist_angle(rel);
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let inv_h = 1.0 / max(params.dt, 1e-8);

        let lower_c = angle - (*jn).lower_translation;
        var lower_bias = 0.0;
        var lower_mass_scale = 1.0;
        var lower_impulse_scale = 0.0;
        if (lower_c > 0.0) {
            lower_bias = lower_c * inv_h;
        } else if (params.use_bias == 1u) {
            lower_bias = soft.x * lower_c;
            lower_mass_scale = soft.y;
            lower_impulse_scale = soft.z;
        }
        let lower_cdot =
            dot((*bb).omega - (*ba).omega, twist_jacobian);
        let old_lower = (*jn).lower_impulse;
        let lower_delta =
            -lower_mass_scale * twist_mass * (lower_cdot + lower_bias)
            - lower_impulse_scale * old_lower;
        (*jn).lower_impulse = max(old_lower + lower_delta, 0.0);
        let applied_lower = (*jn).lower_impulse - old_lower;
        (*ba).omega = (*ba).omega
            - applied_lower * world_inv_inertia(*ba, twist_jacobian);
        (*bb).omega = (*bb).omega
            + applied_lower * world_inv_inertia(*bb, twist_jacobian);

        let upper_c = (*jn).upper_translation - angle;
        var upper_bias = 0.0;
        var upper_mass_scale = 1.0;
        var upper_impulse_scale = 0.0;
        if (upper_c > 0.0) {
            upper_bias = upper_c * inv_h;
        } else if (params.use_bias == 1u) {
            upper_bias = soft.x * upper_c;
            upper_mass_scale = soft.y;
            upper_impulse_scale = soft.z;
        }
        let upper_cdot =
            dot((*ba).omega - (*bb).omega, twist_jacobian);
        let old_upper = (*jn).upper_impulse;
        let upper_delta =
            -upper_mass_scale * twist_mass * (upper_cdot + upper_bias)
            - upper_impulse_scale * old_upper;
        (*jn).upper_impulse = max(old_upper + upper_delta, 0.0);
        let applied_upper = (*jn).upper_impulse - old_upper;
        (*ba).omega = (*ba).omega
            + applied_upper * world_inv_inertia(*ba, twist_jacobian);
        (*bb).omega = (*bb).omega
            - applied_upper * world_inv_inertia(*bb, twist_jacobian);
    }

    if (((*jn).flags & SPHERICAL_ENABLE_CONE_LIMIT) != 0u && !fixed_rotation) {
        let c = (*jn).target_translation - swing_angle(rel);
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        var bias = 0.0;
        var mass_scale = 1.0;
        var impulse_scale = 0.0;
        if (c > 0.0) {
            bias = c / max(params.dt, 1e-8);
        } else if (params.use_bias == 1u) {
            bias = soft.x * c;
            mass_scale = soft.y;
            impulse_scale = soft.z;
        }
        let cdot = dot((*ba).omega - (*bb).omega, swing_axis);
        let old_impulse = (*jn).swing_impulse;
        let delta =
            -mass_scale * swing_mass * (cdot + bias)
            - impulse_scale * old_impulse;
        (*jn).swing_impulse = max(old_impulse + delta, 0.0);
        let applied = (*jn).swing_impulse - old_impulse;
        (*ba).omega =
            (*ba).omega + applied * world_inv_inertia(*ba, swing_axis);
        (*bb).omega =
            (*bb).omega - applied * world_inv_inertia(*bb, swing_axis);
    }

    let cdot =
        ((*bb).vel + cross((*bb).omega, rB))
        - ((*ba).vel + cross((*ba).omega, rA));
    var bias = vec3<f32>(0.0);
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (params.use_bias == 1u) {
        let soft = joint_softness((*jn).hertz, (*jn).damping);
        let separation =
            ((*bb).pos + (*bb).dp + rB) - ((*ba).pos + (*ba).dp + rA);
        bias = soft.x * separation;
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let solution = motor_linear_mass_mul(*ba, *bb, rA, rB, cdot + bias);
    let impulse =
        -mass_scale * solution - impulse_scale * (*jn).angular_impulse;
    (*jn).angular_impulse = (*jn).angular_impulse + impulse;
    apply_P(ba, rA, impulse, -1.0);
    apply_P(bb, rB, impulse, 1.0);
}

fn solve_weld(
    jn: ptr<function, Joint>,
    ba: ptr<function, Body>,
    bb: ptr<function, Body>,
) {
    let qa = normalize(quat_mul((*ba).dq, (*ba).rot));
    let qb = normalize(quat_mul((*bb).dq, (*bb).rot));
    let rA = joint_lever((*jn).a, qa, (*jn).anchor_a);
    let rB = joint_lever((*jn).b, qb, (*jn).anchor_b);

    if (params.use_bias == 2u) {
        apply_P(ba, rA, (*jn).weld_linear_impulse, -1.0);
        apply_P(bb, rB, (*jn).weld_linear_impulse, 1.0);
        (*ba).omega = (*ba).omega
            - world_inv_inertia(*ba, (*jn).weld_angular_impulse);
        (*bb).omega = (*bb).omega
            + world_inv_inertia(*bb, (*jn).weld_angular_impulse);
        return;
    }

    let i0 = world_inv_inertia(*ba, vec3<f32>(1.0, 0.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(1.0, 0.0, 0.0));
    let i1 = world_inv_inertia(*ba, vec3<f32>(0.0, 1.0, 0.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 1.0, 0.0));
    let i2 = world_inv_inertia(*ba, vec3<f32>(0.0, 0.0, 1.0))
        + world_inv_inertia(*bb, vec3<f32>(0.0, 0.0, 1.0));
    let fixed_rotation = abs(dot(i0, cross(i1, i2))) < 1e-30;

    // Box3D weld order: angular constraint, then point-to-point constraint.
    if (!fixed_rotation) {
        let frame_a = normalize(quat_mul(qa, (*jn).frame_a_rotation));
        var frame_b = normalize(quat_mul(qb, (*jn).frame_b_rotation));
        if (dot(frame_a, frame_b) < 0.0) {
            frame_b = -frame_b;
        }
        let rel = quat_mul(quat_inv(frame_a), frame_b);
        let soft = select(
            joint_softness((*jn).hertz, (*jn).damping),
            spring_softness(
                (*jn).weld_angular_hertz,
                (*jn).weld_angular_damping,
            ),
            (*jn).weld_angular_hertz > 0.0,
        );
        var bias = vec3<f32>(0.0);
        var mass_scale = 1.0;
        var impulse_scale = 0.0;
        if (params.use_bias == 1u || (*jn).weld_angular_hertz > 0.0) {
            let local_error =
                delta_quat_to_rotation(rel, vec4<f32>(0.0, 0.0, 0.0, 1.0));
            bias = soft.x * -quat_rotate(frame_a, local_error);
            mass_scale = soft.y;
            impulse_scale = soft.z;
        }
        let cdot = (*bb).omega - (*ba).omega;
        let impulse =
            -mass_scale * solve3(i0, i1, i2, cdot + bias)
            - impulse_scale * (*jn).weld_angular_impulse;
        (*jn).weld_angular_impulse =
            (*jn).weld_angular_impulse + impulse;
        (*ba).omega = (*ba).omega - world_inv_inertia(*ba, impulse);
        (*bb).omega = (*bb).omega + world_inv_inertia(*bb, impulse);
    }

    let cdot =
        ((*bb).vel + cross((*bb).omega, rB))
        - ((*ba).vel + cross((*ba).omega, rA));
    let soft = select(
        joint_softness((*jn).hertz, (*jn).damping),
        spring_softness((*jn).weld_linear_hertz, (*jn).weld_linear_damping),
        (*jn).weld_linear_hertz > 0.0,
    );
    var bias = vec3<f32>(0.0);
    var mass_scale = 1.0;
    var impulse_scale = 0.0;
    if (params.use_bias == 1u || (*jn).weld_linear_hertz > 0.0) {
        let separation =
            ((*bb).pos + (*bb).dp + rB) - ((*ba).pos + (*ba).dp + rA);
        bias = soft.x * separation;
        mass_scale = soft.y;
        impulse_scale = soft.z;
    }
    let solution = motor_linear_mass_mul(*ba, *bb, rA, rB, cdot + bias);
    let impulse =
        -mass_scale * solution - impulse_scale * (*jn).weld_linear_impulse;
    (*jn).weld_linear_impulse = (*jn).weld_linear_impulse + impulse;
    apply_P(ba, rA, impulse, -1.0);
    apply_P(bb, rB, impulse, 1.0);
}

fn joint_writable_root(jn: Joint) -> u32 {
    var ra = EMPTY;
    var rb = EMPTY;
    let ba = load_body(jn.a);
    let bb = load_body(jn.b);
    if (joint_endpoint_writable(ba)) {
        ra = island_root(jn.a);
        if (ra == EMPTY) {
            ra = jn.a;
        }
    }
    if (joint_endpoint_writable(bb)) {
        rb = island_root(jn.b);
        if (rb == EMPTY) {
            rb = jn.b;
        }
    }
    if (ra == EMPTY) {
        return rb;
    }
    if (rb == EMPTY || ra == rb) {
        return ra;
    }
    return min(ra, rb);
}

fn joint_solver_serial() -> bool {
    return (params.diagnostic_flags & DIAG_SERIAL_JOINTS) != 0u;
}

@compute @workgroup_size(64)
fn solve_joints(
    @builtin(global_invocation_id) dispatch_gid: vec3<u32>,
    @builtin(local_invocation_index) lid: u32,
) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let serial = joint_solver_serial();
    let list_ok = scratch[SCR_JOINT_LIST_OK] == 1u;
    if (serial && lid != 0u) {
        return;
    }
    let ncomp = scratch[SCR_JOINT_COMP_N];
    var use_list = !serial && list_ok;
    var n = params.joint_count;
    var list_off = 0u;
    if (use_list) {
        if (gid.x >= ncomp) {
            return;
        }
        list_off = scratch[joint_list_off_base() + gid.x];
        n = scratch[joint_list_count_base() + gid.x];
    } else if (!serial) {
        // Capacity/list failure must not drop joints: one lane solves all.
        if (lid != 0u) {
            return;
        }
    }
    let h = params.dt;
    for (var k = 0u; k < n; k++) {
        var i = k;
        if (use_list) {
            i = scratch[joint_list_base() + list_off + k];
        }
        var jn = joints[i];
        if (jn.kind == JOINT_NONE || jn.kind == JOINT_FILTER) {
            continue;
        }
        if (params.use_bias == 2u
            && jn.kind != JOINT_REVOLUTE
            && jn.kind != JOINT_SPHERICAL
            && jn.kind != JOINT_WELD
            && jn.kind != JOINT_WHEEL
            && jn.kind != JOINT_PRISMATIC
            && jn.kind != JOINT_DISTANCE
            && jn.kind != JOINT_PARALLEL
            && jn.kind != JOINT_MOTOR) {
            continue;
        }
        var ba = load_body(jn.a);
        var bb = load_body(jn.b);
        // Sleeping solver sets retain impulses until an endpoint wakes.
        if (is_immovable(ba) && is_immovable(bb)) {
            continue;
        }
        // 0: complete diagnostic walk, 1: dynamic joints, 2: anchored joints.
        // Keep sleep out of the classification: it must not change priority.
        let anchored = is_non_dynamic(ba) || is_non_dynamic(bb);
        if ((params.color_select == 1u && anchored)
            || (params.color_select == 2u && !anchored)) {
            continue;
        }
        let qa = normalize(quat_mul(ba.dq, ba.rot));
        let qb = normalize(quat_mul(bb.dq, bb.rot));
        var rA = joint_lever(jn.a, qa, jn.anchor_a);
        var rB = joint_lever(jn.b, qb, jn.anchor_b);
        let pa = ba.pos + ba.dp + rA;
        let pb = bb.pos + bb.dp + rB;
        var err = pb - pa;
        if (jn.kind == JOINT_MOTOR) {
            rA = quat_rotate(ba.dq, joint_lever(jn.a, ba.rot, jn.anchor_a));
            rB = quat_rotate(bb.dq, joint_lever(jn.b, bb.rot, jn.anchor_b));
            err = ((bb.dp - ba.dp) + (rB - rA)) + (bb.pos - ba.pos);
        }
        if (jn.kind == JOINT_REVOLUTE) {
            solve_revolute(&jn, &ba, &bb);
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_WHEEL) {
            solve_wheel(&jn, &ba, &bb);
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_WELD) {
            solve_weld(&jn, &ba, &bb);
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_SPHERICAL) {
            solve_spherical(&jn, &ba, &bb);
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_MOTOR) {
            // The warm-start wave reapplies the cached impulse to this substep's
            // velocities. Solving a new delta here loses sustained support force.
            if (params.use_bias == 2u) {
                let linear = vec3<f32>(jn.impulse, jn.perp_impulse)
                    + vec3<f32>(jn.spring_impulse, jn.lower_impulse, jn.upper_impulse);
                let angular = jn.angular_impulse
                    + vec3<f32>(jn.motor_impulse, jn._pad2);
                // Native combines both cached torques before multiplying by
                // inverse inertia, then adds the angular velocity delta once.
                if (joint_endpoint_writable(ba)) {
                    ba.vel = ba.vel - body_inv_mass(ba) * linear;
                    ba.omega = ba.omega - world_inv_inertia(ba, gyro_cross(rA,linear) + angular);
                }
                if (joint_endpoint_writable(bb)) {
                    bb.vel = bb.vel + body_inv_mass(bb) * linear;
                    bb.omega = bb.omega + world_inv_inertia(bb, gyro_cross(rB,linear) + angular);
                }
                if (joint_endpoint_writable(ba)) { store_body(jn.a, ba); }
                if (joint_endpoint_writable(bb)) { store_body(jn.b, bb); }
                continue;
            }
            let frame_a = normalize(quat_mul(qa, jn.frame_a_rotation));
            var frame_b = normalize(quat_mul(qb, jn.frame_b_rotation));
            if (dot(frame_a, frame_b) < 0.0) {
                frame_b = -frame_b;
            }
            let rel = quat_mul(quat_inv(frame_a), frame_b);
            var angular_spring_impulse =
                vec3<f32>(jn.motor_impulse, jn._pad2.x, jn._pad2.y);
            if (jn.max_motor_force > 0.0 && jn.spring_hertz > 0.0) {
                let omega = 6.2831853 * jn.spring_hertz;
                let a1 = 2.0 * jn.spring_damping + h * omega;
                let a2 = h * omega * a1;
                let a3 = 1.0 / (1.0 + a2);
                let bias_rate = omega / max(a1, 1e-8);
                let mass_scale = a2 * a3;
                let impulse_scale = a3;
                let rotation_error = 2.0 * quat_rotate(frame_a, rel.xyz);
                let cdot = bb.omega - ba.omega;
                let old = angular_spring_impulse;
                let delta = -mass_scale
                    * motor_angular_mass_mul(ba, bb, cdot + bias_rate * rotation_error)
                    - impulse_scale * old;
                angular_spring_impulse =
                    motor_clamp_vector_length(old + delta, h * jn.max_motor_force);
                let impulse = angular_spring_impulse - old;
                apply_joint_torque(&ba, -impulse);
                apply_joint_torque(&bb, impulse);
            }

            if (jn.lower_translation > 0.0) {
                let cdot = bb.omega - ba.omega - jn.motor_angular_velocity;
                let old = jn.angular_impulse;
                jn.angular_impulse = motor_clamp_vector_length(
                    old - motor_angular_mass_mul(ba, bb, cdot),
                    h * jn.lower_translation,
                );
                let impulse = jn.angular_impulse - old;
                apply_joint_torque(&ba, -impulse);
                apply_joint_torque(&bb, impulse);
            }

            var linear_spring_impulse =
                vec3<f32>(jn.spring_impulse, jn.lower_impulse, jn.upper_impulse);
            if (jn.upper_translation > 0.0 && jn.hertz > 0.0) {
                let omega = 6.2831853 * jn.hertz;
                let a1 = 2.0 * jn.damping + h * omega;
                let a2 = h * omega * a1;
                let a3 = 1.0 / (1.0 + a2);
                let bias_rate = omega / max(a1, 1e-8);
                let mass_scale = a2 * a3;
                let impulse_scale = a3;
                let cdot =
                    (bb.vel + gyro_cross(bb.omega, rB)) - (ba.vel + gyro_cross(ba.omega, rA));
                let old = linear_spring_impulse;
                let delta = -mass_scale
                    * motor_linear_mass_mul(ba, bb, rA, rB, cdot + bias_rate * err)
                    - impulse_scale * old;
                linear_spring_impulse =
                    motor_clamp_vector_length(old + delta, h * jn.upper_translation);
                let impulse = linear_spring_impulse - old;
                apply_P(&ba, rA, impulse, -1.0);
                apply_P(&bb, rB, impulse, 1.0);
            }

            var linear_velocity_impulse =
                vec3<f32>(jn.impulse, jn.perp_impulse.x, jn.perp_impulse.y);
            if (jn.target_translation > 0.0) {
                let cdot =
                    (bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA))
                    - jn.axis;
                let old = linear_velocity_impulse;
                linear_velocity_impulse = clamp_vector_length(
                    old - motor_linear_mass_mul(ba, bb, rA, rB, cdot),
                    h * jn.target_translation,
                );
                let impulse = linear_velocity_impulse - old;
                apply_P(&ba, rA, impulse, -1.0);
                apply_P(&bb, rB, impulse, 1.0);
            }

            jn.impulse = linear_velocity_impulse.x;
            jn.perp_impulse = linear_velocity_impulse.yz;
            jn.spring_impulse = linear_spring_impulse.x;
            jn.lower_impulse = linear_spring_impulse.y;
            jn.upper_impulse = linear_spring_impulse.z;
            jn.motor_impulse = angular_spring_impulse.x;
            jn._pad2 = angular_spring_impulse.yz;
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_PARALLEL) {
            let frame_a = normalize(quat_mul(qa, jn.frame_a_rotation));
            var frame_b = normalize(quat_mul(qb, jn.frame_b_rotation));
            if (dot(frame_a, frame_b) < 0.0) {
                frame_b = -frame_b;
            }
            let rel = quat_mul(quat_inv(frame_a), frame_b);
            let axis_x = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(1.0, 0.0, 0.0)
                    + cross(rel.xyz, vec3<f32>(1.0, 0.0, 0.0)),
            );
            let axis_y = 0.5 * quat_rotate(
                frame_a,
                rel.w * vec3<f32>(0.0, 1.0, 0.0)
                    + cross(rel.xyz, vec3<f32>(0.0, 1.0, 0.0)),
            );
            if (params.use_bias == 2u) {
                let impulse = jn.perp_impulse.x * axis_x + jn.perp_impulse.y * axis_y;
                apply_joint_torque(&ba, -impulse);
                apply_joint_torque(&bb, impulse);
            } else if (jn.max_motor_force > 0.0) {
                let kxx =
                    dot(axis_x, world_inv_inertia(ba, axis_x) + world_inv_inertia(bb, axis_x));
                let kyy =
                    dot(axis_y, world_inv_inertia(ba, axis_y) + world_inv_inertia(bb, axis_y));
                let kxy =
                    dot(axis_x, world_inv_inertia(ba, axis_y) + world_inv_inertia(bb, axis_y));
                let det = kxx * kyy - kxy * kxy;
                if (abs(det) > 1e-12) {
                    let omega = 6.2831853 * jn.spring_hertz;
                    let a1 = 2.0 * jn.spring_damping + h * omega;
                    let a2 = h * omega * a1;
                    let a3 = 1.0 / (1.0 + a2);
                    let bias_rate = select(0.0, omega / max(a1, 1e-8), jn.spring_hertz > 0.0);
                    let mass_scale = a2 * a3;
                    let impulse_scale = select(0.0, a3, jn.spring_hertz > 0.0);
                    let wrel = bb.omega - ba.omega;
                    let rhs = vec2<f32>(
                        dot(wrel, axis_x) + bias_rate * rel.x,
                        dot(wrel, axis_y) + bias_rate * rel.y,
                    );
                    let solution = vec2<f32>(
                        (kyy * rhs.x - kxy * rhs.y) / det,
                        (kxx * rhs.y - kxy * rhs.x) / det,
                    );
                    let old = jn.perp_impulse;
                    jn.perp_impulse =
                        old - mass_scale * solution - impulse_scale * old;
                    let max_impulse = h * jn.max_motor_force;
                    let impulse_length = length(jn.perp_impulse);
                    if (impulse_length > max_impulse) {
                        jn.perp_impulse = jn.perp_impulse * (max_impulse / impulse_length);
                    }
                    let delta = jn.perp_impulse - old;
                    let angular_impulse = delta.x * axis_x + delta.y * axis_y;
                    apply_joint_torque(&ba, -angular_impulse);
                    apply_joint_torque(&bb, angular_impulse);
                }
            }
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_DISTANCE) {
            let distance = length(err);
            var axis = vec3<f32>(1.0, 0.0, 0.0);
            if (distance > 1e-8) {
                axis = err / distance;
            }
            let axial_mass = normal_mass(ba, bb, rA, rB, axis);
            let enable_spring = (jn.flags & DISTANCE_ENABLE_SPRING) != 0u;
            let enable_limit = (jn.flags & DISTANCE_ENABLE_LIMIT) != 0u;
            let soft_distance =
                enable_spring && (jn.lower_translation < jn.upper_translation || !enable_limit);
            if (soft_distance) {
                if (jn.spring_hertz > 0.0) {
                    let omega = 6.2831853 * jn.spring_hertz;
                    let a1 = 2.0 * max(jn.spring_damping, 0.0) + h * omega;
                    let a2 = h * omega * a1;
                    let a3 = 1.0 / (1.0 + a2);
                    let bias_rate = omega / max(a1, 1e-8);
                    let mass_scale = select(1.0, a2 * a3, params.use_bias == 1u);
                    let impulse_scale = select(0.0, a3, params.use_bias == 1u);
                    let vrel =
                        (bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA));
                    let cdot = dot(vrel, axis);
                    let bias = select(
                        0.0,
                        bias_rate * (distance - jn.target_translation),
                        params.use_bias == 1u,
                    );
                    let dj =
                        -mass_scale * axial_mass * (cdot + bias)
                        - impulse_scale * jn.spring_impulse;
                    let old = jn.spring_impulse;
                    jn.spring_impulse = clamp(
                        old + dj,
                        h * jn.perp_impulse.x,
                        h * jn.perp_impulse.y,
                    );
                    let P = axis * (jn.spring_impulse - old);
                    apply_P(&ba, rA, P, -1.0);
                    apply_P(&bb, rB, P, 1.0);
                }
                if (enable_limit) {
                    let inv_h = 1.0 / max(h, 1e-8);
                    let softness = contact_softness(is_immovable(ba) || is_immovable(bb));
                    let vrel =
                        (bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA));

                    let lower_c = distance - jn.lower_translation;
                    let lower_bias = select(
                        lower_c * inv_h,
                        softness.x * lower_c,
                        lower_c <= 0.0 && params.use_bias == 1u,
                    );
                    let old_lower = jn.lower_impulse;
                    let lower_dj = -axial_mass * (dot(vrel, axis) + lower_bias);
                    jn.lower_impulse = max(old_lower + lower_dj, 0.0);
                    let lower_p = axis * (jn.lower_impulse - old_lower);
                    apply_P(&ba, rA, lower_p, -1.0);
                    apply_P(&bb, rB, lower_p, 1.0);

                    let upper_c = jn.upper_translation - distance;
                    let upper_bias = select(
                        upper_c * inv_h,
                        softness.x * upper_c,
                        upper_c <= 0.0 && params.use_bias == 1u,
                    );
                    let old_upper = jn.upper_impulse;
                    let upper_dj = -axial_mass * (-dot(vrel, axis) + upper_bias);
                    jn.upper_impulse = max(old_upper + upper_dj, 0.0);
                    let upper_p = -axis * (jn.upper_impulse - old_upper);
                    apply_P(&ba, rA, upper_p, -1.0);
                    apply_P(&bb, rB, upper_p, 1.0);
                }
                if ((jn.flags & DISTANCE_ENABLE_MOTOR) != 0u && jn.max_motor_force > 0.0) {
                    let vrel =
                        (bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA));
                    let dj = axial_mass * (jn.motor_speed - dot(vrel, axis));
                    let old = jn.motor_impulse;
                    let max_impulse = h * jn.max_motor_force;
                    jn.motor_impulse = clamp(old + dj, -max_impulse, max_impulse);
                    let P = axis * (jn.motor_impulse - old);
                    apply_P(&ba, rA, P, -1.0);
                    apply_P(&bb, rB, P, 1.0);
                }
            } else {
                let omega = 6.2831853 * max(jn.hertz, 1.0);
                let a1 = 2.0 * max(jn.damping, 0.25) + h * omega;
                let a2 = h * omega * a1;
                let a3 = 1.0 / (1.0 + a2);
                let mass_scale = select(1.0, a2 * a3, params.use_bias == 1u);
                let impulse_scale = select(0.0, a3, params.use_bias == 1u);
                let bias = select(
                    0.0,
                    omega / max(a1, 1e-8) * (distance - jn.target_translation),
                    params.use_bias == 1u,
                );
                let vrel =
                    (bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA));
                let dj =
                    -mass_scale * axial_mass * (dot(vrel, axis) + bias)
                    - impulse_scale * jn.impulse;
                jn.impulse = jn.impulse + dj;
                let P = axis * dj;
                apply_P(&ba, rA, P, -1.0);
                apply_P(&bb, rB, P, 1.0);
            }
            if (params.use_bias == 0u) {
                // Distance-only diagnostic snapshot; these fields are unused by its solver.
                jn.weld_linear_impulse = vec3<f32>(jn.impulse + jn.spring_impulse, jn.lower_impulse, jn.upper_impulse);
                jn.weld_angular_impulse = vec3<f32>(jn.motor_impulse, 0.0, 0.0);
                jn.impulse = 0.0;
                jn.spring_impulse = 0.0;
                jn.lower_impulse = 0.0;
                jn.upper_impulse = 0.0;
                jn.motor_impulse = 0.0;
            }
            err = vec3<f32>(0.0);
        } else if (jn.kind == JOINT_PRISMATIC) {
            solve_prismatic(&jn, &ba, &bb);
            err = vec3<f32>(0.0);
        }
        let nlen = length(err);
        if (nlen > 1e-8) {
            let n = err / nlen;
            let kmass = max(body_inv_mass(ba) + body_inv_mass(bb), 1e-8);
            let soft = contact_softness(is_immovable(ba) || is_immovable(bb));
            let hertz = max(jn.hertz, 1.0);
            let omega = 6.2831853 * hertz;
            let zeta = max(jn.damping, 0.25);
            let a1 = 2.0 * zeta + h * omega;
            let a2 = h * omega * a1;
            let a3 = 1.0 / (1.0 + a2);
            let bias_rate = omega / a1;
            var mass_scale = a2 * a3;
            var impulse_scale = a3;
            if (params.use_bias == 0u) {
                mass_scale = 1.0;
                impulse_scale = 0.0;
            }
            let vn = dot((bb.vel + cross(bb.omega, rB)) - (ba.vel + cross(ba.omega, rA)), n);
            let c = nlen;
            let bias = select(0.0, bias_rate * c, params.use_bias == 1u);
            let nm = 1.0 / kmass;
            let dj = -mass_scale * nm * (vn + bias) - impulse_scale * jn.impulse;
            jn.impulse = jn.impulse + dj;
            let P = n * dj;
            apply_P(&ba, rA, P, -1.0);
            apply_P(&bb, rB, P, 1.0);
            if (params.use_bias == 1u) {
                let corr = n * c * 0.2;
                if (!is_immovable(ba)) {
                    ba.dp = ba.dp + corr * (body_inv_mass(ba) / kmass);
                }
                if (!is_immovable(bb)) {
                    bb.dp = bb.dp - corr * (body_inv_mass(bb) / kmass);
                }
            }
        }
        if (joint_endpoint_writable(ba)) {
            store_body(jn.a, ba);
        }
        if (joint_endpoint_writable(bb)) {
            store_body(jn.b, bb);
        }
        joints[i] = jn;
    }
}

@compute @workgroup_size(64)
fn compact_joint_heads(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i < params.body_count) {
        scratch[joint_head_base() + i] = EMPTY;
    }
    if (gid.x == 0u) {
        scratch[SCR_JOINT_COMP_N] = 0u;
        scratch[SCR_JOINT_LIST_OK] = 0u;
    }
}

@compute @workgroup_size(64)
fn compact_joint_components(@builtin(local_invocation_index) lid: u32) {
    if (lid != 0u) {
        return;
    }
    var ncomp = 0u;
    let head = joint_head_base();
    let unique = joint_comp_base();
    let offb = joint_list_off_base();
    let cntb = joint_list_count_base();
    let listb = joint_list_base();
    for (var i = 0u; i < params.joint_count; i++) {
        let jn = joints[i];
        if (jn.kind == JOINT_NONE || jn.kind == JOINT_FILTER) {
            continue;
        }
        let root = joint_writable_root(jn);
        if (root == EMPTY || root >= params.body_count) {
            continue;
        }
        if (scratch[head + root] == EMPTY) {
            scratch[unique + ncomp] = root;
            scratch[head + root] = ncomp;
            ncomp = ncomp + 1u;
        }
    }
    scratch[SCR_JOINT_COMP_N] = ncomp;
    for (var c = 0u; c < ncomp; c++) {
        scratch[cntb + c] = 0u;
    }
    for (var i = 0u; i < params.joint_count; i++) {
        let jn = joints[i];
        if (jn.kind == JOINT_NONE || jn.kind == JOINT_FILTER) {
            continue;
        }
        let root = joint_writable_root(jn);
        if (root == EMPTY || root >= params.body_count) {
            continue;
        }
        let c = scratch[head + root];
        scratch[cntb + c] = scratch[cntb + c] + 1u;
    }
    var acc = 0u;
    for (var c = 0u; c < ncomp; c++) {
        scratch[offb + c] = acc;
        acc = acc + scratch[cntb + c];
        scratch[cntb + c] = 0u;
    }
    for (var i = 0u; i < params.joint_count; i++) {
        let jn = joints[i];
        if (jn.kind == JOINT_NONE || jn.kind == JOINT_FILTER) {
            continue;
        }
        let root = joint_writable_root(jn);
        if (root == EMPTY || root >= params.body_count) {
            continue;
        }
        let c = scratch[head + root];
        let w = scratch[offb + c] + scratch[cntb + c];
        scratch[listb + w] = i;
        scratch[cntb + c] = scratch[cntb + c] + 1u;
    }
    scratch[SCR_JOINT_LIST_OK] = 1u;
}
// Velocity/position integrate and TGS delta apply.

fn modified_cross(a: vec3<f32>, b: vec3<f32>) -> vec3<f32> {
    return vec3<f32>(
        a.y * b.z + a.z * b.y,
        a.z * b.x + a.x * b.z,
        a.x * b.y + a.y * b.x,
    );
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_init(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    let s = body_states[i];
    let static_body = (s.flags & (FLAG_STATIC | FLAG_KINEMATIC | FLAG_DISABLED)) != 0u;
    atomicStore(&atom[atom_island_label() + i], select(i, EMPTY, static_body));
    atomicStore(&atom[atom_island_wake() + i], 0u);
    atomicStore(&atom[atom_island_ready() + i], 1u);
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_union_edges(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    let nc = min(scratch[SCR_NCONTACTS], pair_cap());
    if (i < nc) {
        let c = contacts[scratch[scr_active_contact() + i]];
        if (c.a != EMPTY && c.count != 0u) {
            island_union(c.a, c.b);
        }
    }
    if (i < params.joint_count) {
        let j = joints[i];
        if (j.kind != JOINT_NONE) {
            island_union(j.a, j.b);
        }
    }
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_accumulate_wake(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    if (params.enable_sleep == 0u) {
        body_states[i].flags = body_states[i].flags & (~FLAG_SLEEP);
        body_states[i].sleep_time = 0.0;
        return;
    }
    let root = island_root(i);
    atomicStore(&atom[atom_island_label() + i], root);
    if (root != EMPTY && (body_states[i].flags & FLAG_SLEEP) == 0u) {
        atomicOr(&atom[atom_island_wake() + root], 1u);
    }
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_apply_wake(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count || params.enable_sleep == 0u) {
        return;
    }
    let root = atomicLoad(&atom[atom_island_label() + i]);
    if (root != EMPTY && atomicLoad(&atom[atom_island_wake() + root]) != 0u
        && (body_states[i].flags & FLAG_SLEEP) != 0u) {
        body_states[i].flags = body_states[i].flags & (~FLAG_SLEEP);
        body_states[i].sleep_time = 0.0;
    }
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_reset_ready(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    if (gid.x < params.body_count) {
        atomicStore(&atom[atom_island_ready() + gid.x], 1u);
    }
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_accumulate_ready(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count || params.enable_sleep == 0u) {
        return;
    }
    let root = atomicLoad(&atom[atom_island_label() + i]);
    if (root == EMPTY) {
        return;
    }
    // Explicitly sleeping bodies stay ready even before the automatic sleep
    // timer expires. Island wake propagation above handles active neighbours.
    let ready = (body_states[i].flags & FLAG_SLEEP) != 0u
        || ((body_states[i].flags & FLAG_SLEEP_ENABLED) != 0u
            && body_states[i].sleep_time >= TIME_TO_SLEEP);
    atomicAnd(&atom[atom_island_ready() + root], select(0u, 1u, ready));
}

@compute @workgroup_size(ISLAND_WORKGROUP_SIZE)
fn island_apply_sleep(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, ISLAND_WORKGROUP_SIZE), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count || params.enable_sleep == 0u) {
        return;
    }
    let root = atomicLoad(&atom[atom_island_label() + i]);
    if (root == EMPTY) {
        return;
    }
    if (atomicLoad(&atom[atom_island_ready() + root]) != 0u) {
        body_states[i].flags = body_states[i].flags | FLAG_SLEEP;
        body_states[i].vel = vec3<f32>(0.0);
        body_states[i].omega = vec3<f32>(0.0);
    } else {
        body_states[i].flags = body_states[i].flags & (~FLAG_SLEEP);
    }
}

@compute @workgroup_size(64)
fn reset_deltas(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    var b = body_states[i];
    b.dp = vec3<f32>(0.0);
    b.dq = vec4<f32>(0.0, 0.0, 0.0, 1.0);
    body_states[i] = b;
}

@compute @workgroup_size(64)
fn apply_deltas(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    var b = body_states[i];
    b.flags = b.flags & (~FLAG_FAST);
    if ((b.flags & (FLAG_STATIC | FLAG_DISABLED | FLAG_SLEEP)) == 0u) {
        // Always apply TGS pose. Skipping `dp` while "quiet" left stacks nested
        // inside each other until a later step woke them and popped them apart.
        let base_rotation = b.rot;
        b.pos = b.pos + b.dp;
        b.rot = gyro_finish_rotation(b.dq, b.rot);
        let extra = body_extra_offset(i);
        let half = vec3<f32>(scene_f32(extra + 4u), scene_f32(extra + 5u), scene_f32(extra + 6u));
        let local_omega = abs(quat_rotate(quat_inv(base_rotation), b.omega));
        let velocity_arc = modified_cross(local_omega, half);
        let max_velocity = length(b.vel) + length(velocity_arc);
        let local_delta_rotation = abs(quat_rotate(quat_inv(base_rotation), b.dq.xyz));
        let rotation_arc = modified_cross(local_delta_rotation, half);
        let max_delta = length(b.dp) + 2.0 * length(rotation_arc);
        let sleep_velocity = max(max_velocity, 0.5 * max_delta / max(params.step_dt, 1e-8));
        b.sleep_velocity = sleep_velocity;
        let quiet = params.enable_sleep != 0u
            && (b.flags & FLAG_SLEEP_ENABLED) != 0u
            && sleep_velocity <= scene_f32(extra + 7u);
        let min_extent = scene_f32(extra + 3u);
        let max_motion = max(max_delta, max_velocity * params.step_dt);
        if (!quiet && params.enable_continuous != 0u
            && (b.flags & (FLAG_KINEMATIC | FLAG_DISABLED)) == 0u
            && (b.flags & FLAG_KINEMATIC) == 0u && max_motion > 0.5 * min_extent) {
            b.flags = b.flags | FLAG_FAST;
        }
        if (quiet) {
            b.sleep_time = b.sleep_time + params.step_dt;
        } else {
            b.sleep_time = 0.0;
            b.flags = b.flags & (~FLAG_SLEEP);
        }
    }
    b.dp = vec3<f32>(0.0);
    b.dq = vec4<f32>(0.0, 0.0, 0.0, 1.0);
    body_states[i] = b;
}

fn fused_body(i: u32) -> bool {
    return scratch[fused_flag_base() + i] != 0u;
}

fn integrate_vel_one(i: u32) {
    var b = load_body(i);
    // Kinematic bodies damp their prescribed velocities too. Their zero inverse
    // mass suppresses gravity/forces; static and disabled bodies do not advance.
    if ((b.flags & (FLAG_STATIC | FLAG_DISABLED | FLAG_SLEEP)) == 0u) {
        let g = vec3<f32>(params.gravity_x, params.gravity_y, params.gravity_z);
        let h = params.dt;
        let ld = 1.0 / (1.0 + h * b.linear_damping);
        let ad = 1.0 / (1.0 + h * b.angular_damping);
        let extra = body_extra_offset(i);
        let force = vec3<f32>(scene_f32(extra + 8u), scene_f32(extra + 9u), scene_f32(extra + 10u));
        let torque = vec3<f32>(scene_f32(extra + 12u), scene_f32(extra + 13u), scene_f32(extra + 14u));
        let gravity_scale = select(0.0, b.gravity_scale, b.inv_mass > 0.0);
        if (any(force != vec3<f32>(0.0))) {
            // Native applies the load on every substep, after damping the old velocity.
            let delta = (h * b.inv_mass) * force + (h * gravity_scale) * g;
            b.vel = delta + ld * b.vel;
        } else {
            b.vel = g * (h * gravity_scale) + b.vel * ld;
        }
        if (any(torque != vec3<f32>(0.0))) {
            b.omega = h * world_inv_inertia(b, torque) + ad * b.omega;
        } else {
            b.omega = b.omega * ad;
        }
        gyro_apply_gyro(&b, h);
        if ((b.flags & 256u) != 0u) { b.vel.x = 0.0; }
        if ((b.flags & 512u) != 0u) { b.vel.y = 0.0; }
        if ((b.flags & 1024u) != 0u) { b.vel.z = 0.0; }
        if ((b.flags & 2048u) != 0u) { b.omega.x = 0.0; }
        if ((b.flags & 4096u) != 0u) { b.omega.y = 0.0; }
        if ((b.flags & 8192u) != 0u) { b.omega.z = 0.0; }
    }
    store_body(i, b);
}

fn integrate_pos_one(i: u32) {
    var b = body_states[i];
    if ((b.flags & FLAG_STATIC) == 0u
        && (b.flags & FLAG_SLEEP) == 0u
        && (b.flags & FLAG_DISABLED) == 0u) {
        if ((b.flags & 256u) != 0u) { b.vel.x = 0.0; }
        if ((b.flags & 512u) != 0u) { b.vel.y = 0.0; }
        if ((b.flags & 1024u) != 0u) { b.vel.z = 0.0; }
        if ((b.flags & 2048u) != 0u) { b.omega.x = 0.0; }
        if ((b.flags & 4096u) != 0u) { b.omega.y = 0.0; }
        if ((b.flags & 8192u) != 0u) { b.omega.z = 0.0; }
        let max_linear_speed = params.maximum_linear_speed;
        let linear_speed2 = dot(b.vel, b.vel);
        if (linear_speed2 > max_linear_speed * max_linear_speed) {
            b.vel = b.vel * (max_linear_speed / sqrt(linear_speed2));
        }
        let max_angular_speed = 0.78539816339 / max(params.step_dt, 1e-8);
        let angular_speed2 = dot(b.omega, b.omega);
        if ((b.flags & FLAG_ALLOW_FAST_ROTATION) == 0u
            && angular_speed2 > max_angular_speed * max_angular_speed) {
            b.omega = b.omega * (max_angular_speed / sqrt(angular_speed2));
        }
        let h = params.dt;
        b.dp = b.dp + b.vel * h;
        b.dq = gyro_integrate_rotation(b.dq, b.omega, h);
    }
    body_states[i] = b;
}

fn solve_tiny_slot(slot: u32, mode: u32) {
    var c = load_solve_contact(slot);
    if (c.a == EMPTY || c.count == 0u) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_contact_chain(slot, &ba, &bb, mode);
    if (!is_immovable(ba)) {
        store_body(c.a, ba);
    }
    if (!is_immovable(bb)) {
        store_body(c.b, bb);
    }
}

fn solve_validated_component_slot(slot: u32, mode: u32) {
    var c = load_solve_contact(slot);
    if (c.a == EMPTY || c.count == 0u) {
        return;
    }
    var ba = load_body(c.a);
    var bb = load_body(c.b);
    solve_validated_contact_chain_store(slot, &ba, &bb, mode, true);
    if (!is_immovable(ba)) {
        store_body(c.a, ba);
    }
    if (!is_immovable(bb)) {
        store_body(c.b, bb);
    }
}

@compute @workgroup_size(64)
fn solve_tiny_islands(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count || !fused_body(i)) {
        return;
    }
    let nsub = max(params.sub_step_count, 1u);
    let base = fused_slots_base() + 8u * i;
    for (var sub = 0u; sub < nsub; sub++) {
        integrate_vel_one(i);
        for (var k = 0u; k < 8u; k++) {
            let slot = scratch[base + k];
            if (slot != EMPTY) {
                solve_tiny_slot(slot, 2u);
                solve_tiny_slot(slot, 1u);
            }
        }
        integrate_pos_one(i);
        for (var k = 0u; k < 8u; k++) {
            let slot = scratch[base + k];
            if (slot != EMPTY) {
                solve_tiny_slot(slot, 0u);
            }
        }
    }
    for (var k = 0u; k < 8u; k++) {
        let slot = scratch[base + k];
        if (slot != EMPTY) {
            solve_tiny_slot(slot, 3u);
        }
    }
}

@compute @workgroup_size(64)
fn integrate_vel(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    integrate_vel_one(i);
}

@compute @workgroup_size(64)
fn integrate_pos(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i = gid.x;
    if (i >= params.body_count) {
        return;
    }
    integrate_pos_one(i);
}

// Opt-in, phase-accurate diagnostics. Each dispatch records the body state
// visible to the following pipeline plus aggregate contact persistence data.
@compute @workgroup_size(64)
fn capture_phase(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if ((params.diagnostic_flags & DIAG_PHASE_CAPTURE) == 0u) {
        return;
    }
    let i = gid.x;
    let phase = params.color_select;
    if (i < params.body_count) {
        let b = body_states[i];
        let base = phase_body_base() + (phase * params.body_count + i) * 8u;
        scratch[base] = bitcast<u32>(b.vel.x);
        scratch[base + 1u] = bitcast<u32>(b.vel.z);
        scratch[base + 2u] = bitcast<u32>(length(b.omega));
        scratch[base + 3u] = b.flags;
        scratch[base + 4u] = bitcast<u32>(b.vel.y);
        scratch[base + 5u] = bitcast<u32>(b.omega.x);
        scratch[base + 6u] = bitcast<u32>(b.omega.y);
        scratch[base + 7u] = bitcast<u32>(b.omega.z);
    }
    if (i != 0u) {
        return;
    }
    var touching = 0u;
    var feature_points = 0u;
    var warm_points = 0u;
    var normal_impulse = 0.0;
    var tangent_impulse2 = 0.0;
    let pair_count = min(scratch[SCR_NCONTACTS], pair_cap());
    for (var j = 0u; j < pair_count; j++) {
        let slot = scratch[scr_active_contact() + j];
        let c = load_contact(slot);
        if (c.a == EMPTY || c.count == 0u) {
            continue;
        }
        touching = touching + 1u;
        for (var p = 0u; p < c.count; p++) {
            feature_points = feature_points + select(0u, 1u, feat_at(c, p) != 0u);
            let impulse = rb_at(c, p).w;
            warm_points = warm_points + select(0u, 1u, impulse > 0.0);
            normal_impulse = normal_impulse + impulse;
        }
        tangent_impulse2 = tangent_impulse2 + dot(c.friction_impulse, c.friction_impulse);
    }
    let summary = phase_summary_base() + phase * 8u;
    scratch[summary] = phase;
    scratch[summary + 1u] = touching;
    scratch[summary + 2u] = feature_points;
    scratch[summary + 3u] = warm_points;
    scratch[summary + 4u] = bitcast<u32>(normal_impulse);
    scratch[summary + 5u] = bitcast<u32>(sqrt(tangent_impulse2));
    scratch[summary + 6u] = pair_count;
    scratch[summary + 7u] = scratch[SCR_BSTRIDE];
}

// Experimental complete-component TGS. Static endpoints are read-only and
// moving immovable endpoints/joints are excluded by the host eligibility check.
fn component_owns_contact(slot: u32, root: u32) -> bool {
    // Other components may already be updating hot contacts. Persistent pair
    // identity and scene shape metadata stay read-only throughout TGS.
    let key=contact_persistent[slot].pair.xy;
    let a=load_shape(key.x).body_index;
    let b=load_shape(key.y).body_index;
    return island_root(a)==root || island_root(b)==root;
}
fn component_integrate(root: u32, position: bool, n: u32, ids: ptr<function, array<u32, 8>>) {
    if (n <= 8u) {
        for (var i=0u; i<n; i++) {
            if (position) { integrate_pos_one((*ids)[i]); } else { integrate_vel_one((*ids)[i]); }
        }
    } else {
        for (var i=0u; i<params.body_count; i++) {
            if (island_root(i) == root) {
                if (position) { integrate_pos_one(i); } else { integrate_vel_one(i); }
            }
        }
    }
}
fn component_phase(root: u32, mode: u32, n: u32, slots: ptr<function, array<u32, 32>>) {
    if (n <= 32u) {
        for (var i=0u; i<n; i++) { solve_validated_component_slot((*slots)[i], mode); }
    } else {
        // Large components retain all constraints, in reference wave order.
        for (var wave=0u; wave<=OVERFLOW_COLOR; wave++) {
            let col = select(wave-1u, OVERFLOW_COLOR, wave==0u);
            for (var i=0u; i<scratch[SCR_COLOR+col]; i++) {
                let slot=listed_index(col,i);
                if (component_owns_contact(slot,root)) { solve_tiny_slot(slot,mode); }
            }
        }
    }
}
override SMALL_COMPONENT_WORKGROUP_SIZE:u32=16u;
@compute @workgroup_size(SMALL_COMPONENT_WORKGROUP_SIZE)
fn solve_complete_components(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, SMALL_COMPONENT_WORKGROUP_SIZE), 0u, 0u);
    let root=gid.x;
    if (atomicLoad(&query[260u])!=0u) {return;}
    if (root>=params.body_count || island_root(root)!=root) {return;}
    // Island-wide wake propagation has completed. A sleeping root proves all
    // writable members sleep; preserve their bodies and cached impulses.
    if ((body_states[root].flags & FLAG_SLEEP)!=0u) {return;}
    let meta_base=component_meta(root);
    let body_n=atomicLoad(&query[meta_base]);
    let contact_n=atomicLoad(&query[meta_base+1u]);
    if (body_n>8u || contact_n>32u) {return;}
    let body_start=atomicLoad(&query[meta_base+2u]);
    let contact_start=atomicLoad(&query[meta_base+3u]);
    var ids: array<u32,8>;
    for (var i=0u;i<body_n;i++) {ids[i]=atomicLoad(&query[component_bodies()+body_start+i]);}
    var slots: array<u32,32>;
    var keys: array<u32,32>;
    for (var i=0u;i<contact_n;i++) {
        let at=component_contacts()+2u*(contact_start+i);
        let slot=atomicLoad(&query[at]);let key=atomicLoad(&query[at+1u]);
        // No allocation/retirement occurs during this component's TGS dispatch.
        // Reject the complete component before integration if a chain is invalid.
        if (!contact_chain_valid(slot)) { return; }
        var j=i;
        loop {
            if (j==0u) {break;}
            if (keys[j-1u]<=key) {break;}
            keys[j]=keys[j-1u];slots[j]=slots[j-1u];j--;
        }
        keys[j]=key;slots[j]=slot;
    }
    for (var sub=0u; sub<max(params.sub_step_count,1u); sub++) {
        component_integrate(root,false,body_n,&ids);
        component_phase(root,2u,contact_n,&slots);
        component_phase(root,1u,contact_n,&slots);
        component_integrate(root,true,body_n,&ids);
        // Dispatch binds use_bias=1. Keep the relaxed phase uniform-derived,
        // like the global solver: literal-zero specialization changed normal
        // impulse results on NVIDIA and accumulated drift in the comparison.
        component_phase(root,params.use_bias - 1u,contact_n,&slots);
    }
    component_phase(root,3u,contact_n,&slots);
}


var<workgroup> large_component_enabled: u32;
var<workgroup> large_component_color_mask: u32;
fn large_component_integrate(root: u32, lid: u32, position: bool) {
    let meta_base=component_meta(root);let n=atomicLoad(&query[meta_base]);let start=atomicLoad(&query[meta_base+2u]);
    for (var k=lid; k<n; k+=64u) {
        let i=atomicLoad(&query[component_bodies()+start+k]);
        if (position) { integrate_pos_one(i); } else { integrate_vel_one(i); }
    }
    storageBarrier();
    workgroupBarrier();
}
fn large_component_phase(root: u32, lid: u32, mode: u32, color_mask:u32) {
    for (var wave=0u; wave<=OVERFLOW_COLOR; wave++) {
        let col=select(wave-1u,OVERFLOW_COLOR,wave==0u);
        if ((color_mask & (1u<<col))==0u) {continue;}
        let n=scratch[SCR_COLOR+col];
        if (col==OVERFLOW_COLOR) {
            if (lid==0u) {
                for (var i=0u; i<n; i++) {
                    let slot=listed_index(col,i);
                    if (component_owns_contact(slot,root)) {solve_validated_component_slot(slot,mode);}
                }
            }
        } else {
            let count=atomicLoad(&query[component_color_counts()+24u*root+col]);
            let start=atomicLoad(&query[component_color_starts()+24u*root+col]);
            // Each color is contiguous; do not rescan all island contacts for every wave.
            for (var i=lid;i<count;i+=64u) {
                solve_validated_component_slot(atomicLoad(&query[component_contacts()+2u*(start+i)]),mode);
            }
        }
        storageBarrier();
        workgroupBarrier();
    }
}
var<workgroup> large_component_invalid: atomic<u32>;
@compute @workgroup_size(64)
fn solve_large_components(@builtin(workgroup_id) group: vec3<u32>, @builtin(local_invocation_index) lid:u32) {
    let index=group.x+256u*group.y;
    if (lid==0u) {
        large_component_enabled=EMPTY;
        atomicStore(&large_component_invalid,0u);
        if (index<atomicLoad(&query[256u])) {
            let candidate=atomicLoad(&query[component_large_roots()+index]);
            if ((body_states[candidate].flags & FLAG_SLEEP)==0u) {large_component_enabled=candidate;}
        }
    }
    workgroupBarrier();
    let root=workgroupUniformLoad(&large_component_enabled);
    if (root==EMPTY) {return;}
    // Every color, including overflow, occupies this component's compact range.
    // Links, endpoints and point counts cannot change during the TGS dispatch.
    // Reject the entire component before integration, then reuse that proof.
    let meta_base=component_meta(root);
    let contact_count=atomicLoad(&query[meta_base+1u]);
    let contact_start=atomicLoad(&query[meta_base+3u]);
    for (var i=lid;i<contact_count;i+=64u) {
        let slot=atomicLoad(&query[component_contacts()+2u*(contact_start+i)]);
        if (!contact_chain_valid(slot)) {atomicStore(&large_component_invalid,1u);}
    }
    workgroupBarrier();
    if (lid==0u) {
        if (atomicLoad(&large_component_invalid)!=0u) {large_component_enabled=EMPTY;}
        var mask=0u;
        for (var col=0u;col<=OVERFLOW_COLOR;col++) {
            if (atomicLoad(&query[component_color_counts()+24u*root+col])!=0u) {mask|=1u<<col;}
        }
        large_component_color_mask=mask;
    }
    workgroupBarrier();
    if (workgroupUniformLoad(&large_component_enabled)==EMPTY) {return;}
    // Uniform across this workgroup: empty colors need no storage barrier.
    // Lists remain fixed through all substeps; active color order is unchanged.
    let color_mask=workgroupUniformLoad(&large_component_color_mask);
    for (var sub=0u; sub<max(params.sub_step_count,1u); sub++) {
        large_component_integrate(root,lid,false);
        large_component_phase(root,lid,2u,color_mask);
        large_component_phase(root,lid,1u,color_mask);
        large_component_integrate(root,lid,true);
        large_component_phase(root,lid,params.use_bias-1u,color_mask);
    }
    large_component_phase(root,lid,3u,color_mask);
}


// Query words 0..255 retain their existing query/status ABI. This private
// tail is rebuilt after island wake/prepare and remains immutable during TGS.
fn component_meta(root:u32)->u32 {return 261u+4u*root;}
fn component_bodies()->u32 {return 261u+4u*params.body_count;}
fn component_contacts()->u32 {return component_bodies()+params.body_count;}
fn component_large_roots()->u32 {return component_contacts()+2u*params.contact_capacity;}
fn component_color_counts()->u32 {return component_large_roots()+params.body_count;}
fn component_color_starts()->u32 {return component_color_counts()+24u*params.body_count;}
fn component_contact_root(slot:u32)->u32 {
    let key=contact_persistent[slot].pair.xy;
    let a=island_root(load_shape(key.x).body_index);
    let b=island_root(load_shape(key.y).body_index);
    return select(a,b,a==EMPTY);
}
@compute @workgroup_size(64)
fn component_reset(@builtin(global_invocation_id) dispatch_gid:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if (gid.x<params.body_count) {
        atomicStore(&query[component_meta(gid.x)],0u);
        atomicStore(&query[component_meta(gid.x)+1u],0u);
        for (var col=0u;col<=OVERFLOW_COLOR;col++) {atomicStore(&query[component_color_counts()+24u*gid.x+col],0u);}
    }
}
// Validate membership in the current graph lists, not just stale color metadata.
// This also handles memoized graphs without reconstructing their liveness rules.
fn component_active_slot(i:u32)->u32 {
    let slot=scratch[scr_active_contact()+i];
    if (slot>=params.contact_capacity) {return EMPTY;}
    let col=contacts[slot].color;
    if (col>OVERFLOW_COLOR) {return EMPTY;}
    let local=contact_persistent[slot].lifecycle.z;
    if (local>=scratch[SCR_COLOR+col]) {return EMPTY;}
    if (listed_index(col,local)!=slot) {return EMPTY;}
    return slot;
}
@compute @workgroup_size(64)
fn component_count(@builtin(global_invocation_id) dispatch_gid:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let i=gid.x;
    if (i<params.body_count) {
        let root=island_root(i);
        if (root!=EMPTY) {atomicAdd(&query[component_meta(root)],1u);}
    }
    // Physical dispatch covers capacity; stride also handles candidate lists
    // longer than the root-slot pool without omitting late allocated roots.
    if (i>=params.contact_capacity) {return;}
    for (var candidate_i=i;candidate_i<min(scratch[SCR_NCONTACTS],pair_cap());candidate_i+=params.contact_capacity) {
        let slot=component_active_slot(candidate_i);
        if (slot==EMPTY) {continue;}
        let root=component_contact_root(slot);
        if (root!=EMPTY) {
            let col=contacts[slot].color;
            atomicAdd(&query[component_meta(root)+1u],1u);
            atomicAdd(&query[component_color_counts()+24u*root+col],1u);
        }
    }
}
// One cooperative prefix workgroup: each lane counts a contiguous root range,
// then scans range totals. Root order remains canonical without a serial N scan.
var<workgroup> component_prefix: array<vec3<u32>,256>;
var<workgroup> component_prefix_valid: u32;
@compute @workgroup_size(256)
fn component_offsets(@builtin(local_invocation_index) lid:u32) {
    let first=params.body_count*lid/256u;
    let end=params.body_count*(lid+1u)/256u;
    var counts=vec3<u32>(0u);
    for (var root=first;root<end;root++) {
        let m=component_meta(root);
        let nb=atomicLoad(&query[m]);let nc=atomicLoad(&query[m+1u]);
        counts+=vec3<u32>(nb,nc,select(0u,1u,nb>8u || nc>32u));
    }
    component_prefix[lid]=counts;
    workgroupBarrier();
    for (var stride=1u;stride<256u;stride*=2u) {
        var before=vec3<u32>(0u);
        if (lid>=stride) {before=component_prefix[lid-stride];}
        workgroupBarrier();
        component_prefix[lid]+=before;
        workgroupBarrier();
    }
    let totals=component_prefix[255u];
    if (lid==0u) {
        component_prefix_valid=select(0u,1u,totals.x<=params.body_count && totals.y<=params.contact_capacity);
        atomicStore(&query[260u],1u-component_prefix_valid);
        atomicStore(&query[256u],select(0u,totals.z,component_prefix_valid!=0u));
        atomicStore(&query[257u],select(0u,min(totals.z,256u),component_prefix_valid!=0u));
        atomicStore(&query[258u],max((totals.z+255u)/256u,1u));
        atomicStore(&query[259u],1u);
        if (component_prefix_valid==0u) {record_contact_drop(15u);}
    }
    workgroupBarrier();
    if (workgroupUniformLoad(&component_prefix_valid)==0u) {return;}
    var starts=component_prefix[lid]-counts;
    for (var root=first;root<end;root++) {
        let m=component_meta(root);
        let nb=atomicLoad(&query[m]);let nc=atomicLoad(&query[m+1u]);
        atomicStore(&query[m+2u],starts.x);atomicStore(&query[m+3u],starts.y);
        if (nb>8u || nc>32u) {
            atomicStore(&query[component_large_roots()+starts.z],root);starts.z++;
        }
        starts.x+=nb;starts.y+=nc;
        atomicStore(&query[m],0u);atomicStore(&query[m+1u],0u);
    }
}
@compute @workgroup_size(64)
fn component_scatter(@builtin(global_invocation_id) dispatch_gid:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if (atomicLoad(&query[260u])!=0u) {return;}
    let i=gid.x;
    if (i<params.body_count) {
        let root=island_root(i);
        if (root!=EMPTY) {
            let meta_base=component_meta(root);let local=atomicAdd(&query[meta_base],1u);
            atomicStore(&query[component_bodies()+atomicLoad(&query[meta_base+2u])+local],i);
        }
    }
    if (i>=params.contact_capacity) {return;}
    for (var candidate_i=i;candidate_i<min(scratch[SCR_NCONTACTS],pair_cap());candidate_i+=params.contact_capacity) {
        let slot=component_active_slot(candidate_i);
        if (slot==EMPTY) {continue;}
        let root=component_contact_root(slot);
        if (root!=EMPTY) {
            let col=contacts[slot].color;
            let graph_local=contact_persistent[slot].lifecycle.z;
            let meta_base=component_meta(root);atomicAdd(&query[meta_base+1u],1u);
            let local=atomicAdd(&query[component_color_counts()+24u*root+col],1u);
            let at=component_contacts()+2u*(atomicLoad(&query[component_color_starts()+24u*root+col])+local);
            atomicStore(&query[at],slot);
            atomicStore(&query[at+1u],(select(col+1u,0u,col==OVERFLOW_COLOR)<<24u)|graph_local);
        }
    }
}

@compute @workgroup_size(64)
fn component_color_offsets(@builtin(global_invocation_id) dispatch_gid:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    let root=gid.x;
    if (root>=params.body_count || atomicLoad(&query[260u])!=0u) {return;}
    var start=atomicLoad(&query[component_meta(root)+3u]);
    for (var col=0u;col<=OVERFLOW_COLOR;col++) {
        let index=24u*root+col;
        atomicStore(&query[component_color_starts()+index],start);
        start+=atomicLoad(&query[component_color_counts()+index]);
        atomicStore(&query[component_color_counts()+index],0u);
    }
}

// Count after CCD. Kinematics and any enabled non-static awake body block idle.
@compute @workgroup_size(64)
fn count_active_bodies(@builtin(global_invocation_id) dispatch_gid:vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if (gid.x>=params.body_count) {return;}
    let flags=body_states[gid.x].flags;
    if ((flags & (FLAG_STATIC|FLAG_DISABLED))==0u && ((flags & FLAG_SLEEP)==0u || (flags & FLAG_KINEMATIC)!=0u)) {
        atomicAdd(&query[72u],1u);
    }
}
const Q_OX: u32 = 0u;
const Q_TX: u32 = 3u;
const Q_CAT: u32 = 6u;
const Q_MASK: u32 = 8u;
const Q_MAX: u32 = 10u;
const Q_FRAC: u32 = 12u;
const Q_WIN: u32 = 13u;
const Q_OVERFLOW: u32 = 14u;
const Q_HIT: u32 = 16u;
const Q_SHAPE: u32 = 17u;
const Q_POINT: u32 = 18u;
const Q_NORMAL: u32 = 21u;
const Q_FRAC_OUT: u32 = 24u;
const Q_BODY: u32 = 25u;
const Q_MAT: u32 = 26u;
const Q_CPU: u32 = 28u;
const Q_TRI: u32 = 29u;
const Q_OVERFLOW_OUT: u32 = 30u;
const RAY_TRI_NONE: u32 = 0xffffu;
const MESH_VISIT_CAP: u32 = 4096u;
const MESH_STACK_CAP: u32 = 64u;

struct RayCand {
    n: vec3<f32>,
    t: f32,
    tri: u32,
    mat_lo: u32,
    mat_hi: u32,
    overflow: u32,
}

fn q_f32(i: u32) -> f32 {
    return bitcast<f32>(atomicLoad(&query[i]));
}

fn store_q_f32(i: u32, v: f32) {
    atomicStore(&query[i], bitcast<u32>(v));
}

fn ray_finite3(v: vec3<f32>) -> bool {
    return all(v == v) && all(abs(v) < vec3<f32>(1e20));
}

fn query_bits_hit(shape_lo: u32, shape_hi: u32, query_lo: u32, query_hi: u32) -> bool {
    return ((shape_lo & query_lo) | (shape_hi & query_hi)) != 0u;
}

fn winner_key(shape: u32, tri: u32) -> u32 {
    return (shape << 16u) | (tri & RAY_TRI_NONE);
}

fn empty_cand() -> RayCand {
    return RayCand(vec3<f32>(0.0), 0.0, RAY_TRI_NONE, 0u, 0u, 0u);
}

fn ray_aabb_hit(origin: vec3<f32>, dir: vec3<f32>, t_max: f32, lo: vec3<f32>, hi: vec3<f32>) -> bool {
    var tmin = 0.0;
    var tmax = t_max;
    for (var a = 0u; a < 3u; a++) {
        if (abs(dir[a]) < 1e-12) {
            if (origin[a] < lo[a] || origin[a] > hi[a]) {
                return false;
            }
            continue;
        }
        let invd = 1.0 / dir[a];
        var t0 = (lo[a] - origin[a]) * invd;
        var t1 = (hi[a] - origin[a]) * invd;
        if (t0 > t1) {
            let tmp = t0;
            t0 = t1;
            t1 = tmp;
        }
        tmin = max(tmin, t0);
        tmax = min(tmax, t1);
        if (tmax < tmin) {
            return false;
        }
    }
    return true;
}

fn ray_sphere_entry(origin: vec3<f32>, dir: vec3<f32>, center: vec3<f32>, radius: f32, t_max: f32) -> vec2<f32> {
    let m = origin - center;
    let b = dot(m, dir);
    let c = dot(m, m) - radius * radius;
    let disc = b * b - c;
    if (disc < 0.0) {
        return vec2<f32>(-1.0, 0.0);
    }
    let t = -b - sqrt(disc);
    if (t <= 0.0 || t > t_max) {
        return vec2<f32>(-1.0, 0.0);
    }
    return vec2<f32>(t, 1.0);
}

fn ray_obb(origin: vec3<f32>, dir: vec3<f32>, rot: vec4<f32>, center: vec3<f32>, half: vec3<f32>, t_max: f32) -> vec4<f32> {
    let inv = quat_inv(rot);
    let o = quat_rotate(inv, origin - center);
    let d = quat_rotate(inv, dir);
    var tmin = 0.0;
    var tmax = t_max;
    var n = vec3<f32>(0.0);
    for (var a = 0u; a < 3u; a++) {
        if (abs(d[a]) < 1e-12) {
            if (o[a] < -half[a] || o[a] > half[a]) {
                return vec4<f32>(0.0);
            }
            continue;
        }
        let invd = 1.0 / d[a];
        var t0 = (-half[a] - o[a]) * invd;
        var t1 = (half[a] - o[a]) * invd;
        var n0 = -1.0;
        var n1 = 1.0;
        if (t0 > t1) {
            let tmp = t0;
            t0 = t1;
            t1 = tmp;
            let tn = n0;
            n0 = n1;
            n1 = tn;
        }
        if (t0 > tmin) {
            tmin = t0;
            n = vec3<f32>(0.0);
            n[a] = n0;
        }
        tmax = min(tmax, t1);
        if (tmax < tmin) {
            return vec4<f32>(0.0);
        }
    }
    if (tmin <= 0.0 || tmin > t_max) {
        return vec4<f32>(0.0);
    }
    let wn = quat_rotate(rot, n);
    let len = length(wn);
    if (len < 1e-12) {
        return vec4<f32>(0.0);
    }
    return vec4<f32>(wn / len, tmin);
}

fn ray_capsule(origin: vec3<f32>, dir: vec3<f32>, a: vec3<f32>, b: vec3<f32>, radius: f32, t_max: f32) -> vec4<f32> {
    let ba = b - a;
    let oa = origin - a;
    let baba = dot(ba, ba);
    let bard = dot(ba, dir);
    let baoa = dot(ba, oa);
    let rdoa = dot(dir, oa);
    let oaoa = dot(oa, oa);
    let a2 = baba - bard * bard;
    let b2 = baba * rdoa - baoa * bard;
    let c2 = baba * oaoa - baoa * baoa - radius * radius * baba;
    if (abs(a2) < 1e-12 || baba < 1e-12) {
        let sa = ray_sphere_entry(origin, dir, a, radius, t_max);
        let sb = ray_sphere_entry(origin, dir, b, radius, t_max);
        var t = t_max + 1.0;
        var c = a;
        var hit = false;
        if (sa.y > 0.0) {
            t = sa.x;
            c = a;
            hit = true;
        }
        if (sb.y > 0.0 && sb.x < t) {
            t = sb.x;
            c = b;
            hit = true;
        }
        if (!hit) {
            return vec4<f32>(0.0);
        }
        let p = origin + t * dir;
        let n = p - c;
        let ln = length(n);
        if (ln < 1e-12) {
            return vec4<f32>(0.0);
        }
        return vec4<f32>(n / ln, t);
    }
    let disc = b2 * b2 - a2 * c2;
    if (disc < 0.0) {
        return vec4<f32>(0.0);
    }
    let t = (-b2 - sqrt(disc)) / a2;
    let y = baoa + t * bard;
    if (t > 0.0 && t <= t_max && y > 0.0 && y < baba) {
        let p = origin + t * dir;
        let q = a + ba * (y / baba);
        let n = p - q;
        let ln = length(n);
        if (ln < 1e-12) {
            return vec4<f32>(0.0);
        }
        return vec4<f32>(n / ln, t);
    }
    let cap = select(b, a, y <= 0.0);
    let sph = ray_sphere_entry(origin, dir, cap, radius, t_max);
    if (sph.y <= 0.0) {
        return vec4<f32>(0.0);
    }
    let p = origin + sph.x * dir;
    let n = p - cap;
    let ln = length(n);
    if (ln < 1e-12) {
        return vec4<f32>(0.0);
    }
    return vec4<f32>(n / ln, sph.x);
}

fn ray_hull(origin: vec3<f32>, dir: vec3<f32>, xf_p: vec3<f32>, xf_q: vec4<f32>, shape: Shape, t_max: f32) -> vec4<f32> {
    let nplane = hull_plane_count(shape);
    if (nplane == 0u) {
        return vec4<f32>(0.0);
    }
    var t_enter = 0.0;
    var t_leave = t_max;
    var n_enter = vec3<f32>(0.0);
    for (var i = 0u; i < nplane; i++) {
        let pl = load_hull_plane(shape, i);
        let nw = quat_rotate(xf_q, pl.xyz);
        let offset = pl.w + dot(nw, xf_p);
        let denom = dot(nw, dir);
        let dist = offset - dot(nw, origin);
        if (abs(denom) < 1e-12) {
            if (dist < 0.0) {
                return vec4<f32>(0.0);
            }
            continue;
        }
        let t = dist / denom;
        if (denom < 0.0) {
            if (t > t_enter) {
                t_enter = t;
                n_enter = nw;
            }
        } else {
            t_leave = min(t_leave, t);
        }
        if (t_leave < t_enter) {
            return vec4<f32>(0.0);
        }
    }
    if (t_enter <= 0.0 || t_enter > t_max) {
        return vec4<f32>(0.0);
    }
    let ln = length(n_enter);
    if (ln < 1e-12) {
        return vec4<f32>(0.0);
    }
    return vec4<f32>(n_enter / ln, t_enter);
}

fn ray_triangle(origin: vec3<f32>, dir: vec3<f32>, a: vec3<f32>, b: vec3<f32>, c: vec3<f32>, t_max: f32) -> vec4<f32> {
    let ab = b - a;
    let ac = c - a;
    let n = cross(ab, ac);
    let denom = dot(n, dir);
    if (denom >= -1e-12) {
        return vec4<f32>(0.0);
    }
    let t = dot(n, a - origin) / denom;
    if (t <= 0.0 || t > t_max) {
        return vec4<f32>(0.0);
    }
    let p = origin + t * dir;
    let ap = p - a;
    let d00 = dot(ab, ab);
    let d01 = dot(ab, ac);
    let d11 = dot(ac, ac);
    let d20 = dot(ap, ab);
    let d21 = dot(ap, ac);
    let inv = 1.0 / (d00 * d11 - d01 * d01);
    let v = (d11 * d20 - d01 * d21) * inv;
    let w = (d00 * d21 - d01 * d20) * inv;
    let u = 1.0 - v - w;
    if (u < -1e-5 || v < -1e-5 || w < -1e-5) {
        return vec4<f32>(0.0);
    }
    let ln = length(n);
    if (ln < 1e-12) {
        return vec4<f32>(0.0);
    }
    return vec4<f32>(n / ln, t);
}

fn mesh_world_vertex(shape: Shape, xf_p: vec3<f32>, xf_q: vec4<f32>, index: u32) -> vec3<f32> {
    let local = load_mesh_vertex(shape, index);
    return xf_p + quat_rotate(xf_q, local);
}

fn ray_mesh(origin: vec3<f32>, dir: vec3<f32>, xf_p: vec3<f32>, xf_q: vec4<f32>, shape: Shape, t_max: f32) -> RayCand {
    var best = empty_cand();
    let inv = quat_inv(xf_q);
    let o_local = mesh_to_raw_point(shape, quat_rotate(inv, origin - xf_p));
    let d_local = mesh_to_raw_vector(shape, quat_rotate(inv, dir));
    var stack: array<u32, 64>;
    var stack_count = 0u;
    if (shape.topology_counts == 0u) {
        let ntri = shape.topology_slot;
        if (ntri > MESH_VISIT_CAP) {
            best.overflow = 1u;
            return best;
        }
        for (var i = 0u; i < ntri; i++) {
            let tri = load_mesh_triangle(shape, i);
            let p1 = mesh_world_vertex(shape, xf_p, xf_q, tri.x);
            let p2 = mesh_world_vertex(shape, xf_p, xf_q, tri.y);
            let p3 = mesh_world_vertex(shape, xf_p, xf_q, tri.z);
            let hit = ray_triangle(origin, dir, p1, p2, p3, select(best.t, t_max, best.t <= 0.0));
            if (hit.w > 0.0 && (best.t <= 0.0 || hit.w < best.t)) {
                best.n = hit.xyz;
                best.t = hit.w;
                best.tri = i;
                let mat = load_surface_material(shape, tri.w >> 8u);
                best.mat_lo = mat.user_material_id.x;
                best.mat_hi = mat.user_material_id.y;
            }
        }
        return best;
    }
    stack[0] = 0u;
    stack_count = 1u;
    var visits = 0u;
    loop {
        if (stack_count == 0u || visits >= MESH_VISIT_CAP) {
            if (visits >= MESH_VISIT_CAP && stack_count > 0u) {
                best.overflow = 1u;
            }
            break;
        }
        visits = visits + 1u;
        stack_count = stack_count - 1u;
        let node_index = stack[stack_count];
        if (node_index >= shape.topology_counts) {
            continue;
        }
        let lower = load_mesh_node_lower(shape, node_index);
        let upper = load_mesh_node_upper(shape, node_index);
        if (!ray_aabb_hit(o_local, d_local, t_max, lower.xyz, upper.xyz)) {
            continue;
        }
        let data = bitcast<u32>(lower.w);
        if ((data & 3u) != 3u) {
            let right = node_index + (data >> 2u);
            if (stack_count + 2u > MESH_STACK_CAP) {
                best.overflow = 1u;
                continue;
            }
            stack[stack_count] = right;
            stack[stack_count + 1u] = node_index + 1u;
            stack_count = stack_count + 2u;
            continue;
        }
        let triangle_count = data >> 2u;
        let triangle_offset = bitcast<u32>(upper.w);
        for (var leaf_index = 0u; leaf_index < triangle_count; leaf_index++) {
            let triangle_index = triangle_offset + leaf_index;
            if (triangle_index >= shape.topology_slot) {
                continue;
            }
            let tri = load_mesh_triangle(shape, triangle_index);
            let p1 = mesh_world_vertex(shape, xf_p, xf_q, tri.x);
            let p2 = mesh_world_vertex(shape, xf_p, xf_q, tri.y);
            let p3 = mesh_world_vertex(shape, xf_p, xf_q, tri.z);
            let tmax = select(best.t, t_max, best.t <= 0.0);
            let hit = ray_triangle(origin, dir, p1, p2, p3, tmax);
            if (hit.w > 0.0 && (best.t <= 0.0 || hit.w < best.t)) {
                best.n = hit.xyz;
                best.t = hit.w;
                best.tri = triangle_index;
                let mat = load_surface_material(shape, tri.w >> 8u);
                best.mat_lo = mat.user_material_id.x;
                best.mat_hi = mat.user_material_id.y;
            }
        }
    }
    return best;
}

fn ray_shape_hit(i: u32, origin: vec3<f32>, dir: vec3<f32>, t_max: f32) -> RayCand {
    var out = empty_cand();
    let shape = load_shape(i);
    if ((shape.event_flags & SHAPE_PUBLIC_PROXY) != 0u) { return out; }
    let cat_lo = atomicLoad(&query[Q_CAT]);
    let cat_hi = atomicLoad(&query[Q_CAT + 1u]);
    let mask_lo = atomicLoad(&query[Q_MASK]);
    let mask_hi = atomicLoad(&query[Q_MASK + 1u]);
    if (!query_bits_hit(shape.category_bits_lo, shape.category_bits_hi, mask_lo, mask_hi)
        || !query_bits_hit(shape.mask_bits_lo, shape.mask_bits_hi, cat_lo, cat_hi)) {
        return out;
    }
    if (shape.body_index >= params.body_count) {
        return out;
    }
    let body = load_body(shape.body_index);
    if ((body.flags & FLAG_DISABLED) != 0u) {
        return out;
    }
    let xf_q = normalize(body.rot);
    let xf_p = body.pos - quat_rotate(xf_q, load_body_cold(shape.body_index).local_center);
    let center = xf_p + quat_rotate(xf_q, shape.local_center);
    var lo = vec3<f32>(0.0);
    var hi = vec3<f32>(0.0);
    if (shape.kind == KIND_SPHERE) {
        let r = vec3<f32>(shape.half.x);
        lo = center - r;
        hi = center + r;
    } else if (shape.kind == KIND_CAPSULE) {
        let a = xf_p + quat_rotate(xf_q, shape.local_center - shape.axis);
        let b = xf_p + quat_rotate(xf_q, shape.local_center + shape.axis);
        let r = vec3<f32>(shape.half.x);
        lo = min(a, b) - r;
        hi = max(a, b) + r;
    } else if (shape.kind == KIND_CONVEX_HULL) {
        let n = hull_point_count(shape);
        if (n == 0u) {
            return out;
        }
        var p0 = xf_p + quat_rotate(xf_q, load_hull_point(shape, 0u));
        lo = p0;
        hi = p0;
        for (var k = 1u; k < n; k++) {
            let p = xf_p + quat_rotate(xf_q, load_hull_point(shape, k));
            lo = min(lo, p);
            hi = max(hi, p);
        }
    } else if (shape.kind == KIND_MESH) {
        if (shape.topology_counts == 0u) {
            if (shape.topology_slot == 0u) {
                return out;
            }
        } else {
            let local_lo = load_mesh_node_lower(shape, 0u).xyz;
            let local_hi = load_mesh_node_upper(shape, 0u).xyz;
            lo = vec3<f32>(1.0e30);
            hi = vec3<f32>(-1.0e30);
            for (var c = 0u; c < 8u; c++) {
                let lp = vec3<f32>(
                    select(local_lo.x, local_hi.x, (c & 1u) != 0u),
                    select(local_lo.y, local_hi.y, (c & 2u) != 0u),
                    select(local_lo.z, local_hi.z, (c & 4u) != 0u),
                );
                let p = xf_p + quat_rotate(xf_q, mesh_to_body_point(shape, lp));
                lo = min(lo, p);
                hi = max(hi, p);
            }
        }
    } else {
        let x = abs(quat_rotate(xf_q, vec3<f32>(shape.half.x, 0.0, 0.0)));
        let y = abs(quat_rotate(xf_q, vec3<f32>(0.0, shape.half.y, 0.0)));
        let z = abs(quat_rotate(xf_q, vec3<f32>(0.0, 0.0, shape.half.z)));
        let e = x + y + z;
        lo = center - e;
        hi = center + e;
    }
    if (!(shape.kind == KIND_MESH && shape.topology_counts == 0u) && !ray_aabb_hit(origin, dir, t_max, lo, hi)) {
        return out;
    }
    out.mat_lo = shape.user_material_id.x;
    out.mat_hi = shape.user_material_id.y;
    if (shape.kind == KIND_SPHERE) {
        let sph = ray_sphere_entry(origin, dir, center, shape.half.x, t_max);
        if (sph.y > 0.0) {
            let p = origin + sph.x * dir;
            let n = p - center;
            let ln = length(n);
            if (ln >= 1e-12) {
                out.n = n / ln;
                out.t = sph.x;
            }
        }
    } else if (shape.kind == KIND_BOX) {
        let hit = ray_obb(origin, dir, xf_q, center, shape.half, t_max);
        out.n = hit.xyz;
        out.t = hit.w;
    } else if (shape.kind == KIND_CAPSULE) {
        let a = xf_p + quat_rotate(xf_q, shape.local_center - shape.axis);
        let b = xf_p + quat_rotate(xf_q, shape.local_center + shape.axis);
        let hit = ray_capsule(origin, dir, a, b, shape.half.x, t_max);
        out.n = hit.xyz;
        out.t = hit.w;
    } else if (shape.kind == KIND_CONVEX_HULL) {
        let hit = ray_hull(origin, dir, xf_p, xf_q, shape, t_max);
        out.n = hit.xyz;
        out.t = hit.w;
    } else if (shape.kind == KIND_MESH) {
        out = ray_mesh(origin, dir, xf_p, xf_q, shape, t_max);
    }
    return out;
}

fn ray_pass(gid: u32, stage: u32) {
    let origin = vec3<f32>(q_f32(Q_OX), q_f32(Q_OX + 1u), q_f32(Q_OX + 2u));
    let translation = vec3<f32>(q_f32(Q_TX), q_f32(Q_TX + 1u), q_f32(Q_TX + 2u));
    if (!ray_finite3(origin) || !ray_finite3(translation)) {
        return;
    }
    let t_len = length(translation);
    if (t_len < 1e-12) {
        return;
    }
    let dir = translation / t_len;
    let t_max = q_f32(Q_MAX) * t_len;
    if (gid >= params.shape_count) {
        return;
    }
    let hit = ray_shape_hit(gid, origin, dir, t_max);
    if (hit.overflow != 0u) {
        atomicOr(&query[Q_OVERFLOW], 1u);
    }
    if (hit.t <= 0.0) {
        return;
    }
    let fraction = hit.t / t_len;
    if (fraction <= 0.0 || fraction > q_f32(Q_MAX) || !(fraction == fraction)) {
        return;
    }
    let key = bitcast<u32>(fraction);
    let packed = winner_key(load_shape(gid)._pad_filter.y, hit.tri);
    if (stage == 0u) {
        atomicMin(&query[Q_FRAC], key);
        return;
    }
    if (key != atomicLoad(&query[Q_FRAC])) {
        return;
    }
    if (stage == 1u) {
        atomicMin(&query[Q_WIN], packed);
        return;
    }
    if (packed != atomicLoad(&query[Q_WIN])) {
        return;
    }
    let shape = load_shape(gid);
    atomicStore(&query[Q_HIT], 1u);
    atomicStore(&query[Q_SHAPE], gid);
    atomicStore(&query[Q_CPU], shape._pad_filter.y);
    atomicStore(&query[Q_BODY], shape.body_index);
    atomicStore(&query[Q_MAT], hit.mat_lo);
    atomicStore(&query[Q_MAT + 1u], hit.mat_hi);
    store_q_f32(Q_POINT, origin.x + hit.t * dir.x);
    store_q_f32(Q_POINT + 1u, origin.y + hit.t * dir.y);
    store_q_f32(Q_POINT + 2u, origin.z + hit.t * dir.z);
    store_q_f32(Q_NORMAL, hit.n.x);
    store_q_f32(Q_NORMAL + 1u, hit.n.y);
    store_q_f32(Q_NORMAL + 2u, hit.n.z);
    store_q_f32(Q_FRAC_OUT, fraction);
    atomicStore(&query[Q_TRI], hit.tri);
    atomicStore(&query[Q_OVERFLOW_OUT], atomicLoad(&query[Q_OVERFLOW]));
}

@compute @workgroup_size(64)
fn ray_closest(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    ray_pass(gid.x, 0u);
}

@compute @workgroup_size(64)
fn ray_closest_pick(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    ray_pass(gid.x, 1u);
}

@compute @workgroup_size(64)
fn ray_closest_commit(@builtin(global_invocation_id) dispatch_gid: vec3<u32>) {
    let gid = vec3<u32>(linear_invocation_id(dispatch_gid, 64u), 0u, 0u);
    if (gid.x == 0u) {
        atomicStore(&query[Q_OVERFLOW_OUT], atomicLoad(&query[Q_OVERFLOW]));
    }
    ray_pass(gid.x, 2u);
}
