"""CPU-only reproduction of the native Naga emitter; run after timing jobs."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
root=Path.cwd();base=root/'artifacts/connected-scheduling/shader-identity';deps=root/'target/native-cache-build/release/deps'
parser=argparse.ArgumentParser();parser.add_argument('--naga-rlib',type=Path);args=parser.parse_args()
# Resolve the emitter dependency from the actual native-cache viewer fingerprint,
# not by whichever old rlib happens to have the newest modification timestamp.
fingerprints=root/'target/native-cache-build/release/.fingerprint'
viewers=[p for p in fingerprints.glob('gpu-physics-*/bin-gpu-physics.json') if json.loads(json.loads(p.read_text())['features'])==['native-command-cache']]
viewer=max(viewers,key=lambda p:p.stat().st_mtime);metadata=json.loads(viewer.read_text())
fingerprint=next(d[-1] for d in metadata['deps'] if d[1]=='naga').to_bytes(8,'little').hex()
matches=[p for p in fingerprints.glob('naga-*/lib-naga') if p.read_text().strip()==fingerprint];assert len(matches)==1
naga=(args.naga_rlib or deps/('lib'+matches[0].parent.name+'.rlib')).resolve()
print('Naga emitter:',naga,'viewer fingerprint:',viewer,flush=True)

env=os.environ|json.loads((base.parent/'baseline.json').read_text())['environment']
subprocess.run(['rustc',str(base/'compare.rs'),'--edition=2021','-L','dependency='+str(deps),'--extern','naga='+str(naga),'-O','-o',str(base/'compare')],env=env,check=True)
for variant in ['baseline','register','adaptive']:
 subprocess.run([str(base/'compare'),str(base/(variant+'.wgsl')),str(base/variant)],env=env,check=True)
entries={p.stem for p in (base/'baseline').glob('*.spv')};assert entries
assert all({p.stem for p in (base/v).glob('*.spv')}==entries for v in ['register','adaptive'])
rows=[]
for entry in sorted(entries):
 hashes={v:hashlib.sha256((base/v/(entry+'.spv')).read_bytes()).hexdigest() for v in ['baseline','register','adaptive']}
 rows.append({'entry':entry,'sha256':hashes,'register_equal':hashes['baseline']==hashes['register'],'adaptive_equal':hashes['baseline']==hashes['adaptive']})
report={'viewer_fingerprint':str(viewer.relative_to(root)),'naga_fingerprint':fingerprint,'native_precision_source_sha256':hashlib.sha256((root/'src/native_precision.rs').read_bytes()).hexdigest(),'naga_rlib_sha256':hashlib.sha256(naga.read_bytes()).hexdigest(),'source_sha256':{v:hashlib.sha256((base/(v+'.wgsl')).read_bytes()).hexdigest() for v in ['baseline','register','adaptive']},'entries':rows}
(base/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Compared',len(rows),'entrypoints. Changed:')
for r in rows:
 if not r['register_equal'] or not r['adaptive_equal']:print(r['entry'],'register_equal=',r['register_equal'],'adaptive_equal=',r['adaptive_equal'])
