"""Report every paired qualification effect; do not discard inconvenient trials."""
from pathlib import Path
import json,statistics
base=Path(__file__).resolve().parent
for kind in ['physics','renderers']:
 p=base/('qualification-'+kind)/'jobs.json'
 if not p.exists():continue
 rows=json.loads(p.read_text());scopes=sorted({(r.get('scene',r.get('renderer')),r['count']) for r in rows})
 print(kind, sum(r['status']=='ok' for r in rows),'completed')
 for scope,n in scopes:
  rr=[r for r in rows if (r.get('scene',r.get('renderer')),r['count'])==(scope,n) and r['status']=='ok']
  if len(rr)!=9:continue
  vals={v:[next(r['result'][0]['mean_ms'] for r in rr if r['variant']==v and r['trial']==t) for t in [1,2,3]] for v in ['before','after','cpu']}
  changes=[100*(a/b-1) for b,a in zip(vals['before'],vals['after'])]
  print(scope,n,'before/after/cpu',[round(statistics.median(vals[v]),3) for v in vals], 'paired change %',[round(x,2) for x in changes], 'ALL_SLOWER' if all(x>0 for x in changes) else '')
