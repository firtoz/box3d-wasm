from pathlib import Path
import json,subprocess,hashlib,shutil
root=Path.cwd();base=root/'artifacts/connected-scheduling';identity=base/'shader-identity'
# Preserve the exploratory emitter comparison, then use the measured viewer's
# exact dependency fingerprint and its 128-lane island specializations.
shutil.copy2(identity/'report.json',identity/'report-exploratory.json')
shutil.copy2(identity/'run.log',identity/'run-exploratory.log')
with (identity/'run.log').open('w') as f:subprocess.run(['python3',str(identity/'run.py')],stdout=f,stderr=f,check=True)
report=json.loads((identity/'report.json').read_text());changed=[x['entry'] for x in report['entries'] if not x['adaptive_equal']]
assert len(report['entries'])==130
assert set(changed)=={'finish_occupied_contacts','solve_color_partition_one_group','solve_color_tail_one_group','solve_color_wave_one_group'},changed
review=json.loads((base/'large-regression-review.json').read_text());review['shader_report_sha256']=hashlib.sha256((identity/'report.json').read_bytes()).hexdigest();review['shader_entries_compared']=len(report['entries']);review['emitter_dependency']=report['naga_fingerprint']
(base/'large-regression-review.json').write_text(json.dumps(review,indent=2)+'\n')
print('Exact native emitter and specializations verified:',len(report['entries']),'entries; only intended four changed',flush=True)
subprocess.run(['python3',str(base/'finish-qualification.py')],check=True)
subprocess.run(['python3',str(base/'write-results-doc.py')],check=True)
