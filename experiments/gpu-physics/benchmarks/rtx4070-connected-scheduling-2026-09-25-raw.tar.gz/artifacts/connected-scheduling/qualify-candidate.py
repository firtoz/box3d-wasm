from pathlib import Path
import os,json,subprocess,hashlib,shutil,re
root=Path.cwd();base=root/'artifacts/connected-scheduling'
env={k:v for k,v in os.environ.items() if not k.startswith(('GPU_PHYSICS_','GPU_BENCH_'))}|json.loads((base/'baseline.json').read_text())['environment']
def run(cmd,name,e=env):
 with (base/name).open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=f,check=True)
 print('PASS '+name,flush=True)
bin='target/native-cache-build/release/deps/gpu_physics-f43e538e836f4d30'
# Initial full suite: 274 pass; the cross-adapter case requires both ICDs.
assert '274 passed; 1 failed' in (base/'qualification-library.log').read_text()
both=env.copy();both.pop('VK_DRIVER_FILES',None);both.pop('VK_ICD_FILENAMES',None)
run([bin,'staged_ring::tests::cross_adapter_ring_preserves_generations_and_bytes','--exact','--test-threads=1','--nocapture'],'qualification-cross-adapter.log',both)
assert '1 passed; 0 failed' in (base/'qualification-cross-adapter.log').read_text()
off=env.copy()
for k in off:
 if k.startswith('GPU_PHYSICS_NATIVE_') or k in ['GPU_PHYSICS_FULL_REPLAY','GPU_PHYSICS_GLOBAL_REPLAY','GPU_PHYSICS_GRAPH_MEMO']:off[k]='0'
for case in ['graph_mutations_match_canonical','graph_density_status','color_tail_tests','appended_extent_tests','destroy_and_reuse_slots']:
 run([bin,case,'--test-threads=1','--nocapture'],'cache-off-'+case+'.log',off)
run(['./scripts/build-native-cache.sh','build','--release'],'qualification-build.log')
shutil.copy2('target/native-cache-build/release/gpu-physics',base/'qualified-candidate-gpu')
run(['./scripts/build-native-cache.sh','build','--release','--features','external-c-shim'],'qualification-shim-build.log')
run(['cmake','--build','native-samples/build-gpu-native-cache-portable','--target','samples_gpu','-j6'],'qualification-sokol-build.log')
shutil.copy2('native-samples/build-gpu-native-cache-portable/bin/samples_gpu',base/'qualified-candidate-sokol')
files=['src/sim.rs','src/api/world.rs','src/manifold_chain_tests.rs','shaders/physics/solve.wgsl','shaders/physics/broadphase.wgsl']
(base/'qualification-build.json').write_text(json.dumps({'binaries':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['qualified-candidate-gpu','qualified-candidate-sokol']},'sources':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}},indent=2)+'\n')
print('Qualified binaries frozen; starting matched physics measurements',flush=True)
subprocess.run(['python3',str(base/'run-qualification-physics.py')],env=env,check=True)
print('Physics complete; starting renderer measurements',flush=True)
subprocess.run(['python3',str(base/'run-qualification-renderers.py')],env=env,check=True)
