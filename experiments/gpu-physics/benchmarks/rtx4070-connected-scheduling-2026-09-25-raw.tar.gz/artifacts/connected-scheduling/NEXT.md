# Completed qualification handoff

All benchmark jobs are terminal: 108 physics trials, 72 renderer trials and nine balanced 100k follow-up trials. No new runs are needed.

275 native-cache tests passed across two invocations; the original missing-AMD-driver failure is retained. Eight cache-off checks passed. All 19 scene recordings match 300 decoded baseline frames each.

The 25% target was missed: 2k improves 15.5%, 5k improves 20.0%, and 1k is noisy. Initial 100k slowdown did not reproduce consistently; both rounds remain in evidence. Charts and README report these limitations.

Final evidence is packaged and independently validated before the user-authorized commit. Historical CHECKPOINT.md and CONTINUE.md describe earlier work, not pending jobs.
