"""Validate and display the initial regression signal alongside all causal repeats."""
from pathlib import Path
import argparse,json,hashlib,statistics,math
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--validate-only',action='store_true');a=p.parse_args()
base=Path(__file__).resolve().parent;probe=base/'large-regression-probe';m=json.loads((probe/'manifest.json').read_text());rows=json.loads((probe/'summary.json').read_text());assert len(rows)==9
initial=json.loads((base/'qualification-physics/jobs.json').read_text());hashes={};means={};identities=[]
for row in rows:
 key=(row['trial'],row['variant']);assert key not in means;path=probe/f'{key[0]}-{key[1]}.json';assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
 d=json.loads(path.read_text());r=d['raw_runs'][0]
 assert d['bodies']==100001 and d['sub_steps']==4 and not d['sleep'] and r['physics_step']==330 and len(r['completed_step_ms'])==240 and all(math.isfinite(x) and x>0 for x in r['completed_step_ms'])
 mean=statistics.mean(r['completed_step_ms']);assert abs(mean-row['completed_step_ms'])<1e-8;means[key]=mean
 identities.append((r['live_contacts'],r['awake_dynamic'],r['solver_dispatches'],r['allocations']['total_bytes']))
 hashes[str(path.relative_to(base))]=row['sha256']
assert len(set(identities))==1
first=[];follow=[];register=[]
for t in [1,2,3]:
 rr={r['variant']:r for r in initial if (r['scene'],r['count'],r['trial'])==('falling-cubes',100000,t)};assert len(rr)==3 and all(r['status']=='ok' for r in rr.values())
 for v in ['before','after']:
  folder=base/'qualification-physics'/rr[v]['key'];manifest=json.loads((folder/'manifest.json').read_text());assert manifest['environment']==m['environment'];binary='baseline' if v=='before' else 'adaptive'
  assert manifest['binaries']['gpu']['sha256']==m['variants'][binary]['sha256']
  path=folder/'100000-physics-gpu-1.json';raw=json.loads(path.read_text())['raw_runs'][0];value=statistics.mean(raw['completed_step_ms']);assert abs(value-rr[v]['result'][0]['mean_ms'])<1e-8
  assert (raw['live_contacts'],raw['awake_dynamic'],raw['solver_dispatches'],raw['allocations']['total_bytes'])==identities[0]
  hashes[str(path.relative_to(base))]=hashlib.sha256(path.read_bytes()).hexdigest()
 first.append(100*(rr['after']['result'][0]['mean_ms']/rr['before']['result'][0]['mean_ms']-1))
 follow.append(100*(means[(t,'adaptive')]/means[(t,'baseline')]-1))
 register.append(100*(means[(t,'register-only')]/means[(t,'baseline')]-1))
report={'initial_paired_change_percent':first,'followup_paired_change_percent':follow,'register_only_paired_change_percent':register,'initial_median_paired_change_percent':statistics.median(first),'followup_median_paired_change_percent':statistics.median(follow),'all_six_median_paired_change_percent':statistics.median(first+follow),'probe_trial_means':[{'trial':t,'variant':v,'mean_ms':x} for (t,v),x in means.items()],'common_workload':identities[0],'raw_sha256':hashes,'note':'Positive means slower. Original and balanced follow-up runs are both retained; three-way control uses the same GPU binary identities/environment/workload. This is not a confidence interval.'}
print(json.dumps({k:v for k,v in report.items() if k not in ['raw_sha256','probe_trial_means']},indent=2))
if a.validate_only:raise SystemExit(0)
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axs=plt.subplots(1,2,figsize=(13,5),layout='constrained')
axs[0].bar([0,1,2],first,color='#8a8995',label='Initial paired trials');axs[0].bar([4,5,6],follow,color='#097f98',label='Balanced follow-up')
axs[0].axhline(0,color='black',lw=.8);axs[0].set(xticks=[0,1,2,4,5,6],xticklabels=['1','2','3','1','2','3'],xlabel='Trial within each measurement round',ylabel='Adaptive / baseline time change (%)',title='100k cubes: positive = slower');axs[0].legend();axs[0].grid(axis='y',alpha=.2)
for v,label,color in [('baseline','Baseline','#8a8995'),('register-only','Solver-only checkpoint','#8a5ca8'),('adaptive','Adaptive candidate','#097f98')]:
 axs[1].plot([1,2,3],[means[t,v] for t in [1,2,3]],'o-',label=label,color=color)
axs[1].set(xticks=[1,2,3],xlabel='Balanced trial (cyclic run order)',ylabel='Completed-step mean (ms; zoomed scale)',title='Three-way causal probe');axs[1].legend();axs[1].grid(alpha=.2)
fig.suptitle('RTX 4070 Laptop / Ryzen 9 8945HS — 100k regression investigation, 2026-09-25\nSame four substeps, 90 warmup + 240 timed steps, no sleep; normal desktop load')
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
for ext in ['png','svg']:
 path=a.output.with_suffix('.'+ext);fig.savefig(path,dpi=180)
 if ext=='svg':path.write_text('\n'.join(l.rstrip() for l in path.read_text().splitlines())+'\n')
