"""Validate and package the connected-scheduling qualification, excluding binaries/videos."""
from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path.cwd();base=root/'artifacts/connected-scheduling'
for kind in ['physics','renderers']:
 subprocess.run(['python3','scripts/plot-small-scene.py',str(base/('qualification-'+kind)),'unused','--title','archive validation','--validate-only',*(['--renderers'] if kind=='renderers' else [])],check=True)
log=(base/'qualification-library.log').read_text()
assert '274 passed; 1 failed' in log and 'AMD destination' in log
assert '1 passed; 0 failed' in (base/'qualification-cross-adapter.log').read_text()
subprocess.run(['python3',str(base/'plot-large-regression.py'),'unused','--validate-only'],check=True)
review=json.loads((base/'large-regression-review.json').read_text());assert review['status']=='not_reproduced_consistently'
assert review['shader_report_sha256']==hashlib.sha256((base/'shader-identity/report.json').read_bytes()).hexdigest()
assert review['comparison_sha256']==hashlib.sha256((root/'benchmarks/rtx4070-connected-scheduling-large-check-2026-09-25.json').read_bytes()).hexdigest()
for case in ['graph_mutations_match_canonical','graph_density_status','color_tail_tests','appended_extent_tests','destroy_and_reuse_slots']:
 results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',(base/('cache-off-'+case+'.log')).read_text());assert results and all(int(ok)>0 and int(fail)==0 for ok,fail in results)
r=json.loads((base/'recordings-validation.json').read_text());assert len(r)==19 and all(v['frames']==300 and v['different_frames']==0 for v in r.values())
build=json.loads((base/'qualification-build.json').read_text())
for name,h in build['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
for name,h in build['binaries'].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h
files={}
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.log','.py','.wgsl','.patch','.md','.png','.svg','.rs'] and '__pycache__' not in p.parts:
  files[str(p.relative_to(root))]=p.read_bytes()
for p in (root/'scripts').iterdir():
 if p.suffix in ['.py','.sh','.ts']:files['scripts/'+p.name]=p.read_bytes()
for p in (root/'benchmarks').glob('rtx4070-connected-scheduling-*.json'):files[str(p.relative_to(root))]=p.read_bytes()
files['changes-from-c46b81e2.patch']=subprocess.check_output(['git','diff','c46b81e2','--','src','shaders','scripts','README.md'],cwd=root)
for name in build['sources']:files['candidate-sources/'+name]=(root/name).read_bytes()
for label in ['000-box3d-cpu','2026-09-25-small-scene-after','2026-09-25-connected-scheduling-after']:
 for p in (root/'recordings/snapshots'/label).glob('*.json'):files[str(p.relative_to(root))]=p.read_bytes()
files['REPRODUCE.md']=b'''# Connected-scene scheduling qualification, 2026-09-25

RTX 4070 Laptop / Ryzen 9 8945HS; baseline c46b81e2. Candidate source hashes
and binary SHA-256 identities are in qualification-build.json. The included
changes-from-c46b81e2.patch uses repository-relative paths. Runtime git/source
fields identify the checkout during measurement, not the frozen executable.
Binaries, caches and MP4s are excluded; recording identities and decoded-frame
comparisons are included. Earlier charts/evidence remain separate history.

Extract into an empty directory. Verify SHA256SUMS.json against every payload.
Revalidate the raw grids without GPU or matplotlib:

    python3 scripts/plot-small-scene.py artifacts/connected-scheduling/qualification-physics unused --title validation --validate-only
    python3 scripts/plot-small-scene.py artifacts/connected-scheduling/qualification-renderers unused --title validation --validate-only --renderers

The initial 100k slowdown triggered nine balanced baseline/register-only/adaptive
follow-up runs. Both rounds are retained. Revalidate their raw hashes with:

    python3 artifacts/connected-scheduling/plot-large-regression.py unused --validate-only

The shader-identity report uses the actual viewer Cargo dependency fingerprint
for Naga, including island and mesh overrides. The exploratory report used a
different dependency and is superseded by report.json. The included emitter
source and run.py reproduce the comparison after rebuilding the dependency.

Install matplotlib, omit --validate-only and provide an output prefix to regenerate
charts. Shading is the full trial range, not confidence intervals. p50/p95 are
medians of per-trial percentiles. Phase timestamps overlap host work and are not
an additive completed-step decomposition. Headline GPU runs retain ordinary
phase timestamps; extra host/broadphase instrumentation is disabled.

Hardware replication: build both source revisions with scripts/build-native-cache.sh
build --release. For Sokol, also build --features external-c-shim and the samples_gpu
CMake target. Freeze binaries and update paths/hashes in the included runners.
Use fresh output directories. Both variants use global solving, automatic color
prefix and global replay enabled. Four substeps, dt=1/60, no sleep, 90 warmup +
240 timed steps, eight CPU workers. Three alternating before/after/CPU trials.
Normal desktop load; no idle gate. Renderer runs use the recorded Xvfb configuration,
NVIDIA hardware and matched actual viewport/settings. Their FPS describes this
display setup and is distinct from physics-only completed steps per second.

275 native-cache tests passed across two invocations: the NVIDIA-only invocation
passed 274, with the cross-adapter test failing because its AMD destination was
hidden by VK_DRIVER_FILES. Retained failure log plus successful exact test rerun
with VK_DRIVER_FILES/VK_ICD_FILENAMES unset document that environment correction.
Cache-off logs cover mutation/switching, stale hints, color tails and growth/reuse.
No test thresholds were weakened. Pilot and rejected-prototype data are diagnostic,
not extra qualification trials. CHECKPOINT.md/CONTINUE.md are historical notes.
'''
manifest={k:hashlib.sha256(v).hexdigest() for k,v in files.items()};files['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'benchmarks/rtx4070-connected-scheduling-2026-09-25-raw.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;t.addfile(info,io.BytesIO(data))
out.with_suffix(out.suffix+'.sha256').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print('Packaged',len(files),'files;',out.stat().st_size,'bytes')
