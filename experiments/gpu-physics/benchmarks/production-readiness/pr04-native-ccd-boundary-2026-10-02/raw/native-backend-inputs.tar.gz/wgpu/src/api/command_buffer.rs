use crate::*;

/// Handle to a command buffer on the GPU.
///
/// A `CommandBuffer` represents a complete sequence of commands that may be submitted to a command
/// queue with [`Queue::submit`]. A `CommandBuffer` is obtained by recording a series of commands to
/// a [`CommandEncoder`] and then calling [`CommandEncoder::finish`].
///
/// Corresponds to [WebGPU `GPUCommandBuffer`](https://gpuweb.github.io/gpuweb/#command-buffer).
#[derive(Debug)]
pub struct CommandBuffer {
    pub(crate) buffer: dispatch::DispatchCommandBuffer,
}
#[cfg(send_sync)]
static_assertions::assert_impl_all!(CommandBuffer: Send, Sync);

impl CommandBuffer {
    #[cfg(custom)]
    /// Returns custom implementation of CommandBuffer (if custom backend and is internally T)
    pub fn as_custom<T: custom::CommandBufferInterface>(&self) -> Option<&T> {
        self.buffer.as_custom()
    }
}

#[cfg(wgpu_core)]
pub struct NativePhysicsReplay(pub(crate) std::sync::Arc<wgc::command::NativePhysicsReplay>);
impl CommandBuffer {
    /// Isolated unsafe native API. The recording must satisfy the private backend's reusable-buffer contract.
    #[cfg(wgpu_core)]
    pub unsafe fn native_physics_capture(self)->NativePhysicsReplay {
        let core=self.buffer.as_core_opt().expect("native backend");
        NativePhysicsReplay(unsafe{core.context.native_physics_capture(core)})
    }
}
