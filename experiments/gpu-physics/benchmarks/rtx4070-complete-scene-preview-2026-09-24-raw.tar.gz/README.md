# Complete-scene preview through 50,000 cubes

This is a frozen prefix of the ongoing larger-count sweep: 288 trials, six modes,
three fresh-world trials per count. It does not establish final 10 FPS limits.
The manifest records measured binary identities, environment and settings.
The measured-source patch is distinct from later chart postprocessing changes.

With Python and matplotlib installed, from the extracted archive root:

```sh
python scripts/plot-falling-cubes.py preview-50k reproduced --title 'RTX 4070 Laptop / Ryzen 9 8945HS • driver 610.57.04' --scope-note 'Preview through 50,000 cubes; higher counts still running'
```

The plotter revalidates raw measurements against stored per-trial summaries.
Compare reproduced.json with report.json. CPU uses eight workers; sleeping is off;
90 warmup and 240 measured steps with four substeps and dt 1/60 second.
Application framebuffer is 2040x1148. Trial variability is retained.
